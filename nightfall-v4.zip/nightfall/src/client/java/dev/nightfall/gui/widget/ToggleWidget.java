package dev.nightfall.gui.widget;

import dev.nightfall.gui.ThemeManager;
import dev.nightfall.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class ToggleWidget extends Widget {
    private final Module module;

    public ToggleWidget(Module module, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.module = module;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int color = module.isEnabled() ? ThemeManager.ACCENT : (isHovered(mouseX, mouseY) ? ThemeManager.HOVER : ThemeManager.PANEL_BG);
        g.fill(x, y, x + width, y + height, color);
        g.drawString(Minecraft.getInstance().font, module.getName(), x + 6, y + 4, 0xFFFFFFFF);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isHovered(mouseX, mouseY) && button == 0) {
            module.toggle();
            return true;
        }
        return false;
    }
}