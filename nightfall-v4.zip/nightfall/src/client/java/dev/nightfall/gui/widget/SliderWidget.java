package dev.nightfall.gui.widget;

import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class SliderWidget extends Widget {
    private final Setting.DoubleSetting setting;
    private boolean dragging = false;

    public SliderWidget(Setting.DoubleSetting setting, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.setting = setting;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        double min = setting.getMin();
        double max = setting.getMax();
        double val = setting.getValue();
        
        float percent = (float) ((val - min) / (max - min));
        int fillWidth = (int) (width * percent);

        // Фон
        g.fill(x, y, x + width, y + height, 0xFF15151C);
        // Заполнение
        g.fill(x, y, x + fillWidth, y + height, 0xFF7C5CFF);
        
        // Текст
        String text = setting.getName() + ": " + String.format("%.2f", val);
        g.drawString(Minecraft.getInstance().font, text, x + 4, y + 3, 0xFFFFFFFF);

        if (dragging) {
            double mousePercent = Mth.clamp((mouseX - x) / (double) width, 0, 1);
            double newValue = min + (max - min) * mousePercent;
            setting.setValue(newValue);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (isHovered(mouseX, mouseY) && button == 0) {
            dragging = true;
            return true;
        }
        return false;
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
    }
}