package dev.nightfall.gui.widget;

import net.minecraft.client.gui.GuiGraphics;

public abstract class Widget {
    protected int x, y, width, height;

    public Widget(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public abstract void render(GuiGraphics g, int mouseX, int mouseY, float partialTick);
    public abstract boolean mouseClicked(double mouseX, double mouseY, int button);
    public void mouseReleased(double mouseX, double mouseY, int button) {}

    public boolean isHovered(double mx, double my) {
        return mx >= x && mx <= x + width && my >= y && my <= y + height;
    }
}