package dev.nightfall.gui;

import dev.nightfall.NightfallClient;
import dev.nightfall.gui.widget.SliderWidget;
import dev.nightfall.gui.widget.ToggleWidget;
import dev.nightfall.gui.widget.Widget;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class ClickGUI extends Screen {
    private Category selected = Category.COMBAT;
    private Module expandedModule = null;
    private final List<Widget> activeWidgets = new ArrayList<>();

    public ClickGUI() {
        super(Component.literal("Nightfall"));
    }

    public static void open() {
        Minecraft.getInstance().setScreen(new ClickGUI());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        g.fill(0, 0, this.width, this.height, ThemeManager.BG_DARK);

        // Левая панель (Категории)
        int px = 40, py = 40, pw = 140, ph = this.height - 80;
        g.fill(px, py, px + pw, py + ph, ThemeManager.PANEL_BG);

        int y = py + 10;
        for (Category c : Category.values()) {
            boolean sel = c == selected;
            g.fill(px + 5, y, px + pw - 5, y + 18, sel ? ThemeManager.ACCENT : (isHovered(mouseX, mouseY, px + 5, y, pw - 10, 18) ? ThemeManager.HOVER : ThemeManager.PANEL_BG));
            g.drawString(this.font, c.getDisplayName(), px + 10, y + 5, sel ? ThemeManager.TEXT_WHITE : ThemeManager.TEXT_GRAY);
            y += 22;
        }

        // Кнопки внизу левой панели
        int btnY = py + ph - 50;
        
        // HUD Editor
        g.fill(px, btnY, px + pw, btnY + 20, isHovered(mouseX, mouseY, px, btnY, pw, 20) ? ThemeManager.HOVER : ThemeManager.PANEL_BG);
        g.drawString(this.font, "HUD Editor", px + 10, btnY + 6, ThemeManager.ACCENT);

        // Theme Editor
        g.fill(px, btnY + 25, px + pw, btnY + 45, isHovered(mouseX, mouseY, px, btnY + 25, pw, 20) ? ThemeManager.HOVER : ThemeManager.PANEL_BG);
        g.drawString(this.font, "Theme Studio", px + 10, btnY + 31, ThemeManager.ACCENT);

        // Правая панель (Модули)
        int cx = px + pw + 10, cy = py, cw = 220;
        g.fill(cx, cy, cx + cw, cy + ph, ThemeManager.PANEL_BG);
        g.drawString(this.font, selected.getDisplayName().toUpperCase(), cx + 10, cy + 10, ThemeManager.ACCENT);

        activeWidgets.clear();
        int listY = cy + 30;
        List<Module> mods = NightfallClient.getInstance().moduleManager.getByCategory(selected);
        
        for (Module m : mods) {
            ToggleWidget toggle = new ToggleWidget(m, cx + 5, listY, cw - 10, 16);
            toggle.render(g, mouseX, mouseY, partial);
            activeWidgets.add(toggle);
            listY += 20;

            if (expandedModule == m) {
                for (Setting<?> s : m.settings) {
                    if (s instanceof Setting.DoubleSetting ds) {
                        SliderWidget slider = new SliderWidget(ds, cx + 15, listY, cw - 30, 16);
                        slider.render(g, mouseX, mouseY, partial);
                        activeWidgets.add(slider);
                        listY += 20;
                    }
                }
            }
        }

        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int px = 40, py = 40, pw = 140, ph = this.height - 80;
        int btnY = py + ph - 50;

        // Клик по HUD Editor
        if (isHovered(mx, my, px, btnY, pw, 20)) {
            Minecraft.getInstance().setScreen(new HudEditorScreen());
            return true;
        }

        // Клик по Theme Studio
        if (isHovered(mx, my, px, btnY + 25, pw, 20)) {
            Minecraft.getInstance().setScreen(new ThemeScreen());
            return true;
        }

        // Клик по категории
        int y = py + 10;
        for (Category c : Category.values()) {
            if (isHovered(mx, my, px + 5, y, pw - 10, 18)) {
                selected = c;
                expandedModule = null;
                return true;
            }
            y += 22;
        }

        for (Widget w : activeWidgets) {
            if (w.mouseClicked(mx, my, button)) return true;
        }

        int cx = px + pw + 10, listY = py + 30;
        List<Module> mods = NightfallClient.getInstance().moduleManager.getByCategory(selected);
        for (Module m : mods) {
            if (isHovered(mx, my, cx + 5, listY, 210, 16)) {
                if (button == 1) {
                    expandedModule = (expandedModule == m) ? null : m;
                }
                return true;
            }
            listY += 20;
            if (expandedModule == m) {
                for (Setting<?> s : m.settings) {
                    if (s instanceof Setting.DoubleSetting) listY += 20;
                }
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        for (Widget w : activeWidgets) w.mouseReleased(mx, my, button);
        return super.mouseReleased(mx, my, button);
    }

    private boolean isHovered(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}