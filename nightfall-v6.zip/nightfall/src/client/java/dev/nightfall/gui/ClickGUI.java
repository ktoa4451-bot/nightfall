package dev.nightfall.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nightfall.NightfallClient;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Module menu with the same kind of settings control as the Ghostline menu: left click toggles a module, right click opens its settings
 * (switches, sliders for decimals and whole numbers, keybind, reset), the mouse wheel scrolls, the description of the module under the
 * cursor is shown at the bottom. Changes are saved when the menu closes.
 */
public class ClickGUI extends Screen {
    private enum Kind { MODULE, BOOL, DOUBLE, INT, BIND, RESET }

    private static final class Row {
        final Kind kind; final Module module; final Setting<?> setting; final int y, h;
        Row(Kind kind, Module module, Setting<?> setting, int y, int h) { this.kind = kind; this.module = module; this.setting = setting; this.y = y; this.h = h; }
    }

    private Category selected = Category.COMBAT;
    private Module expanded;
    private Module listening;      // module whose keybind is being set
    private Row dragging;
    private int scroll;
    private int contentH;

    public ClickGUI() { super(Component.literal("Nightfall")); }

    public static void open() { Minecraft.getInstance().setScreen(new ClickGUI()); }

    // ------------------------------------------------------------------ layout

    private int px() { return 40; }
    private int py() { return 40; }
    private int pw() { return 140; }
    private int ph() { return this.height - 80; }
    private int cx() { return px() + pw() + 10; }
    private int cw() { return Math.max(180, Math.min(340, this.width - cx() - 30)); }
    private int top() { return py() + 30; }
    private int bottom() { return py() + ph() - 22; }

    private List<Row> layout() {
        List<Row> rows = new ArrayList<>();
        int y = top() - scroll;
        for (Module m : NightfallClient.getInstance().moduleManager.getByCategory(selected)) {
            rows.add(new Row(Kind.MODULE, m, null, y, 18)); y += 20;
            if (m != expanded) continue;
            for (Setting<?> s : m.settings) {
                Kind k = s instanceof Setting.BooleanSetting ? Kind.BOOL : s instanceof Setting.DoubleSetting ? Kind.DOUBLE : s instanceof Setting.IntSetting ? Kind.INT : null;
                if (k == null) continue;
                rows.add(new Row(k, m, s, y, 16)); y += 18;
            }
            rows.add(new Row(Kind.BIND, m, null, y, 16)); y += 18;
            rows.add(new Row(Kind.RESET, m, null, y, 16)); y += 20;
        }
        contentH = y + scroll - top();
        return rows;
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }

    private static String keyName(int key) {
        if (key < 0) return "none";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RShift";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LShift";
        try { return InputConstants.Type.KEYSYM.getOrCreate(key).getName().replace("key.keyboard.", "").replace("key.mouse.", "mouse ").toUpperCase(Locale.ROOT); }
        catch (RuntimeException e) { return "key " + key; }
    }

    // ------------------------------------------------------------------ drawing

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        g.fill(0, 0, this.width, this.height, ThemeManager.BG_DARK);
        int px = px(), py = py(), pw = pw(), ph = ph();
        g.fill(px, py, px + pw, py + ph, ThemeManager.PANEL_BG);

        int y = py + 10;
        for (Category c : Category.values()) {
            boolean sel = c == selected;
            int n = NightfallClient.getInstance().moduleManager.getByCategory(c).size();
            g.fill(px + 5, y, px + pw - 5, y + 18, sel ? ThemeManager.ACCENT : (in(mouseX, mouseY, px + 5, y, pw - 10, 18) ? ThemeManager.HOVER : ThemeManager.PANEL_BG));
            g.drawString(this.font, c.getDisplayName() + " (" + n + ")", px + 10, y + 5, sel ? ThemeManager.TEXT_WHITE : ThemeManager.TEXT_GRAY);
            y += 22;
        }
        int btnY = py + ph - 50;
        g.fill(px, btnY, px + pw, btnY + 20, in(mouseX, mouseY, px, btnY, pw, 20) ? ThemeManager.HOVER : ThemeManager.PANEL_BG);
        g.drawString(this.font, "HUD Editor", px + 10, btnY + 6, ThemeManager.ACCENT);
        g.fill(px, btnY + 25, px + pw, btnY + 45, in(mouseX, mouseY, px, btnY + 25, pw, 20) ? ThemeManager.HOVER : ThemeManager.PANEL_BG);
        g.drawString(this.font, "Theme Studio", px + 10, btnY + 31, ThemeManager.ACCENT);

        int cx = cx(), cw = cw();
        g.fill(cx, py, cx + cw, py + ph, ThemeManager.PANEL_BG);
        g.drawString(this.font, selected.getDisplayName().toUpperCase(Locale.ROOT), cx + 10, py + 10, ThemeManager.ACCENT);
        g.drawString(this.font, "LMB switch  RMB settings  wheel scroll", cx + 10, py + 20, ThemeManager.TEXT_GRAY);

        List<Row> rows = layout();
        int maxScroll = Math.max(0, contentH - (bottom() - top()));
        scroll = Mth.clamp(scroll, 0, maxScroll);
        String tip = null;
        g.enableScissor(cx + 2, top(), cx + cw - 2, bottom());
        for (Row r : rows) {
            if (r.y + r.h < top() || r.y > bottom()) continue;
            int x = cx + 5, w = cw - 10;
            boolean hov = in(mouseX, mouseY, x, r.y, w, r.h) && mouseY >= top() && mouseY <= bottom();
            switch (r.kind) {
                case MODULE -> {
                    g.fill(x, r.y, x + w, r.y + r.h, r.module.isEnabled() ? ThemeManager.ACCENT : (hov ? ThemeManager.HOVER : ThemeManager.BG_DARK));
                    g.drawString(this.font, r.module.getName(), x + 6, r.y + 5, ThemeManager.TEXT_WHITE);
                    String right = (r.module.getKeyBind() >= 0 ? "[" + keyName(r.module.getKeyBind()) + "] " : "") + (expanded == r.module ? "v" : ">");
                    g.drawString(this.font, right, x + w - 6 - this.font.width(right), r.y + 5, r.module.isEnabled() ? ThemeManager.TEXT_WHITE : ThemeManager.TEXT_GRAY);
                    if (hov) tip = r.module.getDescription();
                }
                case BOOL -> {
                    boolean v = (Boolean) r.setting.getValue();
                    g.fill(x + 10, r.y, x + w, r.y + r.h, hov ? ThemeManager.HOVER : ThemeManager.BG_DARK);
                    g.drawString(this.font, r.setting.getName(), x + 16, r.y + 4, ThemeManager.TEXT_WHITE);
                    g.fill(x + w - 26, r.y + 3, x + w - 6, r.y + 13, v ? ThemeManager.ACCENT : ThemeManager.HOVER);
                    g.fill(v ? x + w - 16 : x + w - 26, r.y + 3, v ? x + w - 6 : x + w - 16, r.y + 13, ThemeManager.TEXT_WHITE);
                }
                case DOUBLE, INT -> {
                    double min, max, val;
                    if (r.setting instanceof Setting.DoubleSetting ds) { min = ds.getMin(); max = ds.getMax(); val = ds.getValue(); }
                    else { Setting.IntSetting is = (Setting.IntSetting) r.setting; min = is.getMin(); max = is.getMax(); val = is.getValue(); }
                    int sw = w - 10;
                    g.fill(x + 10, r.y, x + 10 + sw, r.y + r.h, ThemeManager.BG_DARK);
                    g.fill(x + 10, r.y, x + 10 + (int) (sw * Mth.clamp((val - min) / Math.max(1e-9, max - min), 0, 1)), r.y + r.h, ThemeManager.ACCENT);
                    String t = r.setting.getName() + ": " + (r.kind == Kind.INT ? String.valueOf((int) val) : String.format(Locale.ROOT, "%.2f", val));
                    g.drawString(this.font, t, x + 16, r.y + 4, ThemeManager.TEXT_WHITE);
                }
                case BIND -> {
                    g.fill(x + 10, r.y, x + w, r.y + r.h, listening == r.module ? ThemeManager.ACCENT : (hov ? ThemeManager.HOVER : ThemeManager.BG_DARK));
                    String t = listening == r.module ? "Press a key (Esc cancel, Backspace clear)" : "Keybind: " + keyName(r.module.getKeyBind());
                    g.drawString(this.font, t, x + 16, r.y + 4, ThemeManager.TEXT_WHITE);
                }
                case RESET -> {
                    g.fill(x + 10, r.y, x + w, r.y + r.h, hov ? ThemeManager.HOVER : ThemeManager.BG_DARK);
                    g.drawString(this.font, "Reset to defaults", x + 16, r.y + 4, ThemeManager.TEXT_GRAY);
                }
            }
        }
        g.disableScissor();
        // scroll bar
        if (maxScroll > 0) {
            int trackH = bottom() - top(), barH = Math.max(16, trackH * trackH / Math.max(trackH, contentH));
            int barY = top() + (int) ((trackH - barH) * (scroll / (double) maxScroll));
            g.fill(cx + cw - 4, barY, cx + cw - 2, barY + barH, ThemeManager.ACCENT);
        }
        if (tip != null) g.drawString(this.font, tip, cx + 10, py + ph - 14, ThemeManager.TEXT_GRAY);
        super.render(g, mouseX, mouseY, partial);
    }

    // ------------------------------------------------------------------ input

    private boolean rightButton() {
        long win = GLFW.glfwGetCurrentContext();
        return win != 0 && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
    }

    private void setSlider(Row r, double mx) {
        int sw = cw() - 10 - 10;
        double pct = Mth.clamp((mx - (cx() + 5 + 10)) / sw, 0, 1);
        if (r.setting instanceof Setting.DoubleSetting ds) {
            double v = ds.getMin() + (ds.getMax() - ds.getMin()) * pct;
            ds.setValue(Math.round(v * 100.0) / 100.0);
        } else if (r.setting instanceof Setting.IntSetting is) {
            is.setValue((int) Math.round(is.getMin() + (is.getMax() - is.getMin()) * pct));
        }
    }

    @SuppressWarnings("unchecked")
    private static void reset(Module m) {
        for (Setting<?> s : m.settings) ((Setting<Object>) s).setValue(s.getDefaultValue());
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        boolean right = rightButton();
        listening = (listening != null && !in(mx, my, cx(), top(), cw(), bottom() - top())) ? null : listening;
        int px = px(), py = py(), pw = pw(), ph = ph(), btnY = py + ph - 50;
        if (in(mx, my, px, btnY, pw, 20)) { Minecraft.getInstance().setScreen(new HudEditorScreen()); return true; }
        if (in(mx, my, px, btnY + 25, pw, 20)) { Minecraft.getInstance().setScreen(new ThemeScreen()); return true; }
        int y = py + 10;
        for (Category c : Category.values()) {
            if (in(mx, my, px + 5, y, pw - 10, 18)) { selected = c; expanded = null; scroll = 0; listening = null; return true; }
            y += 22;
        }
        if (my < top() || my > bottom()) return super.mouseClicked(event, doubleClick);
        int x = cx() + 5, w = cw() - 10;
        for (Row r : layout()) {
            if (!in(mx, my, x, r.y, w, r.h)) continue;
            switch (r.kind) {
                case MODULE -> { if (right) { expanded = expanded == r.module ? null : r.module; listening = null; } else r.module.toggle(); }
                case BOOL -> { @SuppressWarnings("unchecked") Setting<Boolean> b = (Setting<Boolean>) r.setting; b.setValue(!b.getValue()); }
                case DOUBLE, INT -> { dragging = r; setSlider(r, mx); }
                case BIND -> listening = listening == r.module ? null : r.module;
                case RESET -> reset(r.module);
            }
            return true;
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging != null) { setSlider(dragging, event.x()); return true; }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scroll = Mth.clamp(scroll - (int) (scrollY * 18), 0, Math.max(0, contentH - (bottom() - top())));
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listening != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) listening.setKeyBind(key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? -1 : key);
            listening = null;
            return true;                       // the key press belongs to the bind, Esc only cancels the bind
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        try { NightfallClient.getInstance().configManager.save("default"); } catch (RuntimeException ignored) { }
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
