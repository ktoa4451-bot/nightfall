package dev.nightfall.hud;

import dev.nightfall.hud.element.*;
import dev.nightfall.render.HoleEsp;
import dev.nightfall.render.ItemEsp;
import dev.nightfall.render.PlayerEsp;
import dev.nightfall.render.PvpOverlay;
import dev.nightfall.render.WaypointOverlay;
import dev.nightfall.render.XrayEsp;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class HudManager {
    public void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("nightfall", "keystrokes"),
                new KeystrokesElement()
        );
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("nightfall", "cps"),
                new CpsElement()
        );

        // ESP and world overlays drawn on the screen (they are visible through walls)
        overlay("item_esp", (g, dt) -> ItemEsp.render(g, Minecraft.getInstance(), dt.getGameTimeDeltaPartialTick(true)));
        overlay("pvp_overlay", (g, dt) -> PvpOverlay.render(g, Minecraft.getInstance(), dt.getGameTimeDeltaPartialTick(true)));
        overlay("xray_esp", (g, dt) -> XrayEsp.render(g, Minecraft.getInstance(), dt.getGameTimeDeltaPartialTick(true)));
    }

    private static void overlay(String id, net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement e) {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.fromNamespaceAndPath("nightfall", id), e);
    }
}
