package dev.nightfall.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nightfall.NightfallClient;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.util.Anim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Module menu in the "sidebar + cards" style: a dark translucent panel, a sidebar with the categories and tools
 * (Configs, HUD, Theme, Search), a search field, and the modules as two columns of cards with animated switches.
 * Settings unfold inside the card (switches, sliders, keybind, reset).
 * Click a card to switch the module, click the arrow (or right click) to open its settings. Saved when the menu closes.
 */
public class ClickGUI extends Screen {
    private enum Kind { MODULE, BOOL, DOUBLE, INT, MODE, KEY, TEXT, BIND, RESET }

    private static final int NAV_CATEGORY = 0, NAV_CLASSIC = 1, NAV_HUD = 2, NAV_THEME = 3, NAV_SEARCH = 4;

    private record Nav(String label, Category cat, int type, int y) { }

    private static final class Row {
        final Kind kind; final Module module; final Setting<?> setting;
        final int x, y, w, h, clipTop, clipBottom, cardH;
        Row(Kind kind, Module module, Setting<?> setting, int x, int y, int w, int h, int clipTop, int clipBottom, int cardH) {
            this.kind = kind; this.module = module; this.setting = setting;
            this.x = x; this.y = y; this.w = w; this.h = h;
            this.clipTop = clipTop; this.clipBottom = clipBottom; this.cardH = cardH;
        }
    }

    private static final int HEAD = 22, GAP = 6, SIDE = 112, SEARCH_W = 110;
    private static final Object SEARCH_KEY = new Object();
    private static final int GRAY_DIM = 0xFF6C6C7C;

    private Category selected = Category.COMBAT;      // null = All
    private final Set<Module> open = Collections.newSetFromMap(new IdentityHashMap<>());
    private Module listening;
    private Setting<?> listeningKey;     // key setting waiting for a key press
    private Setting.TextSetting editing; // text setting being typed into
    private Row dragging;
    private boolean searchFocus;
    private String query = "";
    private int contentH;
    private float scroll, scrollTarget, openT;
    private long last = System.nanoTime();
    private final Map<Object, Float> hover = new IdentityHashMap<>();
    private final Map<Module, Float> expandT = new IdentityHashMap<>();
    private final Map<Module, Float> enableT = new IdentityHashMap<>();
    private final Map<Setting<?>, Float> switchT = new IdentityHashMap<>();
    private final Map<Module, Object> bindKeys = new IdentityHashMap<>();

    private Object bindKey(Module m) { return bindKeys.computeIfAbsent(m, x -> new Object()); }

    public ClickGUI() { super(Component.literal("Nightfall")); }

    public static void open() { Minecraft.getInstance().setScreen(new ClickGUI()); }

    // ------------------------------------------------------------------ geometry

    private int ww() { return Math.min(540, this.width - 24); }
    private int wh() { return Math.min(330, this.height - 24); }
    private int wx() { return (this.width - ww()) / 2; }
    private int wy() { return (this.height - wh()) / 2 + (int) ((1f - Anim.easeOutCubic(openT)) * 14f); }
    private int itemH() { return Mth.clamp((wh() - 88) / 11, 11, 18); }
    private int top() { return wy() + 36; }
    private int bottom() { return wy() + wh() - 22; }
    private int cx() { return wx() + SIDE + 10; }
    private int cw() { return ww() - SIDE - 24; }
    private int searchX() { return wx() + ww() - 10 - SEARCH_W; }
    private int searchY() { return wy() + 9; }
    private int settingsLabelY() { return wy() + 46 + itemH() * (1 + Category.values().length) + 4; }

    private List<Nav> navItems() {
        List<Nav> l = new ArrayList<>();
        int ih = itemH(), y = wy() + 46;
        l.add(new Nav("All", null, NAV_CATEGORY, y)); y += ih;
        for (Category c : Category.values()) { l.add(new Nav(c.getDisplayName(), c, NAV_CATEGORY, y)); y += ih; }
        y = settingsLabelY() + 12;
        l.add(new Nav("HUD", null, NAV_HUD, y)); y += ih;
        l.add(new Nav("Theme", null, NAV_THEME, y)); y += ih;
        l.add(new Nav("Classic", null, NAV_CLASSIC, y));
        l.add(new Nav("Search", null, NAV_SEARCH, wy() + wh() - ih - 8));
        return l;
    }

    private static int rowH(Kind k) {
        return switch (k) { case DOUBLE, INT -> 24; case BOOL, BIND, MODE, KEY, TEXT -> 18; default -> 20; };
    }

    private static List<Setting<?>> shown(Module m) {
        List<Setting<?>> out = new ArrayList<>();
        out.addAll(m.settings);
        return out;
    }

    private static Kind kindOf(Setting<?> s) {
        if (s instanceof Setting.BooleanSetting) return Kind.BOOL;
        if (s instanceof Setting.DoubleSetting) return Kind.DOUBLE;
        if (s instanceof Setting.ModeSetting) return Kind.MODE;
        if (s instanceof Setting.KeySetting) return Kind.KEY;
        if (s instanceof Setting.TextSetting) return Kind.TEXT;
        return Kind.INT;
    }

    private static int fullH(Module m) {
        int h = 4;
        for (Setting<?> s : shown(m)) h += rowH(kindOf(s));
        return h + rowH(Kind.BIND) + rowH(Kind.RESET);
    }

    private List<Module> visibleModules() {
        String q = query.trim().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<>();
        for (Module m : NightfallClient.getInstance().moduleManager.getModules()) {
            if (!q.isEmpty()) { if (m.getName().toLowerCase(Locale.ROOT).contains(q)) out.add(m); }
            else if (selected == null || m.getCategory() == selected) out.add(m);
        }
        return out;
    }

    private List<Row> layout() {
        List<Row> rows = new ArrayList<>();
        int cols = cw() >= 250 ? 2 : 1;
        int colW = (cw() - GAP * (cols - 1)) / cols;
        int[] colY = new int[cols];
        int idx = 0;
        for (Module m : visibleModules()) {
            int c = idx++ % cols;
            int x = cx() + c * (colW + GAP);
            int y = top() - (int) scroll + colY[c];
            float t = Anim.easeOutCubic(expandT.getOrDefault(m, 0f));
            int vis = (int) (fullH(m) * t);
            int cardH = HEAD + vis;
            rows.add(new Row(Kind.MODULE, m, null, x, y, colW, HEAD, y, y + HEAD, cardH));
            if (t > 0.001f) {
                int ry = y + HEAD + 2;
                for (Setting<?> s : shown(m)) {
                    Kind k = kindOf(s);
                    rows.add(new Row(k, m, s, x + 6, ry, colW - 12, rowH(k), y + HEAD, y + cardH, 0));
                    ry += rowH(k);
                }
                rows.add(new Row(Kind.BIND, m, null, x + 6, ry, colW - 12, rowH(Kind.BIND), y + HEAD, y + cardH, 0)); ry += rowH(Kind.BIND);
                rows.add(new Row(Kind.RESET, m, null, x + 6, ry, colW - 12, rowH(Kind.RESET), y + HEAD, y + cardH, 0));
            }
            colY[c] += cardH + GAP;
        }
        int mx = 0;
        for (int v : colY) mx = Math.max(mx, v);
        contentH = mx;
        return rows;
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }

    private static String keyName(int key) {
        if (key < 0) return "none";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        try { return InputConstants.Type.KEYSYM.getOrCreate(key).getName().replace("key.keyboard.", "").replace("key.mouse.", "mouse ").toUpperCase(Locale.ROOT); }
        catch (RuntimeException e) { return "KEY " + key; }
    }

    // ------------------------------------------------------------------ drawing helpers

    private float anim(Map<Object, Float> m, Object k, float target, float dt, float speed) {
        float v = Anim.approach(m.getOrDefault(k, 0f), target, dt, speed);
        m.put(k, v);
        return v;
    }

    private float anim2(Map<Module, Float> m, Module k, float target, float dt, float speed) {
        float v = Anim.approach(m.getOrDefault(k, 0f), target, dt, speed);
        m.put(k, v);
        return v;
    }

    /** Rounded fill (2 px corners). The pieces do not overlap, so translucent colours stay even. */
    private static void rr(GuiGraphics g, int x, int y, int w, int h, int col) {
        if (w < 5 || h < 5) { g.fill(x, y, x + w, y + h, col); return; }
        g.fill(x + 2, y, x + w - 2, y + 1, col);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, col);
        g.fill(x, y + 2, x + w, y + h - 2, col);
        g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, col);
        g.fill(x + 2, y + h - 1, x + w - 2, y + h, col);
    }

    /** Rounded fill with bigger (3 px) corners, for the main panel. */
    private static void rr3(GuiGraphics g, int x, int y, int w, int h, int col) {
        if (w < 8 || h < 8) { rr(g, x, y, w, h, col); return; }
        g.fill(x + 3, y, x + w - 3, y + 1, col);
        g.fill(x + 1, y + 1, x + w - 1, y + 3, col);
        g.fill(x, y + 3, x + w, y + h - 3, col);
        g.fill(x + 1, y + h - 3, x + w - 1, y + h - 1, col);
        g.fill(x + 3, y + h - 1, x + w - 3, y + h, col);
    }

    private void pill(GuiGraphics g, int x, int y, float on, float a) {
        int w = 26, h = 12;
        rr(g, x, y, w, h, Anim.fade(Anim.mix(0xFF2C2C3A, ThemeManager.ACCENT, on), a));
        int kx = x + 2 + (int) ((w - h) * on);
        rr(g, kx, y + 2, 8, 8, Anim.fade(Anim.mix(0xFFB8B8C8, 0xFFFFFFFF, on), a));
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        openT = Anim.approach(openT, 1f, dt, 14f);
        float a = Anim.easeOutCubic(openT);
        scroll = Anim.approach(scroll, scrollTarget, dt, 18f);

        g.fill(0, 0, this.width, this.height, ((int) (0xA0 * a) << 24) | 0x04040A);
        int wx = wx(), wy = wy(), ww = ww(), wh = wh();

        // panel, 1 px outline, sidebar divider
        rr3(g, wx, wy, ww, wh, Anim.fade(0xE00D0D12, a));
        int line = Anim.fade(0x30FFFFFF, a);
        g.fill(wx + 3, wy, wx + ww - 3, wy + 1, line);
        g.fill(wx + 3, wy + wh - 1, wx + ww - 3, wy + wh, line);
        g.fill(wx, wy + 3, wx + 1, wy + wh - 3, line);
        g.fill(wx + ww - 1, wy + 3, wx + ww, wy + wh - 3, line);
        g.fill(wx + SIDE, wy + 8, wx + SIDE + 1, wy + wh - 8, Anim.fade(0x18FFFFFF, a));

        // sidebar: logo, categories, tools
        rr(g, wx + 12, wy + 11, 10, 10, Anim.fade(ThemeManager.ACCENT, a));
        g.drawString(this.font, "Nightfall", wx + 27, wy + 12, Anim.fade(ThemeManager.TEXT_WHITE, a));
        g.drawString(this.font, "Categories", wx + 12, wy + 34, Anim.fade(GRAY_DIM, a));
        g.drawString(this.font, "Settings", wx + 12, settingsLabelY(), Anim.fade(GRAY_DIM, a));
        int ih = itemH();
        for (Nav n : navItems()) {
            boolean sel = n.type() == NAV_CATEGORY ? n.cat() == selected && query.isEmpty() : (n.type() == NAV_SEARCH && searchFocus);
            boolean hv = in(mouseX, mouseY, wx + 8, n.y(), SIDE - 16, ih - 1);
            float h = anim(hover, n.label(), hv || sel ? 1f : 0f, dt, 16f);
            if (h > 0.01f) rr(g, wx + 8, n.y(), SIDE - 16, ih - 1, Anim.fade(Anim.mix(0x00FFFFFF, sel ? 0x26FFFFFF : 0x14FFFFFF, h), a));
            if (sel) g.fill(wx + 8, n.y() + 3, wx + 10, n.y() + ih - 4, Anim.fade(ThemeManager.ACCENT, a));
            int icon = Anim.mix(0xFF4A4A5A, ThemeManager.ACCENT, sel ? 1f : h * 0.5f);
            rr(g, wx + 15, n.y() + (ih - 6) / 2, 6, 6, Anim.fade(icon, a));
            g.drawString(this.font, n.label(), wx + 27, n.y() + (ih - 8) / 2, Anim.fade(Anim.mix(ThemeManager.TEXT_GRAY, ThemeManager.TEXT_WHITE, h), a));
        }

        // header: title and search field
        String title = !query.trim().isEmpty() ? "Search" : selected == null ? "All" : selected.getDisplayName();
        g.drawString(this.font, title, cx(), wy + 13, Anim.fade(ThemeManager.TEXT_WHITE, a));
        int sx = searchX(), sy = searchY();
        boolean shv = in(mouseX, mouseY, sx, sy, SEARCH_W, 16);
        float sh = anim(hover, SEARCH_KEY, shv || searchFocus ? 1f : 0f, dt, 16f);
        rr(g, sx, sy, SEARCH_W, 16, Anim.fade(Anim.mix(0xFF15151C, 0xFF1F1F2B, sh), a));
        if (searchFocus) g.fill(sx + 3, sy + 15, sx + SEARCH_W - 3, sy + 16, Anim.fade(ThemeManager.ACCENT, a));
        if (query.isEmpty() && !searchFocus) {
            g.drawString(this.font, "Search", sx + 6, sy + 4, Anim.fade(GRAY_DIM, a));
        } else {
            String shownText = query;
            while (shownText.length() > 1 && this.font.width(shownText) > SEARCH_W - 16) shownText = shownText.substring(1);
            g.drawString(this.font, shownText, sx + 6, sy + 4, Anim.fade(ThemeManager.TEXT_WHITE, a));
            if (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0) {
                int cxp = sx + 6 + this.font.width(shownText) + 1;
                g.fill(cxp, sy + 3, cxp + 1, sy + 13, Anim.fade(ThemeManager.TEXT_WHITE, a));
            }
        }
        g.fill(cx(), top() - 4, wx + ww - 10, top() - 3, Anim.fade(0x18FFFFFF, a));

        // module cards
        List<Row> rows = layout();
        int viewH = bottom() - top();
        int maxScroll = Math.max(0, contentH - viewH);
        scrollTarget = Mth.clamp(scrollTarget, 0, maxScroll);
        if (scroll > maxScroll) scroll = maxScroll;
        String tip = null;
        g.enableScissor(wx + SIDE + 2, top(), wx + ww - 2, bottom());
        for (Row r : rows) {
            if (r.kind == Kind.MODULE) {
                Module m = r.module;
                float en = anim2(enableT, m, m.isEnabled() ? 1f : 0f, dt, 12f);
                anim2(expandT, m, open.contains(m) ? 1f : 0f, dt, 12f);
                if (r.y + r.cardH < top() || r.y > bottom()) continue;
                boolean hv = in(mouseX, mouseY, r.x, r.y, r.w, HEAD) && mouseY >= top() && mouseY <= bottom();
                float h = anim(hover, m, hv ? 1f : 0f, dt, 16f);
                int bg = Anim.mix(Anim.mix(0xFF16161D, 0xFF1D1D27, h), Anim.mix(0xFF16161D, ThemeManager.ACCENT, 0.16f), en);
                rr(g, r.x, r.y, r.w, r.cardH, Anim.fade(bg, a));
                g.fill(r.x, r.y + 5, r.x + 2, r.y + HEAD - 5, Anim.fade(ThemeManager.ACCENT, a * en));
                g.drawString(this.font, m.getName(), r.x + 9, r.y + 7, Anim.fade(Anim.mix(0xFFC9C9D6, 0xFFFFFFFF, Math.max(h, en)), a));
                int pillX = r.x + r.w - 8 - 26;
                pill(g, pillX, r.y + 5, en, a);
                float ex = expandT.getOrDefault(m, 0f);
                g.drawString(this.font, ex > 0.5f ? "v" : ">", pillX - 12, r.y + 7, Anim.fade(Anim.mix(GRAY_DIM, ThemeManager.TEXT_WHITE, h), a));
                if (m.getKeyBind() >= 0) {
                    String kn = keyName(m.getKeyBind());
                    int kw = this.font.width(kn) + 8;
                    int kx = pillX - 20 - kw;
                    if (kx > r.x + 12 + this.font.width(m.getName()) + 4) {
                        rr(g, kx, r.y + 4, kw, 14, Anim.fade(0xFF24242F, a));
                        g.drawString(this.font, kn, kx + 4, r.y + 7, Anim.fade(ThemeManager.TEXT_GRAY, a));
                    }
                }
                if (hv && m.getDescription() != null && !m.getDescription().isEmpty()) tip = m.getDescription();
            } else {
                if (r.clipBottom <= r.clipTop) continue;
                int cy1 = Math.max(r.clipTop, top()), cy2 = Math.min(r.clipBottom, bottom());
                if (cy2 <= cy1) continue;
                g.enableScissor(r.x - 4, cy1, r.x + r.w + 4, cy2);
                drawSetting(g, r, mouseX, mouseY, dt, a);
                g.disableScissor();
            }
        }
        g.disableScissor();

        if (rows.isEmpty()) {
            String none = "Nothing found";
            g.drawString(this.font, none, cx() + (cw() - this.font.width(none)) / 2, top() + 20, Anim.fade(GRAY_DIM, a));
        }
        if (maxScroll > 0) {
            int barH = Math.max(18, viewH * viewH / Math.max(viewH, contentH));
            int barY = top() + (int) ((viewH - barH) * (scroll / maxScroll));
            rr(g, wx + ww - 8, barY, 3, barH, Anim.fade(ThemeManager.ACCENT, a * 0.8f));
        }
        g.fill(cx(), bottom() + 4, wx + ww - 10, bottom() + 5, Anim.fade(0x18FFFFFF, a));
        g.drawString(this.font, tip != null ? tip : "LMB switch   arrow / RMB settings   wheel scroll", cx(), bottom() + 9, Anim.fade(GRAY_DIM, a));
        super.render(g, mouseX, mouseY, partial);
    }

    @SuppressWarnings("unchecked")
    private void drawSetting(GuiGraphics g, Row r, int mouseX, int mouseY, float dt, float a) {
        int x = r.x, w = r.w;
        boolean hv = in(mouseX, mouseY, x, r.y, w, r.h) && mouseY > r.clipTop && mouseY < r.clipBottom;
        Object key = r.setting != null ? r.setting : (r.kind == Kind.BIND ? bindKey(r.module) : (Object) r.kind);
        float h = anim(hover, key, hv ? 1f : 0f, dt, 16f);
        if (h > 0.01f) rr(g, x, r.y, w, r.h - 1, Anim.fade(0x18FFFFFF, a * h));
        switch (r.kind) {
            case BOOL -> {
                Setting<Boolean> b = (Setting<Boolean>) r.setting;
                float on = Anim.approach(switchT.getOrDefault(b, b.getValue() ? 1f : 0f), b.getValue() ? 1f : 0f, dt, 14f);
                switchT.put(b, on);
                g.drawString(this.font, r.setting.getName(), x + 5, r.y + 5, Anim.fade(Anim.mix(0xFFC9C9D6, 0xFFFFFFFF, h), a));
                pill(g, x + w - 5 - 26, r.y + 3, on, a);
            }
            case DOUBLE, INT -> {
                double min, max, val;
                if (r.setting instanceof Setting.DoubleSetting ds) { min = ds.getMin(); max = ds.getMax(); val = ds.getValue(); }
                else { Setting.IntSetting is = (Setting.IntSetting) r.setting; min = is.getMin(); max = is.getMax(); val = is.getValue(); }
                g.drawString(this.font, r.setting.getName(), x + 5, r.y + 3, Anim.fade(Anim.mix(0xFFC9C9D6, 0xFFFFFFFF, h), a));
                String shownVal = r.setting.display();
                String vt = shownVal != null ? shownVal : r.kind == Kind.INT ? String.valueOf((int) val) : String.format(Locale.ROOT, "%.2f", val);
                g.drawString(this.font, vt, x + w - 5 - this.font.width(vt), r.y + 3, Anim.fade(ThemeManager.ACCENT, a));
                int tx = x + 8, tw = w - 16, ty = r.y + 15;
                float pct = (float) Mth.clamp((val - min) / Math.max(1e-9, max - min), 0, 1);
                rr(g, tx, ty, tw, 3, Anim.fade(0xFF2C2C3A, a));
                rr(g, tx, ty, Math.max(3, (int) (tw * pct)), 3, Anim.fade(ThemeManager.ACCENT, a));
                int kx = tx + (int) ((tw - 6) * pct);
                rr(g, kx, ty - 2, 6, 7, Anim.fade(Anim.mix(0xFFCFCFE0, 0xFFFFFFFF, h), a));
            }
            case MODE -> {
                Setting.ModeSetting ms = (Setting.ModeSetting) r.setting;
                g.drawString(this.font, r.setting.getName(), x + 5, r.y + 5, Anim.fade(Anim.mix(0xFFC9C9D6, 0xFFFFFFFF, h), a));
                String opt = ms.display() != null ? ms.display() : ms.getOptions()[Mth.clamp(ms.getValue(), 0, ms.getOptions().length - 1)];
                String shownOpt = "< " + opt + " >";
                g.drawString(this.font, shownOpt, x + w - 5 - this.font.width(shownOpt), r.y + 5, Anim.fade(ThemeManager.ACCENT, a));
            }
            case KEY -> {
                boolean lis = listeningKey == r.setting;
                if (lis) rr(g, x, r.y, w, r.h - 1, Anim.fade(Anim.mix(0xFF16161D, ThemeManager.ACCENT, 0.45f), a));
                g.drawString(this.font, r.setting.getName(), x + 5, r.y + 5, Anim.fade(Anim.mix(0xFFC9C9D6, 0xFFFFFFFF, h), a));
                String kt = lis ? "press a key" : (r.setting.display() != null ? r.setting.display() : "none");
                g.drawString(this.font, kt, x + w - 5 - this.font.width(kt), r.y + 5, Anim.fade(ThemeManager.ACCENT, a));
            }
            case TEXT -> {
                Setting.TextSetting ts = (Setting.TextSetting) r.setting;
                boolean ed = editing == ts;
                if (ed) rr(g, x, r.y, w, r.h - 1, Anim.fade(Anim.mix(0xFF16161D, ThemeManager.ACCENT, 0.30f), a));
                g.drawString(this.font, ts.getName(), x + 5, r.y + 5, Anim.fade(Anim.mix(0xFFC9C9D6, 0xFFFFFFFF, h), a));
                String raw = ts.getValue() == null ? "" : ts.getValue();
                String vis = ts.isSecret() ? "*".repeat(Math.min(raw.length(), 16)) : raw;
                int avail = w - 14 - this.font.width(ts.getName());
                if (ed && (System.currentTimeMillis() / 500) % 2 == 0) vis = vis + "_";
                if (vis.isEmpty() && !ed) vis = "-";
                while (vis.length() > 1 && this.font.width(vis) > avail) vis = ed ? vis.substring(1) : vis.substring(0, vis.length() - 1);
                g.drawString(this.font, vis, x + w - 5 - this.font.width(vis), r.y + 5, Anim.fade(ThemeManager.ACCENT, a));
            }
            case BIND -> {
                boolean lis = listening == r.module;
                if (lis) rr(g, x, r.y, w, r.h - 1, Anim.fade(Anim.mix(0xFF16161D, ThemeManager.ACCENT, 0.45f), a));
                String t = lis ? "Press a key   Esc cancel   Bksp clear" : "Keybind";
                g.drawString(this.font, t, x + 5, r.y + 5, Anim.fade(Anim.mix(0xFFC9C9D6, 0xFFFFFFFF, h), a));
                if (!lis) { String kn = keyName(r.module.getKeyBind()); g.drawString(this.font, kn, x + w - 5 - this.font.width(kn), r.y + 5, Anim.fade(ThemeManager.ACCENT, a)); }
            }
            case RESET -> g.drawString(this.font, "Reset to defaults", x + 5, r.y + 6, Anim.fade(Anim.mix(GRAY_DIM, 0xFFFF7788, h), a));
            default -> { }
        }
    }

    // ------------------------------------------------------------------ input

    private boolean rightButton() {
        long win = GLFW.glfwGetCurrentContext();
        return win != 0 && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
    }

    private void setSlider(Row r, double mx) {
        int tx = r.x + 8, tw = r.w - 16;
        double pct = Mth.clamp((mx - tx) / Math.max(1, tw), 0, 1);
        if (r.setting instanceof Setting.DoubleSetting ds) {
            double v = ds.getMin() + (ds.getMax() - ds.getMin()) * pct;
            ds.setValue(ds.snap(v));
        } else if (r.setting instanceof Setting.IntSetting is) {
            is.setValue((int) Math.round(is.getMin() + (is.getMax() - is.getMin()) * pct));
        }
    }

    private static void reset(Module m) { for (Setting<?> s : m.settings) s.resetToDefault(); }

    @Override
    @SuppressWarnings("unchecked")
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        boolean right = rightButton();
        int wx = wx();
        listeningKey = null;
        editing = null;

        for (Nav n : navItems()) {
            if (!in(mx, my, wx + 8, n.y(), SIDE - 16, itemH() - 1)) continue;
            listening = null;
            switch (n.type()) {
                case NAV_CATEGORY -> { selected = n.cat(); query = ""; searchFocus = false; scroll = 0; scrollTarget = 0; }
                case NAV_CLASSIC -> Minecraft.getInstance().setScreen(new com.ghostline.mod.GhostGui());
                case NAV_HUD -> Minecraft.getInstance().setScreen(new com.ghostline.mod.HudEditorScreen());
                case NAV_THEME -> Minecraft.getInstance().setScreen(new ThemeScreen());
                default -> searchFocus = true;
            }
            return true;
        }
        if (in(mx, my, searchX(), searchY(), SEARCH_W, 16)) { searchFocus = true; listening = null; return true; }
        searchFocus = false;

        if (my < top() || my > bottom()) return super.mouseClicked(event, doubleClick);
        for (Row r : layout()) {
            if (r.kind == Kind.MODULE) {
                if (!in(mx, my, r.x, r.y, r.w, HEAD)) continue;
                int pillX = r.x + r.w - 8 - 26;
                boolean arrow = mx >= pillX - 18 && mx < pillX - 2;
                if (right || arrow) { if (!open.remove(r.module)) open.add(r.module); listening = null; }
                else r.module.toggle();
                return true;
            }
            if (my < r.clipTop || my > r.clipBottom || !in(mx, my, r.x, r.y, r.w, r.h)) continue;
            switch (r.kind) {
                case BOOL -> { Setting<Boolean> b = (Setting<Boolean>) r.setting; b.setValue(!b.getValue()); }
                case DOUBLE, INT -> { dragging = r; setSlider(r, mx); }
                case MODE -> {
                    Setting.ModeSetting ms = (Setting.ModeSetting) r.setting;
                    int n = ms.getOptions().length;
                    if (n > 0) ms.setValue((ms.getValue() + (right ? n - 1 : 1)) % n);
                }
                case KEY -> listeningKey = r.setting;
                case TEXT -> editing = (Setting.TextSetting) r.setting;
                case BIND -> listening = listening == r.module ? null : r.module;
                case RESET -> reset(r.module);
                default -> { }
            }
            return true;
        }
        listening = null;
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging != null) { setSlider(dragging, event.x()); return true; }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollTarget = Mth.clamp(scrollTarget - (float) (scrollY * 34), 0, Math.max(0, contentH - (bottom() - top())));
        return true;
    }

    private static char typed(int key) {
        if (key >= GLFW.GLFW_KEY_A && key <= GLFW.GLFW_KEY_Z) return (char) ('a' + (key - GLFW.GLFW_KEY_A));
        if (key >= GLFW.GLFW_KEY_0 && key <= GLFW.GLFW_KEY_9) return (char) ('0' + (key - GLFW.GLFW_KEY_0));
        if (key == GLFW.GLFW_KEY_SPACE) return ' ';
        return 0;
    }

    private static char typedText(int key, boolean shift) {
        if (key >= GLFW.GLFW_KEY_A && key <= GLFW.GLFW_KEY_Z) { char c = (char) ('a' + (key - GLFW.GLFW_KEY_A)); return shift ? Character.toUpperCase(c) : c; }
        if (key >= GLFW.GLFW_KEY_0 && key <= GLFW.GLFW_KEY_9) return (char) ('0' + (key - GLFW.GLFW_KEY_0));
        return switch (key) {
            case GLFW.GLFW_KEY_SPACE -> ' ';
            case GLFW.GLFW_KEY_PERIOD -> '.';
            case GLFW.GLFW_KEY_COMMA -> ',';
            case GLFW.GLFW_KEY_MINUS -> shift ? '_' : '-';
            case GLFW.GLFW_KEY_SLASH -> '/';
            case GLFW.GLFW_KEY_SEMICOLON -> shift ? ':' : ';';
            default -> 0;
        };
    }

    /** True while a text field, key capture or search box is active (so movement keys must not fire). */
    public boolean isTyping() { return searchFocus || editing != null || listening != null || listeningKey != null; }

    @Override
    @SuppressWarnings("unchecked")
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listeningKey != null) {
            Setting<Integer> ks = (Setting<Integer>) listeningKey;
            if (key != GLFW.GLFW_KEY_ESCAPE) ks.setValue(key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? -1 : key);
            listeningKey = null;
            return true;
        }
        if (editing != null) {
            String cur = editing.getValue() == null ? "" : editing.getValue();
            long win = GLFW.glfwGetCurrentContext();
            boolean ctrl = win != 0 && (GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS);
            boolean shift = win != 0 && (GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS);
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { editing = null; return true; }
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!cur.isEmpty()) editing.setValue(cur.substring(0, cur.length() - 1)); return true; }
            if (ctrl && key == GLFW.GLFW_KEY_V) {
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    String joined = cur + clip.replace("\n", "").replace("\r", "").trim();
                    editing.setValue(joined.length() > 256 ? joined.substring(0, 256) : joined);
                }
                return true;
            }
            if (ctrl && key == GLFW.GLFW_KEY_A) { editing.setValue(""); return true; }
            char c = typedText(key, shift);
            if (c != 0 && cur.length() < 256) editing.setValue(cur + c);
            return true;
        }
        if (listening != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) listening.setKeyBind(key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? -1 : key);
            listening = null;
            return true;
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { searchFocus = false; return true; }
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scroll = 0; scrollTarget = 0; return true; }
            char c = typed(key);
            if (c != 0 && query.length() < 24) { query += c; scroll = 0; scrollTarget = 0; }
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        try { NightfallClient.getInstance().configManager.save("default"); } catch (RuntimeException ignored) { }
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
