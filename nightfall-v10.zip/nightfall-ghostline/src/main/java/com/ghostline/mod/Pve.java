package com.ghostline.mod;

import com.ghostline.mod.automation.*;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.*;

/**
 * PvE assistants built on the Automation API: Mob Tracker, Loot Tracker, Auto Mine, Warden Guard (+ escape point),
 * Auto End info, Combat reminders, Resource Planner. Everything that moves the player goes through AutoNav.TASKS
 * (one movement task at a time, /glstop or Panic stops it).
 */
public final class Pve {
    private Pve() { }

    private static final List<String> hud = new ArrayList<>();
    private static int tickN;

    // ================================================================== helpers

    static Map<String, Integer> inventoryCounts(LocalPlayer p) {
        Map<String, Integer> m = new HashMap<>();
        for (int i = 0; i < 36; i++) {
            ItemStack s = p.getInventory().getItem(i);
            if (!s.isEmpty()) m.merge(BuiltInRegistries.ITEM.getKey(s.getItem()).getPath(), s.getCount(), Integer::sum);
        }
        return m;
    }

    private static void say(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[Ghostline] " + s), false);
    }

    private static int freeSlots(LocalPlayer p) {
        int f = 0; for (int i = 0; i < 36; i++) if (p.getInventory().getItem(i).isEmpty()) f++; return f;
    }

    private static void face(LocalPlayer p, Vec3 t, float maxStep) {
        Vec3 e = p.getEyePosition();
        double dx = t.x - e.x, dy = t.y - e.y, dz = t.z - e.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = Mth.clamp((float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))), -90f, 90f);
        p.setYRot(p.getYRot() + Mth.clamp(Mth.wrapDegrees(yaw - p.getYRot()), -maxStep, maxStep));
        p.setXRot(p.getXRot() + Mth.clamp(pitch - p.getXRot(), -maxStep, maxStep));
    }

    // ================================================================== Mob Tracker

    private static void mobTracker(Minecraft mc, LocalPlayer p) {
        Module m = Config.MOBTRACKER;
        double range = m.get(0).value; boolean hostileOnly = m.get(1).i() == 1; int max = m.get(2).i();
        List<LivingEntity> l = new ArrayList<>();
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range), x -> x != p && x.isAlive() && !(x instanceof Player)))
            if (!hostileOnly || e instanceof Monster) l.add(e);
        l.sort(Comparator.comparingDouble(p::distanceToSqr));
        for (int i = 0; i < Math.min(max, l.size()); i++) {
            LivingEntity e = l.get(i);
            float rel = Mth.wrapDegrees((float) (Math.toDegrees(Math.atan2(e.getZ() - p.getZ(), e.getX() - p.getX())) - 90.0) - p.getYRot());
            String arrow = Math.abs(rel) < 45 ? "^" : Math.abs(rel) > 135 ? "v" : rel > 0 ? ">" : "<";
            hud.add(String.format(Locale.ROOT, "%s %s  %.0f m  %.0f HP", arrow, e.getName().getString(), (double) p.distanceTo(e), e.getHealth()));
        }
    }

    // ================================================================== Loot Tracker

    private static final LootLog LOOT = new LootLog(100);
    private static boolean lootWorld;

    private static void lootTracker(Minecraft mc, LocalPlayer p) {
        Module m = Config.LOOTTRACKER;
        if (tickN % 10 == 0) {
            Map<String, Integer> gains = LOOT.update(inventoryCounts(p), System.currentTimeMillis());
            Set<String> imp = importantSet();
            for (Map.Entry<String, Integer> g : gains.entrySet())
                if (imp.contains(g.getKey())) Toasts.info(Lang.t("loot.title"), "+" + g.getValue() + " " + g.getKey());
        }
        int n = m.get(1).i();
        if (n > 0) for (Map.Entry<String, Integer> e : LOOT.top(n, null)) hud.add("+" + e.getValue() + " " + e.getKey());
    }

    private static Set<String> importantSet() {
        Set<String> s = new HashSet<>();
        for (String t : Config.LOOTTRACKER.get(0).text.split("[,;\\s]+")) if (!t.isBlank()) s.add(t.toLowerCase(Locale.ROOT).replace("minecraft:", ""));
        return s;
    }

    // ================================================================== Combat reminders

    private static long lastRemind;

    private static void combatAssist(Minecraft mc, LocalPlayer p) {
        Module m = Config.COMBATASSIST;
        long now = System.currentTimeMillis();
        if (now - lastRemind < m.get(3).value * 1000) return;
        String msg = null;
        if (p.getHealth() <= m.get(0).value) msg = String.format(Lang.t("ca.hp"), p.getHealth());
        else if (p.getFoodData().getFoodLevel() <= m.get(1).value) msg = String.format(Lang.t("ca.food"), p.getFoodData().getFoodLevel());
        else {
            for (EquipmentSlot sl : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                ItemStack s = p.getItemBySlot(sl);
                if (s.isEmpty() || !s.isDamageableItem() || s.getMaxDamage() <= 0) continue;
                int left = (s.getMaxDamage() - s.getDamageValue()) * 100 / s.getMaxDamage();
                if (left <= m.get(2).value) { msg = String.format(Lang.t("ca.armor"), s.getHoverName().getString(), left); break; }
            }
        }
        if (msg != null) { lastRemind = now; Toasts.warn(Lang.t("ca.title"), msg); }
    }

    // ================================================================== Resource Planner

    private static boolean planDone;

    private static void resourcePlan(Minecraft mc, LocalPlayer p) {
        Module m = Config.RESOURCEPLAN;
        Map<String, Integer> need = ResourcePlan.parse(m.get(0).text, null);
        if (need.isEmpty()) { planDone = false; return; }
        Map<String, Integer> miss = ResourcePlan.missing(need, inventoryCounts(p));
        if (miss.isEmpty()) {
            if (!planDone && m.get(2).i() == 1) Toasts.info(Lang.t("plan.title"), Lang.t("plan.done"));
            planDone = true;
            return;
        }
        planDone = false;
        if (m.get(1).i() == 1) { int k = 0; for (Map.Entry<String, Integer> e : miss.entrySet()) { if (k++ >= 5) break; hud.add(Lang.t("plan.need") + " " + e.getValue() + " " + e.getKey()); } }
    }

    // ================================================================== Warden Guard + escape point

    static final WardenFsm WARDEN = new WardenFsm();
    private static WardenFsm.State prevWarden = WardenFsm.State.DISABLED;
    private static boolean escapeKnown;
    private static double lastWardenDist = Double.NaN;

    static int[] escapePoint() {
        String[] t = Config.WARDENGUARD.get(0).text.trim().split("[\\s,]+");
        if (t.length != 3) return null;
        try { return new int[]{Integer.parseInt(t[0]), Integer.parseInt(t[1]), Integer.parseInt(t[2])}; }
        catch (NumberFormatException e) { return null; }
    }

    private static void wardenGuard(Minecraft mc, LocalPlayer p) {
        Module m = Config.WARDENGUARD;
        WARDEN.enable(true);
        WARDEN.mode = WardenFsm.Mode.values()[Mth.clamp(m.get(1).i(), 0, 2)];
        WARDEN.radius = m.get(2).value; WARDEN.warnDist = m.get(3).value; WARDEN.evadeDist = m.get(4).value;
        WARDEN.calmNeeded = (int) (m.get(5).value * 20);
        WARDEN.escapeAvailable = escapePoint() != null;
        double best = Double.NaN;
        for (Warden w : mc.level.getEntitiesOfClass(Warden.class, p.getBoundingBox().inflate(WARDEN.radius), Entity::isAlive)) {
            double d = p.distanceTo(w);
            if (Double.isNaN(best) || d < best) best = d;
        }
        lastWardenDist = best;
        WARDEN.step(best);
        if (WARDEN.justWarned) Toasts.warn(Lang.t("wg.title"), String.format(Lang.t("wg.warn"), best));
        if (WARDEN.state != prevWarden) {
            if (WARDEN.state == WardenFsm.State.EVADING && !AutoNav.active()) {
                int[] e = escapePoint();
                if (e != null) { AutoNav.listen(); AutoNav.TASKS.submit(new AutoNav.NavTask(e[0], e[1], e[2], true)); Toasts.warn(Lang.t("wg.title"), Lang.t("wg.evade")); }
            } else if (prevWarden == WardenFsm.State.EVADING && WARDEN.state != WardenFsm.State.EVADING) {
                AutoNav.stop(mc);
            }
            prevWarden = WARDEN.state;
        }
        if (WARDEN.state != WardenFsm.State.IDLE && WARDEN.state != WardenFsm.State.DISABLED)
            hud.add(String.format(Locale.ROOT, "Warden: %s%s", WARDEN.state, Double.isNaN(best) ? "" : String.format(Locale.ROOT, "  %.0f m", best)));
    }

    // ================================================================== Auto End (information only)

    private static void autoEnd(Minecraft mc, LocalPlayer p) {
        if (mc.level.dimension() != Level.END) return;
        Module m = Config.AUTOEND;
        if (m.get(0).i() == 1) {
            for (EnderDragon d : mc.level.getEntitiesOfClass(EnderDragon.class, p.getBoundingBox().inflate(200), Entity::isAlive)) {
                hud.add(String.format(Locale.ROOT, "Dragon: %.0f / %.0f HP  %.0f m", d.getHealth(), d.getMaxHealth(), (double) p.distanceTo(d)));
                break;
            }
        }
        if (m.get(1).i() == 1) {
            int c = mc.level.getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(128), Entity::isAlive).size();
            if (c > 0) hud.add(Lang.t("end.crystals") + " " + c);
        }
    }

    // ================================================================== Auto Mine

    static final class MineTask extends AutomationTask {
        private enum Ph { SEARCH, WALK, DIG, COLLECT }
        final Set<String> ids; final int radius; final boolean mine;
        private final Map<Block, Boolean> wanted = new HashMap<>();
        private final Set<Long> bad = new HashSet<>();
        private Ph ph = Ph.SEARCH;
        private BlockPos target; private Walker walker;
        private int mined, failures, digTicks; private long phaseAt, collectUntil;
        private ItemEntity item;

        MineTask(Set<String> ids, int radius, boolean mine) {
            super("AutoMine", 5, 10 * 60_000L);
            this.ids = ids; this.radius = radius; this.mine = mine;
            param("blocks", String.join(",", ids)).param("radius", String.valueOf(radius)).param("mode", mine ? "mine" : "preview");
        }

        private boolean isWanted(BlockState s) {
            return wanted.computeIfAbsent(s.getBlock(), b -> ids.contains(BuiltInRegistries.BLOCK.getKey(b).getPath()));
        }

        @Override protected AutomationResult onStart(long now) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.level == null) return AutomationResult.failure("no player or world");
            if (ids.isEmpty()) return AutomationResult.failure("no block ids given");
            return AutomationResult.success("started");
        }

        @Override protected void onStop(TaskState s, String why) {
            Minecraft mc = Minecraft.getInstance();
            AutoNav.release(mc);
            if (mc.gameMode != null) mc.gameMode.stopDestroyBlock();
            AutoNav.showRoute(null, 0, mined + " mined: " + (why == null ? "" : why));
        }

        @Override protected AutomationResult onTick(long now) {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null || mc.gameMode == null) return AutomationResult.failure("world lost");
            if (!p.isAlive()) return AutomationResult.failure("player died");
            if (mc.screen != null) { AutoNav.release(mc); return null; }
            if (mine) {
                if (freeSlots(p) < Config.AUTOMINE.get(2).i()) return AutomationResult.success("inventory almost full, " + mined + " mined");
                if (Config.AUTOMINE.get(5).i() == 1)
                    for (Monster z : mc.level.getEntitiesOfClass(Monster.class, p.getBoundingBox().inflate(8), Entity::isAlive))
                        return AutomationResult.failure("hostile mob nearby (" + z.getName().getString() + ")");
            }
            switch (ph) {
                case SEARCH -> { return search(mc, p, now); }
                case WALK -> { return walk(mc, p, now); }
                case COLLECT -> { return collect(mc, p, now); }
                default -> { return dig(mc, p, now); }
            }
        }

        private AutomationResult search(Minecraft mc, LocalPlayer p, long now) {
            BlockPos base = p.blockPosition();
            List<BlockPos> found = new ArrayList<>();
            BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
            for (int dx = -radius; dx <= radius; dx++) for (int dy = -radius; dy <= radius; dy++) for (int dz = -radius; dz <= radius; dz++) {
                q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                if (mc.level.isOutsideBuildHeight(q.getY()) || !mc.level.getChunkSource().hasChunk(q.getX() >> 4, q.getZ() >> 4)) continue;
                if (bad.contains(q.asLong())) continue;
                if (isWanted(mc.level.getBlockState(q))) found.add(q.immutable());
            }
            found.sort(Comparator.comparingDouble(b -> b.distSqr(base)));
            if (!mine) return AutomationResult.success(found.size() + " matching blocks within " + radius + (found.isEmpty() ? "" : "; nearest " + found.get(0).toShortString()));
            boolean tunnel = Config.AUTOMINE.get(7).i() == 1;
            AutoNav.McWorld view = new AutoNav.McWorld(mc.level, tunnel);
            Pathfinder pf = new Pathfinder(view, AutoNav.options(tunnel));
            int tried = 0;
            for (BlockPos t : found) {
                if (tried >= 6) break;
                List<int[]> spots = MineTargets.standSpots(pf, t.getX(), t.getY(), t.getZ(), base.getX(), base.getY(), base.getZ());
                for (int[] s : spots.subList(0, Math.min(2, spots.size()))) {
                    tried++;
                    Path r = pf.find(base.getX(), base.getY(), base.getZ(), s[0], s[1], s[2]);
                    if (r.found()) {
                        target = t; walker = new Walker(r, p, now, tunnel); ph = Ph.WALK; phaseAt = now;
                        AutoNav.showRoute(r, now, "mining " + t.toShortString());
                        stage("walking to " + t.toShortString());
                        return null;
                    }
                }
                bad.add(t.asLong()); // no reachable standing spot (buried, over water...): skip it
            }
            return AutomationResult.success(found.isEmpty() ? "no more matching blocks, " + mined + " mined" : "nothing else reachable, " + mined + " mined");
        }

        private AutomationResult walk(Minecraft mc, LocalPlayer p, long now) {
            if (!isWanted(mc.level.getBlockState(target))) { ph = Ph.SEARCH; return null; } // someone else mined it
            Walker.R r = walker.step(mc, p, now, () -> null);
            if (r == Walker.R.ARRIVED) { ph = Ph.DIG; digTicks = 0; return null; }
            if (r == Walker.R.FAILED) {
                bad.add(target.asLong());
                if (++failures > 5) return AutomationResult.failure("too many failed routes: " + walker.reason);
                ph = Ph.SEARCH;
            }
            return null;
        }

        /** Picks up the drops of the block we just mined: nearest item entity within a few blocks, bounded to 6 seconds. */
        private AutomationResult collect(Minecraft mc, LocalPlayer p, long now) {
            if (now > collectUntil) { AutoNav.release(mc); ph = Ph.SEARCH; return null; }
            if (item == null || !item.isAlive()) {
                item = null; double bd = 1e18;
                for (ItemEntity it : mc.level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(7), Entity::isAlive)) {
                    double d = p.distanceToSqr(it);
                    if (d < bd && it.blockPosition().distSqr(target) <= 36) { bd = d; item = it; }
                }
                walker = null;
                if (item == null) { AutoNav.release(mc); ph = Ph.SEARCH; return null; }
            }
            if (p.distanceToSqr(item) < 1.0) { AutoNav.release(mc); return null; } // close enough: it is picked up by itself
            if (walker == null) {
                BlockPos ib = item.blockPosition();
                Path r = AutoNav.plan(mc, p, ib.getX(), ib.getY(), ib.getZ());
                if (!r.found()) { item = null; collectUntil = Math.min(collectUntil, now + 300); AutoNav.release(mc); ph = Ph.SEARCH; return null; }
                walker = new Walker(r, p, now);
            }
            Walker.R r = walker.step(mc, p, now, () -> null);
            if (r != Walker.R.WALKING) { walker = null; if (r == Walker.R.FAILED) { item = null; ph = Ph.SEARCH; } }
            return null;
        }

        private AutomationResult dig(Minecraft mc, LocalPlayer p, long now) {
            BlockState st = mc.level.getBlockState(target);
            if (!isWanted(st)) {
                mined++; digTicks = 0; mc.gameMode.stopDestroyBlock();
                if (Config.AUTOMINE.get(6).i() == 1) { ph = Ph.COLLECT; collectUntil = now + 6000; item = null; walker = null; }
                else ph = Ph.SEARCH;
                return null;
            }
            // best hotbar tool
            int cur = p.getInventory().getSelectedSlot(), best = cur;
            float bs = p.getInventory().getItem(cur).getDestroySpeed(st);
            for (int i = 0; i < 9; i++) { float sp = p.getInventory().getItem(i).getDestroySpeed(st); if (sp > bs + 0.01f) { bs = sp; best = i; } }
            if (best != cur) p.getInventory().setSelectedSlot(best);
            ItemStack tool = p.getInventory().getItem(best);
            if (tool.isDamageableItem() && tool.getMaxDamage() - tool.getDamageValue() < Config.AUTOMINE.get(1).i())
                return AutomationResult.success("tool is almost broken, " + mined + " mined");
            Vec3 eye = p.getEyePosition(), c = Vec3.atCenterOf(target);
            BlockHitResult hit = mc.level.clip(new ClipContext(eye, c, ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, p));
            boolean seen = hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(target);
            if (eye.distanceTo(c) > 4.7 || !seen) { bad.add(target.asLong()); ph = Ph.SEARCH; return null; }
            face(p, c, 40f);
            Direction dir = Direction.getApproximateNearest(eye.x - c.x, eye.y - c.y, eye.z - c.z);
            mc.gameMode.continueDestroyBlock(target, dir);
            p.swing(InteractionHand.MAIN_HAND);
            stage("mining " + mined);
            if (++digTicks > Config.AUTOMINE.get(4).value * 20) { bad.add(target.asLong()); ph = Ph.SEARCH; mc.gameMode.stopDestroyBlock(); }
            return null;
        }
    }

    // ================================================================== tick / render

    public static void tick(Minecraft mc, LocalPlayer p) {
        tickN++;
        hud.clear();
        if (Config.MOBTRACKER.enabled && Config.MOBTRACKER.get(3).i() == 1) mobTracker(mc, p);
        if (Config.LOOTTRACKER.enabled) lootTracker(mc, p); else LOOT.rebase();
        if (Config.COMBATASSIST.enabled) combatAssist(mc, p);
        if (Config.RESOURCEPLAN.enabled) resourcePlan(mc, p);
        if (Config.WARDENGUARD.enabled) wardenGuard(mc, p);
        else if (WARDEN.state != WardenFsm.State.DISABLED) { WARDEN.enable(false); prevWarden = WardenFsm.State.DISABLED; }
        if (Config.AUTOEND.enabled) autoEnd(mc, p);
        if (Config.DASHBOARD.enabled) {
            long now = System.currentTimeMillis();
            List<String> l = TaskReport.lines(AutoNav.TASKS, now, Config.DASHBOARD.get(0).i());
            int k = 0;
            for (String s : l) { if (k++ >= 8) break; if (Config.DASHBOARD.get(1).i() == 0 && s.contains("[IDLE]")) continue; hud.add(s); }
        }
    }

    public static void worldGone() { LOOT.rebase(); hud.clear(); WARDEN.enable(false); prevWarden = WardenFsm.State.DISABLED; }

    public static void render(GuiGraphics g, int startY) {
        int y = startY;
        for (String s : hud) { g.fill(2, y - 1, 6 + Ui.font().width(s) + 2, y + 10, Ui.c(Ui.bg(), 0.6f)); Ui.text(g, s, 5, y, Ui.c(0xFFFFFF, 1f)); y += 12; }
    }

    public static int hudLines() { return hud.size(); }

    // ================================================================== commands

    public static void registerCommands(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("glmine")
            .then(ClientCommandManager.argument("blocks", StringArgumentType.word())
                .executes(c -> mineCmd(StringArgumentType.getString(c, "blocks"), 10, false))
                .then(ClientCommandManager.argument("radius", IntegerArgumentType.integer(2, 16))
                    .executes(c -> mineCmd(StringArgumentType.getString(c, "blocks"), IntegerArgumentType.getInteger(c, "radius"), false))
                    .then(ClientCommandManager.literal("preview")
                        .executes(c -> mineCmd(StringArgumentType.getString(c, "blocks"), IntegerArgumentType.getInteger(c, "radius"), true))))));
        d.register(ClientCommandManager.literal("glplan")
            .then(ClientCommandManager.literal("set").then(ClientCommandManager.argument("items", StringArgumentType.greedyString()).executes(c -> {
                List<String> err = new ArrayList<>();
                Map<String, Integer> m = ResourcePlan.parse(StringArgumentType.getString(c, "items"), err);
                Config.RESOURCEPLAN.get(0).text = ResourcePlan.format(m);
                say("plan: " + (m.isEmpty() ? "empty" : ResourcePlan.format(m)) + (err.isEmpty() ? "" : "  (skipped: " + String.join("; ", err) + ")"));
                return 1;
            })))
            .then(ClientCommandManager.literal("show").executes(c -> {
                LocalPlayer p = Minecraft.getInstance().player; if (p == null) return 0;
                Map<String, Integer> need = ResourcePlan.parse(Config.RESOURCEPLAN.get(0).text, null);
                Map<String, Integer> miss = ResourcePlan.missing(need, inventoryCounts(p));
                say(need.isEmpty() ? "plan is empty" : miss.isEmpty() ? "plan complete" : "missing: " + ResourcePlan.format(miss));
                return 1;
            }))
            .then(ClientCommandManager.literal("clear").executes(c -> { Config.RESOURCEPLAN.get(0).text = ""; say("plan cleared"); return 1; })));
        d.register(ClientCommandManager.literal("glescape")
            .then(ClientCommandManager.literal("set").executes(c -> {
                LocalPlayer p = Minecraft.getInstance().player; if (p == null) return 0;
                BlockPos b = p.blockPosition();
                Config.WARDENGUARD.get(0).text = b.getX() + " " + b.getY() + " " + b.getZ();
                say("escape point set: " + Config.WARDENGUARD.get(0).text);
                return 1;
            }))
            .then(ClientCommandManager.literal("check").executes(c -> {
                Minecraft mc = Minecraft.getInstance(); int[] e = escapePoint();
                if (mc.player == null || mc.level == null) return 0;
                if (e == null) { say("no escape point: stand somewhere safe and use /glescape set"); return 0; }
                Path r = AutoNav.plan(mc, mc.player, e[0], e[1], e[2]);
                say(r.found() ? "escape route OK: " + r.length() + " blocks" : "no safe route to the escape point: " + r.reason());
                return r.found() ? 1 : 0;
            }))
            .then(ClientCommandManager.literal("go").executes(c -> {
                int[] e = escapePoint();
                if (e == null) { say("no escape point: use /glescape set"); return 0; }
                AutomationResult r = AutoNav.go(e[0], e[1], e[2], false);
                say(r.message()); return r.ok() ? 1 : 0;
            })));
        d.register(ClientCommandManager.literal("glloot")
            .then(ClientCommandManager.literal("reset").executes(c -> { LOOT.reset(); say("loot stats reset"); return 1; }))
            .then(ClientCommandManager.literal("show").executes(c -> {
                List<Map.Entry<String, Integer>> t = LOOT.top(10, null);
                say(t.isEmpty() ? "nothing collected yet" : t.stream().map(e -> "+" + e.getValue() + " " + e.getKey()).reduce((a, b) -> a + ", " + b).orElse(""));
                return 1;
            })));
        d.register(ClientCommandManager.literal("glpoint")
            .then(ClientCommandManager.literal("set").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                Minecraft mc = Minecraft.getInstance(); if (mc.player == null) return 0;
                String n = StringArgumentType.getString(c, "name");
                BlockPos b = mc.player.blockPosition();
                Config.WAYPOINTS_LIST.removeIf(w -> w.name.equalsIgnoreCase(n));
                Config.WAYPOINTS_LIST.add(new Config.Waypoint(n, b.getX(), b.getY(), b.getZ()));
                say("point saved: " + n + " " + b.toShortString());
                return 1;
            })))
            .then(ClientCommandManager.literal("del").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                String n = StringArgumentType.getString(c, "name");
                boolean ok = Config.WAYPOINTS_LIST.removeIf(w -> w.name.equalsIgnoreCase(n));
                say(ok ? "point deleted" : "no such point");
                return ok ? 1 : 0;
            })))
            .then(ClientCommandManager.literal("list").executes(c -> {
                say(Config.WAYPOINTS_LIST.isEmpty() ? "no points yet: /glpoint set <name>"
                    : Config.WAYPOINTS_LIST.stream().map(w -> w.name + " " + w.x + " " + w.y + " " + w.z).reduce((a2, b2) -> a2 + " | " + b2).orElse(""));
                return 1;
            }))
            .then(ClientCommandManager.literal("go").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                String n = StringArgumentType.getString(c, "name");
                Config.Waypoint q = Config.WAYPOINTS_LIST.stream().filter(w -> w.name.equalsIgnoreCase(n)).findFirst().orElse(null);
                if (q == null) { say("no such point: /glpoint list"); return 0; }
                AutomationResult r = AutoNav.go(q.x, q.y, q.z, false);
                say(r.message());
                return r.ok() ? 1 : 0;
            }))));
        d.register(ClientCommandManager.literal("glprofile")
            .then(ClientCommandManager.literal("save").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                try { java.nio.file.Path f = ConfigIO.exportFile(StringArgumentType.getString(c, "name")); say("profile saved: " + f.getFileName()); return 1; }
                catch (java.io.IOException | RuntimeException e) { say("cannot save the profile: " + e.getMessage()); return 0; }
            })))
            .then(ClientCommandManager.literal("load").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                try { say("profile loaded: " + ConfigIO.importExport(StringArgumentType.getString(c, "name"))); return 1; }
                catch (RuntimeException e) { say("cannot load the profile: " + e.getMessage()); return 0; }
            })))
            .then(ClientCommandManager.literal("delete").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                try { ConfigIO.deleteExport(StringArgumentType.getString(c, "name")); say("profile deleted"); return 1; }
                catch (java.io.IOException | RuntimeException e) { say("cannot delete: " + e.getMessage()); return 0; }
            })))
            .then(ClientCommandManager.literal("list").executes(c -> {
                List<String> l = ConfigIO.listExports();
                say(l.isEmpty() ? "no profiles yet: /glprofile save <name>" : String.join(", ", l));
                return 1;
            })));
        d.register(ClientCommandManager.literal("gltasks").executes(c -> {
            List<String> l = TaskReport.lines(AutoNav.TASKS, System.currentTimeMillis(), 5);
            say(l.isEmpty() ? "no tasks yet" : String.join(" | ", l));
            return 1;
        }));
        d.register(ClientCommandManager.literal("glend").executes(c -> {
            Minecraft mc = Minecraft.getInstance(); LocalPlayer p = mc.player; if (p == null) return 0;
            List<String> todo = new ArrayList<>();
            if (p.getHealth() < 18) todo.add("health " + (int) p.getHealth() + "/20");
            if (p.getFoodData().getFoodLevel() < 18) todo.add("food " + p.getFoodData().getFoodLevel() + "/20");
            if (freeSlots(p) < 6) todo.add("free slots " + freeSlots(p));
            for (EquipmentSlot sl : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) if (p.getItemBySlot(sl).isEmpty()) todo.add("empty armor slot " + sl.getName());
            Map<String, Integer> inv = inventoryCounts(p);
            if (inv.getOrDefault("ender_pearl", 0) == 0) todo.add("no ender pearls");
            if (inv.entrySet().stream().noneMatch(e -> e.getKey().endsWith("bow") || e.getKey().equals("crossbow"))) todo.add("no bow");
            say(todo.isEmpty() ? "End checklist: all good" : "End checklist, check: " + String.join(", ", todo));
            return 1;
        }));
    }

    private static int mineCmd(String blocks, int radius, boolean preview) {
        Minecraft mc = Minecraft.getInstance();
        if (!Config.AUTOMINE.enabled) { say("module AutoMine is off"); return 0; }
        if (Config.panic || mc.player == null || mc.level == null) return 0;
        if (AutoNav.TASKS.busy()) { say("another task is running: /glstop first"); return 0; }
        Set<String> ids = new LinkedHashSet<>();
        for (String s : blocks.split(",")) { String t = s.trim().toLowerCase(Locale.ROOT).replace("minecraft:", ""); if (t.matches("[a-z0-9_]{1,48}")) ids.add(t); }
        if (ids.isEmpty()) { say("usage: /glmine diamond_ore,deepslate_diamond_ore [radius] [preview]"); return 0; }
        boolean mine = !preview && Config.AUTOMINE.get(3).i() == 1;
        AutoNav.listen();
        AutoNav.TASKS.submit(new MineTask(ids, radius, mine));
        say((mine ? "mining " : "scanning for ") + ids);
        return 1;
    }
}
