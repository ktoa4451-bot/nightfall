# Nightfall: what is new in this build

Repair (the project could not compile before): stale duplicate classes removed (HudManager, TargetHudElement/TargetHubElement, HudEditorScreen/HubEditorScreen),
HudManager no longer references four classes that do not exist, `ResourceLocation` -> `Identifier`, `src/client` is now compiled with `src/main`.

New modules (17): TriggerBot, ShieldBreaker, AutoTotem, Surround | Speed, Step, SafeWalk, Jesus, Spider, ElytraFly |
AutoTool, Scaffold, Nuker | HoleESP, ItemESP, CustomSky | Waypoints (+ /nfpoint set|del|list).
Modules that need a tick implement `Tickable`; EventHandler calls them (a failing module is logged, not fatal).

NOT built or run in game: there is no Minecraft in the place where this was written. `tools/run-tests.sh` checks only the pure maths in `dev.nightfall.util`
(33 checks). CustomSky uses two optional mixins (nightfall.sky.mixins.json); if their targets differ in your exact version they do nothing.

Still missing from your list: Bed/Anchor Aura, Criticals, FreeCamera, Chams, China Hat/Wings/Halo, Motion Blur/Bloom, Discord RPC, NameProtect, Friend Manager,
Music Player/Snake/Space Dodger, Update Checker, FastPlace, Strafe/Jump trainers, Combat replay, NoFall.


## PvP pack (this build)
New (10 modules, 41 in total): HitSelect (hits on critical hits, falls back after MaxWaitMs), WTap, MaceHelper (vanilla smash bonus formula), AutoPotion (splash healing, hotbar),
AutoPearl (one-shot: bind a key, it throws a pearl and switches itself off), Offhand (totem when low, else your preferred item), AutoWeb, CrystalHelper (hints only),
TargetInfo (health, armor, hands, distance), CombatLog (health change log).
Logic checks: 10 + 8 + 15 + 33 = 66 (util package). Everything that touches the game is untested in game.
Not made on purpose: AutoCity (breaks other players' defences), SelfTrap/AntiCrystal (need placement support planning), Bed/Anchor Aura, anything aimed at beating an anticheat.

## XRay
XRay (Visuals): marks ores through rock as an on-screen overlay (coal, iron, copper, gold, redstone, lapis, diamond, emerald, quartz, ancient debris; each can be switched off).
The scan is spread over ticks (6000 cells per tick by default), results replace the old ones after each pass, nearest MaxMarks are drawn. It does not change how blocks are drawn,
so it cannot show blocks the server never sent (anti-xray servers hide them). A texture-hiding x-ray needs render mixins whose targets I could not check for 1.21.11.

## Menu (like Ghostline)
ClickGUI rewritten: left click switches a module, right click opens its settings; switches for on/off settings, sliders for decimals AND whole numbers (before, only decimal sliders existed,
so most settings of the new modules could not be changed), a keybind row (click, press a key; Esc cancels, Backspace clears), "Reset to defaults", mouse-wheel scrolling with a scroll bar,
the description of the hovered module at the bottom, module key shown next to its name. Module keybinds now actually toggle modules (they were saved but never used). The config is saved when the
menu closes and when the game exits. Input methods use the 1.21.11 signatures (MouseButtonEvent / KeyEvent) taken from the Ghostline screens that run on that version; HudEditorScreen was converted the same way.
Not tested in game.

## Menu update (modern look)
Centred window that fades and slides in, category tabs with a sliding underline, soft-cornered module cards, animated switches, an accent bar on enabled modules,
settings that unfold smoothly, thin sliders with a knob, smooth scrolling with a scroll bar, hover fades. Animation maths is frame-rate independent (util/Anim, 10 checks).
The window is drawn with plain rectangles (corners are cut by 2 px), so it needs no textures or shaders. Not tested in game.

## Menu redesign (sidebar + cards)
ClickGUI now has a left sidebar (All + categories, then Configs / HUD / Theme, Search at the bottom), a search field in the header and the modules as two columns of cards. Click a card to switch the module, the arrow (or right click) opens its settings. Search works with letters, digits and space.

## CrystalHelper AutoPlace + AnchorHelper
CrystalHelper: with AutoPlace on, an end crystal is placed on obsidian that a player placed near you (crystals in hotbar/offhand; MinEnemyDmg / MaxSelfDmg checks; it only places). AnchorHelper: place a respawn anchor and it fills it with glowstone up to ChargeTo (default 4); one glowstone per click, next click only after the new charge is visible.

## Hitboxes
Widens the crosshair pick box of other players by Expand blocks (PlayersOnly, SkipFriends). Client-side aiming only, the server still checks reach.

## Batch 2
Velocity (Horizontal/Vertical percent), Parkour (EdgeLead), AutoRespawn, AntiAfk, AutoLeave (sends /hub, /spawn, /lobby or /home once when a player comes close), AutoTpAccept (FriendsOnly).


## Batch 3 (written from scratch)
FastUse (Player): Delay 0-4 ticks between right clicks for Blocks / Crystals / Exp (accessor mixin on Minecraft.rightClickDelay).
FreeCam (Player): camera flies (Speed), the player stands still; mouse and WASD/Space/Shift move the camera. A stand-in entity that is not in the world is the camera entity.
Attack, break, place and use are blocked while it is on. It switches itself off when the world changes. Not tested in game: the mixins use KeyboardInput.tick, Entity.turn and Minecraft.rightClickDelay of 1.21.11.
