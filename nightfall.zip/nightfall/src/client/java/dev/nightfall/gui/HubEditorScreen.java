package dev.nightfall.gui;

import dev.nightfall.NightfallClient;
import dev.nightfall.hud.HudManager;
import dev.nightfall.hud.element.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class HudEditorScreen extends Screen {
    private final ArrayListElement arrayList;
    private final WatermarkElement watermark;
    private final CpsElement cps;
    private final KeystrokesElement keystrokes;
    private final TargetHudElement targetHud;
    private final ArmorElement armor;
    private final FpsElement fps;
    private final CoordsElement coords;
    private final NotificationElement notifications;
    private final SessionElement session;
    private final RadarElement radar;
    private final PotionElement potion;

    private Object dragging = null;
    private int dragOffsetX, dragOffsetY;

    public HudEditorScreen() {
        super(Component.literal("HUD Editor"));
        
        this.arrayList = HudManager.ARRAY_LIST;
        this.watermark = HudManager.WATERMARK;
        this.cps = HudManager.CPS;
        this.keystrokes = HudManager.KEYSTROKES;
        this.targetHud = HudManager.TARGET_HUD;
        this.armor = HudManager.ARMOR;
        this.fps = HudManager.FPS;
        this.coords = HudManager.COORDS;
        this.notifications = HudManager.NOTIFICATIONS;
        this.session = HudManager.SESSION;
        this.radar = HudManager.RADAR;
        this.potion = HudManager.POTION;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, this.width, this.height, 0x88000000);

        for (int i = 0; i < this.width; i += 20) {
            g.fill(i, 0, i + 1, this.height, 0x22FFFFFF);
        }
        for (int i = 0; i < this.height; i += 20) {
            g.fill(0, i, this.width, i + 1, 0x22FFFFFF);
        }

        arrayList.render(g, partialTick);
        watermark.render(g, partialTick);
        cps.render(g, partialTick);
        keystrokes.render(g, partialTick);
        targetHud.render(g, partialTick);
        armor.render(g, partialTick);
        fps.render(g, partialTick);
        coords.render(g, partialTick);
        notifications.render(g, partialTick);
        session.render(g, partialTick);
        radar.render(g, partialTick);
        potion.render(g, partialTick);

        g.drawString(this.font, "Drag elements. ESC to save & exit.", 10, 10, 0xFFFFFFFF);

        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (isHovered(mouseX, mouseY, arrayList.getX(), arrayList.getY(), 100, 100)) dragging = arrayList;
            else if (isHovered(mouseX, mouseY, watermark.getX(), watermark.getY(), 100, 20)) dragging = watermark;
            else if (isHovered(mouseX, mouseY, cps.getX(), cps.getY(), 80, 20)) dragging = cps;
            else if (isHovered(mouseX, mouseY, keystrokes.getX(), keystrokes.getY(), 60, 60)) dragging = keystrokes;
            else if (isHovered(mouseX, mouseY, targetHud.getX(), targetHud.getY(), 140, 40)) dragging = targetHud;
            else if (isHovered(mouseX, mouseY, armor.getX(), armor.getY(), 80, 80)) dragging = armor;
            else if (isHovered(mouseX, mouseY, fps.getX(), fps.getY(), 80, 20)) dragging = fps;
            else if (isHovered(mouseX, mouseY, coords.getX(), coords.getY(), 150, 20)) dragging = coords;
            else if (isHovered(mouseX, mouseY, notifications.getX(), notifications.getY(), 150, 60)) dragging = notifications;
            else if (isHovered(mouseX, mouseY, session.getX(), session.getY(), 120, 20)) dragging = session;
            else if (isHovered(mouseX, mouseY, radar.getX(), radar.getY(), 100, 100)) dragging = radar;
            else if (isHovered(mouseX, mouseY, potion.getX(), potion.getY(), 120, 100)) dragging = potion;

            if (dragging != null) {
                dragOffsetX = (int) mouseX;
                dragOffsetY = (int) mouseY;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (dragging != null) {
            int newX = (int) mouseX - dragOffsetX;
            int newY = (int) mouseY - dragOffsetY;

            if (dragging instanceof ArrayListElement e) e.setPosition(newX, newY);
            else if (dragging instanceof WatermarkElement e) e.setPosition(newX, newY);
            else if (dragging instanceof CpsElement e) e.setPosition(newX, newY);
            else if (dragging instanceof KeystrokesElement e) e.setPosition(newX, newY);
            else if (dragging instanceof TargetHudElement e) e.setPosition(newX, newY);
            else if (dragging instanceof ArmorElement e) e.setPosition(newX, newY);
            else if (dragging instanceof FpsElement e) e.setPosition(newX, newY);
            else if (dragging instanceof CoordsElement e) e.setPosition(newX, newY);
            else if (dragging instanceof NotificationElement e) e.setPosition(newX, newY);
            else if (dragging instanceof SessionElement e) e.setPosition(newX, newY);
            else if (dragging instanceof RadarElement e) e.setPosition(newX, newY);
            else if (dragging instanceof PotionElement e) e.setPosition(newX, newY);
            
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public void onClose() {
        NightfallClient.getInstance().configManager.save("hud_layout");
        super.onClose();
    }

    private boolean isHovered(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}