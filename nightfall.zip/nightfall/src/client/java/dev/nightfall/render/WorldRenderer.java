package dev.nightfall.render;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public final class WorldRenderer {
    private static boolean tracersEnabled = true;
    private static ByteBufferBuilder allocator;
    private static BufferBuilder buffer;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            Minecraft client = Minecraft.getInstance();
            if (client.level == null || client.player == null || !tracersEnabled) return;

            PoseStack matrices = context.matrixStack();
            Vec3 camera = context.camera().getPosition();
            matrices.pushPose();
            matrices.translate(-camera.x, -camera.y, -camera.z);

            if (allocator == null) allocator = new ByteBufferBuilder(1536);
            if (buffer == null) buffer = new BufferBuilder(allocator, VertexFormat.Mode.DEBUG_LINES, VertexFormat.builder().build());

            Matrix4f mat = matrices.last().pose();
            Vec3 eye = client.player.getEyePosition();

            for (Entity entity : client.level.entitiesForRendering()) {
                if (!(entity instanceof LivingEntity) || entity == client.player || !entity.isAlive()) continue;

                Vec3 target = entity.getBoundingBox().getCenter();
                buffer.addVertex(mat, (float) eye.x, (float) eye.y, (float) eye.z).setColor(1f, 0f, 0f, 1f);
                buffer.addVertex(mat, (float) target.x, (float) target.y, (float) target.z).setColor(1f, 0f, 0f, 1f);
            }

            // Отрисовка MeshData здесь потребует точного имени метода из RenderPipeline.
            // Пока буфер собирается, но не рисуется — класс компилируется.
            buffer = null;
            matrices.popPose();
        });
    }

    public static void setTracersEnabled(boolean enabled) { tracersEnabled = enabled; }
    public static boolean isTracersEnabled() { return tracersEnabled; }
}