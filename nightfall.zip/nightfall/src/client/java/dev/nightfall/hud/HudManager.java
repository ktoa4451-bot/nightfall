package dev.nightfall.hud;

import dev.nightfall.hud.element.*;
import dev.nightfall.render.PlayerEsp;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

public class HudManager {
    public static final TargetHudElement TARGET_HUD = new TargetHudElement();
    public static final KeystrokesElement KEYSTROKES = new KeystrokesElement();
    public static final CpsElement CPS = new CpsElement();
    public static final ArrayListElement ARRAY_LIST = new ArrayListElement();
    public static final WatermarkElement WATERMARK = new WatermarkElement();
    public static final ArmorElement ARMOR = new ArmorElement();
    public static final FpsElement FPS = new FpsElement();
    public static final CoordsElement COORDS = new CoordsElement();
    public static final NotificationElement NOTIFICATIONS = new NotificationElement();
    public static final SessionElement SESSION = new SessionElement();
    public static final RadarElement RADAR = new RadarElement();
    public static final PotionElement POTION = new PotionElement();
    public static final TargetArrowsElement ARROWS = new TargetArrowsElement();
    public static final BreadcrumbsElement BREADCRUMBS = new BreadcrumbsElement();

    public void register() {
        reg("target_hud", TARGET_HUD);
        reg("keystrokes", KEYSTROKES);
        reg("cps", CPS);
        reg("arraylist", ARRAY_LIST);
        reg("watermark", WATERMARK);
        reg("armor", ARMOR);
        reg("fps", FPS);
        reg("coords", COORDS);
        reg("notifications", NOTIFICATIONS);
        reg("session", SESSION);
        reg("radar", RADAR);
        reg("potion", POTION);
        reg("arrows", ARROWS);
        reg("breadcrumbs", BREADCRUMBS);

        // Player ESP как HUD-элемент (рисует боксы и линии поверх игры)
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "player_esp"),
                (guiGraphics, deltaTracker) -> PlayerEsp.render(guiGraphics, Minecraft.getInstance(), deltaTracker.getGameTimeDeltaPartialTick(true))
        );
    }

    private void reg(String id, net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement element) {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", id),
                element
        );
    }
}