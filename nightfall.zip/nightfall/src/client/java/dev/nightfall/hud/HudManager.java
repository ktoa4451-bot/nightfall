package dev.nightfall.hud;

import dev.nightfall.hud.element.*;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.ResourceLocation;

public class HudManager {
    public static final TargetHudElement TARGET_HUD = new TargetHudElement();
    public static final KeystrokesElement KEYSTROKES = new KeystrokesElement();
    public static final CpsElement CPS = new CpsElement();
    public static final ArrayListElement ARRAY_LIST = new ArrayListElement();
    public static final WatermarkElement WATERMARK = new WatermarkElement();
    public static final ArmorElement ARMOR = new ArmorElement();
    public static final FpsElement FPS = new FpsElement();
    public static final CoordsElement COORDS = new CoordsElement();

    public void register() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "target_hud"), TARGET_HUD);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "keystrokes"), KEYSTROKES);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "cps"), CPS);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "arraylist"), ARRAY_LIST);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "watermark"), WATERMARK);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "armor"), ARMOR);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "fps"), FPS);
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "coords"), COORDS);
    }
}