package dev.nightfall.hud.element;

import dev.nightfall.NightfallClient;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class KeystrokesElement implements HudElement {
    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        var mod = NightfallClient.getInstance().moduleManager
                .getByName("Keystrokes").orElse(null);
        if (mod == null || !mod.isEnabled()) return;

        Minecraft client = Minecraft.getInstance();
        int x = 10;
        int y = client.getWindow().getGuiScaledHeight() - 80;

        drawKey(g, client, x + 20, y, 18, 18, "W", client.options.keyUp.isDown());
        drawKey(g, client, x, y + 20, 18, 18, "A", client.options.keyLeft.isDown());
        drawKey(g, client, x + 20, y + 20, 18, 18, "S", client.options.keyDown.isDown());
        drawKey(g, client, x + 40, y + 20, 18, 18, "D", client.options.keyRight.isDown());
        drawKey(g, client, x, y + 40, 58, 14, "SPACE", client.options.keyJump.isDown());
    }

    private void drawKey(GuiGraphics g, Minecraft client, int x, int y,
                         int w, int h, String label, boolean pressed) {
        g.fill(x, y, x + w, y + h, pressed ? 0xFF7C5CFF : 0xCC1A1A22);
        int tw = client.font.width(label);
        g.drawString(client.font, label, x + (w - tw) / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }
}