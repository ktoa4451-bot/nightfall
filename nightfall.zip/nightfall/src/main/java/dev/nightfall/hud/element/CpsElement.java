package dev.nightfall.hud.element;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.CpsCounter;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class CpsElement implements HudElement {
    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        var m = NightfallClient.getInstance().moduleManager
                .getByName("CpsCounter").orElse(null);
        if (!(m instanceof CpsCounter cps) || !cps.isEnabled()) return;

        Minecraft client = Minecraft.getInstance();
        int x = client.getWindow().getGuiScaledWidth() / 2 - 40;
        int y = client.getWindow().getGuiScaledHeight() - 40;

        g.fill(x, y, x + 80, y + 14, 0xCC15151C);
        String text = "L " + cps.getLeftCps() + " | R " + cps.getRightCps();
        g.drawString(client.font, text, x + 4, y + 3, 0xFFFFFFFF);
    }
}