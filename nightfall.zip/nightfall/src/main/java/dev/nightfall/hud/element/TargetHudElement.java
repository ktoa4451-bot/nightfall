package dev.nightfall.hud.element;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.TargetHud;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;

public class TargetHudElement implements HudElement {
    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        TargetHud mod = (TargetHud) NightfallClient.getInstance().moduleManager
                .getByName("TargetHud").orElse(null);
        if (mod == null || !mod.isEnabled()) return;

        LivingEntity target = mod.getTarget();
        if (target == null) return;

        Minecraft client = Minecraft.getInstance();
        int x = client.getWindow().getGuiScaledWidth() / 2 + 20;
        int y = client.getWindow().getGuiScaledHeight() / 2 + 20;

        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();

        g.fill(x, y, x + 140, y + 40, 0xCC15151C);
        g.drawString(client.font, name, x + 6, y + 4, 0xFFFFFFFF);

        int barW = 128;
        int filled = (int) (barW * Math.min(1f, hp / Math.max(0.01f, maxHp)));
        g.fill(x + 6, y + 20, x + 6 + barW, y + 26, 0xFF331111);
        g.fill(x + 6, y + 20, x + 6 + filled, y + 26, 0xFFFF3355);

        g.drawString(client.font, String.format("%.1f", hp), x + 6, y + 30, 0xFFFFAAAA);

        double dist = client.player != null ? client.player.distanceTo(target) : 0;
        g.drawString(client.font, String.format("%.1fm", dist), x + 100, y + 30, 0xFFAAAAFF);
    }
}