package dev.nightfall.hud;

import dev.nightfall.hud.element.CpsElement;
import dev.nightfall.hud.element.KeystrokesElement;
import dev.nightfall.hud.element.TargetHudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.resources.ResourceLocation;

public class HudManager {
    public void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "target_hud"),
                new TargetHudElement()
        );

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "keystrokes"),
                new KeystrokesElement()
        );

        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                ResourceLocation.fromNamespaceAndPath("nightfall", "cps"),
                new CpsElement()
        );
    }
}