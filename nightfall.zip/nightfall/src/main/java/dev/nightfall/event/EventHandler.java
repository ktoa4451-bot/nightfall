package dev.nightfall.event;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.Module;
import dev.nightfall.module.impl.combat.AimAssist;
import net.minecraft.client.Minecraft;

public class EventHandler {
    public void onTick(Minecraft client) {
        if (client.player == null) return;

        for (Module m : NightfallClient.getInstance().moduleManager.getModules()) {
            if (!m.isEnabled()) continue;
            if (m instanceof AimAssist aa) aa.onTick(client);
        }
    }
}