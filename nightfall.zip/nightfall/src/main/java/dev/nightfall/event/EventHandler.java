package dev.nightfall.event;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.Module;
import dev.nightfall.module.impl.combat.AimAssist;
import dev.nightfall.module.impl.movement.Sprint;
import dev.nightfall.module.impl.visuals.CpsCounter;
import net.minecraft.client.Minecraft;

public class EventHandler {
    private boolean lastAttackDown = false;
    private boolean lastUseDown = false;

    public void onTick(Minecraft client) {
        if (client.player == null) return;

        boolean attackDown = client.options.keyAttack.isDown();
        boolean useDown = client.options.keyUse.isDown();

        if (attackDown && !lastAttackDown) triggerCps(true);
        if (useDown && !lastUseDown) triggerCps(false);

        lastAttackDown = attackDown;
        lastUseDown = useDown;

        for (Module m : NightfallClient.getInstance().moduleManager.getModules()) {
            if (!m.isEnabled()) continue;
            if (m instanceof AimAssist aa) aa.onTick(client);
            if (m instanceof Sprint sp) sp.onTick(client);
        }
    }

    private void triggerCps(boolean left) {
        var mod = NightfallClient.getInstance().moduleManager.getByName("CpsCounter").orElse(null);
        if (mod instanceof CpsCounter cps && cps.isEnabled()) cps.onClick(left);
    }
}