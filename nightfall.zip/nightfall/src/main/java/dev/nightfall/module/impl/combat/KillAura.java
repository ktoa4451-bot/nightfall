package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class KillAura extends Module {
    private final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 3.0, 1.0, 6.0);
    private LivingEntity target;

    public KillAura() {
        super("KillAura", "Training aura (local only).", Category.COMBAT);
        settings.add(range);
    }

    @Override public void onEnable() { target = null; }
    @Override public void onDisable() { target = null; }

    public void onTick(Minecraft client) {
        if (!isEnabled() || client.player == null || client.level == null) return;
        // Ограничение: только локальный мир
        if (!client.hasSingleplayerServer()) { target = null; return; }

        target = null;
        double maxDist = range.getValue();
        for (Entity e : client.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity living) || living == client.player || !living.isAlive()) continue;
            if (client.player.distanceTo(living) <= maxDist) { target = living; break; }
        }
    }

    public LivingEntity getTarget() { return target; }
}