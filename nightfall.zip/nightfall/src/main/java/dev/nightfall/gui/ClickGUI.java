package dev.nightfall.gui;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.List;

public class ClickGUI extends Screen {
    private Category selected = Category.COMBAT;

    private static final int PANEL_X = 40;
    private static final int PANEL_Y = 40;
    private static final int PANEL_W = 140;

    public ClickGUI() {
        super(Component.literal("Nightfall"));
    }

    public static void open() {
        Minecraft.getInstance().setScreen(new ClickGUI());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        g.fill(0, 0, this.width, this.height, 0xCC0A0A0F);
        g.fill(PANEL_X, PANEL_Y, PANEL_X + PANEL_W, this.height - 40, 0xFF15151C);

        int y = PANEL_Y + 10;
        for (Category c : Category.values()) {
            boolean sel = c == selected;
            g.fill(PANEL_X + 5, y, PANEL_X + PANEL_W - 5, y + 18,
                    sel ? 0xFF2A2A38 : 0xFF1A1A22);
            g.drawString(this.font, c.getDisplayName(), PANEL_X + 10, y + 5,
                    sel ? 0xFFFFFFFF : 0xFFAAAAAA);
            y += 22;
        }

        int cx = PANEL_X + PANEL_W + 20;
        int cy = PANEL_Y + 10;
        g.drawString(this.font, selected.getDisplayName(), cx, cy, 0xFFFFFFFF);

        int listY = cy + 20;
        for (Module m : NightfallClient.getInstance().moduleManager.getByCategory(selected)) {
            g.fill(cx, listY, cx + 160, listY + 16,
                    m.isEnabled() ? 0xFF7C5CFF : 0xFF444455);
            g.drawString(this.font, m.getName(), cx + 6, listY + 4, 0xFFFFFFFF);
            listY += 20;
        }

        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int y = PANEL_Y + 10;
        for (Category c : Category.values()) {
            if (mx >= PANEL_X + 5 && mx <= PANEL_X + PANEL_W - 5
                    && my >= y && my <= y + 18) {
                selected = c;
                return true;
            }
            y += 22;
        }

        int cx = PANEL_X + PANEL_W + 20;
        int listY = PANEL_Y + 10 + 20;
        List<Module> mods = NightfallClient.getInstance().moduleManager.getByCategory(selected);
        for (Module m : mods) {
            if (mx >= cx && mx <= cx + 160 && my >= listY && my <= listY + 16) {
                if (button == 0) m.toggle();
                else if (button == 1) NightfallClient.getInstance().configManager.save("default");
                return true;
            }
            listY += 20;
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}