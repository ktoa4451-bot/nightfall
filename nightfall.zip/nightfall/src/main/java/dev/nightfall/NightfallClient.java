package dev.nightfall;

import dev.nightfall.config.ConfigManager;
import dev.nightfall.event.EventHandler;
import dev.nightfall.module.ModuleManager;
import dev.nightfall.module.impl.combat.AimAssist;
import dev.nightfall.module.impl.combat.KillAura;
import dev.nightfall.module.impl.combat.ReachDisplay;
import dev.nightfall.module.impl.misc.Fullbright;
import dev.nightfall.module.impl.movement.Sprint;
import dev.nightfall.module.impl.visuals.CpsCounter;
import dev.nightfall.module.impl.visuals.Keystrokes;
import dev.nightfall.module.impl.visuals.TargetHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NightfallClient implements ClientModInitializer {
    public static final String MOD_ID = "nightfall";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static NightfallClient instance;

    public ModuleManager moduleManager;
    public ConfigManager configManager;
    public EventHandler eventHandler;
    public KeyMapping openGuiKey;

    public static NightfallClient getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        // Инициализация менеджеров
        configManager = new ConfigManager();
        moduleManager = new ModuleManager();
        eventHandler = new EventHandler();

        // Регистрация всех модулей
        moduleManager.register(new AimAssist());
        moduleManager.register(new KillAura());
        moduleManager.register(new ReachDisplay());
        moduleManager.register(new CpsCounter());
        moduleManager.register(new Keystrokes());
        moduleManager.register(new TargetHud());
        moduleManager.register(new Sprint());
        moduleManager.register(new Fullbright());

        // Регистрация клавиши для открытия меню (Right Shift)
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.nightfall.opengui",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.nightfall"
        ));

        // Обработка событий каждый тик
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            eventHandler.onTick(client);
            
            // Открытие ClickGUI
            while (openGuiKey.consumeClick()) {
                if (client.screen == null) {
                    dev.nightfall.gui.ClickGUI.open();
                }
            }
        });

        // Регистрация HUD-элементов
        new dev.nightfall.hud.HudManager().register();
        
        // Регистрация мирового рендера (Tracers)
        dev.nightfall.render.WorldRenderer.register();

        // Загрузка конфига
        configManager.load("default");

        LOGGER.info("Nightfall Client initialized. Modules: {}", moduleManager.getModules().size());
    }
}