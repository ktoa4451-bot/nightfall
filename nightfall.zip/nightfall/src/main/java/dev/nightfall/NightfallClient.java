package dev.nightfall;

import dev.nightfall.config.ConfigManager;
import dev.nightfall.event.EventHandler;
import dev.nightfall.module.ModuleManager;
import dev.nightfall.module.impl.combat.AimAssist;
import dev.nightfall.module.impl.combat.ReachDisplay;
import dev.nightfall.module.impl.visuals.CpsCounter;
import dev.nightfall.module.impl.visuals.Keystrokes;
import dev.nightfall.module.impl.visuals.TargetHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NightfallClient implements ClientModInitializer {
    public static final String MOD_ID = "nightfall";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static NightfallClient instance;

    public ModuleManager moduleManager;
    public ConfigManager configManager;
    public EventHandler eventHandler;
    public KeyMapping openGuiKey;

    public static NightfallClient getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        configManager = new ConfigManager();
        moduleManager = new ModuleManager();
        eventHandler = new EventHandler();

        moduleManager.register(new AimAssist());
        moduleManager.register(new ReachDisplay());
        moduleManager.register(new CpsCounter());
        moduleManager.register(new Keystrokes());
        moduleManager.register(new TargetHud());

        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.nightfall.opengui",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.nightfall"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            eventHandler.onTick(client);
            while (openGuiKey.consumeClick()) {
                dev.nightfall.gui.ClickGUI.open();
            }
        });

        configManager.load("default");

        LOGGER.info("Nightfall initialized. Modules: {}", moduleManager.getModules().size());
    }
}