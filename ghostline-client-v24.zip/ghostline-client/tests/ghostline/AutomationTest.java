import com.ghostline.mod.automation.*;
import java.util.*;
import java.util.function.*;

/** Pathfinder + TaskManager tests on synthetic grids (pure Java, no Minecraft). These are logic tests, not in-game tests. */
public class AutomationTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }

    /** Flat floor at y=63 (solid), air above, inside x,z in [0,size). Everything else UNKNOWN unless overridden. */
    static class Grid implements WorldView {
        final Map<String, Kind> over = new HashMap<>();
        final int size; final boolean unknownOutside;
        Grid(int size, boolean unknownOutside) { this.size = size; this.unknownOutside = unknownOutside; }
        void set(int x, int y, int z, Kind k) { over.put(x + "," + y + "," + z, k); }
        public Kind kind(int x, int y, int z) {
            Kind o = over.get(x + "," + y + "," + z); if (o != null) return o;
            if (x < 0 || z < 0 || x >= size || z >= size) return unknownOutside ? Kind.UNKNOWN : Kind.AIR;
            if (y < 63) return Kind.SOLID;
            return Kind.AIR;
        }
    }

    static class TestTask extends AutomationTask {
        int ticks, stopped; TaskState stopState; boolean move; int doneAfter; boolean boom; boolean failStart;
        TestTask(String n, int prio, long timeout, boolean move, int doneAfter) { super(n, prio, timeout); this.move = move; this.doneAfter = doneAfter; }
        public boolean controlsMovement() { return move; }
        protected AutomationResult onStart(long now) { return failStart ? AutomationResult.failure("cannot start") : AutomationResult.success("go"); }
        protected AutomationResult onTick(long now) {
            ticks++; if (boom) throw new IllegalStateException("boom");
            return doneAfter > 0 && ticks >= doneAfter ? AutomationResult.success("done") : null;
        }
        protected void onStop(TaskState s, String r) { stopped++; stopState = s; }
    }

    /** A deep trench x0..x1 across the whole map (cannot be walked through: too deep to climb out of). */
    static Grid trench(int x0, int x1) {
        Grid g = new Grid(30, true);
        for (int z = 0; z < 30; z++) for (int x = x0; x <= x1; x++) for (int y = 40; y <= 64; y++) g.set(x, y, z, WorldView.Kind.AIR);
        return g;
    }

    static boolean validPath(WorldView w, Path p, int maxFall) {
        Pathfinder pf = new Pathfinder(w, null);
        int[] prev = null;
        for (int[] n : p.nodes()) {
            if (!pf.standable(n[0], n[1], n[2])) return false;
            if (prev != null) {
                int dx = Math.abs(n[0] - prev[0]), dz = Math.abs(n[2] - prev[2]), dy = n[1] - prev[1];
                if (dx + dz != 1 || dy > 1 || dy < -maxFall) return false;
            }
            prev = n;
        }
        return true;
    }

    public static void main(String[] a) {
        // ---------- Pathfinder
        Grid g = new Grid(30, true);
        Path p = new Pathfinder(g, null).find(1, 63, 1, 10, 63, 1);
        check("flat: path found, length 10", p.found() && p.length() == 10);
        check("flat: every step valid", validPath(g, p, 3));
        check("same start and goal", new Pathfinder(g, null).find(2, 63, 2, 2, 63, 2).found());

        // wall across x=5 for z in 0..9 -> must go around (z=10 open)
        Grid w = new Grid(30, true);
        for (int z = 0; z < 10; z++) { w.set(5, 63, z, WorldView.Kind.SOLID); w.set(5, 64, z, WorldView.Kind.SOLID); }
        Path pw = new Pathfinder(w, null).find(1, 63, 1, 9, 63, 1);
        check("wall: detour found", pw.found() && pw.length() > 9);
        check("wall: detour never enters wall", validPath(w, pw, 3));

        // one block step up and a 3-block drop
        Grid s = new Grid(30, true);
        s.set(5, 63, 1, WorldView.Kind.SOLID); // floor block raised by one at x=5 (feet at y=64)
        for (int x = 5; x < 30; x++) for (int z = 0; z < 30; z++) s.set(x, 63, z, WorldView.Kind.SOLID);
        Path ps = new Pathfinder(s, null).find(1, 63, 1, 8, 64, 1);
        check("step up 1 block", ps.found() && validPath(s, ps, 3));
        // 2 blocks high wall cannot be jumped
        Grid hi = new Grid(30, true);
        for (int z = 0; z < 30; z++) { hi.set(5, 63, z, WorldView.Kind.SOLID); hi.set(5, 64, z, WorldView.Kind.SOLID); }
        check("2-high wall across the whole map: no path", !new Pathfinder(hi, null).find(1, 63, 1, 9, 63, 1).found());
        // pit 3 deep: dropping allowed, climbing back not
        Grid pit = new Grid(30, true);
        for (int x = 5; x < 30; x++) for (int z = 0; z < 30; z++) { for (int y = 60; y < 63; y++) pit.set(x, y, z, WorldView.Kind.AIR); }
        Path down = new Pathfinder(pit, null).find(4, 63, 1, 6, 60, 1);
        check("drop of 3 blocks allowed", down.found());
        Path back = new Pathfinder(pit, null).find(6, 60, 1, 4, 63, 1);
        check("climbing 3 blocks back is not possible", !back.found());
        Pathfinder.Options lowFall = new Pathfinder.Options(); lowFall.maxFall = 1;
        check("maxFall=1 forbids that drop", !new Pathfinder(pit, lowFall).find(4, 63, 1, 6, 60, 1).found());

        // enclosed goal
        Grid box = new Grid(30, true);
        for (int x = 9; x <= 11; x++) for (int z = 0; z <= 2; z++) if (!(x == 10 && z == 1)) { box.set(x, 63, z, WorldView.Kind.SOLID); box.set(x, 64, z, WorldView.Kind.SOLID); }
        check("goal enclosed by walls: NO_PATH", new Pathfinder(box, null).find(1, 63, 1, 10, 63, 1).status() == Path.Status.NO_PATH);

        // lava: floor made of lava between start and goal across the whole map width
        Grid lava = new Grid(30, true);
        for (int z = 0; z < 30; z++) { lava.set(5, 62, z, WorldView.Kind.DANGER); lava.set(5, 63, z, WorldView.Kind.DANGER); }
        check("lava line across the map: no path", !new Pathfinder(lava, null).find(1, 63, 1, 9, 63, 1).found());
        Grid lava2 = new Grid(30, true);
        for (int z = 0; z < 20; z++) { lava2.set(5, 62, z, WorldView.Kind.DANGER); lava2.set(5, 63, z, WorldView.Kind.DANGER); }
        Path pl = new Pathfinder(lava2, null).find(1, 63, 1, 9, 63, 1);
        check("lava with a gap: route avoids lava", pl.found() && validPath(lava2, pl, 3));
        boolean touches = false; for (int[] n : pl.nodes()) if (n[0] == 5 && n[2] < 20) touches = true;
        check("lava route never stands on lava", !touches);
        Grid goalLava = new Grid(30, true); goalLava.set(9, 62, 1, WorldView.Kind.DANGER);
        check("goal above danger rejected", new Pathfinder(goalLava, null).find(1, 63, 1, 9, 63, 1).status() == Path.Status.INVALID);

        // unknown blocks are not safe
        Grid unk = new Grid(30, true);
        for (int z = 0; z < 30; z++) unk.set(5, 63, z, WorldView.Kind.UNKNOWN);
        check("unknown strip: no path through unknown", !new Pathfinder(unk, null).find(1, 63, 1, 9, 63, 1).found());
        check("goal outside loaded area rejected", new Pathfinder(g, null).find(1, 63, 1, 50, 63, 1).status() == Path.Status.INVALID);

        // water
        Grid wat = new Grid(30, true);
        for (int z = 0; z < 30; z++) { wat.set(5, 63, z, WorldView.Kind.WATER); wat.set(5, 64, z, WorldView.Kind.WATER); }
        check("water not allowed by default: no path", !new Pathfinder(wat, null).find(1, 63, 1, 9, 63, 1).found());
        Pathfinder.Options sw = new Pathfinder.Options(); sw.allowWater = true;
        // with water the floor under (5,63) is water kind=WATER at y=63 -> swimming node needs water at feet and below
        for (int z = 0; z < 30; z++) { wat.set(5, 62, z, WorldView.Kind.WATER); }
        check("water allowed: crossing a river works", new Pathfinder(wat, sw).find(1, 63, 1, 9, 63, 1).found());


        // ladders: a 5-high wall across the whole map, a ladder column at x=4, upper floor at x>=5
        Grid lad = new Grid(30, true);
        for (int x = 5; x < 30; x++) for (int z = 0; z < 30; z++) for (int y = 63; y <= 67; y++) lad.set(x, y, z, WorldView.Kind.SOLID);
        for (int y = 63; y <= 68; y++) lad.set(4, y, 1, WorldView.Kind.CLIMB);
        Path up = new Pathfinder(lad, null).find(2, 63, 1, 8, 68, 1);
        check("ladder: climbs a 5-high wall", up.found());
        boolean usesLadder = false; for (int[] n : up.nodes()) if (n[0] == 4 && n[1] >= 65) usesLadder = true;
        check("ladder: route really goes up the ladder column", usesLadder);
        Pathfinder.Options noClimb = new Pathfinder.Options(); noClimb.allowClimb = false;
        check("ladder: no route when climbing is disabled", !new Pathfinder(lad, noClimb).find(2, 63, 1, 8, 68, 1).found());
        Path downL = new Pathfinder(lad, null).find(8, 68, 1, 2, 63, 1);
        check("ladder: climbing down works too", downL.found());
        Grid noLad = new Grid(30, true);
        for (int x = 5; x < 30; x++) for (int z = 0; z < 30; z++) for (int y = 63; y <= 67; y++) noLad.set(x, y, z, WorldView.Kind.SOLID);
        check("same wall without a ladder: no path", !new Pathfinder(noLad, null).find(2, 63, 1, 8, 68, 1).found());
        // vertical shaft with a ladder reaching the cave floor
        Grid shaft = new Grid(30, true);
        for (int y = 55; y <= 62; y++) shaft.set(3, y, 3, WorldView.Kind.CLIMB);
        for (int y = 40; y <= 54; y++) for (int x = 0; x < 30; x++) for (int z = 0; z < 30; z++) shaft.set(x, y, z, WorldView.Kind.SOLID);
        check("ladder shaft down to a cave floor", new Pathfinder(shaft, null).find(2, 63, 3, 3, 55, 3).found());

        // tunnelling: a 2-high, 3-thick rock wall across the whole map made of BREAKABLE blocks
        Grid rock = new Grid(30, true);
        for (int x = 5; x <= 7; x++) for (int z = 0; z < 30; z++) { rock.set(x, 63, z, WorldView.Kind.BREAKABLE); rock.set(x, 64, z, WorldView.Kind.BREAKABLE); }
        check("rock wall: no path when digging is off", !new Pathfinder(rock, null).find(1, 63, 1, 12, 63, 1).found());
        Pathfinder.Options dig = new Pathfinder.Options(); dig.allowBreak = true;
        Path tun = new Pathfinder(rock, dig).find(1, 63, 1, 12, 63, 1);
        check("rock wall: tunnel found when digging is on", tun.found());
        int dug = 0; for (int[] n : tun.nodes()) if (rock.kind(n[0], n[1], n[2]) == WorldView.Kind.BREAKABLE) dug++;
        check("tunnel digs only the 3 cells it needs (" + dug + ")", dug == 3);
        // a gap in the wall: walking around is cheaper than digging 3 cells
        rock.set(6, 63, 2, WorldView.Kind.AIR); rock.set(6, 64, 2, WorldView.Kind.AIR); rock.set(5, 63, 2, WorldView.Kind.AIR); rock.set(5, 64, 2, WorldView.Kind.AIR); rock.set(7, 63, 2, WorldView.Kind.AIR); rock.set(7, 64, 2, WorldView.Kind.AIR);
        Path gap = new Pathfinder(rock, dig).find(1, 63, 1, 12, 63, 1);
        int dug2 = 0; for (int[] n : gap.nodes()) if (rock.kind(n[0], n[1], n[2]) == WorldView.Kind.BREAKABLE) dug2++;
        check("gap in the wall: route uses the gap, no digging", gap.found() && dug2 == 0);
        // a breakable floor is a normal floor even without digging
        Grid floor = new Grid(30, true); for (int x = 0; x < 30; x++) for (int z = 0; z < 30; z++) floor.set(x, 62, z, WorldView.Kind.BREAKABLE);
        check("breakable floor can be walked on", new Pathfinder(floor, null).find(1, 63, 1, 9, 63, 1).found());
        // falling through a column of breakable blocks is not a fall
        Grid column = new Grid(30, true); for (int y = 60; y <= 63; y++) column.set(6, y, 1, WorldView.Kind.BREAKABLE);
        for (int y = 55; y <= 62; y++) column.set(6, y, 1, WorldView.Kind.BREAKABLE);
        check("never plans a drop through blocks that still have to be dug", !new Pathfinder(column, null).find(5, 63, 1, 6, 61, 1).found());

        // budget
        Pathfinder.Options tiny = new Pathfinder.Options(); tiny.maxNodes = 5;
        Path b = new Pathfinder(new Grid(200, false), tiny).find(1, 63, 1, 150, 63, 150);
        check("node budget stops the search", b.status() == Path.Status.BUDGET && b.expanded() <= 5);
        Pathfinder.Options part = new Pathfinder.Options(); part.maxNodes = 300; part.acceptPartial = true;
        Path pp = new Pathfinder(new Grid(200, false), part).find(1, 63, 1, 150, 63, 150);
        check("partial path returned only when asked, and flagged PARTIAL", pp.status() == Path.Status.PARTIAL && pp.length() > 1);
        long t0 = System.nanoTime();
        Pathfinder.Options bigOpt = new Pathfinder.Options(); bigOpt.maxMillis = 1000;
        Path big = new Pathfinder(new Grid(300, false), bigOpt).find(1, 63, 1, 120, 63, 120);
        long ms = (System.nanoTime() - t0) / 1_000_000;
        check("120+120 blocks on open ground found (" + ms + " ms, " + big.expanded() + " nodes)", big.found());
        // a throwing world view must not crash the search
        WorldView bad = (x, y, z) -> { throw new RuntimeException("chunk gone"); };
        check("world view that throws -> INVALID, no exception", new Pathfinder(bad, null).find(0, 63, 0, 5, 63, 0).status() == Path.Status.INVALID);

        // ---------- TaskManager
        long now = 1000;
        TaskManager tm = new TaskManager();
        List<String> ev = new ArrayList<>();
        tm.addListener(e -> ev.add(e.type() + ":" + e.task().name));
        TestTask lo = new TestTask("lo", 1, 0, true, 0), hi2 = new TestTask("hi", 5, 0, true, 0), side = new TestTask("side", 0, 0, false, 0);
        check("submit ok", tm.submit(lo) && tm.submit(hi2) && tm.submit(side));
        check("same task cannot be queued twice", !tm.submit(lo));
        tm.tick(now, true);
        check("higher priority movement task starts first", hi2.state() == TaskState.RUNNING && lo.state() == TaskState.IDLE);
        check("non movement task runs next to it", side.state() == TaskState.RUNNING);
        check("only one movement owner", tm.movementOwner() == hi2);
        tm.pause(hi2, now + 10);
        tm.tick(now + 20, true);
        check("paused movement task keeps the slot (lo still waiting)", hi2.state() == TaskState.PAUSED && lo.state() == TaskState.IDLE);
        int before = hi2.ticks; tm.tick(now + 30, true);
        check("paused task is not ticked", hi2.ticks == before);
        check("resume works", tm.resume(hi2, now + 40) && hi2.state() == TaskState.RUNNING);
        tm.cancel(hi2, now + 50, "user");
        check("cancel: state, reason and onStop once", hi2.state() == TaskState.CANCELLED && hi2.stopReason().equals("user") && hi2.stopped == 1 && hi2.stopState == TaskState.CANCELLED);
        tm.tick(now + 60, true);
        check("next movement task starts after cancel", lo.state() == TaskState.RUNNING);
        check("finished task cannot be resumed or restarted", !tm.resume(hi2, now) && !tm.submit(hi2));

        TestTask quick = new TestTask("quick", 9, 0, false, 3); tm.submit(quick);
        for (int i = 0; i < 5; i++) tm.tick(now + 100 + i, true);
        check("task completes with result", quick.state() == TaskState.COMPLETED && quick.result().ok() && quick.stopped == 1);

        TestTask crash = new TestTask("crash", 1, 0, false, 0); crash.boom = true; tm.submit(crash);
        tm.tick(now + 200, true);
        tm.tick(now + 201, true);
        check("exception in a task -> FAILED + cleanup, manager keeps running", crash.state() == TaskState.FAILED && crash.stopped == 1 && lo.state() == TaskState.RUNNING);

        TestTask bad2 = new TestTask("badstart", 1, 0, false, 0); bad2.failStart = true; tm.submit(bad2);
        tm.tick(now + 300, true);
        check("onStart failure -> FAILED with reason", bad2.state() == TaskState.FAILED && bad2.result().message().equals("cannot start"));

        TaskManager tm2 = new TaskManager();
        TestTask slow = new TestTask("slow", 1, 100, false, 0); tm2.submit(slow);
        tm2.tick(0, true); tm2.pause(slow, 50); tm2.tick(5000, true); tm2.resume(slow, 5000);
        tm2.tick(5040, true);
        check("timeout counts running time only (pause excluded)", slow.state() == TaskState.RUNNING);
        tm2.tick(5200, true);
        check("timeout fires after the limit", slow.state() == TaskState.FAILED && slow.stopReason().equals("timeout"));

        TaskManager tm3 = new TaskManager();
        TestTask w1 = new TestTask("w1", 1, 0, true, 0), w2 = new TestTask("w2", 1, 0, false, 0); tm3.submit(w1); tm3.submit(w2);
        tm3.tick(0, true);
        tm3.tick(1, false);
        check("world lost -> everything stopped and cleaned", w1.state() == TaskState.CANCELLED && w2.state() == TaskState.CANCELLED && w1.stopped == 1 && !tm3.busy());
        TestTask w3 = new TestTask("w3", 1, 0, true, 0), w4 = new TestTask("w4", 1, 0, true, 0); tm3.submit(w3); tm3.submit(w4);
        tm3.tick(10, true); tm3.stopAll(11, "panic");
        check("stopAll cancels running and queued", w3.state() == TaskState.CANCELLED && w4.state() == TaskState.CANCELLED && w3.stopReason().equals("panic"));

        check("transition table: finished states are final", !TaskState.COMPLETED.canGo(TaskState.RUNNING) && !TaskState.CANCELLED.canGo(TaskState.PAUSED) && !TaskState.IDLE.canGo(TaskState.PAUSED) && TaskState.PAUSED.canGo(TaskState.RUNNING));
        check("events were emitted", ev.contains("STARTED:hi") && ev.contains("CANCELLED:hi") && ev.contains("COMPLETED:quick") && ev.contains("FAILED:crash"));

        // a listener that cancels from inside an event must not break the scheduler
        TaskManager tm4 = new TaskManager();
        TestTask re = new TestTask("re", 1, 0, true, 0); tm4.submit(re);
        tm4.addListener(e -> { if (e.type() == AutomationEvent.Type.STARTED) tm4.tick(5, true); });
        tm4.tick(1, true);
        check("re-entrant tick from a listener is ignored safely", re.state() == TaskState.RUNNING);

        // ---------- parkour (gap jumps)
        Grid gp = trench(5, 6);
        check("trench across the map: no path without parkour", !new Pathfinder(gp, null).find(1, 63, 1, 10, 63, 1).found());
        Pathfinder.Options pk = new Pathfinder.Options(); pk.allowParkour = true; pk.maxGap = 2;
        Path pj = new Pathfinder(gp, pk).find(1, 63, 1, 10, 63, 1);
        check("parkour: 2-gap jump makes a route", pj.found());
        boolean jumpStep = false, allStand = true; int[] pv = null;
        Pathfinder pf2 = new Pathfinder(gp, pk);
        for (int[] n : pj.nodes()) { if (!pf2.standable(n[0], n[1], n[2])) allStand = false; if (pv != null && Math.abs(n[0] - pv[0]) + Math.abs(n[2] - pv[2]) == 3) jumpStep = true; pv = n; }
        check("parkour: every node is standable", allStand);
        check("parkour: the route has a 3-block jump step", jumpStep);
        Pathfinder.Options pk1 = new Pathfinder.Options(); pk1.allowParkour = true; pk1.maxGap = 1;
        check("parkour: maxGap=1 cannot cross a 2-wide trench", !new Pathfinder(gp, pk1).find(1, 63, 1, 10, 63, 1).found());
        Pathfinder.Options pk3 = new Pathfinder.Options(); pk3.allowParkour = true; pk3.maxGap = 3;
        check("parkour: 3-wide trench crossed with maxGap=3", new Pathfinder(trench(5, 7), pk3).find(1, 63, 1, 11, 63, 1).found());
        check("parkour: 3-wide trench not crossed with maxGap=2", !new Pathfinder(trench(5, 7), pk).find(1, 63, 1, 11, 63, 1).found());
        Grid lavaGap = trench(5, 6);
        for (int z = 0; z < 30; z++) for (int x = 5; x <= 6; x++) lavaGap.set(x, 62, z, WorldView.Kind.DANGER);
        check("parkour: never over lava", !new Pathfinder(lavaGap, pk).find(1, 63, 1, 10, 63, 1).found());
        Grid lowRoof = trench(5, 6);
        for (int z = 0; z < 30; z++) lowRoof.set(4, 65, z, WorldView.Kind.SOLID);                               // ceiling above the take-off cell
        check("parkour: no jump without head room", !new Pathfinder(lowRoof, pk).find(1, 63, 1, 10, 63, 1).found());
        Grid lowFar = trench(5, 6);
        for (int z = 0; z < 30; z++) for (int x = 7; x < 30; x++) { lowFar.set(x, 62, z, WorldView.Kind.AIR); }   // far side is one block lower (floor at y=61)
        Path dj = new Pathfinder(lowFar, pk).find(1, 63, 1, 10, 62, 1);
        check("parkour: jump down to a lower far side", dj.found());
        check("parkour: the default options never jump", !new Pathfinder(trench(5, 6), new Pathfinder.Options()).find(1, 63, 1, 10, 63, 1).found());
        System.out.println(pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
