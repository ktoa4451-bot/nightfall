package dev.nightfall.ai;

import com.ghostline.mod.SecretStore;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/** Settings of the AI chat. The API key is stored encrypted (SecretStore), never as plain text and never inside the module config. */
public final class AiStore {
    private AiStore() { }

    private static boolean loaded;
    private static String provider = "anthropic";     // "anthropic" or "openai" (any OpenAI-compatible server)
    private static String model = "";
    private static String url = "";
    private static String keyEnc = "";

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("nightfall").resolve("ai.properties"); }

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        SecretStore.init(FabricLoader.getInstance().getConfigDir());
        Path f = file();
        if (!Files.exists(f)) return;
        try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
            Properties p = new Properties();
            p.load(r);
            provider = p.getProperty("provider", provider);
            model = p.getProperty("model", "");
            url = p.getProperty("url", "");
            keyEnc = p.getProperty("key", "");
        } catch (IOException ignored) { }
    }

    private static void save() {
        try {
            Files.createDirectories(file().getParent());
            Properties p = new Properties();
            p.setProperty("provider", provider);
            p.setProperty("model", model);
            p.setProperty("url", url);
            p.setProperty("key", keyEnc);
            try (Writer w = Files.newBufferedWriter(file(), StandardCharsets.UTF_8)) { p.store(w, "Ghostline Client AI chat"); }
        } catch (IOException ignored) { }
    }

    public static synchronized String provider() { load(); return provider; }
    public static synchronized boolean hasKey() { load(); return !keyEnc.isEmpty(); }
    public static synchronized String key() { load(); return SecretStore.decrypt(keyEnc); }

    public static synchronized boolean setKey(String k) {
        load();
        String enc = SecretStore.encrypt(k == null ? "" : k.trim());
        if (enc.isEmpty()) return false;               // could not encrypt: do not store anything
        keyEnc = enc;
        save();
        return true;
    }

    public static synchronized boolean setProvider(String p) {
        load();
        p = p.toLowerCase(Locale.ROOT);
        if (!p.equals("anthropic") && !p.equals("openai")) return false;
        provider = p; save();
        return true;
    }

    public static synchronized void setModel(String m) { load(); model = m.trim(); save(); }

    /** Returns false when the address is not https (plain http is only accepted for localhost). */
    public static synchronized boolean setUrl(String u) {
        load();
        u = u.trim();
        if (!u.isEmpty() && !allowed(u)) return false;
        url = u; save();
        return true;
    }

    public static boolean allowed(String u) {
        try {
            URI x = URI.create(u);
            String host = x.getHost();
            if (host == null) return false;
            if ("https".equalsIgnoreCase(x.getScheme())) return true;
            return "http".equalsIgnoreCase(x.getScheme()) && (host.equals("localhost") || host.equals("127.0.0.1") || host.equals("[::1]"));
        } catch (RuntimeException e) { return false; }
    }

    public static synchronized String effectiveModel() {
        load();
        if (!model.isEmpty()) return model;
        return provider.equals("openai") ? "gpt-4o-mini" : "claude-sonnet-5-5";
    }

    public static synchronized String effectiveUrl() {
        load();
        if (!url.isEmpty()) return url;
        return provider.equals("openai") ? "https://api.openai.com/v1/chat/completions" : "https://api.anthropic.com/v1/messages";
    }
}
