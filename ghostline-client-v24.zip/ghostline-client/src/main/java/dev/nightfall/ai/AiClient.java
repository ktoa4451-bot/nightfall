package dev.nightfall.ai;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Sends the chat to the AI service the player configured (Anthropic or any OpenAI-compatible server) and returns the answer.
 * Only the typed messages of this chat are sent, nothing about the game. The callback runs on a network thread.
 */
public final class AiClient {
    private AiClient() { }

    public record Turn(String role, String text) { }

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private static final String SYSTEM = "You are a helpful assistant inside the chat of a Minecraft client. Keep answers short (a few sentences) unless asked for more.";
    private static final List<Turn> HISTORY = new ArrayList<>();
    private static final int MAX_TURNS = 20;

    public static synchronized void clear() { HISTORY.clear(); }

    /** Adds the question to the history, asks the service and passes the answer (or "Error: ...") to done. */
    public static void chat(String userText, Consumer<String> done) {
        List<Turn> copy;
        synchronized (AiClient.class) {
            HISTORY.add(new Turn("user", userText));
            while (HISTORY.size() > MAX_TURNS) HISTORY.remove(0);
            copy = new ArrayList<>(HISTORY);
        }
        ask(copy, reply -> {
            if (!reply.startsWith("Error: ")) synchronized (AiClient.class) { HISTORY.add(new Turn("assistant", reply)); }
            done.accept(reply);
        });
    }

    private static void ask(List<Turn> turns, Consumer<String> done) {
        try {
            String provider = AiStore.provider(), key = AiStore.key(), url = AiStore.effectiveUrl();
            if (key.isEmpty()) { done.accept("Error: no API key"); return; }
            if (!AiStore.allowed(url)) { done.accept("Error: the address must be https"); return; }

            JsonObject body = new JsonObject();
            body.addProperty("model", AiStore.effectiveModel());
            JsonArray msgs = new JsonArray();
            boolean anthropic = provider.equals("anthropic");
            if (anthropic) { body.addProperty("max_tokens", 700); body.addProperty("system", SYSTEM); }
            else {
                body.addProperty("max_tokens", 700);
                JsonObject sys = new JsonObject(); sys.addProperty("role", "system"); sys.addProperty("content", SYSTEM); msgs.add(sys);
            }
            for (Turn t : turns) {
                JsonObject m = new JsonObject(); m.addProperty("role", t.role()); m.addProperty("content", t.text()); msgs.add(m);
            }
            body.add("messages", msgs);

            HttpRequest.Builder rb = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(60))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(new Gson().toJson(body)));
            if (anthropic) rb.header("x-api-key", key).header("anthropic-version", "2023-06-01");
            else rb.header("Authorization", "Bearer " + key);

            HTTP.sendAsync(rb.build(), HttpResponse.BodyHandlers.ofString())
                .thenAccept(r -> done.accept(parse(r.statusCode(), r.body(), anthropic)))
                .exceptionally(e -> { done.accept("Error: " + e.getClass().getSimpleName()); return null; });
        } catch (RuntimeException e) {
            done.accept("Error: " + e.getClass().getSimpleName());
        }
    }

    private static String parse(int status, String text, boolean anthropic) {
        try {
            JsonObject root = JsonParser.parseString(text).getAsJsonObject();
            if (status / 100 != 2) {
                String msg = "HTTP " + status;
                if (root.has("error") && root.get("error").isJsonObject() && root.getAsJsonObject("error").has("message"))
                    msg += ": " + root.getAsJsonObject("error").get("message").getAsString();
                return "Error: " + cut(msg, 200);
            }
            if (anthropic) {
                StringBuilder sb = new StringBuilder();
                for (JsonElement el : root.getAsJsonArray("content")) {
                    JsonObject o = el.getAsJsonObject();
                    if (o.has("text")) sb.append(o.get("text").getAsString());
                }
                return cut(sb.toString().trim(), 2000);
            }
            return cut(root.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message").get("content").getAsString().trim(), 2000);
        } catch (RuntimeException e) {
            return "Error: HTTP " + status + ", unexpected answer";
        }
    }

    private static String cut(String s, int max) { return s.length() <= max ? s : s.substring(0, max) + "..."; }
}
