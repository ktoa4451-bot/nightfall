package dev.nightfall.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.nightfall.NightfallClient;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private final Path dir;

    public ConfigManager() {
        this.dir = FabricLoader.getInstance().getConfigDir().resolve("nightfall");
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            NightfallClient.LOGGER.error("Failed to create config dir", e);
        }
    }

    public void save(String profile) {
        JsonObject root = new JsonObject();
        JsonObject mods = new JsonObject();

        for (Module m : NightfallClient.getInstance().moduleManager.getModules()) {
            if (m instanceof dev.nightfall.bridge.GhostModule) continue;   // saved by Ghostline's own config
            JsonObject jm = new JsonObject();
            jm.addProperty("enabled", m.savesEnabled() && m.isEnabled());
            jm.addProperty("keybind", m.getKeyBind());

            JsonObject js = new JsonObject();
            for (Setting<?> s : m.settings) {
                Object v = s.getValue();
                if (v instanceof Boolean b) js.addProperty(s.getName(), b);
                else if (v instanceof Number n) js.addProperty(s.getName(), n);
                else if (v != null) js.addProperty(s.getName(), v.toString());
            }
            jm.add("settings", js);
            mods.add(m.getName(), jm);
        }

        root.add("modules", mods);

        try {
            Files.writeString(path(profile), GSON.toJson(root));
            NightfallClient.LOGGER.info("Config '{}' saved.", profile);
        } catch (IOException e) {
            NightfallClient.LOGGER.error("Failed to save config", e);
        }
    }

    public void load(String profile) {
        Path p = path(profile);
        if (!Files.exists(p)) {
            NightfallClient.LOGGER.warn("Config '{}' not found.", profile);
            return;
        }

        try {
            String content = Files.readString(p);
            JsonObject root = JsonParser.parseString(content).getAsJsonObject();
            if (!root.has("modules")) return;

            JsonObject mods = root.getAsJsonObject("modules");
            for (Module m : NightfallClient.getInstance().moduleManager.getModules()) {
                if (m instanceof dev.nightfall.bridge.GhostModule || !mods.has(m.getName())) continue;
                JsonObject jm = mods.getAsJsonObject(m.getName());

                if (m.savesEnabled() && jm.has("enabled")) m.setEnabled(jm.get("enabled").getAsBoolean());
                if (jm.has("keybind")) m.setKeyBind(jm.get("keybind").getAsInt());

                if (jm.has("settings")) {
                    JsonObject js = jm.getAsJsonObject("settings");
                    for (Setting<?> s : m.settings) {
                        if (js.has(s.getName())) apply(s, js.get(s.getName()));
                    }
                }
            }
            NightfallClient.LOGGER.info("Config '{}' loaded.", profile);
        } catch (Exception e) {
            NightfallClient.LOGGER.error("Failed to load config: {}", e.getMessage());
        }
    }

    public List<String> listProfiles() {
        List<String> profiles = new ArrayList<>();
        try (Stream<Path> stream = Files.list(dir)) {
            stream.filter(p -> p.toString().endsWith(".json"))
                  .forEach(p -> profiles.add(p.getFileName().toString().replace(".json", "")));
        } catch (IOException e) {
            NightfallClient.LOGGER.error("Failed to list profiles", e);
        }
        return profiles;
    }

    public void deleteProfile(String profile) {
        try {
            Files.deleteIfExists(path(profile));
        } catch (IOException e) {
            NightfallClient.LOGGER.error("Failed to delete profile", e);
        }
    }

    @SuppressWarnings("unchecked")
    private void apply(Setting<?> s, JsonElement el) {
        try {
            if (s instanceof Setting.BooleanSetting) ((Setting<Boolean>) s).setValue(el.getAsBoolean());
            else if (s instanceof Setting.DoubleSetting) ((Setting<Double>) s).setValue(el.getAsDouble());
            else if (s instanceof Setting.IntSetting) ((Setting<Integer>) s).setValue(el.getAsInt());
        } catch (Exception ignored) {}
    }

    private Path path(String name) {
        return dir.resolve(name + ".json");
    }
}