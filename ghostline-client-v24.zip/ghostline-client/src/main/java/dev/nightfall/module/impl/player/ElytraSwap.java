package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

/** One-shot module (put a key on it): swaps the chest slot between an elytra and a chestplate, then switches itself off. */
public class ElytraSwap extends Module implements Tickable {
    private final Setting.BooleanSetting firework = new Setting.BooleanSetting("Firework", false);
    private boolean pending;

    public ElytraSwap() {
        super("ElytraSwap", "Swaps elytra and chestplate (use a keybind).", Category.PLAYER);
        settings.add(firework);
    }

    @Override public void onEnable() { pending = true; }
    @Override public boolean savesEnabled() { return false; }
    @Override public void onDisable() { pending = false; }

    @Override
    public void onTick(Minecraft mc) {
        if (!pending) return;
        pending = false;
        LocalPlayer p = mc.player;
        if (p != null && mc.gameMode != null && mc.screen == null && p.isAlive() && p.containerMenu.getCarried().isEmpty()) {
            boolean wearingElytra = p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
            int from = -1;
            for (int i = 9; i < 45; i++) {
                var s = p.inventoryMenu.getSlot(i).getItem();
                if (wearingElytra ? s.is(ItemTags.CHEST_ARMOR) : s.is(Items.ELYTRA)) { from = i; break; }
            }
            if (from >= 0) {
                int id = p.inventoryMenu.containerId;
                mc.gameMode.handleInventoryMouseClick(id, from, 0, ClickType.PICKUP, p);
                mc.gameMode.handleInventoryMouseClick(id, 6, 0, ClickType.PICKUP, p);      // 6 = chest armor slot
                if (!p.containerMenu.getCarried().isEmpty()) mc.gameMode.handleInventoryMouseClick(id, from, 0, ClickType.PICKUP, p);
                if (firework.getValue() && !wearingElytra && !p.onGround()) {
                    for (int i = 0; i < 9; i++) {
                        if (p.getInventory().getItem(i).is(Items.FIREWORK_ROCKET)) {
                            int prev = p.getInventory().getSelectedSlot();
                            p.getInventory().setSelectedSlot(i);
                            mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                            p.getInventory().setSelectedSlot(prev);
                            break;
                        }
                    }
                }
            }
        }
        setEnabled(false);
    }
}
