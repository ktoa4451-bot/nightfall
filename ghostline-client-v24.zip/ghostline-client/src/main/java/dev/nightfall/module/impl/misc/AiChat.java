package dev.nightfall.module.impl.misc;

import dev.nightfall.gui.AiChatScreen;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;

/** One-shot module (put a key on it): opens the chat window with the AI and the other users. */
public class AiChat extends Module implements Tickable {
    private boolean pending;

    public AiChat() { super("AiChat", "Opens the chat window: AI and users (use a keybind).", Category.MISC); }

    @Override public void onEnable() { pending = true; }
    @Override public void onDisable() { pending = false; }
    @Override public boolean savesEnabled() { return false; }

    @Override
    public void onTick(Minecraft mc) {
        if (!pending) return;
        pending = false;
        setEnabled(false);
        if (mc.player != null) mc.setScreen(new AiChatScreen());
    }
}
