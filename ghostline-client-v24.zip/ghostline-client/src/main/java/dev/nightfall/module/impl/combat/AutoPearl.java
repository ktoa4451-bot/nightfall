package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/** One-shot module: bind a key to it. Each time it is switched on it throws an ender pearl from the hotbar toward your crosshair and switches itself off. */
public class AutoPearl extends Module implements Tickable {
    private boolean pending;

    public AutoPearl() { super("AutoPearl", "Throws an ender pearl, then switches off (use a keybind).", Category.COMBAT); }

    @Override public void onEnable() { pending = true; }
    @Override public boolean savesEnabled() { return false; }
    @Override public void onDisable() { pending = false; }

    @Override
    public void onTick(Minecraft mc) {
        if (!pending) return;
        pending = false;
        LocalPlayer p = mc.player;
        if (p != null && mc.gameMode != null && mc.screen == null && p.isAlive()) {
            for (int i = 0; i < 9; i++) {
                if (p.getInventory().getItem(i).is(Items.ENDER_PEARL)) {
                    int prev = p.getInventory().getSelectedSlot();
                    p.getInventory().setSelectedSlot(i);
                    mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                    p.getInventory().setSelectedSlot(prev);
                    break;
                }
            }
        }
        setEnabled(false);
    }
}
