package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

/** Marks the entity you hit last (for a few seconds): a sweeping ring, orbiting dots or a corner box (drawn by render/VisualFx). */
public class TargetEsp extends Module {
    public final Setting.ModeSetting mode = new Setting.ModeSetting("Mode", new String[]{"Circle", "Orbit", "Box"}, 0);
    public final Setting.DoubleSetting seconds = new Setting.DoubleSetting("Seconds", 3.0, 1.0, 10.0);

    private Entity last;
    private long hitNanos;

    public TargetEsp() {
        super("TargetEsp", "Marks the entity you hit last.", Category.VISUALS);
        settings.add(mode); settings.add(seconds);
        AttackEntityCallback.EVENT.register((p, w, h, e, hit) -> {
            if (isEnabled() && e instanceof LivingEntity) { last = e; hitNanos = System.nanoTime(); }
            return InteractionResult.PASS;
        });
    }

    @Override public void onEnable() { last = null; }
    @Override public void onDisable() { last = null; }

    /** The marked entity, or null when it is gone, dead or the time is over. */
    public Entity target() {
        Entity t = last;
        if (t == null || !t.isAlive() || t.isRemoved() || (System.nanoTime() - hitNanos) / 1e9 > seconds.getValue()) return null;
        return t;
    }
}
