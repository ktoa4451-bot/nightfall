package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.CrystalMath;
import dev.nightfall.util.NewBlocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Right after a player places obsidian near you, an end crystal is put on top of it (crystals in the hotbar or the offhand).
 * It only places; breaking the crystal is up to you or another module. Needs air above the block and no entity in the way.
 */
public class ObsidianCrystal extends Module implements Tickable {
    private final Setting.DoubleSetting reach = new Setting.DoubleSetting("Reach", 4.5, 2.0, 6.0);
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 2, 1, 10);
    private final Setting.BooleanSetting others = new Setting.BooleanSetting("Others", true);     // obsidian placed by other players
    private final Setting.BooleanSetting self = new Setting.BooleanSetting("Self", true);         // obsidian you place yourself
    private final Setting.BooleanSetting safe = new Setting.BooleanSetting("Safe", true);         // skip when the blast could hurt you too much
    private final Setting.DoubleSetting maxSelf = new Setting.DoubleSetting("MaxSelfDmg", 8.0, 1.0, 36.0);

    private final NewBlocks watch = new NewBlocks();
    private final Map<Long, Integer> pending = new LinkedHashMap<>();   // obsidian position -> tick when the wish expires
    private int tick;

    public ObsidianCrystal() {
        super("ObsidianCrystal", "Puts an end crystal on obsidian a player has just placed.", Category.COMBAT);
        settings.add(reach); settings.add(delay); settings.add(others); settings.add(self); settings.add(safe); settings.add(maxSelf);
    }

    @Override public void onEnable() { tick = 0; pending.clear(); watch.reset(); }
    @Override public void onDisable() { pending.clear(); watch.reset(); }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive() || p.isSpectator()) return;
        tick++;

        // 1) find obsidian that appeared (scan wider than the reach so walking never makes old blocks "new")
        if (tick % 2 == 0) {
            int scan = (int) Math.ceil(reach.getValue()) + 3;
            BlockPos base = p.blockPosition();
            List<Long> now = new ArrayList<>();
            BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
            for (int dx = -scan; dx <= scan; dx++) for (int dy = -scan; dy <= scan; dy++) for (int dz = -scan; dz <= scan; dz++) {
                q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                if (mc.level.getBlockState(q).is(Blocks.OBSIDIAN)) now.add(q.asLong());
            }
            for (long l : watch.update(now)) {
                BlockPos pos = BlockPos.of(l);
                if (Math.abs(pos.getX() - base.getX()) <= 1 && Math.abs(pos.getZ() - base.getZ()) <= 1 && Math.abs(pos.getY() - base.getY()) <= 1) continue;   // your own surround
                Vec3 c = Vec3.atCenterOf(pos);
                if (p.getEyePosition().distanceTo(c) > reach.getValue() + 1.5) continue;
                Player placer = null;                                    // who stands closest (within arm's reach of the block) placed it
                double best = 36.0;
                for (Player o : mc.level.players()) {
                    if (!o.isAlive() || o.isSpectator()) continue;
                    double d = o.distanceToSqr(c);
                    if (d < best) { best = d; placer = o; }
                }
                if (placer == null) continue;
                if (placer == p ? !self.getValue() : !others.getValue()) continue;
                pending.put(l, tick + 40);
            }
        }
        if (pending.isEmpty() || tick % delay.getValue() != 0) return;

        // 2) put one crystal on the first block that is still valid
        ItemHand hand = ItemHand.find(p, Items.END_CRYSTAL);
        int diff = mc.level.getDifficulty().getId();
        double hp = p.getHealth() + p.getAbsorptionAmount();
        var it = pending.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            BlockPos base = BlockPos.of(e.getKey());
            if (tick > e.getValue() || !mc.level.getBlockState(base).is(Blocks.OBSIDIAN)) { it.remove(); continue; }
            if (hand == null) return;
            Vec3 top = new Vec3(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            if (p.getEyePosition().distanceTo(top) > reach.getValue()) continue;
            if (!mc.level.getBlockState(base.above()).isAir() || !mc.level.getBlockState(base.above(2)).isAir()) continue;
            if (!mc.level.getEntitiesOfClass(Entity.class, new AABB(base.getX(), base.getY() + 1, base.getZ(), base.getX() + 1, base.getY() + 3, base.getZ() + 1), x -> true).isEmpty()) continue;
            if (safe.getValue()) {
                double dmg = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), top.x, top.y, top.z), 1.0, diff);
                if (dmg > maxSelf.getValue() || dmg >= hp - 2.0) continue;
            }
            hand.use(p, () -> mc.gameMode.useItemOn(p, hand.hand, new BlockHitResult(top, Direction.UP, base, false)));
            p.swing(hand.hand);
            it.remove();
            return;
        }
    }
}
