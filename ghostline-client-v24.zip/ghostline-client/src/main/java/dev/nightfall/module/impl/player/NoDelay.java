package dev.nightfall.module.impl.player;

import dev.nightfall.mixin.client.LivingEntityAccessor;
import dev.nightfall.mixin.client.MinecraftAccessor;
import dev.nightfall.mixin.client.MultiPlayerGameModeAccessor;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** Removes the small pauses: between jumps (hold jump), between broken blocks (hold attack) and between placed blocks / used items (hold use). */
public class NoDelay extends Module implements Tickable {
    private final Setting.BooleanSetting jump = new Setting.BooleanSetting("Jump", true);
    private final Setting.BooleanSetting breaking = new Setting.BooleanSetting("Break", true);
    private final Setting.BooleanSetting place = new Setting.BooleanSetting("Place", false);

    public NoDelay() {
        super("NoDelay", "No pause between jumps, broken blocks and placed blocks.", Category.PLAYER);
        settings.add(jump); settings.add(breaking); settings.add(place);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null) return;
        if (jump.getValue() && mc.options.keyJump.isDown()) ((LivingEntityAccessor) p).nightfall$setNoJumpDelay(0);
        if (breaking.getValue() && mc.options.keyAttack.isDown()) ((MultiPlayerGameModeAccessor) mc.gameMode).nightfall$setDestroyDelay(0);
        if (place.getValue() && mc.options.keyUse.isDown()) ((MinecraftAccessor) mc).nightfall$setRightClickDelay(0);
    }
}
