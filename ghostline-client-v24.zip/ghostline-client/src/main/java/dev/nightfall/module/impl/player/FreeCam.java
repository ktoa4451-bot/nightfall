package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.MoveMath;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.Vec3;

/**
 * Detaches the camera from your player: the player stands still (no movement input, mouse does not turn it)
 * and the camera flies around. A hidden stand-in entity (never added to the world) is used as the camera entity.
 * While it is on, attacking, breaking, placing and using items are blocked so nothing is done from the camera spot.
 */
public class FreeCam extends Module implements Tickable {
    private static FreeCam instance;
    private static boolean guardsRegistered;

    private final Setting.DoubleSetting speed = new Setting.DoubleSetting("Speed", 0.8, 0.1, 4.0);

    private ArmorStand cam;
    private Vec3 eye = Vec3.ZERO;
    private float yaw, pitch;
    private CameraType savedType;

    public FreeCam() {
        super("FreeCam", "Camera flies around while your player stays in place.", Category.PLAYER);
        settings.add(speed);
        instance = this;
        registerGuards();
    }

    private static void registerGuards() {
        if (guardsRegistered) return;
        guardsRegistered = true;
        AttackBlockCallback.EVENT.register((p, w, h, pos, dir) -> isActive() ? InteractionResult.FAIL : InteractionResult.PASS);
        AttackEntityCallback.EVENT.register((p, w, h, e, hit) -> isActive() ? InteractionResult.FAIL : InteractionResult.PASS);
        UseBlockCallback.EVENT.register((p, w, h, hit) -> isActive() ? InteractionResult.FAIL : InteractionResult.PASS);
        UseEntityCallback.EVENT.register((p, w, h, e, hit) -> isActive() ? InteractionResult.FAIL : InteractionResult.PASS);
        UseItemCallback.EVENT.register((p, w, h) -> isActive() ? InteractionResult.FAIL : InteractionResult.PASS);
    }

    /** True while the camera is detached (mixins read this). */
    public static boolean isActive() { return instance != null && instance.cam != null; }

    /** Mouse look: called from the Entity.turn mixin. Returns true when the player must NOT turn. */
    public static boolean look(Entity who, double dYaw, double dPitch) {
        FreeCam f = instance;
        Minecraft mc = Minecraft.getInstance();
        if (f == null || f.cam == null || who != mc.player) return false;
        f.yaw += (float) dYaw * 0.15f;
        f.pitch = Mth.clamp(f.pitch + (float) dPitch * 0.15f, -90f, 90f);
        f.cam.setYRot(f.yaw); f.cam.yRotO = f.yaw;
        f.cam.setXRot(f.pitch); f.cam.xRotO = f.pitch;
        return true;
    }

    @Override public void onEnable() { }
    @Override public boolean savesEnabled() { return false; }

    @Override
    public void onDisable() { stop(Minecraft.getInstance()); }

    private void start(Minecraft mc) {
        cam = new ArmorStand(EntityType.ARMOR_STAND, mc.level);
        eye = mc.player.getEyePosition();
        yaw = mc.player.getYRot();
        pitch = mc.player.getXRot();
        place(true);
        savedType = mc.options.getCameraType();
        mc.options.setCameraType(CameraType.FIRST_PERSON);
        mc.setCameraEntity(cam);
    }

    private void stop(Minecraft mc) {
        if (cam == null) return;
        cam = null;
        if (mc != null) {
            if (mc.player != null) mc.setCameraEntity(mc.player);
            if (savedType != null && mc.options != null) mc.options.setCameraType(savedType);
        }
        savedType = null;
    }

    private void place(boolean snap) {
        if (snap) cam.setPos(eye.x, eye.y - cam.getEyeHeight(), eye.z);
        cam.setOldPosAndRot();
        cam.setPos(eye.x, eye.y - cam.getEyeHeight(), eye.z);
        cam.setYRot(yaw); cam.setXRot(pitch);
        cam.yRotO = yaw; cam.xRotO = pitch;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        if (cam == null) { start(mc); return; }
        if (cam.level() != mc.level) { setEnabled(false); return; }      // changed world / died / reconnected
        double f = 0, l = 0, v = 0;
        if (mc.screen == null) {
            f = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
            l = (mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0);
            v = (mc.options.keyJump.isDown() ? 1 : 0) - (mc.options.keyShift.isDown() ? 1 : 0);
        }
        double[] h = MoveMath.horizontal(f, l, yaw, speed.getValue());
        eye = eye.add(h[0], v * speed.getValue(), h[1]);
        place(false);
    }
}
