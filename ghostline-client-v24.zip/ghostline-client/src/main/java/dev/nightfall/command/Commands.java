package dev.nightfall.command;

import com.ghostline.mod.Config;
import dev.nightfall.NightfallClient;
import dev.nightfall.module.Module;
import com.ghostline.mod.FriendsHelp;
import com.ghostline.mod.Pathing;
import dev.nightfall.ai.AiClient;
import dev.nightfall.ai.AiStore;
import dev.nightfall.gui.AiChatScreen;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Chat commands with a dot prefix. Anything that starts with "." is handled here and never sent to the server
 * (start a message with ".." to send a text that really begins with a dot).
 * .help  .toggle <module>  .bind <module> <key|none>  .list  .config save|load|list|delete <name>  .friend add|remove|list|clear <name>
 */
public final class Commands {
    private Commands() { }

    public static void register() {
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> {
            if (msg.length() < 2 || msg.charAt(0) != '.' || msg.charAt(1) == '.') return true;
            try { run(msg.substring(1).trim()); }
            catch (RuntimeException e) { say("Error: " + e.getMessage(), ChatFormatting.RED); }
            return false;
        });
    }

    private static void say(String text, ChatFormatting color) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[Ghostline] " + text).withStyle(color), false);
    }

    private static void say(String text) { say(text, ChatFormatting.GRAY); }

    private static Module find(String name) {
        for (Module m : NightfallClient.getInstance().moduleManager.getModules()) if (m.getName().equalsIgnoreCase(name)) return m;
        return null;
    }

    /** A number, or ~ / ~5 / ~-3 relative to the player. */
    private static int coord(String s, int base) {
        if (s.startsWith("~")) return base + (s.length() == 1 ? 0 : Integer.parseInt(s.substring(1)));
        return Integer.parseInt(s);
    }

    private static int parseKey(String s) {
        s = s.toLowerCase(Locale.ROOT);
        if (s.equals("none") || s.equals("-")) return -1;
        if (s.equals("rshift")) return 344;
        if (s.equals("lshift")) return 340;
        if (s.length() == 1 && Character.isLetterOrDigit(s.charAt(0))) return Character.toUpperCase(s.charAt(0));   // GLFW: A-Z, 0-9 = ASCII
        if (s.matches("f([1-9]|1[0-2])")) return 289 + Integer.parseInt(s.substring(1));                           // F1 = 290
        throw new IllegalArgumentException("unknown key '" + s + "' (use a letter, digit, F1-F12, lshift, rshift or none)");
    }

    private static void run(String line) {
        String[] a = line.split("\\s+");
        String cmd = a[0].toLowerCase(Locale.ROOT);
        NightfallClient nf = NightfallClient.getInstance();
        switch (cmd) {
            case "help", "?" -> {
                say(".toggle <module>   .bind <module> <key|none>   .list");
                say(".config save|load|list|delete <name>");
                say(".friend add|remove|list|clear <name>");
                say(".goto <x y z | x z | player <name>>   .follow <name>   .mine <block,block> [radius]   .stop   .path");
                say(".pathset list | <setting> | <setting> <value>   (every planner and walker option)");
                say(".ai (opens the chat window)   .ai <question>   .say <text> (all friends)   .msg <name> <text>");
            }
            case "toggle", "t" -> {
                if (a.length < 2) { say("usage: .toggle <module>"); return; }
                Module m = find(a[1]);
                if (m == null) { say("no module '" + a[1] + "'", ChatFormatting.RED); return; }
                m.toggle();
                say(m.getName() + (m.isEnabled() ? " on" : " off"), m.isEnabled() ? ChatFormatting.GREEN : ChatFormatting.GRAY);
            }
            case "bind" -> {
                if (a.length < 3) { say("usage: .bind <module> <key|none>"); return; }
                Module m = find(a[1]);
                if (m == null) { say("no module '" + a[1] + "'", ChatFormatting.RED); return; }
                m.setKeyBind(parseKey(a[2]));
                say(m.getName() + " bound to " + a[2].toUpperCase(Locale.ROOT), ChatFormatting.GREEN);
            }
            case "list" -> {
                List<String> on = new ArrayList<>();
                for (Module m : nf.moduleManager.getModules()) if (m.isEnabled()) on.add(m.getName());
                say(on.isEmpty() ? "no module is on" : "on (" + on.size() + "): " + String.join(", ", on));
            }
            case "config", "cfg" -> {
                String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "list";
                String name = a.length > 2 ? a[2] : "default";
                switch (sub) {
                    case "save" -> { nf.configManager.save(name); say("saved '" + name + "'", ChatFormatting.GREEN); }
                    case "load" -> { nf.configManager.load(name); say("loaded '" + name + "'", ChatFormatting.GREEN); }
                    case "delete" -> { nf.configManager.deleteProfile(name); say("deleted '" + name + "'"); }
                    default -> say("configs: " + nf.configManager.listProfiles());
                }
            }
            case "friend", "friends", "f" -> {
                String sub = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "list";
                String name = a.length > 2 ? a[2].toLowerCase(Locale.ROOT) : null;
                switch (sub) {
                    case "add" -> { if (name == null) { say("usage: .friend add <name>"); return; } Config.FRIENDS_SET.add(name); say(name + " is a friend now", ChatFormatting.GREEN); }
                    case "remove", "del" -> { if (name == null) { say("usage: .friend remove <name>"); return; } Config.FRIENDS_SET.remove(name); say(name + " removed"); }
                    case "clear" -> { Config.FRIENDS_SET.clear(); say("friends cleared"); }
                    default -> say(Config.FRIENDS_SET.isEmpty() ? "no friends" : "friends: " + String.join(", ", Config.FRIENDS_SET));
                }
            }
            case "goto", "go" -> {
                Minecraft mc = Minecraft.getInstance();
                if (mc.player == null) return;
                if (a.length == 3 && a[1].equalsIgnoreCase("player")) { say(Pathing.goToPlayer(a[2])); return; }
                if (a.length == 3) { say(Pathing.goToXZ(coord(a[1], mc.player.getBlockX()), coord(a[2], mc.player.getBlockZ()))); return; }
                if (a.length == 4) { say(Pathing.goTo(coord(a[1], mc.player.getBlockX()), coord(a[2], mc.player.getBlockY()), coord(a[3], mc.player.getBlockZ()))); return; }
                say("usage: .goto x y z   .goto x z   .goto player <name>   (~ means relative to you)");
            }
            case "follow" -> {
                if (a.length < 2) { say("usage: .follow <player>   (.stop ends it)"); return; }
                say(Pathing.follow(a[1]));
            }
            case "mine" -> {
                if (a.length < 2) { say("usage: .mine diamond_ore,deepslate_diamond_ore [radius 2-16]"); return; }
                int radius = 10;
                if (a.length > 2) radius = Math.max(2, Math.min(16, Integer.parseInt(a[2])));
                String r = Pathing.mine(a[1], radius);
                if (!r.isEmpty()) say(r, ChatFormatting.RED);
            }
            case "stop", "cancel" -> say(Pathing.stop());
            case "path" -> say(Pathing.status());
            case "pathset", "set" -> {
                if (a.length < 2 || a[1].equalsIgnoreCase("list")) { for (String l : Pathing.settingLines()) say(l); return; }
                say(a.length == 2 ? Pathing.get(a[1]) : Pathing.set(a[1], line.substring(line.indexOf(a[1]) + a[1].length()).trim()));
            }
            case "ai" -> {
                Minecraft mc = Minecraft.getInstance();
                if (a.length < 2) { mc.execute(() -> mc.setScreen(new AiChatScreen())); return; }
                if (!AiStore.hasKey()) { say("No API key yet: open the window with .ai and type /key YOUR_KEY there (the key is stored encrypted).", ChatFormatting.RED); return; }
                String q = line.substring(line.indexOf(' ') + 1).trim();
                say("...", ChatFormatting.DARK_GRAY);
                AiClient.chat(q, reply -> mc.execute(() -> say("AI: " + reply, reply.startsWith("Error: ") ? ChatFormatting.RED : ChatFormatting.AQUA)));
            }
            case "say" -> {
                if (a.length < 2) { say("usage: .say <text>"); return; }
                FriendsHelp.chat("*", line.substring(line.indexOf(' ') + 1).trim());
            }
            case "msg" -> {
                if (a.length < 3) { say("usage: .msg <name> <text>"); return; }
                FriendsHelp.chat(a[1], line.substring(line.indexOf(a[1]) + a[1].length()).trim());
            }
            default -> say("unknown command '" + cmd + "', try .help", ChatFormatting.RED);
        }
    }
}
