package com.ghostline.mod;

import com.ghostline.mod.automation.*;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FallingBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.List;

/**
 * Ghostline Automation, game side: own A* pathfinder (automation package) + a walking controller.
 * Commands: /glgo x y z [preview], /glgo preview x y z, /glstop. Module: AutoNav (Misc page).
 * Walking is switched on only when the "Mode" setting is Walk; Preview just computes and draws the route.
 * Limits: surface walking only (no ladders, swimming off by default, no parkour); slabs, stairs, fences and other
 * non-full blocks are treated as impassable; everything runs on the game thread with a time budget per search.
 */
public final class AutoNav {
    private AutoNav() { }

    public static final TaskManager TASKS = new TaskManager();
    private static Path preview;               // last computed route, drawn while the module is on
    private static long previewAt;
    private static String status = "";
    private static boolean listening;
    private static final PauseGate GATE = new PauseGate(1500, 30_000);

    // ---- settings indices (Config.AUTONAV)
    static final int S_MODE = 0, S_NODES = 1, S_MS = 2, S_FALL = 3, S_WATER = 4, S_TURN = 5, S_ARRIVE = 6,
        S_STUCK = 7, S_REPLANS = 8, S_TIMEOUT = 9, S_MINHP = 10, S_DRAW = 11, S_PARTIAL = 12, S_CLIMB = 13, S_SPRINT = 14, S_MOBPAUSE = 15, S_MOBRANGE = 16,
        S_BREAK = 17, S_BREAKCOST = 18, S_WATERCOST = 19, S_PARKOUR = 20, S_GAP = 21, S_JUMPCOST = 22, S_FOLLOWDIST = 23, S_FOLLOWREPLAN = 24;

    public static String status() { return status; }
    public static boolean active() { return TASKS.busy(); }

    // ------------------------------------------------------------------ world view

    /** Reads the client world. Unloaded chunks and build limits are UNKNOWN; lava, fire, cactus... are DANGER. */
    static final class McWorld implements WorldView {
        private final ClientLevel lv;
        private final BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        private final boolean breakable;
        McWorld(ClientLevel lv) { this(lv, false); }
        /** breakable = classify full blocks that are safe to dig as BREAKABLE (tunnelling). */
        McWorld(ClientLevel lv, boolean breakable) { this.lv = lv; this.breakable = breakable; }

        /** Safe to dig: not bedrock/unbreakable, not a block entity (chest...), no liquid touching it, nothing that falls above it, neighbours loaded. */
        private boolean safeToDig(BlockState s, int x, int y, int z) {
            if (s.hasBlockEntity()) return false;
            BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos(x, y, z);
            if (s.getDestroySpeed(lv, q) < 0) return false;
            for (Direction d : Direction.values()) {
                q.set(x + d.getStepX(), y + d.getStepY(), z + d.getStepZ());
                if (lv.isOutsideBuildHeight(q.getY()) || !lv.getChunkSource().hasChunk(q.getX() >> 4, q.getZ() >> 4)) return false;
                BlockState nb = lv.getBlockState(q);
                if (!nb.getFluidState().isEmpty()) return false;
                if (d == Direction.UP && nb.getBlock() instanceof FallingBlock) return false;
            }
            return true;
        }

        @Override public Kind kind(int x, int y, int z) {
            if (lv.isOutsideBuildHeight(y)) return Kind.UNKNOWN;
            if (!lv.getChunkSource().hasChunk(x >> 4, z >> 4)) return Kind.UNKNOWN;
            pos.set(x, y, z);
            BlockState s = lv.getBlockState(pos);
            FluidState f = s.getFluidState();
            if (!f.isEmpty()) {
                if (f.is(FluidTags.LAVA)) return Kind.DANGER;
                return f.is(FluidTags.WATER) ? Kind.WATER : Kind.DANGER;
            }
            if (s.is(Blocks.FIRE) || s.is(Blocks.SOUL_FIRE) || s.is(Blocks.CACTUS) || s.is(Blocks.MAGMA_BLOCK)
                || s.is(Blocks.SWEET_BERRY_BUSH) || s.is(Blocks.WITHER_ROSE) || s.is(Blocks.CAMPFIRE)
                || s.is(Blocks.SOUL_CAMPFIRE) || s.is(Blocks.POWDER_SNOW) || s.is(Blocks.COBWEB)) return Kind.DANGER;
            if (s.is(BlockTags.CLIMBABLE)) return Kind.CLIMB;
            VoxelShape sh = s.getCollisionShape(lv, pos);
            if (sh.isEmpty()) return Kind.AIR;
            double top = sh.max(Direction.Axis.Y);
            if (!(top > 0.999 && top < 1.001)) return Kind.DANGER; // slabs, fences, carpets: not supported -> avoided
            return breakable && safeToDig(s, x, y, z) ? Kind.BREAKABLE : Kind.SOLID;
        }
    }

    static Pathfinder.Options options() { return options(false); }

    static Pathfinder.Options options(boolean dig) {
        Module m = Config.AUTONAV;
        Pathfinder.Options o = new Pathfinder.Options();
        o.allowBreak = dig;
        o.maxNodes = m.get(S_NODES).i();
        o.maxMillis = m.get(S_MS).i();
        o.maxFall = m.get(S_FALL).i();
        o.allowWater = m.get(S_WATER).i() == 1;
        o.allowClimb = m.get(S_CLIMB).i() == 1;
        o.acceptPartial = m.get(S_PARTIAL).i() == 1;
        o.breakCost = m.get(S_BREAKCOST).value;
        o.waterCost = m.get(S_WATERCOST).value;
        o.allowParkour = m.get(S_PARKOUR).i() == 1;
        o.maxGap = m.get(S_GAP).i();
        o.parkourCost = m.get(S_JUMPCOST).value;
        return o;
    }

    // ------------------------------------------------------------------ the task

    /** Follows a route: smooth turning, forward only when facing the node, jumping, stuck detection with bounded re-planning. */
    static final class Walker {
        enum R { WALKING, ARRIVED, FAILED }
        Path path;
        int idx = 1, replans;
        String reason = "";
        private double lastX, lastZ;
        private long lastCheck;

        private final boolean canDig;
        private int digTicks; private BlockPos digging;

        Walker(Path path, LocalPlayer p, long now) { this(path, p, now, false); }
        Walker(Path path, LocalPlayer p, long now, boolean canDig) { this.path = path; this.canDig = canDig; lastX = p.getX(); lastZ = p.getZ(); lastCheck = now; }

        /** The block that still blocks the next node (feet cell first, then head cell), or null. Only when we are next to it. */
        private BlockPos blocking(Minecraft mc, LocalPlayer p, int[] t) {
            if (Math.hypot(t[0] + 0.5 - p.getX(), t[2] + 0.5 - p.getZ()) > 1.8) return null;
            for (int dy = 0; dy <= 1; dy++) {
                BlockPos b = new BlockPos(t[0], t[1] + dy, t[2]);
                BlockState s = mc.level.getBlockState(b);
                if (!s.getFluidState().isEmpty() || s.is(net.minecraft.tags.BlockTags.CLIMBABLE)) continue;
                if (!s.getCollisionShape(mc.level, b).isEmpty()) return b;
            }
            return null;
        }

        private R digStep(Minecraft mc, LocalPlayer p, BlockPos b, long now) {
            if (new McWorld(mc.level, true).kind(b.getX(), b.getY(), b.getZ()) != WorldView.Kind.BREAKABLE) return fail("unsafe to dig at " + b.toShortString());
            if (!b.equals(digging)) { digging = b; digTicks = 0; mc.gameMode.stopDestroyBlock(); }
            if (++digTicks > Config.AUTOMINE.get(4).value * 20) return fail("cannot dig through " + b.toShortString());
            lastCheck = now; // digging is progress, not being stuck
            mc.options.keyUp.setDown(false);
            mc.options.keyJump.setDown(false);
            net.minecraft.world.phys.Vec3 c = net.minecraft.world.phys.Vec3.atCenterOf(b), e = p.getEyePosition();
            float yaw = (float) (Math.toDegrees(Math.atan2(c.z - e.z, c.x - e.x)) - 90.0);
            float pitch = Mth.clamp((float) (-Math.toDegrees(Math.atan2(c.y - e.y, Math.hypot(c.x - e.x, c.z - e.z)))), -90f, 90f);
            p.setYRot(p.getYRot() + Mth.clamp(Mth.wrapDegrees(yaw - p.getYRot()), -40f, 40f));
            p.setXRot(p.getXRot() + Mth.clamp(pitch - p.getXRot(), -40f, 40f));
            BlockState st = mc.level.getBlockState(b);
            int cur = p.getInventory().getSelectedSlot(), best = cur;
            float bs = p.getInventory().getItem(cur).getDestroySpeed(st);
            for (int i = 0; i < 9; i++) { float sp = p.getInventory().getItem(i).getDestroySpeed(st); if (sp > bs + 0.01f) { bs = sp; best = i; } }
            if (best != cur) p.getInventory().setSelectedSlot(best);
            mc.gameMode.continueDestroyBlock(b, Direction.getApproximateNearest(e.x - c.x, e.y - c.y, e.z - c.z));
            p.swing(InteractionHand.MAIN_HAND);
            return R.WALKING;
        }

        int[] goal() { return path.nodes().get(path.length() - 1); }

        R step(Minecraft mc, LocalPlayer p, long now, java.util.function.Supplier<Path> replan) {
            if (!p.isAlive()) return fail("player died");
            if (p.getHealth() < Config.AUTONAV.get(S_MINHP).value) return fail("health below the limit");
            if (mc.screen != null) { release(mc); return R.WALKING; } // never steer while a screen is open
            if (path == null || path.length() < 2) return R.ARRIVED;
            int[] last = goal();
            double arrive = Config.AUTONAV.get(S_ARRIVE).value;
            double dxg = last[0] + 0.5 - p.getX(), dzg = last[2] + 0.5 - p.getZ();
            if (idx >= path.length() - 1 && Math.sqrt(dxg * dxg + dzg * dzg) <= arrive && Math.abs(p.getY() - last[1]) < 1.5) {
                release(mc);
                if (path.status() == Path.Status.PARTIAL) return fail("reached the closest point only: no full route");
                return R.ARRIVED;
            }
            while (idx < path.length() - 1) {
                int[] n = path.nodes().get(idx);
                double dx = n[0] + 0.5 - p.getX(), dz = n[2] + 0.5 - p.getZ();
                if (dx * dx + dz * dz < 0.36 && Math.abs(p.getY() - n[1]) < 1.2) idx++; else break;
            }
            int[] t = path.nodes().get(Math.min(idx, path.length() - 1));

            if (now - lastCheck >= (long) (Config.AUTONAV.get(S_STUCK).value * 1000)) {
                double moved = Math.hypot(p.getX() - lastX, p.getZ() - lastZ);
                lastX = p.getX(); lastZ = p.getZ(); lastCheck = now;
                if (moved < 0.3) {
                    if (++replans > Config.AUTONAV.get(S_REPLANS).i()) return fail("stuck: no progress after " + (replans - 1) + " re-plans");
                    Path r = replan.get();
                    if (r == null || !(r.found() || r.status() == Path.Status.PARTIAL)) return fail("stuck and no new route: " + (r == null ? "?" : r.reason()));
                    path = r; preview = r; previewAt = now; idx = 1;
                    status = "re-planned (" + replans + "): " + r.length() + " blocks";
                    return R.WALKING;
                }
            }
            if (canDig) {
                BlockPos b = blocking(mc, p, t);
                if (b != null) return digStep(mc, p, b, now);
                if (digging != null) { digging = null; mc.gameMode.stopDestroyBlock(); }
            }
            double dx = t[0] + 0.5 - p.getX(), dz = t[2] + 0.5 - p.getZ();
            if (p.onClimbable()) { // on a ladder/vine: go up by holding jump + forward, down by letting go
                boolean up = t[1] > p.getY() + 0.1;
                mc.options.keyUp.setDown(up || Math.hypot(dx, dz) > 0.35);
                mc.options.keyJump.setDown(up);
                if (Math.hypot(dx, dz) > 0.2) {
                    float w2 = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
                    p.setYRot(p.getYRot() + Mth.clamp(Mth.wrapDegrees(w2 - p.getYRot()), -20f, 20f));
                }
                return R.WALKING;
            }
            float want = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float diff = Mth.wrapDegrees(want - p.getYRot());
            float step = (float) Config.AUTONAV.get(S_TURN).value;
            p.setYRot(p.getYRot() + Mth.clamp(diff, -step, step));
            boolean facing = Math.abs(diff) < 50f;
            mc.options.keyUp.setDown(facing);
            int[] from = path.nodes().get(Math.max(0, Math.min(idx, path.length() - 1) - 1));
            if (Math.abs(t[0] - from[0]) + Math.abs(t[2] - from[2]) >= 2) {            // a gap: run, jump near the edge, keep going in the air
                double along = (p.getX() - (from[0] + 0.5)) * Integer.signum(t[0] - from[0]) + (p.getZ() - (from[2] + 0.5)) * Integer.signum(t[2] - from[2]);
                mc.options.keySprint.setDown(facing && p.getFoodData().getFoodLevel() > 6);
                mc.options.keyJump.setDown(p.onGround() && along >= 0.35 && Math.abs(diff) < 25f);
                return R.WALKING;
            }
            // sprint only while facing the node, with enough food, and not when the route turns or climbs soon
            boolean straight = path.length() > idx + 1 && path.nodes().get(Math.min(idx + 1, path.length() - 1))[1] == t[1];
            mc.options.keySprint.setDown(Config.AUTONAV.get(S_SPRINT).i() == 1 && facing && Math.abs(diff) < 15f && straight
                && p.getFoodData().getFoodLevel() > 6 && !p.horizontalCollision && !p.isInWater());
            boolean swim = p.isInWater() && t[1] >= (int) Math.floor(p.getY());
            mc.options.keyJump.setDown(swim || ((t[1] > p.getY() + 0.1 || p.horizontalCollision) && p.onGround()));
            return R.WALKING;
        }

        private R fail(String why) { reason = why; release(Minecraft.getInstance()); return R.FAILED; }
    }

    /** True when the player allowed digging through blocks that are in the way (setting "Break blocks"). */
    static boolean dig() { return Config.AUTONAV.get(S_BREAK).i() == 1; }

    static Path plan(Minecraft mc, LocalPlayer p, int gx, int gy, int gz) {
        BlockPos b = p.blockPosition();
        boolean dig = dig();
        return new Pathfinder(new McWorld(mc.level, dig), options(dig)).find(b.getX(), b.getY(), b.getZ(), gx, gy, gz);
    }

    static void showRoute(Path r, long now, String text) { preview = r; previewAt = now; status = text; }

    static final class NavTask extends AutomationTask {
        final int gx, gy, gz;
        final boolean walk;
        Path path;
        Walker walker;

        NavTask(int gx, int gy, int gz, boolean walk) {
            super("Navigate", 10, (long) (Config.AUTONAV.get(S_TIMEOUT).value * 1000));
            this.gx = gx; this.gy = gy; this.gz = gz; this.walk = walk;
            param("goal", gx + " " + gy + " " + gz).param("mode", walk ? "walk" : "preview");
        }

        @Override protected AutomationResult onStart(long now) {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null) return AutomationResult.failure("no player or world");
            stage("searching");
            Path r = plan(mc, p, gx, gy, gz);
            if (!(r.found() || r.status() == Path.Status.PARTIAL)) return AutomationResult.failure(r.reason());
            path = r;
            walker = new Walker(r, p, now, dig());
            stage(walk ? "walking" : "preview");
            String txt = (r.status() == Path.Status.PARTIAL ? "partial route, " : "route ") + r.length() + " blocks";
            showRoute(r, now, txt);
            return AutomationResult.success(txt);
        }

        @Override protected AutomationResult onTick(long now) {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null) return AutomationResult.failure("world lost");
            if (!walk) return AutomationResult.success("route computed: " + path.length() + " blocks (preview, not walking)");
            Walker.R r = walker.step(mc, p, now, () -> plan(mc, p, gx, gy, gz));
            stage("node " + walker.idx + "/" + (path.length() - 1));
            return switch (r) {
                case WALKING -> null;
                case ARRIVED -> AutomationResult.success("arrived");
                case FAILED -> AutomationResult.failure(walker.reason);
            };
        }

        @Override protected void onStop(TaskState finalState, String reason) {
            release(Minecraft.getInstance());
            status = reason == null ? "" : reason;
        }
    }

    static void release(Minecraft mc) {
        if (mc == null || mc.options == null) return;
        mc.options.keyUp.setDown(false);
        mc.options.keyJump.setDown(false);
        mc.options.keySprint.setDown(false);
    }

    // ------------------------------------------------------------------ public API

    /** Queues a navigation task. Only one movement task can run: a new one waits until the current one ends. */
    public static AutomationResult go(int x, int y, int z, boolean forcePreview) {
        Minecraft mc = Minecraft.getInstance();
        if (!Config.AUTONAV.enabled) return AutomationResult.failure("module AutoNav is off");
        if (Config.panic || mc.player == null || mc.level == null) return AutomationResult.failure("no player or world");
        if (TASKS.busy()) return AutomationResult.failure("another task is running: /glstop first");
        listen();
        boolean walk = !forcePreview && Config.AUTONAV.get(S_MODE).i() == 1;
        TASKS.submit(new NavTask(x, y, z, walk));
        return AutomationResult.success(walk ? "walking to " + x + " " + y + " " + z : "computing route to " + x + " " + y + " " + z);
    }

    /** Starts walking to a point regardless of the AutoNav module state and its Mode setting (used by AutoWarden). */
    public static AutomationResult goWalk(int x, int y, int z) {
        Minecraft mc = Minecraft.getInstance();
        if (Config.panic || mc.player == null || mc.level == null) return AutomationResult.failure("no player or world");
        if (TASKS.busy()) return AutomationResult.failure("another task is running");
        listen();
        TASKS.submit(new NavTask(x, y, z, true));
        return AutomationResult.success("walking to " + x + " " + y + " " + z);
    }

    /** Emergency stop: cancels everything and releases the keys. Safe to call any time. */
    public static void stop(Minecraft mc) {
        if (TASKS.busy()) TASKS.stopAll(System.currentTimeMillis(), "stopped by user");
        release(mc);
    }

    /** Game-thread tick while the module is enabled. */
    public static void tick(Minecraft mc, LocalPlayer p) {
        listen();
        mobGate(mc, p);
        TASKS.tick(System.currentTimeMillis(), p != null && mc.level != null && !Config.panic);
        if (preview != null && System.currentTimeMillis() - previewAt > 60_000 && !TASKS.busy()) preview = null;
    }

    /** Pauses the walking task while a hostile mob is close, resumes after it was calm for a moment, gives up after 30 s. */
    private static void mobGate(Minecraft mc, LocalPlayer p) {
        AutomationTask owner = null;
        for (AutomationTask t : TASKS.running()) if (t.controlsMovement() && t.state() != TaskState.IDLE) owner = t;
        if (owner == null || p == null || mc.level == null || Config.AUTONAV.get(S_MOBPAUSE).i() == 0) { GATE.reset(); return; }
        double r = Config.AUTONAV.get(S_MOBRANGE).value;
        String who = null;
        for (net.minecraft.world.entity.monster.Monster m : mc.level.getEntitiesOfClass(net.minecraft.world.entity.monster.Monster.class, p.getBoundingBox().inflate(r), e -> e.isAlive())) { who = m.getName().getString(); break; }
        long now = System.currentTimeMillis();
        switch (GATE.update(who != null, now)) {
            case PAUSE -> { TASKS.pause(owner, now); release(mc); status = "paused: " + who + " nearby"; Toasts.warn("AutoNav", status); }
            case RESUME -> { TASKS.resume(owner, now); status = "resumed"; }
            case GIVE_UP -> TASKS.cancel(owner, now, "hostile mob stayed nearby for 30 s");
            default -> { if (GATE.paused()) release(mc); }
        }
    }

    /** Called when there is no player/level: makes sure nothing keeps running. */
    public static void worldGone() {
        if (TASKS.busy()) TASKS.stopAll(System.currentTimeMillis(), "world not available");
        preview = null;
    }

    static void listen() {
        if (listening) return;
        listening = true;
        TASKS.addListener(e -> {
            switch (e.type()) {
                case COMPLETED -> Toasts.info("AutoNav", e.message());
                case FAILED -> Toasts.warn("AutoNav", e.message());
                default -> { }
            }
        });
    }

    // ------------------------------------------------------------------ route drawing (screen overlay, first person)

    public static void renderPath(GuiGraphics g, Minecraft mc, float pt) {
        Path pa = preview;
        if (pa == null || !Config.AUTONAV.enabled || Config.AUTONAV.get(S_DRAW).i() == 0) return;
        LocalPlayer p = mc.player;
        if (p == null || !Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;
        List<int[]> nodes = pa.nodes();
        double[] prev = null;
        int accent = Ui.accent();
        for (int i = 0; i < nodes.size(); i++) {
            int[] n = nodes.get(i);
            double[] s = Project.point(n[0] + 0.5, n[1] + 0.1, n[2] + 0.5);
            if (s == null) { prev = null; continue; }
            int sx = (int) s[0], sy = (int) s[1];
            boolean end = i == nodes.size() - 1;
            int r = end ? 4 : 1;
            g.fill(sx - r, sy - r, sx + r + 1, sy + r + 1, Ui.c(end ? 0x55FF55 : accent, 0.9f));
            if (prev != null) {
                int px = (int) prev[0], py = (int) prev[1];
                int steps = Math.max(Math.abs(sx - px), Math.abs(sy - py)) / 3;
                for (int k = 1; k < steps; k++) g.fill(px + (sx - px) * k / steps, py + (sy - py) * k / steps,
                    px + (sx - px) * k / steps + 1, py + (sy - py) * k / steps + 1, Ui.c(accent, 0.6f));
            }
            prev = s;
        }
    }

    // ------------------------------------------------------------------ commands

    public static void registerCommands(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("glgo")
            .then(ClientCommandManager.argument("x", IntegerArgumentType.integer())
                .then(ClientCommandManager.argument("y", IntegerArgumentType.integer())
                    .then(ClientCommandManager.argument("z", IntegerArgumentType.integer())
                        .executes(ctx -> run(IntegerArgumentType.getInteger(ctx, "x"), IntegerArgumentType.getInteger(ctx, "y"), IntegerArgumentType.getInteger(ctx, "z"), false))
                        .then(ClientCommandManager.literal("preview")
                            .executes(ctx -> run(IntegerArgumentType.getInteger(ctx, "x"), IntegerArgumentType.getInteger(ctx, "y"), IntegerArgumentType.getInteger(ctx, "z"), true)))))));
        d.register(ClientCommandManager.literal("glstop").executes(ctx -> {
            Minecraft mc = Minecraft.getInstance();
            stop(mc);
            say(mc, "stopped");
            return 1;
        }));
    }

    private static int run(int x, int y, int z, boolean preview) {
        Minecraft mc = Minecraft.getInstance();
        AutomationResult r = go(x, y, z, preview);
        say(mc, r.message());
        return r.ok() ? 1 : 0;
    }

    private static void say(Minecraft mc, String s) {
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[Ghostline] AutoNav: " + s), false);
    }
}
