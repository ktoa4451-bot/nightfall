package com.ghostline.mod;

import com.ghostline.mod.AutoNav.McWorld;
import com.ghostline.mod.AutoNav.Walker;
import com.ghostline.mod.automation.AutomationResult;
import com.ghostline.mod.automation.AutomationTask;
import com.ghostline.mod.automation.Path;
import com.ghostline.mod.automation.Pathfinder;
import com.ghostline.mod.automation.TaskState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The "go anywhere" layer on top of the automation pathfinder: goto (coordinates, only x z, a player), follow a player,
 * mine blocks, stop, and a live settings table (every planner / walker option can be read and changed by name).
 * All methods run on the game thread and return a short message for the chat.
 */
public final class Pathing {
    private Pathing() { }

    // ------------------------------------------------------------------ goto

    public static String goTo(int x, int y, int z) {
        AutomationResult r = AutoNav.goWalk(x, y, z);
        return r.message();
    }

    /** Walks to x z: the standing height is found from the loaded chunks (needs them to be loaded). */
    public static String goToXZ(int x, int z) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return "no player or world";
        Pathfinder pf = new Pathfinder(new McWorld(mc.level), AutoNav.options(false));
        int from = p.blockPosition().getY();
        for (int y = from + 48; y >= from - 64; y--) if (pf.standable(x, y, z)) return goTo(x, y, z);
        return "no safe place to stand at " + x + " " + z + " (chunk not loaded, water or lava?)";
    }

    public static String goToPlayer(String name) {
        Minecraft mc = Minecraft.getInstance();
        Player t = find(mc, name);
        if (t == null) return "no player '" + name + "' around";
        return goTo(t.getBlockX(), t.getBlockY(), t.getBlockZ());
    }

    // ------------------------------------------------------------------ follow

    private static Player find(Minecraft mc, String name) {
        if (mc.level == null) return null;
        for (Player o : mc.level.players()) if (o != mc.player && o.getName().getString().equalsIgnoreCase(name)) return o;
        return null;
    }

    public static String follow(String name) {
        Minecraft mc = Minecraft.getInstance();
        if (Config.panic || mc.player == null || mc.level == null) return "no player or world";
        if (AutoNav.TASKS.busy()) return "another task is running: .stop first";
        if (find(mc, name) == null) return "no player '" + name + "' around";
        AutoNav.listen();
        AutoNav.TASKS.submit(new FollowTask(name));
        return "following " + name + " (.stop to end)";
    }

    /** Keeps walking to a player: re-plans on a timer, stands still when close enough. Never ends by itself except when the target is lost for 15 s. */
    static final class FollowTask extends AutomationTask {
        private final String name;
        private Walker walker;
        private long lastPlan, lostSince;
        private int walkFails, planFails;

        FollowTask(String name) { super("Follow", 10, 0); this.name = name; param("target", name); }

        @Override protected AutomationResult onStart(long now) {
            return find(Minecraft.getInstance(), name) == null ? AutomationResult.failure("no player '" + name + "' around") : AutomationResult.success("following " + name);
        }

        private Path planTo(Minecraft mc, LocalPlayer p, Player t) {
            boolean dig = AutoNav.dig();
            Pathfinder pf = new Pathfinder(new McWorld(mc.level, dig), AutoNav.options(dig));
            int gx = t.getBlockX(), gz = t.getBlockZ(), gy = Integer.MIN_VALUE;
            for (int y = t.getBlockY(); y >= t.getBlockY() - 6; y--) if (pf.standable(gx, y, gz)) { gy = y; break; }
            if (gy == Integer.MIN_VALUE) return null;
            Path r = pf.find(p.getBlockX(), p.getBlockY(), p.getBlockZ(), gx, gy, gz);
            return r.found() ? r : null;
        }

        @Override protected AutomationResult onTick(long now) {
            Minecraft mc = Minecraft.getInstance();
            LocalPlayer p = mc.player;
            if (p == null || mc.level == null) return AutomationResult.failure("world lost");
            Player t = find(mc, name);
            if (t == null) {
                if (lostSince == 0) lostSince = now;
                AutoNav.release(mc);
                walker = null;
                return now - lostSince > 15_000 ? AutomationResult.failure("lost " + name) : null;
            }
            lostSince = 0;
            stage(String.format(Locale.ROOT, "%s, %.1f m", name, (double) p.distanceTo(t)));
            if (p.distanceTo(t) <= Config.AUTONAV.get(AutoNav.S_FOLLOWDIST).value) { walker = null; AutoNav.release(mc); return null; }
            long every = (long) (Config.AUTONAV.get(AutoNav.S_FOLLOWREPLAN).value * 1000);
            if (walker == null || now - lastPlan >= every) {
                lastPlan = now;
                Path r = planTo(mc, p, t);
                if (r != null) { walker = new Walker(r, p, now, AutoNav.dig()); planFails = 0; }
                else if (walker == null && ++planFails > 12) return AutomationResult.failure("no route to " + name);
            }
            if (walker != null) {
                Walker.R r = walker.step(mc, p, now, () -> planTo(mc, p, t));
                if (r == Walker.R.FAILED) { if (++walkFails > 6) return AutomationResult.failure(walker.reason); walker = null; }
                else if (r == Walker.R.ARRIVED) walker = null;
                else walkFails = 0;
            }
            return null;
        }

        @Override protected void onStop(TaskState finalState, String reason) { AutoNav.release(Minecraft.getInstance()); }
    }

    // ------------------------------------------------------------------ mine / stop / status

    /** Starts mining the given blocks (comma separated ids) around you. Turns the AutoMine module on. */
    public static String mine(String blocks, int radius) {
        Config.AUTOMINE.enabled = true;
        return Pve.mineCmd(blocks, radius, false) == 1 ? "" : "could not start (see the line above)";
    }

    public static String stop() {
        AutoNav.stop(Minecraft.getInstance());
        return "stopped";
    }

    public static String status() {
        String s = AutoNav.status();
        return AutoNav.active() ? "busy" + (s.isEmpty() ? "" : ": " + s) : "idle" + (s.isEmpty() ? "" : " (last: " + s + ")");
    }

    // ------------------------------------------------------------------ settings table

    private static String norm(String s) { return s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", ""); }

    private static List<Setting> all() {
        List<Setting> l = new ArrayList<>();
        for (Setting s : Config.AUTONAV.settings) if (!s.isText && !s.isKey) l.add(s);
        for (Setting s : Config.AUTOMINE.settings) if (!s.isText && !s.isKey) l.add(s);
        return l;
    }

    private static Setting findSetting(String name) {
        String n = norm(name);
        for (Setting s : all()) if (norm(s.name).equals(n)) return s;
        for (Setting s : all()) if (norm(s.name).startsWith(n)) return s;      // a unique start is enough: ".pathset maxn 30000"
        return null;
    }

    public static List<String> settingLines() {
        List<String> out = new ArrayList<>();
        for (Setting s : all()) out.add(s.name.replace(' ', '_') + " = " + s.display());
        return out;
    }

    /** Sets one option by name. Numbers are clamped to the allowed range; booleans take on/off/true/false/1/0; lists take the option name. */
    public static String set(String name, String value) {
        Setting s = findSetting(name);
        if (s == null) return "no setting '" + name + "' (.pathset list)";
        String v = value.trim().toLowerCase(Locale.ROOT);
        if (s.options != null) {
            int idx = -1;
            for (int i = 0; i < s.options.length; i++) if (s.options[i].toLowerCase(Locale.ROOT).equals(v)) idx = i;
            if (s.isBool()) { if (v.equals("true") || v.equals("1") || v.equals("yes")) idx = 1; else if (v.equals("false") || v.equals("0") || v.equals("no")) idx = 0; }
            if (idx < 0) return s.name + ": use one of " + String.join(", ", s.options);
            s.value = idx;
        } else {
            double d;
            try { d = Double.parseDouble(v); } catch (NumberFormatException e) { return s.name + ": '" + value + "' is not a number (" + s.min + " .. " + s.max + ")"; }
            s.value = Math.max(s.min, Math.min(s.max, d));
        }
        Config.save();
        return s.name + " = " + s.display();
    }

    public static String get(String name) {
        Setting s = findSetting(name);
        return s == null ? "no setting '" + name + "' (.pathset list)" : s.name + " = " + s.display();
    }
}
