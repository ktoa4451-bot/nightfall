package dev.nightfall.gui;

import com.ghostline.mod.FriendsHelp;
import dev.nightfall.ai.AiClient;
import dev.nightfall.ai.AiStore;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.List;

/**
 * Chat window with two tabs. AI: talk to the AI service you set up (commands typed here, not in the game chat: /key, /model, /provider, /url, /clear, /help).
 * Users: chat with the other users of your Ghostline friends server (needs FriendsHelp connected; "@name text" is private, anything else goes to all friends).
 */
public class AiChatScreen extends Screen {
    private record Line(String text, int color) { }

    private static final List<Line> AI_LOG = new ArrayList<>();
    private static boolean waiting;
    private int tab;
    private int scroll;
    private EditBox input;

    public AiChatScreen() { super(Component.literal("Chat")); }

    private int pw() { return Math.min(380, this.width - 12); }
    private int ph() { return Math.min(250, this.height - 12); }
    private int px() { return (this.width - pw()) / 2; }
    private int py() { return (this.height - ph()) / 2; }

    @Override
    protected void init() {
        int x = px(), y = py(), w = pw(), h = ph();
        addRenderableWidget(Button.builder(Component.literal("AI"), b -> { tab = 0; scroll = 0; }).bounds(x + 8, y + 6, 40, 16).build());
        addRenderableWidget(Button.builder(Component.literal("Users"), b -> { tab = 1; scroll = 0; }).bounds(x + 52, y + 6, 52, 16).build());
        addRenderableWidget(Button.builder(Component.literal("Clear"), b -> clearLog()).bounds(x + w - 48, y + 6, 40, 16).build());
        input = new EditBox(this.font, x + 8, y + h - 24, w - 72, 16, Component.literal("Message"));
        input.setMaxLength(300);
        addRenderableWidget(input);
        addRenderableWidget(Button.builder(Component.literal("Send"), b -> submit()).bounds(x + w - 60, y + h - 24, 52, 16).build());
        setInitialFocus(input);
    }

    private void clearLog() {
        if (tab == 0) { AI_LOG.clear(); AiClient.clear(); }
        else FriendsHelp.CHAT_LOG.clear();
        scroll = 0;
    }

    private void ai(String text, int color) { AI_LOG.add(new Line(text, color)); scroll = 0; }

    private void submit() {
        String t = input.getValue().trim();
        if (t.isEmpty()) return;
        input.setValue("");
        if (tab == 1) { sendUsers(t); return; }
        if (t.startsWith("/")) { aiCommand(t); return; }
        if (waiting) { ai("Wait for the answer first.", 0xFFFFC080); return; }
        if (!AiStore.hasKey()) { ai("No API key yet. Type /key YOUR_KEY (it is stored encrypted). /help shows the other commands.", 0xFFFFC080); return; }
        ai("You: " + t, 0xFFFFFFFF);
        waiting = true;
        AiClient.chat(t, reply -> Minecraft.getInstance().execute(() -> {
            waiting = false;
            ai(reply.startsWith("Error: ") ? reply : "AI: " + reply, reply.startsWith("Error: ") ? 0xFFFF8080 : 0xFFB8E0FF);
        }));
    }

    private void aiCommand(String line) {
        String[] a = line.substring(1).split("\\s+", 2);
        String cmd = a[0].toLowerCase(), arg = a.length > 1 ? a[1].trim() : "";
        switch (cmd) {
            case "key" -> ai(arg.isEmpty() ? "Usage: /key YOUR_KEY" : AiStore.setKey(arg) ? "Key saved (encrypted)." : "Could not store the key.", 0xFF90FF90);
            case "model" -> { AiStore.setModel(arg); ai("Model: " + AiStore.effectiveModel(), 0xFF90FF90); }
            case "provider" -> ai(AiStore.setProvider(arg) ? "Provider: " + AiStore.provider() + ", model " + AiStore.effectiveModel() : "Use /provider anthropic or /provider openai", 0xFF90FF90);
            case "url" -> ai(AiStore.setUrl(arg) ? "Address: " + AiStore.effectiveUrl() : "The address must start with https:// (http only for localhost).", 0xFF90FF90);
            case "clear" -> { AI_LOG.clear(); AiClient.clear(); }
            default -> {
                ai("/key <key>   /provider anthropic|openai   /model <name>   /url <https address>   /clear", 0xFFB0B0C0);
                ai("Now: " + AiStore.provider() + ", " + AiStore.effectiveModel() + ", key " + (AiStore.hasKey() ? "saved" : "missing"), 0xFFB0B0C0);
                ai("Your messages go to the service you chose; nothing from the game is sent.", 0xFFB0B0C0);
            }
        }
    }

    private void sendUsers(String t) {
        if (!FriendsHelp.connected()) {
            FriendsHelp.CHAT_LOG.add("Not connected. Set up the friends server first (server/README.md, FriendsHelp module).");
            return;
        }
        if (t.startsWith("@") && t.indexOf(' ') > 1) {
            String to = t.substring(1, t.indexOf(' ')), text = t.substring(t.indexOf(' ') + 1).trim();
            if (text.isEmpty()) return;
            FriendsHelp.chat(to, text);
            FriendsHelp.CHAT_LOG.add("you -> " + to + ": " + text);
        } else {
            FriendsHelp.chat("*", t);
            FriendsHelp.CHAT_LOG.add("you -> friends: " + t);
        }
        scroll = 0;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        int x = px(), y = py(), w = pw(), h = ph();
        g.fill(0, 0, this.width, this.height, 0x40000008);
        g.fill(x, y, x + w, y + h, 0xC0101015);
        g.fill(x, y, x + w, y + 1, 0x30FFFFFF);
        g.fill(x, y + h - 1, x + w, y + h, 0x30FFFFFF);
        g.fill(x, y, x + 1, y + h, 0x30FFFFFF);
        g.fill(x + w - 1, y, x + w, y + h, 0x30FFFFFF);
        g.fill(x + 6, y + 26, x + w - 6, y + 27, 0x20FFFFFF);
        g.drawString(this.font, tab == 0 ? AiStore.provider() + " / " + AiStore.effectiveModel() : (FriendsHelp.connected() ? "friends server: connected" : "friends server: not connected"),
            x + 112, y + 10, 0xFF9A9AA8, false);

        // messages: newest at the bottom, wheel scrolls back
        List<Line> src = new ArrayList<>();
        if (tab == 0) src.addAll(AI_LOG);
        else for (String s : FriendsHelp.CHAT_LOG) src.add(new Line(s, 0xFFE8B0FF));
        int areaX = x + 8, areaY = y + 31, areaW = w - 16, areaH = h - 31 - 30;
        List<FormattedCharSequence> lines = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        for (Line l : src) for (FormattedCharSequence seq : this.font.split(Component.literal(l.text()), areaW)) { lines.add(seq); colors.add(l.color()); }
        int rows = Math.max(1, areaH / 10);
        int maxScroll = Math.max(0, lines.size() - rows);
        scroll = Mth.clamp(scroll, 0, maxScroll);
        int start = Math.max(0, lines.size() - rows - scroll);
        for (int i = 0; i < rows && start + i < lines.size(); i++) {
            g.drawString(this.font, lines.get(start + i), areaX, areaY + i * 10, colors.get(start + i), false);
        }
        if (lines.isEmpty()) g.drawString(this.font, tab == 0 ? "Ask something. /help for the commands." : "Messages from your friends server appear here.", areaX, areaY, 0xFF70707E, false);
        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scroll += (int) Math.signum(scrollY) * 3;
        if (scroll < 0) scroll = 0;
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (key == 257 || key == 335) { submit(); return true; }      // Enter / keypad Enter
        return super.keyPressed(event);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
