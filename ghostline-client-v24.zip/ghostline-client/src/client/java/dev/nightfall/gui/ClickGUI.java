package dev.nightfall.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nightfall.NightfallClient;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.util.Anim;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Module menu in the "sidebar + cards" style: a dark translucent panel, a sidebar with the categories and tools
 * (Configs, HUD, Theme, Search), a search field, and the modules as two columns of cards with animated switches.
 * Settings unfold inside the card (switches, sliders, keybind, reset).
 * Click a card to switch the module, click the arrow (or right click) to open its settings. Saved when the menu closes.
 */
public class ClickGUI extends Screen {
    private enum Kind { MODULE, BOOL, DOUBLE, INT, MODE, KEY, TEXT, BIND, RESET }

    private static final int NAV_CATEGORY = 0, NAV_HUD = 2, NAV_THEME = 3;

    private record Nav(String label, Category cat, int type, int y) { }

    private static final class Row {
        final Kind kind; final Module module; final Setting<?> setting;
        final int x, y, w, h, clipTop, clipBottom, cardH;
        Row(Kind kind, Module module, Setting<?> setting, int x, int y, int w, int h, int clipTop, int clipBottom, int cardH) {
            this.kind = kind; this.module = module; this.setting = setting;
            this.x = x; this.y = y; this.w = w; this.h = h;
            this.clipTop = clipTop; this.clipBottom = clipBottom; this.cardH = cardH;
        }
    }

    private static final int HEAD = 20, GAP = 6, SIDE = 92, SEARCH_W = 84, SEARCH_H = 14, PILL_W = 22;
    private static final int ON = 0xFFE4E4EC, OFF_TRACK = 0x33FFFFFF, TXT = 0xFFEDEDF3, TXT2 = 0xFFB4B4C0;
    private static final Object SEARCH_KEY = new Object();
    private static final int GRAY_DIM = 0xFF6C6C7C;

    private static Category LAST_SEL = Category.COMBAT;   // the menu opens where you left it
    private static int LAST_VIEW;
    private static int OFF_X, OFF_Y;                       // window position (drag the top bar, double click = centre)
    private Category selected = LAST_SEL;                  // null = All
    private int view = LAST_VIEW;                          // 0 all, 1 enabled, 2 favorites
    private boolean dragWin;
    private final Set<Module> open = Collections.newSetFromMap(new IdentityHashMap<>());
    private Module listening;
    private Setting<?> listeningKey;     // key setting waiting for a key press
    private Setting.TextSetting editing; // text setting being typed into
    private Row dragging;
    private boolean dragScroll;
    private boolean searchFocus;
    private String query = "";
    private int contentH;
    private float scroll, scrollTarget, openT;
    private long last = System.nanoTime();
    private final Map<Object, Float> hover = new IdentityHashMap<>();
    private final Map<Module, Float> expandT = new IdentityHashMap<>();
    private final Map<Module, Float> enableT = new IdentityHashMap<>();
    private final Map<Setting<?>, Float> switchT = new IdentityHashMap<>();
    private final Map<Module, Object> bindKeys = new IdentityHashMap<>();

    private Object bindKey(Module m) { return bindKeys.computeIfAbsent(m, x -> new Object()); }

    public ClickGUI() {
        super(Component.literal("Ghostline Client"));
    }

    public static void open() { Minecraft.getInstance().setScreen(new ClickGUI()); }

    // ------------------------------------------------------------------ geometry

    private float sz() { return ThemeManager.menuSize / 100f; }
    private int ww() { int lo = Math.min((int) (300 * sz()), this.width - 8); return Mth.clamp((int) (this.width * 0.66f * sz()), lo, Math.max(lo, Math.min(this.width - 8, (int) (520 * sz())))); }
    private int wh() { int lo = Math.min((int) (190 * sz()), this.height - 8); return Mth.clamp((int) (this.height * 0.62f * sz()), lo, Math.max(lo, Math.min(this.height - 8, (int) (320 * sz())))); }
    private int wx() { return Mth.clamp((this.width - ww()) / 2 + OFF_X, 0, Math.max(0, this.width - ww())); }
    private int wy() { return Mth.clamp((this.height - wh()) / 2 + OFF_Y, 0, Math.max(0, this.height - wh())) + (int) ((1f - Anim.easeOutCubic(openT)) * 10f); }
    private int itemH() { return Mth.clamp((wh() - 61) / (Category.values().length + 3), 10, 17); }
    private int top() { return wy() + 46; }
    private int bottom() { return wy() + wh() - 8; }
    private int cx() { return wx() + SIDE + 8; }
    private int cw() { return ww() - SIDE - 20; }
    private int searchX() { return wx() + ww() - 10 - SEARCH_W; }
    private int searchY() { return wy() + 7; }
    private int settingsLabelY() { return wy() + 40 + itemH() * (1 + Category.values().length) + 4; }

    private List<Nav> navItems() {
        List<Nav> l = new ArrayList<>();
        int ih = itemH(), y = wy() + 40;
        l.add(new Nav("All", null, NAV_CATEGORY, y)); y += ih;
        for (Category c : Category.values()) { l.add(new Nav(c.getDisplayName(), c, NAV_CATEGORY, y)); y += ih; }
        y = settingsLabelY() + 11;
        l.add(new Nav("HUD", null, NAV_HUD, y)); y += ih;
        l.add(new Nav("Theme", null, NAV_THEME, y));
        return l;
    }

    private static int rowH(Kind k) {
        return switch (k) { case DOUBLE, INT -> 24; default -> 17; };
    }

    private static List<Setting<?>> shown(Module m) {
        List<Setting<?>> out = new ArrayList<>();
        out.addAll(m.settings);
        return out;
    }

    private static Kind kindOf(Setting<?> s) {
        if (s instanceof Setting.BooleanSetting) return Kind.BOOL;
        if (s instanceof Setting.DoubleSetting) return Kind.DOUBLE;
        if (s instanceof Setting.ModeSetting) return Kind.MODE;
        if (s instanceof Setting.KeySetting) return Kind.KEY;
        if (s instanceof Setting.TextSetting) return Kind.TEXT;
        return Kind.INT;
    }

    private static int fullH(Module m) {
        int h = 4;
        for (Setting<?> s : shown(m)) h += rowH(kindOf(s));
        return h + rowH(Kind.BIND) + rowH(Kind.RESET);
    }

    private List<Module> visibleModules() {
        String q = query.trim().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<>();
        for (Module m : NightfallClient.getInstance().moduleManager.getModules()) {
            boolean match = !q.isEmpty() ? (m.getName().toLowerCase(Locale.ROOT).contains(q)
                    || (m.getDescription() != null && m.getDescription().toLowerCase(Locale.ROOT).contains(q)))
                : (selected == null || m.getCategory() == selected);
            if (!match) continue;
            if (view == 1 && !m.isEnabled()) continue;
            if (view == 2 && !ThemeManager.isFavorite(m.getName())) continue;
            out.add(m);
        }
        return out;
    }

    private List<Row> layout() {
        List<Row> rows = new ArrayList<>();
        int cols = cw() >= 640 ? 3 : cw() >= 250 ? 2 : 1;
        int colW = (cw() - GAP * (cols - 1)) / cols;
        int[] colY = new int[cols];
        int idx = 0;
        for (Module m : visibleModules()) {
            int c = idx++ % cols;
            int x = cx() + c * (colW + GAP);
            int y = top() - (int) scroll + colY[c];
            float t = Anim.easeOutCubic(expandT.getOrDefault(m, 0f));
            int vis = (int) (fullH(m) * t);
            int cardH = HEAD + vis;
            rows.add(new Row(Kind.MODULE, m, null, x, y, colW, HEAD, y, y + HEAD, cardH));
            if (t > 0.001f) {
                int ry = y + HEAD + 2;
                for (Setting<?> s : shown(m)) {
                    Kind k = kindOf(s);
                    rows.add(new Row(k, m, s, x + 6, ry, colW - 12, rowH(k), y + HEAD, y + cardH, 0));
                    ry += rowH(k);
                }
                rows.add(new Row(Kind.BIND, m, null, x + 6, ry, colW - 12, rowH(Kind.BIND), y + HEAD, y + cardH, 0)); ry += rowH(Kind.BIND);
                rows.add(new Row(Kind.RESET, m, null, x + 6, ry, colW - 12, rowH(Kind.RESET), y + HEAD, y + cardH, 0));
            }
            colY[c] += cardH + GAP;
        }
        int mx = 0;
        for (int v : colY) mx = Math.max(mx, v);
        contentH = mx;
        return rows;
    }

    private int enabledTotal() { int n = 0; for (Module m : NightfallClient.getInstance().moduleManager.getModules()) if (m.isEnabled()) n++; return n; }
    private int enabledIn(Category c) { int n = 0; for (Module m : NightfallClient.getInstance().moduleManager.getModules()) if (m.isEnabled() && (c == null || m.getCategory() == c)) n++; return n; }
    private String chipLabel(int i) { return i == 0 ? "All" : i == 1 ? "Enabled " + enabledTotal() : "Favorites " + ThemeManager.FAVORITES.size(); }
    private int chipW(int i) { return this.font.width(chipLabel(i)) + 10; }
    private int chipX(int i) { int x = cx(); for (int k = 0; k < i; k++) x += chipW(k) + 4; return x; }

    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }

    private static String keyName(int key) {
        if (key < 0) return "none";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        try { return InputConstants.Type.KEYSYM.getOrCreate(key).getName().replace("key.keyboard.", "").replace("key.mouse.", "mouse ").toUpperCase(Locale.ROOT); }
        catch (RuntimeException e) { return "KEY " + key; }
    }

    // ------------------------------------------------------------------ drawing helpers

    private float anim(Map<Object, Float> m, Object k, float target, float dt, float speed) {
        float v = Anim.approach(m.getOrDefault(k, 0f), target, dt, speed);
        m.put(k, v);
        return v;
    }

    private float anim2(Map<Module, Float> m, Module k, float target, float dt, float speed) {
        float v = Anim.approach(m.getOrDefault(k, 0f), target, dt, speed);
        m.put(k, v);
        return v;
    }

    /** Rounded fill (2 px corners). The pieces do not overlap, so translucent colours stay even. */
    private static void rr(GuiGraphics g, int x, int y, int w, int h, int col) {
        if (w < 5 || h < 5) { g.fill(x, y, x + w, y + h, col); return; }
        g.fill(x + 2, y, x + w - 2, y + 1, col);
        g.fill(x + 1, y + 1, x + w - 1, y + 2, col);
        g.fill(x, y + 2, x + w, y + h - 2, col);
        g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, col);
        g.fill(x + 2, y + h - 1, x + w - 2, y + h, col);
    }

    /** Rounded fill with bigger (3 px) corners, for the main panel. */
    private static void rr3(GuiGraphics g, int x, int y, int w, int h, int col) {
        if (w < 8 || h < 8) { rr(g, x, y, w, h, col); return; }
        g.fill(x + 3, y, x + w - 3, y + 1, col);
        g.fill(x + 1, y + 1, x + w - 1, y + 3, col);
        g.fill(x, y + 3, x + w, y + h - 3, col);
        g.fill(x + 1, y + h - 3, x + w - 1, y + h - 1, col);
        g.fill(x + 3, y + h - 1, x + w - 3, y + h, col);
    }

    /** Applies the text colour mode (Light / White / Soft / Accent) to a colour, keeping its alpha. */
    private static int tint(int c) {
        int mode = ThemeManager.textColor;
        if (mode == 0) return c;
        int target = mode == 1 ? 0xFFFFFF : mode == 2 ? 0xA8A8B4 : (ThemeManager.ACCENT & 0xFFFFFF);
        float t = mode == 1 ? 0.55f : mode == 2 ? 0.40f : 0.30f;
        return Anim.mix(c, (c & 0xFF000000) | target, t);
    }

    private void text(GuiGraphics g, String s, int x, int y, int color) {
        g.drawString(this.font, s, x, y, tint(color), ThemeManager.textShadow);
    }

    /** Module names and headings: bold when the option is on. */
    private void title(GuiGraphics g, String s, int x, int y, int color) {
        if (ThemeManager.boldTitles) g.drawString(this.font, Component.literal(s).withStyle(ChatFormatting.BOLD), x, y, tint(color), ThemeManager.textShadow);
        else text(g, s, x, y, color);
    }

    private int titleWidth(String s) {
        return ThemeManager.boldTitles ? this.font.width(Component.literal(s).withStyle(ChatFormatting.BOLD)) : this.font.width(s);
    }

    private void pill(GuiGraphics g, int x, int y, float on, float a) {
        int w = PILL_W, h = 11;
        rr(g, x, y, w, h, Anim.fade(Anim.mix(OFF_TRACK, ON, on), a));
        int kx = x + 2 + (int) ((w - h) * on);
        rr(g, kx, y + 2, 7, 7, Anim.fade(Anim.mix(0xFFB8B8C8, 0xFF1A1A20, on), a));
    }

    /** Small rounded value box on the right of a row (like the drop-down buttons in the reference). */
    private void valueBox(GuiGraphics g, int right, int y, String text, float a, int col) {
        int bw = Math.max(34, this.font.width(text) + 10);
        rr(g, right - bw, y + 2, bw, 13, Anim.fade(0x22FFFFFF, a));
        text(g, text, right - bw + (bw - this.font.width(text)) / 2, y + 5, Anim.fade(col, a));
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        openT = Anim.approach(openT, 1f, dt, 14f);
        float a = Anim.easeOutCubic(openT);
        scroll = Anim.approach(scroll, scrollTarget, dt, 18f);

        g.fill(0, 0, this.width, this.height, ((int) (0x1C * a) << 24) | 0x000008);
        int wx = wx(), wy = wy(), ww = ww(), wh = wh();

        // glass panel, thin outline, sidebar divider
        rr3(g, wx, wy, ww, wh, Anim.fade(0xB8101015, a));
        int line = Anim.fade(0x24FFFFFF, a);
        g.fill(wx + 3, wy, wx + ww - 3, wy + 1, line);
        g.fill(wx + 3, wy + wh - 1, wx + ww - 3, wy + wh, line);
        g.fill(wx, wy + 3, wx + 1, wy + wh - 3, line);
        g.fill(wx + ww - 1, wy + 3, wx + ww, wy + wh - 3, line);
        g.fill(wx + SIDE, wy + 6, wx + SIDE + 1, wy + wh - 6, Anim.fade(0x16FFFFFF, a));

        // sidebar: logo, categories, tools
        rr(g, wx + 10, wy + 9, 9, 9, Anim.fade(ON, a));
        rr(g, wx + 12, wy + 11, 5, 5, Anim.fade(0xFF101015, a));
        title(g, "Ghostline", wx + 24, wy + 10, Anim.fade(TXT, a));
        text(g, "Client categories", wx + 10, wy + 28, Anim.fade(GRAY_DIM, a));
        text(g, "Settings", wx + 10, settingsLabelY(), Anim.fade(GRAY_DIM, a));
        int ih = itemH();
        for (Nav n : navItems()) {
            boolean sel = n.type() == NAV_CATEGORY && n.cat() == selected && query.isEmpty();
            boolean hv = in(mouseX, mouseY, wx + 6, n.y(), SIDE - 12, ih - 1);
            float h = anim(hover, n.label(), hv || sel ? 1f : 0f, dt, 16f);
            if (h > 0.01f) rr(g, wx + 6, n.y(), SIDE - 12, ih - 1, Anim.fade(Anim.mix(0x00FFFFFF, sel ? 0x26FFFFFF : 0x12FFFFFF, h), a));
            rr(g, wx + 12, n.y() + (ih - 5) / 2, 5, 5, Anim.fade(Anim.mix(0x55FFFFFF, 0xDDFFFFFF, sel ? 1f : h * 0.6f), a));
            text(g, n.label(), wx + 23, n.y() + (ih - 8) / 2, Anim.fade(Anim.mix(0xFF9A9AA8, 0xFFFFFFFF, h), a));
            if (n.type() == NAV_CATEGORY) {
                int on = enabledIn(n.cat());
                if (on > 0) { String bn = String.valueOf(on); text(g, bn, wx + SIDE - 12 - this.font.width(bn), n.y() + (ih - 8) / 2, Anim.fade(Anim.mix(0xFF8888A0, ON, sel ? 1f : 0.4f), a)); }
            }
        }

        // top bar: menu icon, tab title, hint, search field
        for (int i = 0; i < 3; i++) g.fill(cx(), wy + 10 + i * 3, cx() + 8, wy + 11 + i * 3, Anim.fade(0xAAFFFFFF, a));
        String title = !query.trim().isEmpty() ? "Search" : selected == null ? "All" : selected.getDisplayName();
        title(g, title, cx() + 14, wy + 10, Anim.fade(TXT, a));
        int sx = searchX(), sy = searchY();
        boolean shv = in(mouseX, mouseY, sx, sy, SEARCH_W, SEARCH_H);
        float sh = anim(hover, SEARCH_KEY, shv || searchFocus ? 1f : 0f, dt, 16f);
        rr(g, sx, sy, SEARCH_W, SEARCH_H, Anim.fade(Anim.mix(0x33000000, 0x55000000, sh), a));
        if (searchFocus) g.fill(sx + 3, sy + SEARCH_H - 1, sx + SEARCH_W - 3, sy + SEARCH_H, Anim.fade(ON, a));
        if (query.isEmpty() && !searchFocus) {
            text(g, "Search", sx + 6, sy + 3, Anim.fade(GRAY_DIM, a));
        } else {
            String shownText = query;
            while (shownText.length() > 1 && this.font.width(shownText) > SEARCH_W - 14) shownText = shownText.substring(1);
            text(g, shownText, sx + 6, sy + 3, Anim.fade(TXT, a));
            if (searchFocus && (System.currentTimeMillis() / 500) % 2 == 0) {
                int cxp = sx + 6 + this.font.width(shownText) + 1;
                g.fill(cxp, sy + 3, cxp + 1, sy + 11, Anim.fade(TXT, a));
            }
        }
        g.fill(cx(), wy + 27, wx + ww - 10, wy + 28, Anim.fade(0x16FFFFFF, a));
        for (int i = 0; i < 3; i++) {
            int chx = chipX(i), cw2 = chipW(i);
            boolean chHover = in(mouseX, mouseY, chx, wy + 31, cw2, 12);
            float chA = anim(hover, "chip" + i, view == i ? 1f : chHover ? 0.5f : 0f, dt, 16f);
            if (chA > 0.01f) rr(g, chx, wy + 31, cw2, 12, Anim.fade(Anim.mix(0x00FFFFFF, 0x30FFFFFF, chA), a));
            text(g, chipLabel(i), chx + 5, wy + 33, Anim.fade(Anim.mix(0xFF9A9AA8, 0xFFFFFFFF, Math.max(chA, view == i ? 1f : 0f)), a));
        }

        // module cards
        List<Row> rows = layout();
        int viewH = bottom() - top();
        int maxScroll = Math.max(0, contentH - viewH);
        scrollTarget = Mth.clamp(scrollTarget, 0, maxScroll);
        if (scroll > maxScroll) scroll = maxScroll;
        String tip = null;
        g.enableScissor(wx + SIDE + 2, top(), wx + ww - 2, bottom());
        for (Row r : rows) {
            if (r.kind == Kind.MODULE) {
                Module m = r.module;
                float en = anim2(enableT, m, m.isEnabled() ? 1f : 0f, dt, 12f);
                anim2(expandT, m, open.contains(m) ? 1f : 0f, dt, 12f);
                if (r.y + r.cardH < top() || r.y > bottom()) continue;
                boolean hv = in(mouseX, mouseY, r.x, r.y, r.w, HEAD) && mouseY >= top() && mouseY <= bottom();
                float h = anim(hover, m, hv ? 1f : 0f, dt, 16f);
                int bg = Anim.mix(Anim.mix(0x16FFFFFF, 0x24FFFFFF, h), 0x2CFFFFFF, en * 0.6f);
                rr(g, r.x, r.y, r.w, r.cardH, Anim.fade(bg, a));
                rr(g, r.x + 5, r.y + 4, 12, 12, Anim.fade(Anim.mix(0x1CFFFFFF, 0x44FFFFFF, en), a));
                String ini = m.getName().substring(0, 1).toUpperCase(Locale.ROOT);
                text(g, ini, r.x + 11 - this.font.width(ini) / 2, r.y + 6, Anim.fade(Anim.mix(0xFFA8A8B6, 0xFFFFFFFF, en), a));
                title(g, m.getName(), r.x + 22, r.y + 6, Anim.fade(Anim.mix(0xFFC8C8D4, 0xFFFFFFFF, Math.max(h, en)), a));
                int pillX = r.x + r.w - 8 - PILL_W;
                pill(g, pillX, r.y + 5, en, a);
                float ex = expandT.getOrDefault(m, 0f);
                boolean fav = ThemeManager.isFavorite(m.getName());
                text(g, "*", pillX - 21, r.y + 7, Anim.fade(fav ? 0xFFFFD060 : Anim.mix(GRAY_DIM, TXT, h), a));
                if (!m.settings.isEmpty()) text(g, ex > 0.5f ? "v" : ">", pillX - 9, r.y + 6, Anim.fade(Anim.mix(GRAY_DIM, TXT, h), a));
                if (ex > 0.05f) g.fill(r.x + 6, r.y + HEAD, r.x + r.w - 6, r.y + HEAD + 1, Anim.fade(0x16FFFFFF, a * ex));
                if (m.getKeyBind() >= 0) {
                    String kn = keyName(m.getKeyBind());
                    int kw = this.font.width(kn) + 8;
                    int kx = pillX - 28 - kw;
                    if (kx > r.x + 26 + titleWidth(m.getName()) + 4) {
                        rr(g, kx, r.y + 3, kw, 14, Anim.fade(0x2A000000, a));
                        text(g, kn, kx + 4, r.y + 6, Anim.fade(TXT2, a));
                    }
                }
                if (hv && m.getDescription() != null && !m.getDescription().isEmpty()) tip = m.getDescription();
            } else {
                if (r.clipBottom <= r.clipTop) continue;
                int cy1 = Math.max(r.clipTop, top()), cy2 = Math.min(r.clipBottom, bottom());
                if (cy2 <= cy1) continue;
                g.enableScissor(r.x - 4, cy1, r.x + r.w + 4, cy2);
                drawSetting(g, r, mouseX, mouseY, dt, a);
                g.disableScissor();
            }
        }
        g.disableScissor();

        if (tip != null) {
            int tx = cx() + 14 + titleWidth(title) + 10, room = sx - tx - 6;
            String tt = tip;
            while (tt.length() > 1 && this.font.width(tt) > room) tt = tt.substring(0, tt.length() - 1);
            if (room > 20) text(g, tt, tx, wy + 10, Anim.fade(GRAY_DIM, a));
        }
        if (rows.isEmpty()) {
            String none = view == 1 ? "No module is on" : view == 2 ? "No favorites: tap the * on a card" : "Nothing found";
            text(g, none, cx() + (cw() - this.font.width(none)) / 2, top() + 20, Anim.fade(GRAY_DIM, a));
        }
        if (maxScroll > 0) {
            int barH = Math.max(14, viewH * viewH / Math.max(viewH, contentH));
            int barY = top() + (int) ((viewH - barH) * (scroll / maxScroll));
            g.fill(wx + ww - 9, top(), wx + ww - 6, bottom(), Anim.fade(0x14FFFFFF, a));
            g.fill(wx + ww - 9, barY, wx + ww - 6, barY + barH, Anim.fade(0x88FFFFFF, a));
        }
        super.render(g, mouseX, mouseY, partial);
    }

    @SuppressWarnings("unchecked")
    private void drawSetting(GuiGraphics g, Row r, int mouseX, int mouseY, float dt, float a) {
        int x = r.x, w = r.w;
        boolean hv = in(mouseX, mouseY, x, r.y, w, r.h) && mouseY > r.clipTop && mouseY < r.clipBottom;
        Object key = r.setting != null ? r.setting : (r.kind == Kind.BIND ? bindKey(r.module) : (Object) r.kind);
        float h = anim(hover, key, hv ? 1f : 0f, dt, 16f);
        if (h > 0.01f) rr(g, x, r.y, w, r.h - 1, Anim.fade(0x12FFFFFF, a * h));
        int label = Anim.mix(TXT2, 0xFFFFFFFF, h);
        switch (r.kind) {
            case BOOL -> {
                Setting<Boolean> b = (Setting<Boolean>) r.setting;
                float on = Anim.approach(switchT.getOrDefault(b, b.getValue() ? 1f : 0f), b.getValue() ? 1f : 0f, dt, 14f);
                switchT.put(b, on);
                text(g, r.setting.getName(), x + 4, r.y + 5, Anim.fade(label, a));
                pill(g, x + w - 4 - PILL_W, r.y + 3, on, a);
            }
            case DOUBLE, INT -> {
                double min, max, val;
                if (r.setting instanceof Setting.DoubleSetting ds) { min = ds.getMin(); max = ds.getMax(); val = ds.getValue(); }
                else { Setting.IntSetting is = (Setting.IntSetting) r.setting; min = is.getMin(); max = is.getMax(); val = is.getValue(); }
                text(g, r.setting.getName(), x + 4, r.y + 3, Anim.fade(label, a));
                String shownVal = r.setting.display();
                String vt = shownVal != null ? shownVal : r.kind == Kind.INT ? String.valueOf((int) val) : String.format(Locale.ROOT, "%.2f", val);
                text(g, vt, x + w - 4 - this.font.width(vt), r.y + 3, Anim.fade(TXT, a));
                int tx = x + 8, tw = w - 16, ty = r.y + 17;
                float pct = (float) Mth.clamp((val - min) / Math.max(1e-9, max - min), 0, 1);
                rr(g, tx, ty, tw, 3, Anim.fade(0x33FFFFFF, a));
                rr(g, tx, ty, Math.max(3, (int) (tw * pct)), 3, Anim.fade(ON, a));
                int kx = tx + (int) ((tw - 5) * pct);
                rr(g, kx, ty - 2, 5, 7, Anim.fade(0xFFFFFFFF, a));
            }
            case MODE -> {
                Setting.ModeSetting ms = (Setting.ModeSetting) r.setting;
                text(g, r.setting.getName(), x + 4, r.y + 5, Anim.fade(label, a));
                String opt = ms.display() != null ? ms.display() : ms.getOptions()[Mth.clamp(ms.getValue(), 0, ms.getOptions().length - 1)];
                valueBox(g, x + w - 4, r.y, opt, a, TXT);
            }
            case KEY -> {
                boolean lis = listeningKey == r.setting;
                text(g, r.setting.getName(), x + 4, r.y + 5, Anim.fade(label, a));
                String kt = lis ? "press a key" : (r.setting.display() != null ? r.setting.display() : "none");
                valueBox(g, x + w - 4, r.y, kt, a, lis ? 0xFFFFFFFF : TXT);
            }
            case TEXT -> {
                Setting.TextSetting ts = (Setting.TextSetting) r.setting;
                boolean ed = editing == ts;
                text(g, ts.getName(), x + 4, r.y + 5, Anim.fade(label, a));
                String raw = ts.getValue() == null ? "" : ts.getValue();
                String vis = ts.isSecret() ? "*".repeat(Math.min(raw.length(), 16)) : raw;
                int avail = w - 30 - this.font.width(ts.getName());
                if (ed && (System.currentTimeMillis() / 500) % 2 == 0) vis = vis + "_";
                if (vis.isEmpty() && !ed) vis = "-";
                while (vis.length() > 1 && this.font.width(vis) > avail) vis = ed ? vis.substring(1) : vis.substring(0, vis.length() - 1);
                valueBox(g, x + w - 4, r.y, vis, a, ed ? 0xFFFFFFFF : TXT);
            }
            case BIND -> {
                boolean lis = listening == r.module;
                text(g, lis ? "Press a key   Esc cancel   Bksp clear" : "Keybind", x + 4, r.y + 5, Anim.fade(label, a));
                if (!lis) valueBox(g, x + w - 4, r.y, keyName(r.module.getKeyBind()), a, TXT);
            }
            case RESET -> text(g, "Reset to defaults", x + 4, r.y + 5, Anim.fade(Anim.mix(GRAY_DIM, 0xFFFF7788, h), a));
            default -> { }
        }
    }

    // ------------------------------------------------------------------ input

    private boolean rightButton() {
        long win = GLFW.glfwGetCurrentContext();
        return win != 0 && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
    }

    private void setSlider(Row r, double mx) {
        int tx = r.x + 8, tw = r.w - 16;
        double pct = Mth.clamp((mx - tx) / Math.max(1, tw), 0, 1);
        if (r.setting instanceof Setting.DoubleSetting ds) {
            double v = ds.getMin() + (ds.getMax() - ds.getMin()) * pct;
            ds.setValue(ds.snap(v));
        } else if (r.setting instanceof Setting.IntSetting is) {
            is.setValue((int) Math.round(is.getMin() + (is.getMax() - is.getMin()) * pct));
        }
    }

    private void scrollFromBar(double my) {
        int viewH = bottom() - top();
        float pct = (float) Mth.clamp((my - top()) / Math.max(1, viewH), 0, 1);
        float max = Math.max(0, contentH - viewH);
        scrollTarget = pct * max; scroll = scrollTarget;
    }

    private static void reset(Module m) { for (Setting<?> s : m.settings) s.resetToDefault(); }

    @Override
    @SuppressWarnings("unchecked")
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        boolean right = rightButton();
        int wx = wx();
        listeningKey = null;
        editing = null;

        int viewH0 = bottom() - top();
        if (contentH > viewH0 && mx >= wx + ww() - 11 && mx <= wx + ww() && my >= top() && my <= bottom()) {
            dragScroll = true; scrollFromBar(my); return true;
        }
        for (int i = 0; i < 3; i++) {
            if (in(mx, my, chipX(i), wy() + 31, chipW(i), 12)) { view = i; LAST_VIEW = i; scroll = 0; scrollTarget = 0; listening = null; return true; }
        }
        if (my >= wy() && my <= wy() + 26 && mx >= cx() && mx <= searchX() - 4) {            // the top bar moves the window; double click centres it
            if (doubleClick) { OFF_X = 0; OFF_Y = 0; } else dragWin = true;
            return true;
        }
        for (Nav n : navItems()) {
            if (!in(mx, my, wx + 8, n.y(), SIDE - 16, itemH() - 1)) continue;
            listening = null;
            switch (n.type()) {
                case NAV_CATEGORY -> { selected = n.cat(); LAST_SEL = selected; query = ""; searchFocus = false; scroll = 0; scrollTarget = 0; }
                case NAV_HUD -> Minecraft.getInstance().setScreen(new com.ghostline.mod.HudEditorScreen());
                case NAV_THEME -> Minecraft.getInstance().setScreen(new ThemeScreen());
                default -> { }
            }
            return true;
        }
        if (in(mx, my, searchX(), searchY(), SEARCH_W, SEARCH_H)) { searchFocus = true; listening = null; return true; }
        searchFocus = false;

        if (my < top() || my > bottom()) return super.mouseClicked(event, doubleClick);
        for (Row r : layout()) {
            if (r.kind == Kind.MODULE) {
                if (!in(mx, my, r.x, r.y, r.w, HEAD)) continue;
                int pillX = r.x + r.w - 8 - PILL_W;
                if (mx >= pillX - 24 && mx < pillX - 14 && !right) { ThemeManager.toggleFavorite(r.module.getName()); return true; }   // the star
                if ((mx >= pillX - 6 && !right) || r.module.settings.isEmpty()) r.module.toggle();                       // the switch (and a bit around it)
                else { if (!open.remove(r.module)) open.add(r.module); listening = null; } // anywhere else on the card header
                return true;
            }
            if (my < r.clipTop || my > r.clipBottom || !in(mx, my, r.x, r.y, r.w, r.h)) continue;
            switch (r.kind) {
                case BOOL -> { Setting<Boolean> b = (Setting<Boolean>) r.setting; b.setValue(!b.getValue()); }
                case DOUBLE, INT -> { dragging = r; setSlider(r, mx); }
                case MODE -> {
                    Setting.ModeSetting ms = (Setting.ModeSetting) r.setting;
                    int n = ms.getOptions().length;
                    if (n > 0) ms.setValue((ms.getValue() + (right ? n - 1 : 1)) % n);
                }
                case KEY -> listeningKey = r.setting;
                case TEXT -> editing = (Setting.TextSetting) r.setting;
                case BIND -> listening = listening == r.module ? null : r.module;
                case RESET -> reset(r.module);
                default -> { }
            }
            return true;
        }
        listening = null;
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragWin) {
            int roomX = Math.max(0, this.width - ww()), roomY = Math.max(0, this.height - wh());
            OFF_X = Mth.clamp(OFF_X + (int) Math.round(dragX), -roomX / 2, roomX - roomX / 2);
            OFF_Y = Mth.clamp(OFF_Y + (int) Math.round(dragY), -roomY / 2, roomY - roomY / 2);
            return true;
        }
        if (dragScroll) { scrollFromBar(event.y()); return true; }
        if (dragging != null) { setSlider(dragging, event.x()); return true; }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null; dragScroll = false; dragWin = false;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollTarget = Mth.clamp(scrollTarget - (float) (scrollY * 34), 0, Math.max(0, contentH - (bottom() - top())));
        return true;
    }

    private static char typed(int key) {
        if (key >= GLFW.GLFW_KEY_A && key <= GLFW.GLFW_KEY_Z) return (char) ('a' + (key - GLFW.GLFW_KEY_A));
        if (key >= GLFW.GLFW_KEY_0 && key <= GLFW.GLFW_KEY_9) return (char) ('0' + (key - GLFW.GLFW_KEY_0));
        if (key == GLFW.GLFW_KEY_SPACE) return ' ';
        return 0;
    }

    private static char typedText(int key, boolean shift) {
        if (key >= GLFW.GLFW_KEY_A && key <= GLFW.GLFW_KEY_Z) { char c = (char) ('a' + (key - GLFW.GLFW_KEY_A)); return shift ? Character.toUpperCase(c) : c; }
        if (key >= GLFW.GLFW_KEY_0 && key <= GLFW.GLFW_KEY_9) return (char) ('0' + (key - GLFW.GLFW_KEY_0));
        return switch (key) {
            case GLFW.GLFW_KEY_SPACE -> ' ';
            case GLFW.GLFW_KEY_PERIOD -> '.';
            case GLFW.GLFW_KEY_COMMA -> ',';
            case GLFW.GLFW_KEY_MINUS -> shift ? '_' : '-';
            case GLFW.GLFW_KEY_SLASH -> '/';
            case GLFW.GLFW_KEY_SEMICOLON -> shift ? ':' : ';';
            default -> 0;
        };
    }

    /** True while a text field, key capture or search box is active (so movement keys must not fire). */
    public boolean isTyping() { return searchFocus || editing != null || listening != null || listeningKey != null; }

    @Override
    @SuppressWarnings("unchecked")
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listeningKey != null) {
            Setting<Integer> ks = (Setting<Integer>) listeningKey;
            if (key != GLFW.GLFW_KEY_ESCAPE) ks.setValue(key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? -1 : key);
            listeningKey = null;
            return true;
        }
        if (editing != null) {
            String cur = editing.getValue() == null ? "" : editing.getValue();
            long win = GLFW.glfwGetCurrentContext();
            boolean ctrl = win != 0 && (GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS);
            boolean shift = win != 0 && (GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS);
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { editing = null; return true; }
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!cur.isEmpty()) editing.setValue(cur.substring(0, cur.length() - 1)); return true; }
            if (ctrl && key == GLFW.GLFW_KEY_V) {
                String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
                if (clip != null) {
                    String joined = cur + clip.replace("\n", "").replace("\r", "").trim();
                    editing.setValue(joined.length() > 256 ? joined.substring(0, 256) : joined);
                }
                return true;
            }
            if (ctrl && key == GLFW.GLFW_KEY_A) { editing.setValue(""); return true; }
            char c = typedText(key, shift);
            if (c != 0 && cur.length() < 256) editing.setValue(cur + c);
            return true;
        }
        if (listening != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) listening.setKeyBind(key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? -1 : key);
            listening = null;
            return true;
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) { searchFocus = false; return true; }
            if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); scroll = 0; scrollTarget = 0; return true; }
            char c = typed(key);
            if (c != 0 && query.length() < 24) { query += c; scroll = 0; scrollTarget = 0; }
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        try { NightfallClient.getInstance().configManager.save("default"); } catch (RuntimeException ignored) { }
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
