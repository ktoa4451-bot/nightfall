package dev.nightfall.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Look of the menu: accent colour, window size, text shadow, text colour and bold titles. Changes are saved at once. */
public class ThemeScreen extends Screen {
    private Button sizeBtn, shadowBtn, colorBtn, boldBtn;

    public ThemeScreen() { super(Component.literal("Theme Studio")); }

    private static String onOff(boolean b) { return b ? "On" : "Off"; }

    private void refresh() {
        sizeBtn.setMessage(Component.literal("Menu size: " + ThemeManager.menuSize + "%"));
        shadowBtn.setMessage(Component.literal("Text shadow: " + onOff(ThemeManager.textShadow)));
        colorBtn.setMessage(Component.literal("Text colour: " + ThemeManager.TEXT_COLORS[ThemeManager.textColor]));
        boldBtn.setMessage(Component.literal("Bold titles: " + onOff(ThemeManager.boldTitles)));
    }

    @Override
    protected void init() {
        int cx = this.width / 2, top = Math.max(30, this.height / 2 - 75);
        int colW = 130, gap = 10, lx = cx - colW - gap / 2, rx = cx + gap / 2;

        String[] themes = {"Purple", "Cyan", "Crimson", "Emerald", "Midnight"};
        for (int i = 0; i < themes.length; i++) {
            String theme = themes[i];
            this.addRenderableWidget(Button.builder(Component.literal(theme), b -> {
                ThemeManager.applyTheme(theme);
                Minecraft.getInstance().setScreen(new ClickGUI());
            }).bounds(lx, top + i * 24, colW, 20).build());
        }

        this.addRenderableWidget(Button.builder(Component.literal("-"), b -> { ThemeManager.setMenuSize(ThemeManager.menuSize - 5); refresh(); }).bounds(rx, top, 20, 20).build());
        sizeBtn = this.addRenderableWidget(Button.builder(Component.literal(""), b -> { ThemeManager.setMenuSize(100); refresh(); }).bounds(rx + 22, top, colW - 44, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("+"), b -> { ThemeManager.setMenuSize(ThemeManager.menuSize + 5); refresh(); }).bounds(rx + colW - 20, top, 20, 20).build());
        shadowBtn = this.addRenderableWidget(Button.builder(Component.literal(""), b -> { ThemeManager.setTextShadow(!ThemeManager.textShadow); refresh(); }).bounds(rx, top + 24, colW, 20).build());
        colorBtn = this.addRenderableWidget(Button.builder(Component.literal(""), b -> { ThemeManager.setTextColor(ThemeManager.textColor + 1); refresh(); }).bounds(rx, top + 48, colW, 20).build());
        boldBtn = this.addRenderableWidget(Button.builder(Component.literal(""), b -> { ThemeManager.setBoldTitles(!ThemeManager.boldTitles); refresh(); }).bounds(rx, top + 72, colW, 20).build());
        refresh();

        this.addRenderableWidget(Button.builder(Component.literal("Back"), b -> Minecraft.getInstance().setScreen(new ClickGUI())).bounds(cx - colW - gap / 2, top + 132, colW * 2 + gap, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);
        int top = Math.max(30, this.height / 2 - 75);
        g.drawCenteredString(this.font, "Theme Studio", this.width / 2, top - 22, ThemeManager.TEXT_WHITE);
        g.drawCenteredString(this.font, "Click the size button to reset it to 100%", this.width / 2, top + 100, ThemeManager.TEXT_GRAY);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
