package dev.nightfall.gui;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/** Colours and look of the menu. Everything here is saved to config/nightfall/appearance.properties and restored on start. */
public class ThemeManager {
    public static int ACCENT = 0xFF7C5CFF;
    public static int BG_DARK = 0xEE0A0A0F;
    public static int PANEL_BG = 0xFF15151C;
    public static int TEXT_WHITE = 0xFFFFFFFF;
    public static int TEXT_GRAY = 0xFFAAAAAA;
    public static int HOVER = 0xFF2A2A38;

    public static final String[] TEXT_COLORS = {"Light", "White", "Soft", "Accent"};
    public static String themeName = "purple";
    /** Size of the menu window in percent of the normal size (85..130). */
    public static int menuSize = 100;
    public static boolean textShadow = true;
    /** 0 Light (default), 1 White, 2 Soft (dimmer), 3 Accent (tinted). */
    public static int textColor = 0;
    public static boolean boldTitles = false;
    /** Names of the favourite modules (the star on the card, the Favorites filter). */
    public static final java.util.Set<String> FAVORITES = new java.util.LinkedHashSet<>();

    static { load(); }

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("nightfall").resolve("appearance.properties"); }

    public static void applyTheme(String themeName) {
        ThemeManager.themeName = themeName.toLowerCase(Locale.ROOT);
        switch (ThemeManager.themeName) {
            case "cyan" -> ACCENT = 0xFF00E5FF;
            case "crimson" -> ACCENT = 0xFFFF3355;
            case "emerald" -> ACCENT = 0xFF00FF88;
            case "midnight" -> ACCENT = 0xFF4444AA;
            default -> { ACCENT = 0xFF7C5CFF; ThemeManager.themeName = "purple"; }
        }
        save();
    }

    public static void setMenuSize(int percent) { menuSize = Math.max(85, Math.min(130, percent)); save(); }
    public static void setTextShadow(boolean on) { textShadow = on; save(); }
    public static void setTextColor(int mode) { textColor = ((mode % TEXT_COLORS.length) + TEXT_COLORS.length) % TEXT_COLORS.length; save(); }
    public static void setBoldTitles(boolean on) { boldTitles = on; save(); }
    public static boolean isFavorite(String module) { return FAVORITES.contains(module); }
    public static void toggleFavorite(String module) { if (!FAVORITES.remove(module)) FAVORITES.add(module); save(); }

    private static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Properties p = new Properties();
            try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) { p.load(r); }
            String t = p.getProperty("theme", "purple");
            switch (t) {
                case "cyan" -> ACCENT = 0xFF00E5FF;
                case "crimson" -> ACCENT = 0xFFFF3355;
                case "emerald" -> ACCENT = 0xFF00FF88;
                case "midnight" -> ACCENT = 0xFF4444AA;
                default -> { ACCENT = 0xFF7C5CFF; t = "purple"; }
            }
            themeName = t;
            menuSize = Math.max(85, Math.min(130, Integer.parseInt(p.getProperty("menuSize", "100").trim())));
            textShadow = Boolean.parseBoolean(p.getProperty("textShadow", "true"));
            textColor = Math.max(0, Math.min(TEXT_COLORS.length - 1, Integer.parseInt(p.getProperty("textColor", "0").trim())));
            boldTitles = Boolean.parseBoolean(p.getProperty("boldTitles", "false"));
            FAVORITES.clear();
            for (String f : p.getProperty("favorites", "").split(",")) if (!f.isBlank()) FAVORITES.add(f.trim());
        } catch (IOException | RuntimeException ignored) { }          // unreadable file: keep the defaults
    }

    private static void save() {
        try {
            Files.createDirectories(file().getParent());
            Properties p = new Properties();
            p.setProperty("theme", themeName);
            p.setProperty("menuSize", String.valueOf(menuSize));
            p.setProperty("textShadow", String.valueOf(textShadow));
            p.setProperty("textColor", String.valueOf(textColor));
            p.setProperty("boldTitles", String.valueOf(boldTitles));
            p.setProperty("favorites", String.join(",", FAVORITES));
            try (Writer w = Files.newBufferedWriter(file(), StandardCharsets.UTF_8)) { p.store(w, "Ghostline Client appearance"); }
        } catch (IOException ignored) { }
    }
}
