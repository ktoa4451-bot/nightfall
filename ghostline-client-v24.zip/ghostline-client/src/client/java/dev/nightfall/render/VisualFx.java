package dev.nightfall.render;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.Module;
import dev.nightfall.module.impl.visuals.Arrows;
import dev.nightfall.module.impl.visuals.BlockOutline;
import dev.nightfall.module.impl.visuals.ChinaHat;
import dev.nightfall.module.impl.visuals.HpAlert;
import dev.nightfall.module.impl.visuals.JumpCircle;
import dev.nightfall.module.impl.visuals.Prediction;
import dev.nightfall.module.impl.visuals.SeeInvisible;
import dev.nightfall.module.impl.visuals.TargetEsp;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.ArrayList;
import java.util.List;

/**
 * Screen-space visuals: low-HP frame, arrows to players, block outline, jump rings, china hat, projectile paths
 * and boxes on invisible entities. Everything is projected onto the screen (see Project), so it needs the first-person view.
 */
public final class VisualFx {
    private VisualFx() { }

    @SuppressWarnings("unchecked")
    private static <T extends Module> T on(String name) {
        Module m = NightfallClient.getInstance().moduleManager.getByName(name).orElse(null);
        return m != null && m.isEnabled() ? (T) m : null;
    }

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.options.hideGui) return;
        hpAlert(g, p);
        if (!Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;
        arrows(g, mc, p);
        blockOutline(g, mc);
        jumpCircle(g);
        chinaHat(g, mc, p, pt);
        prediction(g, mc, p, pt);
        seeInvisible(g, mc, p, pt);
        targetEsp(g, mc, p, pt);
    }

    // ------------------------------------------------------------------ HpAlert

    private static void hpAlert(GuiGraphics g, LocalPlayer p) {
        HpAlert m = on("HpAlert");
        if (m == null || !p.isAlive() || p.getHealth() > m.health.getValue()) return;
        float pulse = 0.5f + 0.5f * (float) Math.sin(System.currentTimeMillis() / 180.0);
        int w = g.guiWidth(), h = g.guiHeight(), t = 4;
        for (int i = 0; i < 12; i++) {
            int col = Ui.c(0xFF2030, (0.30f * pulse + 0.05f) * (1f - i / 12f));
            g.fill(0, i * t, w, i * t + t, col);
            g.fill(0, h - (i + 1) * t, w, h - i * t, col);
            g.fill(i * t, 0, i * t + t, h, col);
            g.fill(w - (i + 1) * t, 0, w - i * t, h, col);
        }
        String s = "LOW HP  " + (int) Math.ceil(p.getHealth());
        Ui.text(g, s, w / 2 - Ui.tw(s) / 2, h / 2 + 38, Ui.c(0xFF5060, 0.7f + 0.3f * pulse));
    }

    // ------------------------------------------------------------------ Arrows

    private static void arrows(GuiGraphics g, Minecraft mc, LocalPlayer p) {
        Arrows m = on("Arrows");
        if (m == null) return;
        int sw = g.guiWidth(), sh = g.guiHeight(), size = m.size.getValue();
        double rad = Math.min(sw, sh) * m.radius.getValue() / 100.0;
        Vec3 eye = Project.eye();
        for (Player e : mc.level.players()) {
            if (e == p || !e.isAlive() || e.isSpectator()) continue;
            double d = p.distanceTo(e);
            if (d > m.range.getValue()) continue;
            double ty = Math.toDegrees(Math.atan2(e.getZ() - eye.z, e.getX() - eye.x)) - 90.0;
            double rel = Math.toRadians(Mth.wrapDegrees((float) ty - Project.yaw));
            double ux = Math.sin(rel), uy = -Math.cos(rel);
            double cx = sw / 2.0 + ux * rad, cy = sh / 2.0 + uy * rad;
            float frac = Mth.clamp(e.getHealth() / Math.max(1f, e.getMaxHealth()), 0f, 1f);
            int col = Ui.c(Ui.mix(0xFF4040, 0x40FF60, frac), 0.95f);
            double bx = cx - ux * size * 0.5, by = cy - uy * size * 0.5, vx = -uy, vy = ux;
            int tipX = (int) (cx + ux * size), tipY = (int) (cy + uy * size);
            int ax = (int) (bx + vx * size * 0.7), ay = (int) (by + vy * size * 0.7);
            int cx2 = (int) (bx - vx * size * 0.7), cy2 = (int) (by - vy * size * 0.7);
            Ui.line(g, tipX, tipY, ax, ay, col);
            Ui.line(g, tipX, tipY, cx2, cy2, col);
            Ui.line(g, ax, ay, cx2, cy2, col);
            if (m.distance.getValue()) {
                String s = (int) d + "m";
                Ui.text(g, s, (int) cx - Ui.tw(s) / 2, (int) cy + (uy > 0 ? -size - 10 : size + 4), col);
            }
        }
    }

    // ------------------------------------------------------------------ BlockOutline

    private static void blockOutline(GuiGraphics g, Minecraft mc) {
        BlockOutline m = on("BlockOutline");
        if (m == null || !(mc.hitResult instanceof BlockHitResult bh) || bh.getType() != HitResult.Type.BLOCK) return;
        BlockPos pos = bh.getBlockPos();
        BlockState st = mc.level.getBlockState(pos);
        if (st.isAir()) return;
        VoxelShape shape = st.getShape(mc.level, pos);
        AABB bb = (shape.isEmpty() ? new AABB(0, 0, 0, 1, 1, 1) : shape.bounds()).move(pos).inflate(0.002);
        double[][] c = Project.corners(bb);
        if (c == null) return;
        int col = Ui.c(Ui.ACCENT, 0.95f);
        for (int i = 0; i < 8; i++) {
            for (int bit = 1; bit <= 4; bit <<= 1) {
                if ((i & bit) != 0) continue;
                double[] a = c[i], b = c[i | bit];
                Ui.line(g, (int) a[0], (int) a[1], (int) b[0], (int) b[1], col);
            }
        }
        if (m.fill.getValue()) {
            float[] r = Project.rect(bb);
            if (r != null) g.fill((int) r[0], (int) r[1], (int) r[2], (int) r[3], Ui.c(Ui.ACCENT, m.fillAlpha.getValue() / 100f));
        }
    }

    // ------------------------------------------------------------------ JumpCircle

    private static void ring(GuiGraphics g, double x, double y, double z, double r, int col) {
        double[] prev = null;
        for (int i = 0; i <= 40; i++) {
            double a = Math.PI * 2 * i / 40;
            double[] q = Project.point(x + Math.cos(a) * r, y, z + Math.sin(a) * r);
            if (q != null && prev != null) Ui.line(g, (int) prev[0], (int) prev[1], (int) q[0], (int) q[1], col);
            prev = q;
        }
    }

    private static void jumpCircle(GuiGraphics g) {
        JumpCircle m = on("JumpCircle");
        if (m == null) return;
        long now = System.nanoTime();
        double life = m.seconds.getValue() * 1e9;
        for (JumpCircle.Ring r : m.alive(now)) {
            double t = Mth.clamp((now - r.bornNanos()) / life, 0, 1);
            double e = 1 - Math.pow(1 - t, 3);
            double rr = m.radius.getValue() * e;
            int col = Ui.c(r.landing() ? 0x60C8FF : Ui.ACCENT, (float) (1 - t) * 0.95f);
            ring(g, r.x(), r.y(), r.z(), rr, col);
            ring(g, r.x(), r.y(), r.z(), rr * 0.9, col);
        }
    }

    // ------------------------------------------------------------------ ChinaHat

    private static void chinaHat(GuiGraphics g, Minecraft mc, LocalPlayer p, float pt) {
        ChinaHat m = on("ChinaHat");
        if (m == null) return;
        int col = Ui.c(Ui.ACCENT, 0.95f);
        for (Player e : mc.level.players()) {
            if (e == p || !e.isAlive() || e.isSpectator() || p.distanceTo(e) > m.range.getValue()) continue;
            Vec3 base = e.getPosition(pt);
            double topY = base.y + e.getBbHeight() + 0.02;
            double[] apex = Project.point(base.x, topY + 0.32, base.z);
            double[] prev = null;
            for (int i = 0; i <= 24; i++) {
                double a = Math.PI * 2 * i / 24;
                double[] q = Project.point(base.x + Math.cos(a) * 0.55, topY, base.z + Math.sin(a) * 0.55);
                if (q != null && prev != null) Ui.line(g, (int) prev[0], (int) prev[1], (int) q[0], (int) q[1], col);
                if (q != null && apex != null && i % 4 == 0) Ui.line(g, (int) apex[0], (int) apex[1], (int) q[0], (int) q[1], col);
                prev = q;
            }
        }
    }

    // ------------------------------------------------------------------ Prediction

    private static boolean tracked(EntityType<?> t) {
        return t == EntityType.ARROW || t == EntityType.SPECTRAL_ARROW || t == EntityType.TRIDENT || t == EntityType.ENDER_PEARL
            || t == EntityType.SNOWBALL || t == EntityType.EGG || t == EntityType.EXPERIENCE_BOTTLE;
    }

    private static void prediction(GuiGraphics g, Minecraft mc, LocalPlayer p, float pt) {
        Prediction m = on("Prediction");
        if (m == null) return;
        for (Entity e : mc.level.getEntitiesOfClass(Entity.class, p.getBoundingBox().inflate(m.range.getValue()), x -> x.isAlive() && tracked(x.getType()))) {
            Vec3 vel = e.getDeltaMovement();
            if (vel.lengthSqr() < 0.01) continue;                       // stuck in a block / stopped
            EntityType<?> t = e.getType();
            double grav = (t == EntityType.ARROW || t == EntityType.SPECTRAL_ARROW || t == EntityType.TRIDENT) ? 0.05 : t == EntityType.EXPERIENCE_BOTTLE ? 0.07 : 0.03;
            List<Vec3> pts = new ArrayList<>();
            Vec3 pos = e.getPosition(pt), landing = null;
            pts.add(pos);
            for (int i = 0; i < 120; i++) {
                Vec3 next = pos.add(vel);
                BlockHitResult hr = mc.level.clip(new ClipContext(pos, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, e));
                if (hr.getType() != HitResult.Type.MISS) { landing = hr.getLocation(); pts.add(landing); break; }
                pts.add(next);
                pos = next;
                vel = vel.scale(0.99).add(0, -grav, 0);
                if (pos.y < -128) break;
            }
            int col = Ui.c(t == EntityType.ENDER_PEARL ? 0xB080FF : 0xFFC050, 0.9f);
            double[] prev = null;
            for (Vec3 v : pts) {
                double[] q = Project.point(v.x, v.y, v.z);
                if (q != null && prev != null) Ui.line(g, (int) prev[0], (int) prev[1], (int) q[0], (int) q[1], col);
                prev = q;
            }
            if (landing != null) {
                float[] r = Project.rect(new AABB(landing.x - 0.2, landing.y - 0.2, landing.z - 0.2, landing.x + 0.2, landing.y + 0.2, landing.z + 0.2));
                if (r != null) Ui.box(g, (int) r[0], (int) r[1], Math.max((int) r[0] + 4, (int) r[2]), Math.max((int) r[1] + 4, (int) r[3]), 1, col);
            }
        }
    }

    // ------------------------------------------------------------------ TargetEsp

    private static void targetEsp(GuiGraphics g, Minecraft mc, LocalPlayer p, float pt) {
        TargetEsp m = on("TargetEsp");
        if (m == null) return;
        Entity t = m.target();
        if (t == null || t == p) return;
        Vec3 pos = t.getPosition(pt);
        double w = t.getBbWidth() * 0.9, hgt = t.getBbHeight();
        long ms = System.currentTimeMillis();
        float frac = t instanceof LivingEntity le ? Mth.clamp(le.getHealth() / Math.max(1f, le.getMaxHealth()), 0f, 1f) : 1f;
        int col = Ui.c(Ui.mix(0xFF4040, 0x40FF60, frac), 0.95f);
        switch (m.mode.getValue()) {
            case 1 -> {                                                       // three dots orbiting at chest height
                for (int k = 0; k < 3; k++) {
                    double a = ms / 450.0 + k * Math.PI * 2 / 3;
                    double[] q = Project.point(pos.x + Math.cos(a) * w, pos.y + hgt * 0.55 + Math.sin(ms / 700.0 + k) * 0.15, pos.z + Math.sin(a) * w);
                    if (q != null) g.fill((int) q[0] - 2, (int) q[1] - 2, (int) q[0] + 2, (int) q[1] + 2, col);
                }
            }
            case 2 -> {                                                       // corner box
                float[] r = Project.rect(t.getBoundingBox().move(pos.subtract(t.position())));
                if (r == null || !Project.onScreen(r)) return;
                int x1 = (int) r[0], y1 = (int) r[1], x2 = Math.max(x1 + 8, (int) r[2]), y2 = Math.max(y1 + 8, (int) r[3]);
                int l = Math.max(3, Math.min(8, (x2 - x1) / 3));
                Ui.line(g, x1, y1, x1 + l, y1, col); Ui.line(g, x1, y1, x1, y1 + l, col);
                Ui.line(g, x2, y1, x2 - l, y1, col); Ui.line(g, x2, y1, x2, y1 + l, col);
                Ui.line(g, x1, y2, x1 + l, y2, col); Ui.line(g, x1, y2, x1, y2 - l, col);
                Ui.line(g, x2, y2, x2 - l, y2, col); Ui.line(g, x2, y2, x2, y2 - l, col);
            }
            default -> {                                                      // ring that slides up and down the body
                double y = pos.y + (0.5 + 0.5 * Math.sin(ms / 600.0)) * hgt;
                ring(g, pos.x, y, pos.z, w, col);
                ring(g, pos.x, pos.y + 0.02, pos.z, w, Ui.c(Ui.ACCENT, 0.5f));
            }
        }
    }

    // ------------------------------------------------------------------ SeeInvisible

    private static void seeInvisible(GuiGraphics g, Minecraft mc, LocalPlayer p, float pt) {
        SeeInvisible m = on("SeeInvisible");
        if (m == null) return;
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(m.range.getValue()),
                x -> x != p && x.isAlive() && x.isInvisible() && !x.isSpectator() && !(x instanceof ArmorStand))) {
            AABB bb = e.getBoundingBox().move(e.getPosition(pt).subtract(e.position()));
            float[] r = Project.rect(bb);
            if (r == null || !Project.onScreen(r)) continue;
            int x1 = (int) r[0], y1 = (int) r[1], x2 = Math.max(x1 + 4, (int) r[2]), y2 = Math.max(y1 + 4, (int) r[3]);
            int col = Ui.c(0xFF5566, 0.95f);
            Ui.box(g, x1, y1, x2, y2, 1, col);
            String s = "Invisible: " + e.getName().getString();
            Ui.text(g, s, (x1 + x2) / 2 - Ui.tw(s) / 2, y1 - 10, col);
        }
    }
}
