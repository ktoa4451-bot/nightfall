# Ghostline Client 2.3.2

Fabric client mod for Minecraft 1.21.11 (Fabric Loader 0.18.2+, Fabric API 0.139.4+1.21.11).
Put the jar and Fabric API into the `mods` folder.

## Controls
- Open the menu with the key set in Controls (Nightfall category). Switch = on/off, tap a card = its settings, drag the bar on the right to scroll.
- Chat commands (a message that starts with "." is not sent to the server, ".." sends a real dot):
  `.help`, `.toggle <module>`, `.bind <module> <letter|digit|F1-F12|lshift|rshift|none>`, `.list`,
  `.config save|load|list|delete <name>`, `.friend add|remove|list|clear <name>`.
- One-shot modules (put a key on them): AutoPearl, ElytraSwap, CordDropper. FreeCam and the one-shot modules are never restored as "on" after a restart.

## New in 2.3.2: menu usability
Filter chips under the top bar: All / Enabled / Favorites (with counts). A * on every card marks a favorite (saved). Numbers next to a category = modules that are on in it.
Search also looks at the descriptions. The menu opens on the category and filter you used last. Drag the top bar to move the window, double click it to centre it again.

## New in 2.3.1: menu look
Menu -> Theme: accent colour (now remembered after a restart), Menu size 85-130% (click the button to reset to 100%), Text shadow on/off, Text colour (Light / White / Soft / Accent), Bold titles.
Saved to config/nightfall/appearance.properties.

## New in 2.3.0: Pathing (a Baritone-like layer)
Chat commands (the planner is the Ghostline A* + walker, drawn route included):
`.goto x y z` / `.goto x z` (height is found for you) / `.goto player <name>` (`~` = relative to you), `.follow <name>`, `.mine <block,block> [radius]`, `.stop`, `.path` (status).
Every option can be changed live, in the menu (card AutoNav, and AutoMine for mining) or with `.pathset list`, `.pathset <setting>`, `.pathset <setting> <value>` (a unique start of the name is enough, e.g. `.pathset maxn 30000`).
Options: max nodes, search budget, max fall, water (+cost), climb ladders, sprint, turn speed, arrive distance, stuck check, re-plans, timeout, stop below HP, partial routes,
Break blocks (+cost: digs only blocks that are safe to dig, never next to liquid or under falling blocks), Parkour (+max gap 1-3, jump cost: jumps over gaps, never over lava; gap 3 may fail), follow distance, follow re-plan.
Safety kept from Ghostline: pauses near hostile mobs, stops below the HP limit, never walks into unloaded chunks, lava, fire or deep drops, panic key stops everything.
Not there (unlike the real Baritone): building / schematics, farming, exploring, placing blocks to bridge, swimming routes by default, diagonal moves.

## New in 2.2.0
- Renamed to Ghostline Client (jar: ghostline-client-2.3.2.jar). Mod id, packages and config folder stay `nightfall`, so old configs keep working.
- Chat window (module AiChat with a key, or `.ai`): tab AI talks to the AI service you configure, tab Users chats with the users of your Ghostline friends server.
  AI setup, typed inside the window: `/key YOUR_KEY` (stored encrypted), `/provider anthropic|openai`, `/model <name>`, `/url <https address>`, `/clear`.
  Only what you type in this chat is sent to the service you chose; the key never goes into the module config. `.ai <question>` asks from the game chat.
  Users chat needs the friends server (`server/README.md`) and FriendsHelp connected: `@name text` is private, anything else goes to all friends. `.say <text>`, `.msg <name> <text>`.
- build.yml picks the zip of the newest commit.

## New in 2.1.0
ObsidianCrystal (puts a crystal on obsidian a player has just placed), ClickGUI redesign (compact glass),
FreeCam, FastUse, NoDelay, HitSound, ShiftTap, TapeMouse, BowSpammer, NoInteract, NoEntityTrace, NoPush,
HpAlert, Arrows, BlockOutline, JumpCircle, ChinaHat, Prediction, SeeInvisible, HitEffect,
ChestStealer, AutoTool, AutoFish, ElytraSwap, CordDropper, chat commands. See FEATURES.md.

## Fixes
- FreeCam / ElytraSwap / CordDropper / AutoPearl came back "on" from the saved config and acted on world join. They are not saved as enabled any more.
- Pve.java could not find `Walker` (it is a nested class of AutoNav): import added.
- Build: Maven failures are retried (3 attempts) in build.yml.

## Build
Push the zip to a GitHub repo together with `.github/workflows/build.yml` (or run the workflow by hand): the jar is built and put into Releases.
Tests of the pure logic: `sh tools/run-tests.sh`.

## Known limits
Not tested in game by the author of this build. If the game does not start, send `logs/latest.log`.
Visuals are drawn on the screen (projection), so they work in first person only.
