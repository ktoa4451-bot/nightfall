package dev.nightfall.module.impl.combat;

import dev.nightfall.NightfallClient;
import dev.nightfall.util.CrystalMath;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public final class Combat {
    private Combat() { }

    private static int auraTick, crystalTick;
    private static LivingEntity auraTarget;

    private static boolean visible(Minecraft mc, LocalPlayer p, Vec3 point) {
        return mc.level.clip(new ClipContext(p.getEyePosition(), point, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS;
    }

    // ================================================================== KillAura

    private static void killAura(Minecraft mc, LocalPlayer p, KillAura m) {
        auraTarget = null;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isUsingItem() || p.isSpectator()) return;
        double range = m.getRange();
        Vec3 eye = p.getEyePosition();
        List<LivingEntity> ents = new ArrayList<>();
        List<AuraTargets.Cand> cands = new ArrayList<>();
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range + 2), x -> x != p && x.isAlive() && (!m.isPlayersOnly() || x instanceof Player))) {
            Vec3 aim = e.getBoundingBox().getCenter();
            double dist = Math.sqrt(e.getBoundingBox().distanceToSqr(eye));
            float yaw = (float) (Math.toDegrees(Math.atan2(aim.z - eye.z, aim.x - eye.x)) - 90.0);
            double ang = Math.abs(Mth.wrapDegrees(yaw - p.getYRot()));
            ents.add(e);
            cands.add(new AuraTargets.Cand(ents.size() - 1, dist, e.getHealth(), ang, visible(mc, p, aim)));
        }
        int i = AuraTargets.pick(cands, range, m.getFov(), AuraTargets.DISTANCE, m.isVisibleOnly());
        if (i < 0) return;
        LivingEntity t = ents.get(i);
        auraTarget = t;
        Vec3 aim = t.getBoundingBox().getCenter();
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = Mth.clamp((float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))), -90f, 90f);
        float step = (float) m.getRotationSpeed();
        p.setYRot(p.getYRot() + Mth.clamp(Mth.wrapDegrees(yaw - p.getYRot()), -step, step));
        p.setXRot(p.getXRot() + Mth.clamp(pitch - p.getXRot(), -step, step));
        if (p.getAttackStrengthScale(0.5f) < 0.92f) return;
        if (m.isRequireCrosshair() && !(mc.hitResult instanceof EntityHitResult eh && eh.getEntity() == t)) return;
        mc.gameMode.attack(p, t);
        p.swing(InteractionHand.MAIN_HAND);
    }

    // ================================================================== AutoCrystal

    private static void autoCrystal(Minecraft mc, LocalPlayer p, AutoCrystal m) {
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isUsingItem()) return;
        if (++crystalTick % 2 != 0) return;
        int diff = mc.level.getDifficulty().getId();
        double hp = p.getHealth() + p.getAbsorptionAmount();
        double reach = m.getReach(), minEnemy = m.getMinEnemyDmg(), maxSelf = m.getMaxSelfDmg(), margin = 2.0;

        List<Player> enemies = new ArrayList<>();
        for (Player o : mc.level.players())
            if (o != p && o.isAlive() && !o.isSpectator() && p.distanceTo(o) <= 12.0) enemies.add(o);
        if (enemies.isEmpty()) return;

        for (EndCrystal c : mc.level.getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(reach), Entity::isAlive)) {
            if (p.getEyePosition().distanceTo(c.getBoundingBox().getCenter()) > reach || !visible(mc, p, c.getBoundingBox().getCenter())) continue;
            double self = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), c.getX(), c.getY(), c.getZ()), 1.0, diff);
            double enemy = 0;
            for (Player o : enemies) enemy = Math.max(enemy, CrystalMath.rawDamage(CrystalMath.distance(o.getX(), o.getY(), o.getZ(), c.getX(), c.getY(), c.getZ()), 1.0, diff));
            if (AuraTargets.crystalWorth(enemy, self, hp, minEnemy, maxSelf, margin)) {
                mc.gameMode.attack(p, c);
                p.swing(InteractionHand.MAIN_HAND);
                return;
            }
        }

        if (!p.getMainHandItem().is(Items.END_CRYSTAL)) return;
        int r = (int) Math.ceil(reach);
        BlockPos base = p.blockPosition(), best = null;
        double bestScore = -999;
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
            BlockState b = mc.level.getBlockState(q);
            if (!b.is(Blocks.OBSIDIAN) && !b.is(Blocks.BEDROCK)) continue;
            if (!mc.level.getBlockState(q.above()).isAir() || !mc.level.getBlockState(q.above(2)).isAir()) continue;
            Vec3 top = new Vec3(q.getX() + 0.5, q.getY() + 1.0, q.getZ() + 0.5);
            if (p.getEyePosition().distanceTo(top) > reach) continue;
            if (!mc.level.getEntitiesOfClass(Entity.class, new AABB(q.getX(), q.getY() + 1, q.getZ(), q.getX() + 1, q.getY() + 3, q.getZ() + 1), e -> true).isEmpty()) continue;
            double self = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), top.x, top.y, top.z), 1.0, diff);
            double enemy = 0;
            for (Player o : enemies) enemy = Math.max(enemy, CrystalMath.rawDamage(CrystalMath.distance(o.getX(), o.getY(), o.getZ(), top.x, top.y, top.z), 1.0, diff));
            if (!AuraTargets.crystalWorth(enemy, self, hp, minEnemy, maxSelf, margin)) continue;
            double sc = CrystalMath.score(enemy, self, hp, 1.5);
            if (sc > bestScore) { bestScore = sc; best = q.immutable(); }
        }
        if (best == null) return;
        Vec3 face = new Vec3(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(face, Direction.UP, best, false));
        p.swing(InteractionHand.MAIN_HAND);
    }

    // ================================================================== ElytraTarget

    private static ElytraOrbit.State etState = ElytraOrbit.State.ORBIT;
    private static int etTicks, etSince = 999, etUsed, etRestore = -1, etDeployTick;
    private static boolean etJumpHeld, etHit, etNoRockets, etLowHp;

    private static void etReset() { etState = ElytraOrbit.State.ORBIT; etTicks = 0; etSince = 999; etUsed = 0; etHit = false; etNoRockets = false; etLowHp = false; }

    private static boolean nearGround(Minecraft mc, LocalPlayer p) {
        Vec3 a = p.position(), b = a.add(0, -7, 0);
        return mc.level.clip(new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.BLOCK;
    }

    private static void elytraTarget(Minecraft mc, LocalPlayer p, ElytraTarget m) {
        if (etJumpHeld) { mc.options.keyJump.setDown(false); etJumpHeld = false; }
        if (etRestore >= 0) { p.getInventory().setSelectedSlot(etRestore); etRestore = -1; }
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isSpectator()) return;
        if (p.getHealth() < m.getMinHealth()) { return; }

        Player target = null; double bd = m.getRange();
        for (Player o : mc.level.players()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            double d = p.distanceTo(o);
            if (d < bd) { bd = d; target = o; }
        }
        if (target == null) { etReset(); return; }

        if (!p.isFallFlying()) {
            if (m.isAutoDeploy() && p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA) && !p.onGround() && !p.isInWater()
                && p.getDeltaMovement().y < -0.1 && ++etDeployTick % 10 == 0) { mc.options.keyJump.setDown(true); etJumpHeld = true; }
            return;
        }

        Vec3 eye = p.getEyePosition();
        double dist = Math.sqrt(target.getBoundingBox().distanceToSqr(eye));
        boolean ready = p.getAttackStrengthScale(0.5f) >= 0.92f;
        ElytraOrbit.State ns = ElytraOrbit.next(etState, etTicks, dist, ready, etHit, 20, m.getRadius() * 3.0);
        if (ns != etState) { etState = ns; etTicks = 0; etHit = false; } else etTicks++;
        etSince++;

        double[] v = ElytraOrbit.desired(p.getX(), p.getY(), p.getZ(), target.getX(), target.getY(), target.getZ(),
            m.getRadius(), m.getHeight(), true, etState);
        if (nearGround(mc, p) && p.getDeltaMovement().y < 0 && etState == ElytraOrbit.State.ORBIT) {
            v[1] = Math.max(v[1], 0.35);
            double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); v[0] /= l; v[1] /= l; v[2] /= l;
        }
        float step = (float) m.getRotationSpeed();
        p.setYRot(p.getYRot() + Mth.clamp(Mth.wrapDegrees((float) ElytraOrbit.yawDeg(v) - p.getYRot()), -step, step));
        p.setXRot(p.getXRot() + Mth.clamp((float) ElytraOrbit.pitchDeg(v) - p.getXRot(), -step, step));

        if (dist <= m.getAttackReach() && ready && visible(mc, p, target.getBoundingBox().getCenter())) {
            mc.gameMode.attack(p, target);
            p.swing(InteractionHand.MAIN_HAND);
            etHit = true;
        }

        double speed = p.getDeltaMovement().length();
        if (ElytraOrbit.needRocket(speed, m.getMinSpeed(), etSince, 10, etUsed, m.getMaxRockets())) {
            if (useRocket(mc, p)) { etSince = 0; etUsed++; }
        }
    }

    private static boolean useRocket(Minecraft mc, LocalPlayer p) {
        if (p.getOffhandItem().is(Items.FIREWORK_ROCKET)) { mc.gameMode.useItem(p, InteractionHand.OFF_HAND); return true; }
        if (p.getMainHandItem().is(Items.FIREWORK_ROCKET)) { mc.gameMode.useItem(p, InteractionHand.MAIN_HAND); return true; }
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getItem(i).is(Items.FIREWORK_ROCKET)) {
                etRestore = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(i);
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }

    public static void stopElytra(Minecraft mc) {
        etReset();
        if (etJumpHeld && mc != null && mc.options != null) { mc.options.keyJump.setDown(false); etJumpHeld = false; }
    }

    // ================================================================== entry

    public static void tick(Minecraft mc, LocalPlayer p) {
        if (p == null || mc.level == null) return;
        
        // Ограничение: только локальный мир
        if (!mc.hasSingleplayerServer()) {
            auraTarget = null;
            return;
        }

        var km = NightfallClient.getInstance().moduleManager.getByName("KillAura").orElse(null);
        if (km instanceof KillAura ka && ka.isEnabled()) {
            if (++auraTick % 2 == 0) killAura(mc, p, ka);
        } else auraTarget = null;

        var cm = NightfallClient.getInstance().moduleManager.getByName("AutoCrystal").orElse(null);
        if (cm instanceof AutoCrystal ac && ac.isEnabled()) {
            autoCrystal(mc, p, ac);
        }

        var em = NightfallClient.getInstance().moduleManager.getByName("ElytraTarget").orElse(null);
        if (em instanceof ElytraTarget et && et.isEnabled()) {
            elytraTarget(mc, p, et);
        } else {
            stopElytra(mc);
        }
    }

    public static LivingEntity getAuraTarget() {
        return auraTarget;
    }
}