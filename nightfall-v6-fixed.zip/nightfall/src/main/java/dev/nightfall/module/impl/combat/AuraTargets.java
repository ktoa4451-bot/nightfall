package dev.nightfall.module.impl.combat;

import java.util.List;

/** Small target-ranking helper used by the combat dispatcher. */
public final class AuraTargets {
    public static final String DISTANCE = "Distance";
    private AuraTargets() {}

    public record Cand(int index, double distance, float health, double angle, boolean visible) {}

    public static int pick(List<Cand> candidates, double range, double fov, String priority, boolean visibleOnly) {
        int best = -1;
        double bestScore = Double.POSITIVE_INFINITY;
        for (Cand c : candidates) {
            if (c.distance() > range || c.angle() > fov || (visibleOnly && !c.visible())) continue;
            double score = DISTANCE.equals(priority) ? c.distance() : c.angle();
            if (score < bestScore) { bestScore = score; best = c.index(); }
        }
        return best;
    }

    public static boolean crystalWorth(double enemyDamage, double selfDamage, double health, double minEnemy, double maxSelf, double margin) {
        return enemyDamage >= minEnemy && selfDamage <= Math.min(maxSelf, Math.max(0.0, health - 1.0)) && enemyDamage >= selfDamage + margin;
    }
}
