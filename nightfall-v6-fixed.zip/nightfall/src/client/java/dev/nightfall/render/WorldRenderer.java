package dev.nightfall.render;

/** Rendering hook placeholder for Fabric API versions where the legacy WorldRenderEvents API is unavailable. */
public final class WorldRenderer {
    private WorldRenderer() {}
    public static void register() {
        // ESP world rendering is currently disabled until a compatible 1.21.11 render pipeline is implemented.
    }
}
