package dev.nightfall.hud;

import dev.nightfall.hud.element.*;
import dev.nightfall.render.HoleEsp;
import dev.nightfall.render.ItemEsp;
import dev.nightfall.render.PlayerEsp;
import dev.nightfall.render.WaypointOverlay;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;

public class HudManager {
    public void register() {
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("nightfall", "target_hud"),
                new TargetHudElement()
        );
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("nightfall", "keystrokes"),
                new KeystrokesElement()
        );
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("nightfall", "cps"),
                new CpsElement()
        );
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("nightfall", "arraylist"),
                new ArrayListElement()
        );
        HudElementRegistry.attachElementBefore(
                VanillaHudElements.CHAT,
                Identifier.fromNamespaceAndPath("nightfall", "watermark"),
                new WatermarkElement()
        );

        // ESP and world overlays drawn on the screen (they are visible through walls)
        overlay("player_esp", (g, dt) -> PlayerEsp.render(g, Minecraft.getInstance(), dt.getGameTimeDeltaPartialTick(true)));
        overlay("hole_esp", (g, dt) -> HoleEsp.render(g, Minecraft.getInstance(), dt.getGameTimeDeltaPartialTick(true)));
        overlay("item_esp", (g, dt) -> ItemEsp.render(g, Minecraft.getInstance(), dt.getGameTimeDeltaPartialTick(true)));
        overlay("waypoints", (g, dt) -> WaypointOverlay.render(g, Minecraft.getInstance(), dt.getGameTimeDeltaPartialTick(true)));
    }

    private static void overlay(String id, net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement e) {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.fromNamespaceAndPath("nightfall", id), e);
    }
}
