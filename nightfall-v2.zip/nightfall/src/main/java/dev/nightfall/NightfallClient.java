package dev.nightfall;

import dev.nightfall.config.ConfigManager;
import com.mojang.blaze3d.platform.InputConstants;
import dev.nightfall.event.EventHandler;
import dev.nightfall.module.ModuleManager;
import dev.nightfall.module.impl.combat.*;
import dev.nightfall.module.impl.misc.Fullbright;
import dev.nightfall.module.impl.misc.WaypointCommands;
import dev.nightfall.module.impl.misc.Waypoints;
import dev.nightfall.module.impl.movement.*;
import dev.nightfall.module.impl.player.AutoArmor;
import dev.nightfall.module.impl.player.AutoGapple;
import dev.nightfall.module.impl.player.AutoTool;
import dev.nightfall.module.impl.player.Nuker;
import dev.nightfall.module.impl.player.Scaffold;
import dev.nightfall.module.impl.visuals.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NightfallClient implements ClientModInitializer {
    public static final String MOD_ID = "nightfall";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static NightfallClient instance;

    public ModuleManager moduleManager;
    public ConfigManager configManager;
    public EventHandler eventHandler;
    public KeyMapping openGuiKey;

    public static NightfallClient getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        // Менеджеры
        configManager = new ConfigManager();
        moduleManager = new ModuleManager();
        eventHandler = new EventHandler();

        // === COMBAT ===
        moduleManager.register(new AimAssist());
        moduleManager.register(new KillAura());
        moduleManager.register(new AutoCrystal());
        moduleManager.register(new ElytraTarget());
        moduleManager.register(new ReachDisplay());
        moduleManager.register(new TriggerBot());
        moduleManager.register(new ShieldBreaker());
        moduleManager.register(new AutoTotem());
        moduleManager.register(new Surround());

        // === VISUALS ===
        moduleManager.register(new CpsCounter());
        moduleManager.register(new Keystrokes());
        moduleManager.register(new TargetHud());
        moduleManager.register(new ESP());
        moduleManager.register(new CustomCrosshair());
        moduleManager.register(new HoleESP());
        moduleManager.register(new ItemESP());
        moduleManager.register(new CustomSky());

        // === MOVEMENT ===
        moduleManager.register(new Sprint());
        moduleManager.register(new Speed());
        moduleManager.register(new Step());
        moduleManager.register(new SafeWalk());
        moduleManager.register(new Jesus());
        moduleManager.register(new Spider());
        moduleManager.register(new ElytraFly());

        // === PLAYER ===
        moduleManager.register(new AutoGapple());
        moduleManager.register(new AutoArmor());
        moduleManager.register(new AutoTool());
        moduleManager.register(new Scaffold());
        moduleManager.register(new Nuker());

        // === MISC ===
        moduleManager.register(new Fullbright());
        moduleManager.register(new Waypoints());

        // Клавиша меню
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
        "key.nightfall.opengui",
        InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_RIGHT_SHIFT,
        KeyMapping.Category.MISC
       ));

        // Тик
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            eventHandler.onTick(client);
            while (openGuiKey.consumeClick()) {
                if (client.screen == null) {
                    dev.nightfall.gui.ClickGUI.open();
                }
            }
        });

        // HUD и Рендер
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> WaypointCommands.register(dispatcher));
        new dev.nightfall.hud.HudManager().register();
        dev.nightfall.render.WorldRenderer.register();

        // Конфиг
        configManager.load("default");

        LOGGER.info("Nightfall Client initialized. Modules: {}", moduleManager.getModules().size());
    }
}