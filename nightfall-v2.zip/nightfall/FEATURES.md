# Nightfall: what is new in this build

Repair (the project could not compile before): stale duplicate classes removed (HudManager, TargetHudElement/TargetHubElement, HudEditorScreen/HubEditorScreen),
HudManager no longer references four classes that do not exist, `ResourceLocation` -> `Identifier`, `src/client` is now compiled with `src/main`.

New modules (17): TriggerBot, ShieldBreaker, AutoTotem, Surround | Speed, Step, SafeWalk, Jesus, Spider, ElytraFly |
AutoTool, Scaffold, Nuker | HoleESP, ItemESP, CustomSky | Waypoints (+ /nfpoint set|del|list).
Modules that need a tick implement `Tickable`; EventHandler calls them (a failing module is logged, not fatal).

NOT built or run in game: there is no Minecraft in the place where this was written. `tools/run-tests.sh` checks only the pure maths in `dev.nightfall.util`
(33 checks). CustomSky uses two optional mixins (nightfall.sky.mixins.json); if their targets differ in your exact version they do nothing.

Still missing from your list: Bed/Anchor Aura, Criticals, FreeCamera, Chams, China Hat/Wings/Halo, Motion Blur/Bloom, Discord RPC, NameProtect, Friend Manager,
Music Player/Snake/Space Dodger, Update Checker, FastPlace, Strafe/Jump trainers, Combat replay, NoFall.
