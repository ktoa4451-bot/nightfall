# Nightfall + Ghostline (one mod)

One jar, mod id `nightfall`. Both entry points start: `dev.nightfall.NightfallClient` and `com.ghostline.mod.CheatMod`.

## Menu
The menu is Nightfall's ClickGUI (right shift, or the Ghostline menu key). Ghostline modules appear in it as normal cards
(enabled flag, key and every setting are read from and written to the Ghostline module, so Ghostline's own config file keeps working).
Settings support switches, sliders, mode lists (click = next, right click = previous), key capture and text fields
(Ctrl+V pastes, secret fields are masked). Sidebar: HUD = Ghostline HUD editor, Theme = Nightfall accent colour,
Classic = the old Ghostline menu (config share/import, friends, raid, language pages that are not in the new menu yet).
Panic (Ghostline) also switches every Nightfall module off.

## Same job in both clients: the Ghostline module is used
KillAura, AimAssist, AutoCrystal, ElytraTarget, TriggerBot, AutoTotem, Surround (= AutoSurround), AutoPearl (= KeyPearl), ESP (= PlayerESP),
HoleESP, CustomSky, TargetHud (= TargetHUD), Sprint (= AutoSprint), Speed, AutoGapple, AutoArmor, AutoTool, Fullbright, Waypoints.
The Nightfall classes are still in the source but not registered. Friends are respected because the Ghostline versions are used.
The Nightfall sky mixins and watermark / module list / TargetHud / ESP / waypoint overlays were removed for the same reason
(Ghostline's HUD module list also shows the enabled Nightfall modules).

## Only in Nightfall (kept)
ReachDisplay, ShieldBreaker, HitSelect, WTap, MaceHelper, AutoPotion, Offhand, AutoWeb, CrystalHelper (+AutoPlace), AnchorHelper, Hitboxes,
CpsCounter, Keystrokes, CustomCrosshair, ItemESP, TargetInfo, CombatLog, XRay, Step, SafeWalk, Jesus, Spider, ElytraFly, Scaffold, Nuker.
Ghostline's own CrystalHelper is hidden: the Nightfall one includes its hints.

## Added later (written from scratch, not copied from any other client)
Hitboxes, Velocity (reduces knockback, mixin on the motion packet), Parkour, AutoRespawn, AntiAfk, AutoLeave, AutoTpAccept, FastUse, FreeCam, HitSound, ShiftTap, TapeMouse, BowSpammer, NoInteract, NoEntityTrace, NoPush.

## Only in Ghostline
Everything else (AutoWarden, TreeFarm, BaseFinder, FriendsHelp, RaidAssistant, InvisHelper, view model, wings/trail, HUD, notifications, title screen...).

## Tests
`sh tools/run-tests.sh` (Nightfall logic) and `bash tools/ghostline-run-tests.sh` (Ghostline logic, needs node for the friends server).
