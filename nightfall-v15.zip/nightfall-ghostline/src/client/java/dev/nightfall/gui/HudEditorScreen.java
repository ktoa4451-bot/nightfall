package dev.nightfall.gui;

import dev.nightfall.NightfallClient;
import dev.nightfall.hud.element.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class HudEditorScreen extends Screen {
    private ArrayListElement arrayList;
    private WatermarkElement watermark;
    private CpsElement cps;
    private KeystrokesElement keystrokes;

    private Object dragging = null;
    private int dragOffsetX, dragOffsetY;

    public HudEditorScreen() {
        super(Component.literal("HUD Editor"));
        
        // Берем текущие элементы из менеджера (нужно будет добавить метод в HudManager)
        // Для простоты создаем новые экземпляры
        this.arrayList = new ArrayListElement();
        this.watermark = new WatermarkElement();
        this.cps = new CpsElement();
        this.keystrokes = new KeystrokesElement();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        // Сетка
        for (int i = 0; i < this.width; i += 20) {
            g.fill(i, 0, i + 1, this.height, 0x22FFFFFF);
        }
        for (int i = 0; i < this.height; i += 20) {
            g.fill(0, i, this.width, i + 1, 0x22FFFFFF);
        }

        // Рисуем элементы
        arrayList.render(g, Minecraft.getInstance().getDeltaTracker());
        watermark.render(g, Minecraft.getInstance().getDeltaTracker());
        cps.render(g, Minecraft.getInstance().getDeltaTracker());
        keystrokes.render(g, Minecraft.getInstance().getDeltaTracker());

        // Подсказка
        g.drawString(this.font, "Drag elements. ESC to save & exit.", 10, 10, 0xFFFFFFFF);

        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mouseX = event.x(), mouseY = event.y();
        {
            if (isHovered(mouseX, mouseY, arrayList.getX(), arrayList.getY(), 100, 100)) dragging = arrayList;
            else if (isHovered(mouseX, mouseY, watermark.getX(), watermark.getY(), 100, 20)) dragging = watermark;
            else if (isHovered(mouseX, mouseY, cps.getX(), cps.getY(), 80, 20)) dragging = cps;
            else if (isHovered(mouseX, mouseY, keystrokes.getX(), keystrokes.getY(), 60, 60)) dragging = keystrokes;

            if (dragging != null) {
                dragOffsetX = (int) mouseX;
                dragOffsetY = (int) mouseY;
                return true;
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        double mouseX = event.x(), mouseY = event.y();
        if (dragging != null) {
            int newX = (int) mouseX - dragOffsetX;
            int newY = (int) mouseY - dragOffsetY;
            
            if (dragging instanceof ArrayListElement e) e.setPosition(newX, newY);
            else if (dragging instanceof WatermarkElement e) e.setPosition(newX, newY);
            else if (dragging instanceof CpsElement e) e.setPosition(newX, newY);
            else if (dragging instanceof KeystrokesElement e) e.setPosition(newX, newY);
            
            return true;
        }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        return super.mouseReleased(event);
    }

    @Override
    public void onClose() {
        // Сохраняем позиции в конфиг
        NightfallClient.getInstance().configManager.save("hud_layout");
        super.onClose();
    }

    private boolean isHovered(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx <= x + w && my >= y && my <= y + h;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}