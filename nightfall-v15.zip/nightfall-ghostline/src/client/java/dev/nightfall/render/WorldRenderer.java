package dev.nightfall.render;

/**
 * ESP world rendering is disabled for now: the old WorldRenderEvents API from fabric-rendering-v1 no longer exists
 * in Fabric API 0.136 / Minecraft 1.21.11 (the drawing code was never finished anyway, it only filled a buffer).
 * Kept as a no-op so NightfallClient.register() still compiles.
 */
public final class WorldRenderer {
    private WorldRenderer() { }

    public static void register() { }
}
