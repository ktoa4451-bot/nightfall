package dev.nightfall.hud.element;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.CpsCounter;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class CpsElement implements HudElement {
    private int x = -40; // от центра, если отрицательный
    private int y = -40; // от низа

    public int getX() { return x; }
    public int getY() { return y; }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        var m = NightfallClient.getInstance().moduleManager.getByName("CpsCounter").orElse(null);
        if (!(m instanceof CpsCounter cps) || !cps.isEnabled()) return;

        Minecraft client = Minecraft.getInstance();
        int baseX = x < 0 ? client.getWindow().getGuiScaledWidth() / 2 + x : x;
        int baseY = y < 0 ? client.getWindow().getGuiScaledHeight() + y : y;

        g.fill(baseX, baseY, baseX + 80, baseY + 14, 0xCC15151C);
        String text = "L " + cps.getLeftCps() + " | R " + cps.getRightCps();
        g.drawString(client.font, text, baseX + 4, baseY + 3, 0xFFFFFFFF);
    }
}