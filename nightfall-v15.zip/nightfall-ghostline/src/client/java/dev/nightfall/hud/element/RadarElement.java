package dev.nightfall.hud.element;

import dev.nightfall.NightfallClient;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

public class RadarElement implements HudElement {
    private int x = 10;
    private int y = 100;
    private final int radius = 50;

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public int getX() { return x; }
    public int getY() { return y; }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return;

        int cx = x + radius;
        int cy = y + radius;

        // Фон радара (круг)
        for (int i = -radius; i <= radius; i++) {
            for (int j = -radius; j <= radius; j++) {
                if (i * i + j * j <= radius * radius) {
                    g.fill(cx + i, cy + j, cx + i + 1, cy + j + 1, 0xAA15151C);
                }
            }
        }

        // Прицел радара
        g.fill(cx - radius, cy, cx + radius, cy + 1, 0x44FFFFFF);
        g.fill(cx, cy - radius, cx + 1, cy + radius, 0x44FFFFFF);

        // Точки игроков
        for (Player p : client.level.players()) {
            if (p == client.player || !p.isAlive()) continue;

            double dist = client.player.distanceTo(p);
            if (dist > 50.0) continue; // Радиус действия радара

            // Вычисляем координаты на радаре
            Vec3 offset = p.position().subtract(client.player.position());
            double angle = Math.atan2(offset.z, offset.x);
            double scale = (dist / 50.0) * radius;
            int dx = (int) (Math.cos(angle) * scale);
            int dz = (int) (Math.sin(angle) * scale);

            int dotX = cx + dx;
            int dotY = cy + dz;
            
            // Рисуем точку (красная, если игрок близко)
            int color = dist < 10 ? 0xFFFF3355 : 0xFF55FF55;
            g.fill(dotX - 1, dotY - 1, dotX + 1, dotY + 1, color);
        }
    }
}