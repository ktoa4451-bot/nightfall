package dev.nightfall.mixin.client;

import dev.nightfall.module.impl.player.FreeCam;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** FreeCam: the mouse turns the camera instead of the player. */
@Mixin(Entity.class)
public class FreeCamLookMixin {
    @Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
    private void nightfall$freeCamLook(double yRot, double xRot, CallbackInfo ci) {
        if (FreeCam.look((Entity) (Object) this, yRot, xRot)) ci.cancel();
    }
}
