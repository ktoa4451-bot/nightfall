package dev.nightfall.mixin.client;

import dev.nightfall.module.impl.player.FreeCam;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.KeyboardInput;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.phys.Vec2;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** FreeCam: the keys move the camera, so the player gets an empty input while it is on. */
@Mixin(KeyboardInput.class)
public abstract class FreeCamInputMixin extends ClientInput {
    @Inject(method = "tick", at = @At("TAIL"), require = 0)
    private void nightfall$freeCamNoInput(CallbackInfo ci) {
        if (FreeCam.isActive()) {
            this.keyPresses = Input.EMPTY;
            this.moveVector = Vec2.ZERO;
        }
    }
}
