package dev.nightfall.mixin.client;

import dev.nightfall.module.impl.combat.Velocity;
import net.minecraft.client.multiplayer.ClientPacketListener;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPacketListener.class)
public class KnockbackMixin {
    @Inject(method = "handleSetEntityMotion", at = @At("HEAD"), require = 0)
    private void nightfall$velocityBefore(CallbackInfo ci) { Velocity.remember(); }

    @Inject(method = "handleSetEntityMotion", at = @At("TAIL"), require = 0)
    private void nightfall$velocityAfter(CallbackInfo ci) { Velocity.apply(); }
}
