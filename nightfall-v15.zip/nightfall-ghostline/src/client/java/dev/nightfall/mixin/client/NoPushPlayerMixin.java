package dev.nightfall.mixin.client;

import dev.nightfall.module.impl.player.NoPush;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
public class NoPushPlayerMixin {
    @Inject(method = "isPushedByFluid()Z", at = @At("HEAD"), cancellable = true, require = 0)
    private void nightfall$noWaterPush(CallbackInfoReturnable<Boolean> cir) {
        if (NoPush.noWater() && (Object) this == Minecraft.getInstance().player) cir.setReturnValue(false);
    }
}
