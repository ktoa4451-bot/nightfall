package dev.nightfall.mixin.client;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Gives modules access to the delay between two right clicks (FastUse). */
@Mixin(Minecraft.class)
public interface MinecraftAccessor {
    @Accessor("rightClickDelay") int nightfall$getRightClickDelay();
    @Accessor("rightClickDelay") void nightfall$setRightClickDelay(int value);
}
