package dev.nightfall.mixin.client;

import dev.nightfall.module.impl.player.NoPush;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class NoPushEntityMixin {
    @Inject(method = "push(Lnet/minecraft/world/entity/Entity;)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void nightfall$noPlayerPush(Entity other, CallbackInfo ci) {
        if (!NoPush.noPlayers()) return;
        Object me = Minecraft.getInstance().player;
        if (me != null && (this == me || other == me)) ci.cancel();
    }
}
