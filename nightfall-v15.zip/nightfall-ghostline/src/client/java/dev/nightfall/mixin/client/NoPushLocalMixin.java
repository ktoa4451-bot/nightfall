package dev.nightfall.mixin.client;

import dev.nightfall.module.impl.player.NoPush;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public class NoPushLocalMixin {
    @Inject(method = "moveTowardsClosestSpace(DD)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void nightfall$noBlockPush(double x, double z, CallbackInfo ci) {
        if (NoPush.noBlocks()) ci.cancel();
    }
}
