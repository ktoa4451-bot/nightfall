package dev.nightfall.mixin.client;

import dev.nightfall.module.impl.player.NoEntityTrace;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class NoEntityTraceMixin {
    @Inject(method = "pick(F)V", at = @At("TAIL"), require = 0)
    private void nightfall$noEntityTrace(float partial, CallbackInfo ci) {
        NoEntityTrace.apply(Minecraft.getInstance(), partial);
    }
}
