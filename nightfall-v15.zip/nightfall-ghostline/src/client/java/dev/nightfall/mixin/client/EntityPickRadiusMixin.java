package dev.nightfall.mixin.client;

import dev.nightfall.module.impl.combat.Hitboxes;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityPickRadiusMixin {
    @Inject(method = "getPickRadius", at = @At("RETURN"), cancellable = true, require = 0)
    private void nightfall$widenPickBox(CallbackInfoReturnable<Float> cir) {
        float extra = Hitboxes.extra((Entity) (Object) this);
        if (extra > 0f) cir.setReturnValue(cir.getReturnValue() + extra);
    }
}
