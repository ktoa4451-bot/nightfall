package com.ghostline.mod.mixin;

import com.ghostline.mod.Config;
import com.ghostline.mod.GhostScreen;
import com.ghostline.mod.Ui;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public class ScreenBackgroundMixin {

    /** Menu screens outside of a world get the dark Ghostline backdrop. Buttons stay vanilla. */
    @Inject(method = "renderBackground", at = @At("TAIL"), require = 0)
    private void ghostline$backdrop(GuiGraphics g, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (Config.panic) return;
        if (Minecraft.getInstance().level != null) return;
        Screen self = (Screen) (Object) this;
        if (self instanceof GhostScreen) return;
        Ui.backdrop(g, self.width, self.height, 0xF2);
        int size = Math.min(256, (int) (self.height * 0.7f));
        Ui.logo(g, Ui.LOGO_BG, self.width / 2 - size / 2, self.height / 2 - size / 2, size);
    }
}
