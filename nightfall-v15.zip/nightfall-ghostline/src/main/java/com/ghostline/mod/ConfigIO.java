package com.ghostline.mod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;

/**
 * CFG export and import on top of {@link CfgCodec}. Every way of loading settings from outside the running game
 * (CFG file, share code, named config file) goes through the same strict validation, and nothing is applied
 * until the whole file has been accepted.
 */
public final class ConfigIO {
    private ConfigIO() { }

    public static final String CODE_PREFIX = "GL1.";
    private static final int MAX_CODE_CHARS = 100_000;
    private static final String MC_VERSION = "1.21.11";

    public static String modVersion() {
        return FabricLoader.getInstance().getModContainer("nightfall")
            .map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("dev");
    }

    // ------------------------------------------------------------------ schema

    /**
     * What a file may contain. Secret settings (tokens, chat ids, server addresses) are marked sensitive: they are never
     * written and never read. When {@code trusted} is false (files and codes from other people) the on/off state of
     * combat, movement, player and misc modules is not importable, so a shared config cannot switch automation on.
     */
    public static Map<String, CfgCodec.Spec> schema(boolean trusted) {
        Map<String, CfgCodec.Spec> s = new HashMap<>();
        List<Module> all = new ArrayList<>(Config.ALL);
        all.addAll(Config.EXTRA);
        for (Module m : all) {
            boolean safeOn = trusted || m.category == 3 || m.category == 5 || m.category == 6 || m.category == 8;
            if (m.toggleable && safeOn && m != Config.TREEFARM && m != Config.RAID) s.put(m.name + ".on", CfgCodec.Spec.flag());
            if (Config.ALL.contains(m)) s.put(m.name + ".bind", CfgCodec.Spec.number(-1, 1000));
            for (Setting st : m.settings) {
                String k = m.name + "." + st.name;
                if (st.secret || st.noSave) s.put(k, CfgCodec.Spec.sensitive());
                else if (st.isText) s.put(k, CfgCodec.Spec.text());
                else s.put(k, CfgCodec.Spec.number(st.min, st.max));
            }
        }
        return s;
    }

    /** Current settings that are safe to write into a file. */
    public static Map<String, String> exportValues() {
        Map<String, CfgCodec.Spec> sc = schema(true);
        Map<String, String> out = new LinkedHashMap<>();
        Properties p = Config.snapshot(false);
        for (String k : p.stringPropertyNames()) {
            CfgCodec.Spec spec = sc.get(k);
            if (spec == null || spec.kind() == CfgCodec.Kind.SENSITIVE) continue;
            out.put(k, p.getProperty(k));
        }
        return out;
    }

    public static String exportText() {
        return CfgCodec.write(exportValues(), modVersion(), MC_VERSION);
    }

    // ------------------------------------------------------------------ files

    public static Path exportDir() throws IOException {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("ghostline-configs").resolve("exports");
        Files.createDirectories(d);
        return d;
    }

    private static String cleanName(String n) {
        String c = n == null ? "" : n.trim().replaceAll("[^\\p{L}\\p{N}_ -]", "");
        return c.isEmpty() ? "ghostline" : (c.length() > 48 ? c.substring(0, 48) : c);
    }

    public static List<String> listExports() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(exportDir())) {
            s.forEach(p -> {
                String f = p.getFileName().toString();
                if (f.endsWith(".cfg")) out.add(f.substring(0, f.length() - 4));
            });
        } catch (Exception ignored) { }
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    /** Writes exports/&lt;name&gt;.cfg and returns the path. */
    public static Path exportFile(String name) throws IOException {
        Path f = exportDir().resolve(cleanName(name) + ".cfg");
        Files.writeString(f, exportText(), StandardCharsets.UTF_8);
        return f;
    }

    public static void deleteExport(String name) throws IOException {
        Files.deleteIfExists(exportDir().resolve(cleanName(name) + ".cfg"));
    }

    public static String importExport(String name) {
        try { return importFile(exportDir().resolve(cleanName(name) + ".cfg")); }
        catch (IOException e) { throw new IllegalArgumentException("cannot read file"); }
    }

    /** Reads a .cfg file (size is checked before reading) and applies it if it passes validation. */
    public static String importFile(Path f) {
        try {
            if (!f.getFileName().toString().toLowerCase().endsWith(".cfg")) throw new IllegalArgumentException("only .cfg files can be imported");
            if (!Files.isRegularFile(f)) throw new IllegalArgumentException("file not found");
            if (Files.size(f) > CfgCodec.MAX_BYTES) throw new IllegalArgumentException("file too large (max " + CfgCodec.MAX_BYTES + " bytes)");
            return applyBytes(Files.readAllBytes(f), true, false);
        } catch (IOException e) { throw new IllegalArgumentException("cannot read file"); }
    }

    // ------------------------------------------------------------------ share codes

    public static String shareCode() {
        return CODE_PREFIX + Base64.getUrlEncoder().withoutPadding().encodeToString(exportText().getBytes(StandardCharsets.UTF_8));
    }

    /**
     * Accepts a "GL1." share code, a path to a .cfg file, or (old versions) a bare base64 code. Throws
     * IllegalArgumentException with a readable reason if the input is rejected.
     */
    public static String importCode(String input) {
        String code = input == null ? "" : input.trim();
        if (code.isEmpty()) throw new IllegalArgumentException("empty input");
        if (code.length() > MAX_CODE_CHARS) throw new IllegalArgumentException("code too long");
        if (code.regionMatches(true, code.length() - 4, ".cfg", 0, 4) && code.length() < 400) {
            return importFile(Path.of(code.replace("\"", "")));
        }
        boolean fresh = code.startsWith(CODE_PREFIX);
        byte[] raw;
        try {
            raw = Base64.getUrlDecoder().decode(fresh ? code.substring(CODE_PREFIX.length()) : code);
        } catch (IllegalArgumentException e) { throw new IllegalArgumentException("not a valid share code"); }
        if (fresh) return applyBytes(raw, true, false);
        // old share code: a properties text. It has no checksum, so it is validated field by field.
        Properties p = new Properties();
        try { p.load(new StringReader(new String(raw, StandardCharsets.UTF_8))); }
        catch (Exception e) { throw new IllegalArgumentException("not a valid share code"); }
        return applyResult(fromProperties(p, false));
    }

    // ------------------------------------------------------------------ validation and applying

    /** Old-style properties (named config files, legacy codes) validated by the same rules. */
    public static CfgCodec.Result fromProperties(Properties p, boolean trusted) {
        Map<String, String> m = new LinkedHashMap<>();
        for (String k : p.stringPropertyNames()) m.put(k, p.getProperty(k));
        String text = CfgCodec.write(m, "legacy", "");
        CfgCodec.Result r = CfgCodec.parse(text.getBytes(StandardCharsets.UTF_8), schema(trusted), true);
        return r;
    }

    private static String applyBytes(byte[] data, boolean requireChecksum, boolean trusted) {
        return applyResult(CfgCodec.parse(data, schema(trusted), requireChecksum));
    }

    /** Applies an accepted result: backs the current state up first and rolls back if anything goes wrong. */
    public static String applyResult(CfgCodec.Result r) {
        if (!r.ok()) throw new IllegalArgumentException(r.firstError());
        Properties backup = Config.snapshot(false);
        try {
            Path b = FabricLoader.getInstance().getConfigDir().resolve("ghostline-configs");
            Files.createDirectories(b);
            try (var w = Files.newBufferedWriter(b.resolve("_backup-before-import.properties"), StandardCharsets.UTF_8)) {
                backup.store(w, "Ghostline: state before the last import");
            }
        } catch (Exception ignored) { }
        Properties p = new Properties();
        r.values.forEach(p::setProperty);
        Toasts.suppressModules(1500); // an import flips many modules; the result is reported once instead
        java.util.Map<Object, Integer> keysBefore = Config.keyHolders();
        int cleared;
        try {
            Config.apply(p, false);
            cleared = Config.clearImportedKeyConflicts(keysBefore);
            Config.save();
        } catch (RuntimeException e) {
            Config.apply(backup, false);
            throw new IllegalArgumentException("could not apply the settings, previous state restored");
        }
        String done = String.format(Lang.t("cfg.import_ok"), r.values.size(), r.unknown, r.skippedSensitive);
        if (cleared > 0) {
            String w = String.format(Lang.t("cfg.keys_cleared"), cleared);
            Toasts.warn("Config", w);
            done += ". " + w;
        }
        return done;
    }

    /** Named config files from the local disk: validated like everything else, but they may restore module on/off states. */
    public static String applyNamed(Properties p) {
        return applyResult(fromProperties(p, true));
    }
}
