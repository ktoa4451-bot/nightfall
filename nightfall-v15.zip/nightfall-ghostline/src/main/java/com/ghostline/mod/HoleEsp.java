package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** Marks safe holes (obsidian/bedrock pits) near you on the screen. Scans a small box every N ticks and keeps at most 40 results. */
public final class HoleEsp {
    private HoleEsp() { }

    private record Hole(int x, int y, int z, int type) { }
    private static final List<Hole> HOLES = new ArrayList<>();
    private static int tick;

    private static int kindOf(Minecraft mc, BlockPos.MutableBlockPos q, int x, int y, int z) {
        if (mc.level.isOutsideBuildHeight(y) || !mc.level.getChunkSource().hasChunk(x >> 4, z >> 4)) return HoleLogic.OTHER;
        q.set(x, y, z);
        BlockState s = mc.level.getBlockState(q);
        if (s.isAir()) return HoleLogic.AIR;
        if (s.is(Blocks.BEDROCK)) return HoleLogic.BEDROCK;
        if (s.is(Blocks.OBSIDIAN) || s.is(Blocks.CRYING_OBSIDIAN)) return HoleLogic.OBSIDIAN;
        return s.getCollisionShape(mc.level, q).isEmpty() ? HoleLogic.AIR : HoleLogic.OTHER;
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.HOLEESP;
        if (++tick % Math.max(5, m.get(1).i()) != 0) return;
        HOLES.clear();
        int r = m.get(0).i();
        boolean showUnsafe = m.get(2).i() == 1;
        BlockPos base = p.blockPosition();
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) for (int dy = -3; dy <= 3; dy++) for (int dz = -r; dz <= r; dz++) {
            int x = base.getX() + dx, y = base.getY() + dy, z = base.getZ() + dz;
            final int fx = x, fy = y, fz = z;
            // cheap pre-check before the full classification
            if (kindOf(mc, q, x, y, z) != HoleLogic.AIR || kindOf(mc, q, x, y - 1, z) == HoleLogic.AIR) continue;
            int t = HoleLogic.classify(i -> {
                int dz2 = i % 3 - 1, dy2 = (i / 3) % 4 - 1, dx2 = i / 12 - 1;
                return kindOf(mc, q, fx + dx2, fy + dy2, fz + dz2);
            });
            if (t == HoleLogic.NONE || (t == HoleLogic.UNSAFE && !showUnsafe)) continue;
            HOLES.add(new Hole(x, y, z, t));
            if (HOLES.size() >= 40) return;
        }
    }

    public static void clear() { HOLES.clear(); }

    public static void render(GuiGraphics g, Minecraft mc, LocalPlayer p, float pt) {
        if (HOLES.isEmpty() || !Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;
        for (Hole h : HOLES) {
            double[] s = Project.point(h.x() + 0.5, h.y() + 0.05, h.z() + 0.5);
            if (s == null) continue;
            int col = h.type() == HoleLogic.BEDROCK_HOLE ? 0x55FF55 : h.type() == HoleLogic.MIXED_SAFE ? 0xFFAA00 : 0xFF5555;
            int sx = (int) s[0], sy = (int) s[1];
            g.fill(sx - 4, sy - 2, sx + 5, sy + 3, Ui.c(col, 0.8f));
        }
    }
}
