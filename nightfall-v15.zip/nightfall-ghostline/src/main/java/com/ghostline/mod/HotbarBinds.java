package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

/**
 * Press a key, get the item: each bind has a key and a short item name (sword, gapple, pearl, crystal, rocket, totem, ...).
 * Pressing the same key again cycles through several matching stacks. Only works with no screen open. Selecting a slot is all it does.
 */
public final class HotbarBinds {
    private HotbarBinds() { }

    private static final boolean[] PREV = new boolean[4];

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.HOTBARBINDS;
        long win = GLFW.glfwGetCurrentContext();
        if (win == 0) return;
        for (int b = 0; b < 4; b++) {
            int key = m.get(b * 2).i();
            boolean down = key > 0 && mc.screen == null && GLFW.glfwGetKey(win, key) == GLFW.GLFW_PRESS;
            if (down && !PREV[b] && p.isAlive()) {
                String[] hb = new String[9];
                for (int i = 0; i < 9; i++) { ItemStack s = p.getInventory().getItem(i); hb[i] = s.isEmpty() ? null : BuiltInRegistries.ITEM.getKey(s.getItem()).getPath(); }
                int slot = HotbarPick.find(hb, m.get(b * 2 + 1).text, p.getInventory().getSelectedSlot());
                if (slot >= 0) p.getInventory().setSelectedSlot(slot);
            }
            PREV[b] = down;
        }
    }
}
