package com.ghostline.mod;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Positions, sizes and visibility of HUD elements for the HUD editor. No Minecraft dependencies.
 * An element is either stacked into a screen corner (the default) or has a custom position, stored as fractions
 * (0..1) of the free screen space so it stays sensible when the window or GUI scale changes.
 */
public final class HudLayout {
    private HudLayout() { }

    public static final String[] IDS = {"watermark", "coords", "modules", "status", "binds", "target", "armor", "effects",
        "waypoints", "treefarm", "friends", "raid", "invis", "findings", "notifications"};
    public static final float MIN_SCALE = 0.5f, MAX_SCALE = 2.0f, STEP = 0.1f;
    private static final int MAX_TEXT = 4000;

    public static final class Entry {
        public boolean custom;
        public float fx, fy;
        public float scale = 1f;
        public boolean enabled = true;

        boolean isDefault() { return !custom && scale == 1f && enabled && fx == 0f && fy == 0f; }
    }

    private static final Map<String, Entry> MAP = new LinkedHashMap<>();
    static { for (String id : IDS) MAP.put(id, new Entry()); }

    public static Entry get(String id) { return MAP.computeIfAbsent(id, k -> new Entry()); }

    public static boolean known(String id) {
        for (String s : IDS) if (s.equals(id)) return true;
        return false;
    }

    public static void resetAll() { for (Entry e : MAP.values()) reset(e); }
    public static void reset(String id) { reset(get(id)); }
    private static void reset(Entry e) { e.custom = false; e.fx = e.fy = 0f; e.scale = 1f; e.enabled = true; }

    public static float clampScale(float s) {
        if (Float.isNaN(s)) return 1f;
        float v = Math.max(MIN_SCALE, Math.min(MAX_SCALE, s));
        return Math.round(v * 10f) / 10f;
    }

    public static float clamp01(float v) { return Float.isNaN(v) ? 0f : Math.max(0f, Math.min(1f, v)); }

    /** Absolute position of an element of size (w,h) inside a screen of (sw,sh), for a custom entry. */
    public static int[] position(Entry e, int w, int h, int sw, int sh) {
        return new int[]{Math.round(e.fx * Math.max(0, sw - w)), Math.round(e.fy * Math.max(0, sh - h))};
    }

    /** Stores an absolute top-left position as fractions (and marks the entry custom). */
    public static void setPosition(Entry e, int x, int y, int w, int h, int sw, int sh) {
        int fw = sw - w, fh = sh - h;
        e.custom = true;
        e.fx = fw <= 0 ? 0f : clamp01(x / (float) fw);
        e.fy = fh <= 0 ? 0f : clamp01(y / (float) fh);
    }

    // ------------------------------------------------------------------ persistence: "id,custom,fx,fy,scale,enabled;..."

    public static String serialize() {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Entry> m : MAP.entrySet()) {
            Entry e = m.getValue();
            if (e.isDefault()) continue;
            if (sb.length() > 0) sb.append(';');
            sb.append(m.getKey()).append(',').append(e.custom ? 1 : 0).append(',').append(String.format(java.util.Locale.ROOT, "%.4f", e.fx))
              .append(',').append(String.format(java.util.Locale.ROOT, "%.4f", e.fy)).append(',')
              .append(String.format(java.util.Locale.ROOT, "%.1f", e.scale)).append(',').append(e.enabled ? 1 : 0);
        }
        return sb.toString();
    }

    private static final java.util.regex.Pattern NUM = java.util.regex.Pattern.compile("-?\\d{1,3}(\\.\\d{1,6})?");

    /** Replaces the layout with the saved text. Bad entries are skipped; returns how many. Never throws. */
    public static int parse(String text) {
        resetAll();
        int bad = 0;
        if (text == null || text.isBlank()) return 0;
        if (text.length() > MAX_TEXT) return 1;
        for (String part : text.split(";")) {
            String[] f = part.split(",", -1);
            if (f.length != 6 || !known(f[0]) || !(f[1].equals("0") || f[1].equals("1")) || !(f[5].equals("0") || f[5].equals("1"))
                || !NUM.matcher(f[2]).matches() || !NUM.matcher(f[3]).matches() || !NUM.matcher(f[4]).matches()) { bad++; continue; }
            Entry e = get(f[0]);
            e.custom = f[1].equals("1");
            e.fx = clamp01(Float.parseFloat(f[2]));
            e.fy = clamp01(Float.parseFloat(f[3]));
            e.scale = clampScale(Float.parseFloat(f[4]));
            e.enabled = f[5].equals("1");
        }
        return bad;
    }
}
