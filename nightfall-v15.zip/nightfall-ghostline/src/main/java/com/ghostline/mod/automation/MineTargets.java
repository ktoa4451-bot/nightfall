package com.ghostline.mod.automation;

import java.util.ArrayList;
import java.util.List;

/** Where can the player stand to mine a given block? Pure geometry on top of {@link Pathfinder#standable}. */
public final class MineTargets {
    private MineTargets() { }

    public static final double EYE = 1.62, REACH = 4.5;

    /** Feet positions next to the block (same column excluded) from which the block centre is within reach. Nearest to (px,py,pz) first. */
    public static List<int[]> standSpots(Pathfinder pf, int tx, int ty, int tz, int px, int py, int pz) {
        List<int[]> out = new ArrayList<>();
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) for (int dy = -3; dy <= 1; dy++) {
            if (dx == 0 && dz == 0 && dy >= 0) continue;
            int x = tx + dx, y = ty + dy, z = tz + dz;
            double ex = x + 0.5, ey = y + EYE, ez = z + 0.5;
            double d = Math.sqrt((tx + 0.5 - ex) * (tx + 0.5 - ex) + (ty + 0.5 - ey) * (ty + 0.5 - ey) + (tz + 0.5 - ez) * (tz + 0.5 - ez));
            if (d > REACH - 0.5) continue;
            if (pf.standable(x, y, z)) out.add(new int[]{x, y, z});
        }
        out.sort((a, b) -> Integer.compare(sq(a, px, py, pz), sq(b, px, py, pz)));
        return out;
    }

    private static int sq(int[] a, int px, int py, int pz) { int x = a[0] - px, y = a[1] - py, z = a[2] - pz; return x * x + y * y + z * z; }
}
