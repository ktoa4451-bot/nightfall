package com.ghostline.mod.event;

import net.minecraft.client.Minecraft;

public record ClientTickEvent(Minecraft client) { }
