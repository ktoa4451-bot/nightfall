package com.ghostline.mod.mixin;

import com.ghostline.mod.SkyFog;
import net.minecraft.world.attribute.EnvironmentAttribute;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Camera-side attribute reads (fog, sky) go through the probe: getValue(attribute, partialTick). Optional mixin (require = 0). */
@Mixin(targets = "net.minecraft.world.attribute.EnvironmentAttributeProbe")
public class EnvironmentAttributeProbeMixin {
    @Inject(method = "getValue", at = @At("RETURN"), cancellable = true, require = 0)
    private void ghostline$value(EnvironmentAttribute<?> attribute, float partialTick, CallbackInfoReturnable<Object> cir) {
        Object v = SkyFog.override(attribute);
        if (v != null) cir.setReturnValue(v);
    }
}
