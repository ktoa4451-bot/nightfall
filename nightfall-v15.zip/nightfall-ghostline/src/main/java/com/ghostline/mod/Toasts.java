package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

import java.util.List;

/**
 * Notification system (toasts). One queue ({@link ToastQueue}) fed by the modules, drawn as a HUD element
 * ("notifications"), so it can be moved and scaled in the HUD editor like everything else.
 * Sources have their own switches in the Notifications settings; module on/off changes are detected here by watching
 * the module list, so every way of toggling a module (menu, key, config, panic) is covered without extra code.
 */
public final class Toasts {
    private Toasts() { }

    private static final ToastQueue Q = new ToastQueue();
    private static final ToastQueue PREVIEW = new ToastQueue();
    private static final int W = 176;
    private static long lastNs = System.nanoTime();

    // setting indexes in Config.NOTIFY
    private static final int S_MENU = 5, S_FRIENDS = 6, S_WARN = 7;

    // ------------------------------------------------------------------ sources

    private static void push(ToastQueue.Type type, String title, String text, int source, boolean urgent) {
        Module n = Config.NOTIFY;
        if (!n.enabled || Config.panic) return;
        if (source >= 0 && n.get(source).i() != 1) return;
        Q.push(type, title, text, (long) (n.get(0).value * 1000), urgent, System.currentTimeMillis());
    }

    public static void menu(boolean error, String text) { push(error ? ToastQueue.Type.ERROR : ToastQueue.Type.SUCCESS, "Ghostline", text, S_MENU, false); }
    public static void friends(ToastQueue.Type t, String title, String text) { push(t, title, text, S_FRIENDS, false); }
    public static void help(String title, String text) { push(ToastQueue.Type.WARN, title, text, S_FRIENDS, true); }
    public static void warn(String title, String text) { push(ToastQueue.Type.WARN, title, text, S_WARN, false); }
    public static void info(String title, String text) { push(ToastQueue.Type.INFO, title, text, S_WARN, false); }
    public static void error(String title, String text) { push(ToastQueue.Type.ERROR, title, text, S_WARN, true); }

    /** The "Send test" button. */
    public static void test() {
        Module n = Config.NOTIFY;
        long d = (long) (n.get(0).value * 1000), now = System.currentTimeMillis();
        Q.push(ToastQueue.Type.INFO, "Ghostline", Lang.t("nt.test"), d, false, now);
        Q.push(ToastQueue.Type.SUCCESS, "Ghostline", Lang.t("nt.test2"), d, false, now);
        Q.push(ToastQueue.Type.WARN, "Ghostline", Lang.t("nt.test3"), d, false, now);
    }

    public static void clear() { Q.clear(); }

    // ------------------------------------------------------------------ module on/off watcher

    private static boolean[] last;
    private static long suppressUntil;

    /** Mutes module notifications for a moment (a config import flips many modules at once). */
    public static void suppressModules(long ms) { suppressUntil = System.currentTimeMillis() + ms; }

    /** Cheap: a loop over the module list once per tick. */
    public static void watchModules() {
        List<Module> all = Config.ALL;
        if (last == null) {
            last = new boolean[all.size()];
            for (int i = 0; i < last.length; i++) last[i] = all.get(i).enabled;
            return;
        }
        boolean quiet = System.currentTimeMillis() < suppressUntil;
        for (int i = 0; i < last.length; i++) {
            Module m = all.get(i);
            if (m.enabled == last[i]) continue;
            last[i] = m.enabled;
            if (!quiet && m.toggleable && m.action == null) {
                push(m.enabled ? ToastQueue.Type.SUCCESS : ToastQueue.Type.INFO, Lang.mod(m), Lang.t(m.enabled ? "nt.on" : "nt.off"), 4, false);
            }
        }
    }

    // ------------------------------------------------------------------ drawing (called by Hud for the "notifications" element)

    private static int color(ToastQueue.Type t) {
        return switch (t) {
            case SUCCESS -> 0x57D68D;
            case WARN -> 0xE8B04A;
            case ERROR -> 0xE05A5A;
            default -> Ui.accent();
        };
    }

    private static int heightOf(ToastQueue.Toast t) {
        return 8 + 11 + Ui.wrap(t.text, W - 18).size() * 10 + 5;
    }

    static void draw(GuiGraphics g, int corner, float op, int sw, int sh, boolean preview) {
        Module n = Config.NOTIFY;
        long now = System.currentTimeMillis();
        long ns = System.nanoTime();
        float dt = Math.min(0.1f, (ns - lastNs) / 1.0e9f);
        lastNs = ns;

        ToastQueue q = Q;
        q.update(now, n.get(1).i());
        List<ToastQueue.Toast> list = q.visible();
        if (list.isEmpty() && preview) { // something to grab and move in the editor
            if (PREVIEW.visible().isEmpty() && PREVIEW.pendingCount() == 0) {
                PREVIEW.push(ToastQueue.Type.SUCCESS, "Fly", Lang.t("nt.on"), 600_000, false, now);
                PREVIEW.push(ToastQueue.Type.WARN, Lang.t("nt.sample"), Lang.t("nt.sample_text"), 600_000, false, now);
            }
            PREVIEW.update(now, 2);
            q = PREVIEW;
            list = q.visible();
        }
        if (list.isEmpty()) return;

        int total = 0;
        for (ToastQueue.Toast t : list) total += heightOf(t) + 4;
        int[] p = Hud.place(g, corner, W, total - 4, sw, sh);

        boolean right = corner == 0 || corner == 2;
        int anim = n.get(3).i();
        boolean bar = n.get(8).i() == 1;
        int y = 0;
        for (ToastQueue.Toast t : list) {
            int h = heightOf(t);
            if (!t.placed) { t.slot = y; t.placed = true; }
            else t.slot += (y - t.slot) * Math.min(1f, dt * 14f);
            float pr = ToastQueue.presence(t, now);
            int xoff = 0;
            float a = 1f;
            if (anim == 0) xoff = (int) ((1f - pr) * (W + 10) * (right ? 1 : -1));
            else if (anim == 1) a = pr;
            else a = pr > 0f ? 1f : 0f;
            float al = a * op;
            if (al > 0.01f) {
                int x = p[0] + xoff, yy = p[1] + Math.round(t.slot);
                int col = color(t.type);
                Ui.rect(g, x, yy, W, h, 5, Ui.c(Ui.bg(), 0.88f * al));
                Ui.ring(g, x, yy, W, h, 5, Ui.c(col, 0.55f * al));
                g.fill(x + 1, yy + 5, x + 4, yy + h - 5, Ui.c(col, al));
                String title = t.count > 1 ? t.title + "  x" + t.count : t.title;
                Ui.text(g, title, x + 10, yy + 5, Ui.c(col, al));
                List<String> lines = Ui.wrap(t.text, W - 18);
                for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), x + 10, yy + 17 + i * 10, Ui.c(Ui.TEXT, al));
                if (bar) {
                    int bw = (int) ((W - 12) * ToastQueue.remaining(t, now));
                    g.fill(x + 6, yy + h - 3, x + 6 + bw, yy + h - 2, Ui.c(col, 0.7f * al));
                }
            }
            y += h + 4;
        }
    }
}
