package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.DoubleConsumer;

/** Base for custom drawn screens: hit regions, click/drag handling, hover animations. */
public abstract class GhostScreen extends Screen {
    protected static final class Hit {
        final int x, y, w, h;
        final boolean clip;
        final Runnable click;
        final DoubleConsumer drag;
        Hit(int x, int y, int w, int h, boolean clip, Runnable click, DoubleConsumer drag) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.clip = clip; this.click = click; this.drag = drag;
        }
        boolean contains(double px, double py) { return px >= x && py >= y && px < x + w && py < y + h; }
    }

    protected final List<Hit> hits = new ArrayList<>();
    protected int mx, my;
    protected int clipX1 = 0, clipY1 = 0, clipX2 = 100000, clipY2 = 100000;
    protected float dt = 0.016f;

    private final Map<String, Float> anims = new HashMap<>();
    private long lastNanos = System.nanoTime();
    private Hit pressed, activeDrag;
    private double dragDist;

    protected GhostScreen(String title) { super(Component.literal(title)); }

    protected void beginFrame(int mouseX, int mouseY) {
        mx = mouseX; my = mouseY;
        hits.clear();
        long n = System.nanoTime();
        dt = Math.min(0.1f, (n - lastNanos) / 1.0e9f);
        lastNanos = n;
    }

    protected float anim(String id, float target) {
        Float cur = anims.get(id);
        float v = cur == null ? target : cur;
        if (!Ui.anim()) v = target;
        else v += (target - v) * Math.min(1f, dt * 16f);
        anims.put(id, v);
        return v;
    }

    protected boolean over(int x, int y, int w, int h, boolean clip) {
        if (mx < x || my < y || mx >= x + w || my >= y + h) return false;
        if (clip && (mx < clipX1 || my < clipY1 || mx >= clipX2 || my >= clipY2)) return false;
        return true;
    }

    protected void hit(int x, int y, int w, int h, boolean clip, Runnable click) {
        hits.add(new Hit(x, y, w, h, clip, click, null));
    }

    protected void hitDrag(int x, int y, int w, int h, boolean clip, DoubleConsumer drag) {
        hits.add(new Hit(x, y, w, h, clip, null, drag));
    }

    /** Standard dark button; registers its own hit region. */
    protected void button(GuiGraphics g, String id, int x, int y, int w, int h, String label, Runnable r) {
        boolean hov = over(x, y, w, h, false);
        float hv = anim(id, hov ? 1f : 0f);
        Ui.rect(g, x, y, w, h, 6, Ui.c(Ui.mix(Ui.card(), Ui.hover(), hv), 0.94f));
        Ui.ring(g, x, y, w, h, 6, Ui.c(Ui.mix(Ui.border(), Ui.accent(), hv * 0.85f), 0.95f));
        if (hv > 0.02f) g.fill(x + 1, y + 6, x + 3, y + h - 6, Ui.c(Ui.accent(), hv));
        Ui.textC(g, label, x + w / 2, y + (h - 8) / 2, Ui.c(Ui.mix(0xC9C9D6, Ui.TEXT, hv), 1f));
        hit(x, y, w, h, false, r);
    }

    protected void onBackgroundClick() { }
    protected void scrollBy(double amount) { }

    // Mouse handling (no @Override on purpose: signatures follow the 1.21.9+ input events).
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double x = event.x(), y = event.y();
        dragDist = 0;
        pressed = null;
        activeDrag = null;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.contains(x, y)) continue;
            if (h.clip && (x < clipX1 || y < clipY1 || x >= clipX2 || y >= clipY2)) continue;
            if (h.drag != null) { activeDrag = h; h.drag.accept(x); }
            else pressed = h;
            return true;
        }
        onBackgroundClick();
        return true;
    }

    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (activeDrag != null) { activeDrag.drag.accept(event.x()); return true; }
        dragDist += Math.abs(dragX) + Math.abs(dragY);
        if (dragDist > 4) { pressed = null; scrollBy(-dragY); }
        return true;
    }

    public boolean mouseReleased(MouseButtonEvent event) {
        if (pressed != null && dragDist <= 4) pressed.click.run();
        pressed = null;
        activeDrag = null;
        return true;
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollBy(-scrollY * 22);
        return true;
    }
}
