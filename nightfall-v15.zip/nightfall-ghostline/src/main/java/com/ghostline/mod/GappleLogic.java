package com.ghostline.mod;

/** Pure state machine for AutoGapple: when to start eating, when to stop holding the use key, cool-down. No Minecraft types. */
public final class GappleLogic {
    public enum Phase { IDLE, EATING, COOLDOWN }
    public enum Action { NONE, START, STOP }

    public Phase phase = Phase.IDLE;
    private int ticks;

    public void reset() { phase = Phase.IDLE; ticks = 0; }

    /**
     * @param usingItem   the player is currently using (eating) an item
     * @param eatBelow    start eating at or below this health (absorption counts as health)
     * @param skipAbsorb  do not eat when absorption already is at least this much (a golden apple was just eaten)
     * @param maxEat      give up holding after this many ticks (a golden apple needs about 32)
     */
    public Action step(double hp, double absorption, boolean usingItem, boolean haveGapple, boolean allowed,
                       double eatBelow, double skipAbsorb, int cooldown, int maxEat) {
        switch (phase) {
            case IDLE -> {
                if (allowed && haveGapple && hp <= eatBelow && absorption < skipAbsorb) { phase = Phase.EATING; ticks = 0; return Action.START; }
            }
            case EATING -> {
                ticks++;
                if ((!usingItem && ticks > 3) || ticks > maxEat || !allowed) { phase = Phase.COOLDOWN; ticks = 0; return Action.STOP; }
            }
            case COOLDOWN -> { if (++ticks >= cooldown) { phase = Phase.IDLE; ticks = 0; } }
        }
        return Action.NONE;
    }
}
