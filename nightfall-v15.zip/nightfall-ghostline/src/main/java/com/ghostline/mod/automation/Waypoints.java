package com.ghostline.mod.automation;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Named points ("home", "mine", "portal") for navigation. Stored as one text line: name=x,y,z,dimension;name=... Pure Java. */
public final class Waypoints {
    public record Point(String name, int x, int y, int z, String dim) { }

    public static final int MAX = 32;
    private final Map<String, Point> points = new LinkedHashMap<>();

    public static boolean validName(String n) { return n != null && n.matches("[a-z0-9_-]{1,24}"); }

    /** Adds or replaces a point. Returns an error text, or null when stored. */
    public String set(String name, int x, int y, int z, String dim) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (!validName(n)) return "name must be 1-24 chars: a-z 0-9 _ -";
        if (!points.containsKey(n) && points.size() >= MAX) return "too many points (max " + MAX + ")";
        String d = dim == null ? "" : dim.replaceAll("[;=,\\s]", "_");
        points.put(n, new Point(n, x, y, z, d));
        return null;
    }

    public boolean remove(String name) { return name != null && points.remove(name.toLowerCase(Locale.ROOT)) != null; }
    public Point get(String name) { return name == null ? null : points.get(name.toLowerCase(Locale.ROOT)); }
    public List<Point> all() { return new ArrayList<>(points.values()); }

    public String format() {
        StringBuilder sb = new StringBuilder();
        for (Point p : points.values()) {
            if (sb.length() > 0) sb.append(';');
            sb.append(p.name).append('=').append(p.x).append(',').append(p.y).append(',').append(p.z).append(',').append(p.dim);
        }
        return sb.toString();
    }

    /** Lenient: broken entries are skipped. */
    public static Waypoints parse(String text) {
        Waypoints w = new Waypoints();
        if (text == null) return w;
        for (String e : text.split(";")) {
            int eq = e.indexOf('=');
            if (eq <= 0) continue;
            String[] v = e.substring(eq + 1).split(",", -1);
            if (v.length < 3) continue;
            try { w.set(e.substring(0, eq).trim(), Integer.parseInt(v[0].trim()), Integer.parseInt(v[1].trim()), Integer.parseInt(v[2].trim()), v.length > 3 ? v[3].trim() : ""); }
            catch (NumberFormatException ignored) { }
        }
        return w;
    }
}
