package com.ghostline.mod;

import java.util.function.IntFunction;

/** Pure hole detection for HoleESP. A "hole" is a 1x1 pit: free body space, a safe floor and a safe block on all four sides. */
public final class HoleLogic {
    private HoleLogic() { }

    /** Cell kinds the caller reports. */
    public static final int AIR = 0, BEDROCK = 1, OBSIDIAN = 2, OTHER = 3;
    public static final int NONE = 0, MIXED_SAFE = 1, BEDROCK_HOLE = 2, UNSAFE = 3;

    /**
     * @param kind  kind at dx,dy,dz relative to the feet cell, packed as ((dx+1)*3+(dy+1))*3+(dz+1) for dx,dz in -1..1 and dy in -1..2
     *              (use {@link #idx})
     * Result: BEDROCK_HOLE (all five blocks bedrock), MIXED_SAFE (all bedrock/obsidian), UNSAFE (closed but some block is breakable), NONE (not a hole).
     */
    public static int classify(IntFunction<Integer> kind) {
        if (kind.apply(idx(0, 0, 0)) != AIR || kind.apply(idx(0, 1, 0)) != AIR) return NONE;
        int[][] parts = {{0, -1, 0}, {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}};
        boolean allBedrock = true, allSafe = true;
        for (int[] p : parts) {
            int k = kind.apply(idx(p[0], p[1], p[2]));
            if (k == AIR) return NONE;                     // open side: not a hole at all
            if (k != BEDROCK) allBedrock = false;
            if (k != BEDROCK && k != OBSIDIAN) allSafe = false;
        }
        return allBedrock ? BEDROCK_HOLE : allSafe ? MIXED_SAFE : UNSAFE;
    }

    public static int idx(int dx, int dy, int dz) { return ((dx + 1) * 4 + (dy + 1)) * 3 + (dz + 1); }
}
