package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/**
 * Keeps obsidian on the four sides of your feet (the classic HvH surround). Needs obsidian in the hotbar. Places a few blocks
 * per step by clicking the top face of the block under each missing cell, then restores your slot. By default it stops when you move
 * off the block so it never fights your own movement.
 */
public final class AutoSurround {
    private AutoSurround() { }

    private static int tick;
    private static BlockPos home;
    private static boolean warned;

    private static boolean solid(Minecraft mc, int[] c) {
        BlockPos b = new BlockPos(c[0], c[1], c[2]);
        return !mc.level.getBlockState(b).getCollisionShape(mc.level, b).isEmpty();
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.AUTOSURROUND;
        if (++tick % Math.max(1, m.get(0).i()) != 0) return;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isSpectator() || !p.onGround()) return;
        BlockPos feet = p.blockPosition();
        if (m.get(2).i() == 1) { // only works on the block where it was switched on / where you stand still
            if (home == null) home = feet;
            if (!home.equals(feet)) { if (p.getDeltaMovement().horizontalDistanceSqr() > 0.0004) return; home = feet; }
        }
        List<int[]> todo = SurroundLogic.plan(feet.getX(), feet.getY(), feet.getZ(), c -> solid(mc, c), m.get(1).i());
        if (todo.isEmpty()) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(Items.OBSIDIAN)) { slot = i; break; }
        if (slot < 0) { if (!warned) { warned = true; Toasts.warn("AutoSurround", Lang.t("sur.noobs")); } return; }
        warned = false;
        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        for (int[] c : todo) {
            AABB box = new AABB(c[0], c[1], c[2], c[0] + 1, c[1] + 1, c[2] + 1);
            if (!mc.level.getEntitiesOfClass(Entity.class, box, e -> e != p && e.isAlive()).isEmpty()) continue; // something stands in the cell
            BlockPos below = new BlockPos(c[0], c[1] - 1, c[2]);
            mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(new Vec3(c[0] + 0.5, c[1], c[2] + 0.5), Direction.UP, below, false));
            p.swing(InteractionHand.MAIN_HAND);
        }
        p.getInventory().setSelectedSlot(prev);
    }

    public static void stop() { home = null; warned = false; }
}
