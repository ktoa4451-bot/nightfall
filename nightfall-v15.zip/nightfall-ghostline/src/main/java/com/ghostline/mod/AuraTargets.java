package com.ghostline.mod;

import java.util.List;

/** Pure target selection for KillAura (no Minecraft types). */
public final class AuraTargets {
    private AuraTargets() { }

    public record Cand(int id, double dist, double health, double angle, boolean visible) { }

    public static final int DISTANCE = 0, HEALTH = 1, ANGLE = 2;

    /** Index of the best candidate or -1. fov is the full cone in degrees (360 = all around). */
    public static int pick(List<Cand> c, double range, double fov, int mode, boolean needVisible) {
        int best = -1;
        for (int i = 0; i < c.size(); i++) {
            Cand x = c.get(i);
            if (x.dist() > range) continue;
            if (fov < 360 && x.angle() > fov / 2.0) continue;
            if (needVisible && !x.visible()) continue;
            if (best < 0 || better(x, c.get(best), mode)) best = i;
        }
        return best;
    }

    private static boolean better(Cand a, Cand b, int mode) {
        double ka = key(a, mode), kb = key(b, mode);
        if (ka != kb) return ka < kb;
        return a.dist() < b.dist();
    }

    private static double key(Cand c, int mode) {
        return switch (mode) { case HEALTH -> c.health(); case ANGLE -> c.angle(); default -> c.dist(); };
    }

    /** Whether a crystal spot/break is worth it and safe: enemy takes enough, you take little and never die. */
    public static boolean crystalWorth(double enemyDmg, double selfDmg, double selfHealth, double minEnemy, double maxSelf, double safetyMargin) {
        if (enemyDmg < minEnemy) return false;
        if (selfDmg > maxSelf) return false;
        return selfDmg < selfHealth - safetyMargin;
    }
}
