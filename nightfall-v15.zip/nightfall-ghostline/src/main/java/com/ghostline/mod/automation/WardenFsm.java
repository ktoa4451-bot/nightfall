package com.ghostline.mod.automation;

/**
 * Auto Warden state machine (pure). It only reacts to a distance that the client really knows (NaN = no confirmed Warden).
 * DISABLED -> IDLE -> DETECTED -> WARNING -> EVADING -> SAFE -> IDLE. Hysteresis stops flip-flopping; PAUSED is user controlled.
 */
public final class WardenFsm {
    public enum State { DISABLED, IDLE, DETECTED, WARNING, EVADING, SAFE, PAUSED }
    public enum Mode { ALERT, ASSIST, EVADE }

    public State state = State.DISABLED;
    private int calmTicks;

    public double radius = 40, warnDist = 20, evadeDist = 12;
    public int calmNeeded = 60;       // ticks without danger before SAFE -> IDLE
    public Mode mode = Mode.ALERT;
    public boolean escapeAvailable;   // a route to the escape point exists

    /** True once per transition into WARNING: the caller sends one notification, not one per tick. */
    public boolean justWarned;
    /** True while the caller should run (or keep running) the evade route. */
    public boolean wantEvade() { return state == State.EVADING; }

    public void enable(boolean on) { if (!on) state = State.DISABLED; else if (state == State.DISABLED) state = State.IDLE; }
    public void pause(boolean p) { if (p && state != State.DISABLED) state = State.PAUSED; else if (!p && state == State.PAUSED) state = State.IDLE; }

    public void step(double dist) {
        justWarned = false;
        if (state == State.DISABLED || state == State.PAUSED) return;
        boolean seen = !Double.isNaN(dist) && dist <= radius;
        if (!seen) {
            if (state == State.IDLE) return;
            if (state == State.SAFE) { if (++calmTicks >= calmNeeded) { state = State.IDLE; calmTicks = 0; } return; }
            state = State.SAFE; calmTicks = 0; return; // target lost: stop evading, wait
        }
        calmTicks = 0;
        boolean evade = mode == Mode.EVADE && escapeAvailable && dist <= evadeDist;
        switch (state) {
            case IDLE, SAFE -> state = State.DETECTED;
            case DETECTED -> { if (dist <= warnDist) { state = State.WARNING; justWarned = true; } }
            case WARNING -> { if (evade) state = State.EVADING; else if (dist > warnDist * 1.25) state = State.DETECTED; }
            case EVADING -> { if (dist > evadeDist * 1.5) state = State.WARNING; }
            default -> { }
        }
        if (state == State.DETECTED && dist <= warnDist) { state = State.WARNING; justWarned = true; }
    }
}
