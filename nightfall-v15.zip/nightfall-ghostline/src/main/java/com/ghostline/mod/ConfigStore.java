package com.ghostline.mod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.stream.Stream;

/** Named configurations stored as files, plus share codes (base64 text). */
public final class ConfigStore {
    private ConfigStore() { }

    private static Path dir() throws IOException {
        Path d = FabricLoader.getInstance().getConfigDir().resolve("ghostline-configs");
        Files.createDirectories(d);
        return d;
    }

    public static String clean(String name) {
        return name == null ? "" : name.trim().replaceAll("[^\\p{L}\\p{N}_ -]", "");
    }

    private static Path path(String name) throws IOException { return dir().resolve(name + ".properties"); }

    public static List<String> list() {
        List<String> out = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir())) {
            s.forEach(p -> {
                String f = p.getFileName().toString();
                if (f.endsWith(".properties")) out.add(f.substring(0, f.length() - ".properties".length()));
            });
        } catch (Exception ignored) { }
        Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
        return out;
    }

    public static boolean exists(String name) {
        try { return Files.exists(path(name)); } catch (IOException e) { return false; }
    }

    public static void save(String name) throws IOException {
        Properties p = Config.snapshot(false);
        try (BufferedWriter w = Files.newBufferedWriter(path(name), StandardCharsets.UTF_8)) {
            p.store(w, "Ghostline config");
        }
    }

    /** Named config files are validated like any other input before anything is applied. */
    public static void load(String name) throws IOException {
        Properties p = new Properties();
        Path f = path(name);
        if (Files.size(f) > CfgCodec.MAX_BYTES * 4L) throw new IOException("config file too large");
        try (BufferedReader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) { p.load(r); }
        ConfigIO.applyNamed(p);
    }

    public static void delete(String name) throws IOException { Files.deleteIfExists(path(name)); }

    /** Share code for the current configuration (checksummed CFG, "GL1." prefix). */
    public static String export() throws IOException {
        return ConfigIO.shareCode();
    }

    /** Throws IllegalArgumentException with the reason when the code or file is rejected. */
    public static String importCode(String code) {
        return ConfigIO.importCode(code);
    }
}
