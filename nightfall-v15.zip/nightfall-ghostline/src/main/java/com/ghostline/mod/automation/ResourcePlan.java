package com.ghostline.mod.automation;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Resource Planner maths: parse "diamond:3, iron_ingot:8", compare with what you have, list what is missing. Pure Java. */
public final class ResourcePlan {
    private ResourcePlan() { }

    public static final int MAX_ENTRIES = 64, MAX_COUNT = 100_000;

    /** Lenient parser: separators , ; or newline, "id:count" or "id" (= 1). Bad entries are skipped and reported in {@code errors}. */
    public static Map<String, Integer> parse(String text, java.util.List<String> errors) {
        Map<String, Integer> out = new LinkedHashMap<>();
        if (text == null) return out;
        for (String raw : text.split("[,;\\n]")) {
            String t = raw.trim().toLowerCase(Locale.ROOT);
            if (t.isEmpty()) continue;
            if (t.startsWith("minecraft:")) t = t.substring(10);
            String id = t; int n = 1;
            int c = t.lastIndexOf(':');
            if (c >= 0) {
                id = t.substring(0, c).trim();
                try { n = Integer.parseInt(t.substring(c + 1).trim()); }
                catch (NumberFormatException e) { if (errors != null) errors.add("bad count: " + raw.trim()); continue; }
            }
            if (!id.matches("[a-z0-9_./-]{1,64}")) { if (errors != null) errors.add("bad id: " + raw.trim()); continue; }
            if (n < 1 || n > MAX_COUNT) { if (errors != null) errors.add("count out of range: " + raw.trim()); continue; }
            if (out.size() >= MAX_ENTRIES && !out.containsKey(id)) { if (errors != null) errors.add("too many entries"); break; }
            out.merge(id, n, (a, b) -> (int) Math.min(MAX_COUNT, (long) a + b));
        }
        return out;
    }

    public static String format(Map<String, Integer> m) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> e : m.entrySet()) { if (sb.length() > 0) sb.append(", "); sb.append(e.getKey()).append(':').append(e.getValue()); }
        return sb.toString();
    }

    /** need minus have, only positive remainders. */
    public static Map<String, Integer> missing(Map<String, Integer> need, Map<String, Integer> have) {
        Map<String, Integer> out = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> e : need.entrySet()) {
            int left = e.getValue() - have.getOrDefault(e.getKey(), 0);
            if (left > 0) out.put(e.getKey(), left);
        }
        return out;
    }

    public static boolean complete(Map<String, Integer> need, Map<String, Integer> have) { return missing(need, have).isEmpty(); }
}
