package com.ghostline.mod;

import net.minecraft.client.Minecraft;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Module {
    public final String name;          // internal name, also the config key
    public final int category;         // 0 combat, 1 movement, 2 player, 3 visuals, 4 misc, 8 cosmetics
    public boolean enabled;
    public int bind = -1;              // GLFW key code, -1 = not bound
    public boolean prevDown;
    public boolean toggleable = true;  // false: the bind always runs the action (Panic)
    public Consumer<Minecraft> action; // set: the bind runs this (when enabled) instead of toggling
    public final List<Setting> settings = new ArrayList<>();

    public Module(String name, int category) { this.name = name; this.category = category; }

    public Module add(Setting s) { settings.add(s); return this; }
    public Module on() { enabled = true; return this; }
    public Module notToggle() { toggleable = false; return this; }
    public Setting get(int i) { return settings.get(i); }
}
