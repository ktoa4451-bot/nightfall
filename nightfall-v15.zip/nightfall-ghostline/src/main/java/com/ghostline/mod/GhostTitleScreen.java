package com.ghostline.mod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.options.OptionsScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.util.Mth;

/** Custom main menu: buttons on the left, logo on the right. */
public class GhostTitleScreen extends GhostScreen {
    public GhostTitleScreen() { super("Ghostline"); }

    @Override
    public boolean shouldCloseOnEsc() { return false; }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        beginFrame(mouseX, mouseY);
        Ui.backdrop(g, this.width, this.height, 255);

        int bw = Mth.clamp((int) (this.width * 0.34f), 120, 190);
        int bh = 24, gap = 8;
        int x = Math.max(14, (int) (this.width * 0.08f));
        int total = 5 * bh + 4 * gap;
        int y = Math.max(10, this.height / 2 - total / 2);

        button(g, "t_sp", x, y, bw, bh, Lang.t("ui.singleplayer"), () -> this.minecraft.setScreen(new SelectWorldScreen(this)));
        button(g, "t_mp", x, y + (bh + gap), bw, bh, Lang.t("ui.multiplayer"), () -> this.minecraft.setScreen(new JoinMultiplayerScreen(this)));
        button(g, "t_op", x, y + (bh + gap) * 2, bw, bh, Lang.t("ui.options"), () -> this.minecraft.setScreen(new OptionsScreen(this, this.minecraft.options)));
        button(g, "t_gl", x, y + (bh + gap) * 3, bw, bh, Lang.t("ui.ghost_menu"), () -> this.minecraft.setScreen(new dev.nightfall.gui.ClickGUI()));
        button(g, "t_q", x, y + (bh + gap) * 4, bw, bh, Lang.t("ui.quit"), () -> this.minecraft.stop());

        int areaX = x + bw + 20;
        int areaW = this.width - areaX;
        int size = Mth.clamp(Math.min(areaW - 20, this.height - 60), 64, 256);
        int lx = areaX + areaW / 2 - size / 2;
        int ly = this.height / 2 - size / 2 - 6;
        Ui.logo(g, Ui.LOGO, lx, ly, size);
        Ui.textC(g, "G H O S T L I N E", areaX + areaW / 2, ly + size + 4, Ui.c(0xB9B2FF, 0.9f));

        Ui.textR(g, "Minecraft 1.21.11", this.width - 8, this.height - 14, Ui.c(Ui.MUTED, 1f));
    }
}
