package com.ghostline.mod.automation;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

/**
 * One unit of automation work. Subclasses implement {@link #onStart}, {@link #onTick}, {@link #onStop}.
 * Everything runs on the game thread (the TaskManager is ticked from the client tick).
 * A task that controls player movement must return true from {@link #controlsMovement()}; the TaskManager
 * never lets two such tasks run at the same time.
 */
public abstract class AutomationTask {
    private static final AtomicLong IDS = new AtomicLong();

    public final long id = IDS.incrementAndGet();
    public final String name;
    public final int priority;                 // higher runs first
    public final long timeoutMs;               // 0 = no timeout
    private final Map<String, String> params = new LinkedHashMap<>();

    private TaskState state = TaskState.IDLE;
    private long startedAt;                    // ms, 0 until started
    private long activeMs;                     // running time without pauses
    private long lastResume;
    private String stage = "";
    private String stopReason = "";
    private AutomationResult result;

    protected AutomationTask(String name, int priority, long timeoutMs) {
        this.name = name; this.priority = priority; this.timeoutMs = Math.max(0, timeoutMs);
    }

    public AutomationTask param(String k, String v) { params.put(k, v); return this; }
    public Map<String, String> params() { return Collections.unmodifiableMap(params); }

    public TaskState state() { return state; }
    public long startedAt() { return startedAt; }
    public String stage() { return stage; }
    public String stopReason() { return stopReason; }
    public AutomationResult result() { return result; }
    public long runningMs(long now) { return state == TaskState.RUNNING ? activeMs + (now - lastResume) : activeMs; }

    protected void stage(String s) { stage = s == null ? "" : s; }

    public boolean controlsMovement() { return true; }

    /** Called once when the task starts. Return a failure to abort. */
    protected abstract AutomationResult onStart(long now);
    /** Called every tick while RUNNING. Return null to keep going, a result to finish (ok = COMPLETED, else FAILED). */
    protected abstract AutomationResult onTick(long now);
    /** Called exactly once when the task leaves RUNNING/PAUSED for good: release keys, clear state. */
    protected abstract void onStop(TaskState finalState, String reason);

    /** Moves to a new state when the transition is legal. Returns false (and changes nothing) otherwise. */
    boolean transition(TaskState to, long now, String reason) {
        if (!state.canGo(to)) return false;
        if (to == TaskState.RUNNING) {
            if (startedAt == 0) startedAt = now;
            lastResume = now;
        } else if (state == TaskState.RUNNING) {
            activeMs += now - lastResume;
        }
        state = to;
        if (reason != null && !reason.isEmpty()) stopReason = reason;
        return true;
    }

    void finish(AutomationResult r) { this.result = r; }

    @Override public String toString() { return name + "#" + id + "[" + state + "]"; }
}
