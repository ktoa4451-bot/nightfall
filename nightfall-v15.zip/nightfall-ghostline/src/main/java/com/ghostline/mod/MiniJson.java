package com.ghostline.mod;

import java.util.LinkedHashMap;
import java.util.Map;

/** Tiny flat-JSON helper for the friends protocol (objects of strings, numbers and booleans). Never throws on bad input. */
public final class MiniJson {
    private MiniJson() { }

    private static final int MAX = 16384;

    public static String encode(Map<String, Object> m) {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> e : m.entrySet()) {
            if (!first) sb.append(',');
            first = false;
            sb.append(quote(e.getKey())).append(':');
            Object v = e.getValue();
            if (v instanceof Number || v instanceof Boolean) sb.append(v);
            else sb.append(quote(String.valueOf(v)));
        }
        return sb.append('}').toString();
    }

    private static String quote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> { if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c); }
            }
        }
        return sb.append('"').toString();
    }

    /** Parses a flat object. Returns null for anything that is not one (nested values, garbage, too long). */
    public static Map<String, String> decode(String s) {
        if (s == null || s.length() > MAX) return null;
        try { return new Parser(s).object(); } catch (RuntimeException e) { return null; }
    }

    private static final class Parser {
        private final String s;
        private int i;
        Parser(String s) { this.s = s; }

        private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        private char peek() { if (i >= s.length()) throw new IllegalStateException(); return s.charAt(i); }
        private void expect(char c) { ws(); if (peek() != c) throw new IllegalStateException(); i++; }

        Map<String, String> object() {
            Map<String, String> m = new LinkedHashMap<>();
            expect('{');
            ws();
            if (peek() == '}') { i++; return m; }
            while (true) {
                ws();
                String k = string();
                expect(':');
                ws();
                m.put(k, value());
                ws();
                char c = peek();
                i++;
                if (c == '}') break;
                if (c != ',') throw new IllegalStateException();
                if (m.size() > 64) throw new IllegalStateException();
            }
            ws();
            if (i != s.length()) throw new IllegalStateException();
            return m;
        }

        private String value() {
            char c = peek();
            if (c == '"') return string();
            int st = i;
            while (i < s.length() && ",}] \t\r\n".indexOf(s.charAt(i)) < 0) i++;
            String lit = s.substring(st, i);
            if (lit.equals("true") || lit.equals("false") || lit.equals("null") || lit.matches("-?\\d{1,18}(\\.\\d{1,18})?([eE][-+]?\\d{1,3})?")) return lit;
            throw new IllegalStateException(); // nested object/array or garbage
        }

        private String string() {
            if (peek() != '"') throw new IllegalStateException();
            i++;
            StringBuilder sb = new StringBuilder();
            while (true) {
                char c = peek();
                i++;
                if (c == '"') break;
                if (c == '\\') {
                    char n = peek();
                    i++;
                    switch (n) {
                        case 'n' -> sb.append('\n');
                        case 'r' -> sb.append('\r');
                        case 't' -> sb.append('\t');
                        case 'b' -> sb.append('\b');
                        case 'f' -> sb.append('\f');
                        case '"', '\\', '/' -> sb.append(n);
                        case 'u' -> {
                            if (i + 4 > s.length()) throw new IllegalStateException();
                            sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            i += 4;
                        }
                        default -> throw new IllegalStateException();
                    }
                } else sb.append(c);
            }
            return sb.toString();
        }
    }
}
