package com.ghostline.mod;

/**
 * Damage estimate for an end crystal explosion (vanilla formula, power 6). This is an UPPER BOUND:
 * armor, enchantments, effects and blocks between the crystal and the target are not included
 * (exposure is assumed to be 1), and the difficulty factor is applied for players only.
 */
public final class CrystalMath {
    private CrystalMath() { }

    public static final double RADIUS = 12.0; // 2 * explosion power (6)

    /** difficulty: 0 peaceful, 1 easy, 2 normal, 3 hard */
    public static double rawDamage(double distance, double exposure, int difficulty) {
        if (distance >= RADIUS || exposure <= 0) return 0;
        double impact = (1.0 - distance / RADIUS) * Math.min(1.0, exposure);
        double dmg = Math.floor((impact * impact + impact) / 2.0 * 7.0 * RADIUS + 1.0);
        return switch (difficulty) {
            case 0 -> 0;
            case 1 -> Math.min(dmg / 2.0 + 1.0, dmg);
            case 3 -> dmg * 1.5;
            default -> dmg;
        };
    }

    public static double distance(double ex, double ey, double ez, double cx, double cy, double cz) {
        double dx = ex - cx, dy = ey - cy, dz = ez - cz;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    /** Higher is better: damage to the enemy minus weighted damage to yourself. A spot that could kill you scores very low. */
    public static double score(double enemyDmg, double selfDmg, double selfHealth, double selfWeight) {
        if (selfDmg >= selfHealth) return -1000.0;
        return enemyDmg - selfDmg * selfWeight;
    }
}
