package com.ghostline.mod.automation;

/** Life cycle of an automation task. Only the transitions allowed by {@link #canGo} ever happen. */
public enum TaskState {
    IDLE, RUNNING, PAUSED, COMPLETED, FAILED, CANCELLED;

    public boolean isFinished() { return this == COMPLETED || this == FAILED || this == CANCELLED; }

    public boolean canGo(TaskState to) {
        return switch (this) {
            case IDLE -> to == RUNNING || to == CANCELLED || to == FAILED;
            case RUNNING -> to == PAUSED || to == COMPLETED || to == FAILED || to == CANCELLED;
            case PAUSED -> to == RUNNING || to == CANCELLED || to == FAILED;
            default -> false; // finished tasks never come back
        };
    }
}
