package com.ghostline.mod;

import java.util.ArrayList;
import java.util.List;

/**
 * Queue and timing of on-screen notifications. No Minecraft dependencies; time is passed in, so it is testable.
 * New toasts wait in a queue while the screen is full, identical ones are merged ("x3"), urgent ones go first.
 * Each toast has an enter animation, a lifetime and an exit animation.
 */
public final class ToastQueue {
    public enum Type { INFO, SUCCESS, WARN, ERROR }

    public static final long ENTER_MS = 240, EXIT_MS = 260, MERGE_WINDOW_MS = 3000;
    public static final int MAX_PENDING = 40;

    public static final class Toast {
        public final Type type;
        public final String title, text;
        public int count = 1;
        public long shownAt, endAt, durationMs;
        public float slot;            // animated vertical position, owned by the renderer
        public boolean placed;        // renderer: slot initialised
        Toast(Type type, String title, String text, long durationMs) { this.type = type; this.title = title; this.text = text; this.durationMs = durationMs; }
        boolean same(Type t, String ti, String tx) { return type == t && title.equals(ti) && text.equals(tx); }
    }

    private final List<Toast> pending = new ArrayList<>();
    private final List<Toast> visible = new ArrayList<>();

    public synchronized void push(Type type, String title, String text, long durationMs, boolean urgent, long now) {
        String ti = title == null ? "" : title, tx = text == null ? "" : text;
        long dur = Math.max(800, Math.min(30_000, durationMs));
        for (Toast t : visible) {
            if (t.same(type, ti, tx) && now < t.endAt && now - t.shownAt < MERGE_WINDOW_MS + t.durationMs) {
                t.count++; t.endAt = now + dur; t.durationMs = dur; t.shownAt = Math.min(t.shownAt, now - ENTER_MS); // refresh, no replay of the enter animation
                return;
            }
        }
        for (Toast t : pending) if (t.same(type, ti, tx)) { t.count++; return; }
        Toast t = new Toast(type, ti, tx, dur);
        if (urgent) pending.add(0, t); else pending.add(t);
        while (pending.size() > MAX_PENDING) pending.remove(pending.size() - 1);
    }

    /** Moves queued toasts onto the screen (up to max at a time) and removes finished ones. */
    public synchronized void update(long now, int max) {
        visible.removeIf(t -> now >= t.endAt + EXIT_MS);
        while (!pending.isEmpty() && visible.size() < Math.max(1, max)) {
            Toast t = pending.remove(0);
            t.shownAt = now;
            t.endAt = now + t.durationMs;
            visible.add(t);
        }
    }

    public synchronized List<Toast> visible() { return new ArrayList<>(visible); }
    public synchronized int pendingCount() { return pending.size(); }

    /** Removes everything (e.g. on panic). */
    public synchronized void clear() { pending.clear(); visible.clear(); }

    private static float ease(float x) { float v = 1f - Math.max(0f, Math.min(1f, x)); return 1f - v * v * v; }

    /** 0 = fully hidden, 1 = fully shown: enter animation, hold, exit animation. */
    public static float presence(Toast t, long now) {
        if (now < t.endAt) return ease((now - t.shownAt) / (float) ENTER_MS);
        return 1f - ease((now - t.endAt) / (float) EXIT_MS);
    }

    /** Remaining lifetime 1..0 for the progress bar. */
    public static float remaining(Toast t, long now) {
        if (now >= t.endAt) return 0f;
        return Math.max(0f, Math.min(1f, (t.endAt - now) / (float) Math.max(1, t.durationMs)));
    }
}
