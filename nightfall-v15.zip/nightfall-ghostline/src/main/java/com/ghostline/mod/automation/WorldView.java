package com.ghostline.mod.automation;

/** What the pathfinder may know about the world. UNKNOWN (unloaded) is never treated as safe. */
public interface WorldView {
    /** BREAKABLE = a full block that is safe to dig through (no fluid next to it, nothing falls on you). It still counts as a solid floor. */
    /** CLIMB = ladder, vine, scaffolding: a body can be inside it and move up/down. */
    enum Kind { AIR, SOLID, BREAKABLE, WATER, DANGER, CLIMB, UNKNOWN }
    Kind kind(int x, int y, int z);
}
