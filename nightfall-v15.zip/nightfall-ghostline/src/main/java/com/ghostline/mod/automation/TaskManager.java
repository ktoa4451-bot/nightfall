package com.ghostline.mod.automation;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/**
 * Queue + scheduler for automation tasks. Rules:
 *  - at most one movement task runs at a time (the highest priority waiting one starts when the slot is free);
 *  - non-movement tasks run next to it;
 *  - a task that throws is FAILED and cleaned up, the client never crashes;
 *  - timeouts count running time only (pauses do not count).
 * Not thread safe on purpose: call everything from the game thread.
 */
public final class TaskManager {
    private final List<AutomationTask> queue = new ArrayList<>();   // IDLE tasks, waiting
    private final List<AutomationTask> active = new ArrayList<>();  // RUNNING or PAUSED
    private final List<Consumer<AutomationEvent>> listeners = new ArrayList<>();
    private final List<AutomationTask> history = new ArrayList<>(); // finished, newest last
    private static final int HISTORY_MAX = 50;
    private boolean ticking;

    public void addListener(Consumer<AutomationEvent> l) { if (l != null && !listeners.contains(l)) listeners.add(l); }
    public void removeListener(Consumer<AutomationEvent> l) { listeners.remove(l); }

    /** Queues a task. Returns false when it is null or not IDLE. */
    public boolean submit(AutomationTask t) {
        if (t == null || t.state() != TaskState.IDLE || queue.contains(t) || active.contains(t)) return false;
        queue.add(t);
        return true;
    }

    public List<AutomationTask> queued() { return List.copyOf(queue); }
    public List<AutomationTask> running() { return List.copyOf(active); }
    public List<AutomationTask> finished() { return List.copyOf(history); }
    public boolean busy() { return !queue.isEmpty() || !active.isEmpty(); }

    public AutomationTask movementOwner() {
        for (AutomationTask t : active) if (t.controlsMovement() && t.state() == TaskState.RUNNING) return t;
        return null;
    }

    private boolean movementSlotTaken() {
        for (AutomationTask t : active) if (t.controlsMovement()) return true; // a PAUSED movement task keeps its slot
        return false;
    }

    public boolean pause(AutomationTask t, long now) {
        if (t == null || !active.contains(t) || !t.transition(TaskState.PAUSED, now, "paused")) return false;
        emit(AutomationEvent.Type.PAUSED, t, "paused");
        return true;
    }

    public boolean resume(AutomationTask t, long now) {
        if (t == null || !active.contains(t) || !t.transition(TaskState.RUNNING, now, "")) return false;
        emit(AutomationEvent.Type.RESUMED, t, "resumed");
        return true;
    }

    public boolean cancel(AutomationTask t, long now, String reason) {
        if (t == null) return false;
        String why = reason == null || reason.isEmpty() ? "cancelled" : reason;
        if (queue.remove(t)) {
            t.transition(TaskState.CANCELLED, now, why);
            t.finish(AutomationResult.failure(why));
            archive(t);
            emit(AutomationEvent.Type.CANCELLED, t, why);
            return true;
        }
        if (active.contains(t)) { end(t, TaskState.CANCELLED, now, why, AutomationResult.failure(why)); return true; }
        return false;
    }

    /** Emergency stop: everything queued or running is cancelled and cleaned up. */
    public void stopAll(long now, String reason) {
        for (AutomationTask t : new ArrayList<>(active)) cancel(t, now, reason);
        for (AutomationTask t : new ArrayList<>(queue)) cancel(t, now, reason);
    }

    /** Call once per game tick. worldReady = player and level exist; when false everything is stopped safely. */
    public void tick(long now, boolean worldReady) {
        if (ticking) return; // a listener must not re-enter the scheduler
        ticking = true;
        try {
            if (!worldReady) { if (busy()) stopAll(now, "world not available"); return; }
            startWaiting(now);
            for (AutomationTask t : new ArrayList<>(active)) {
                if (t.state() != TaskState.RUNNING) continue;
                if (t.timeoutMs > 0 && t.runningMs(now) > t.timeoutMs) {
                    end(t, TaskState.FAILED, now, "timeout", AutomationResult.failure("timeout")); continue;
                }
                AutomationResult r;
                try { r = t.onTick(now); }
                catch (RuntimeException | StackOverflowError e) {
                    end(t, TaskState.FAILED, now, "error: " + e.getClass().getSimpleName(), AutomationResult.failure("error: " + e)); continue;
                }
                if (r != null) end(t, r.ok() ? TaskState.COMPLETED : TaskState.FAILED, now, r.message(), r);
            }
        } finally { ticking = false; }
    }

    private void startWaiting(long now) {
        // highest priority first, FIFO inside one priority
        List<AutomationTask> order = new ArrayList<>(queue);
        order.sort((a, b) -> b.priority != a.priority ? Integer.compare(b.priority, a.priority) : Long.compare(a.id, b.id));
        for (AutomationTask t : order) {
            if (t.controlsMovement() && movementSlotTaken()) continue;
            queue.remove(t);
            AutomationResult r;
            try { r = t.onStart(now); }
            catch (RuntimeException e) { r = AutomationResult.failure("error: " + e); }
            if (r != null && !r.ok()) {
                t.transition(TaskState.FAILED, now, r.message()); // IDLE -> FAILED
                t.finish(r);
                safeStop(t, TaskState.FAILED, r.message());
                archive(t);
                emit(AutomationEvent.Type.FAILED, t, r.message());
                continue;
            }
            t.transition(TaskState.RUNNING, now, "");
            active.add(t);
            emit(AutomationEvent.Type.STARTED, t, t.name);
        }
    }

    private void end(AutomationTask t, TaskState to, long now, String reason, AutomationResult r) {
        active.remove(t);
        t.transition(to, now, reason);
        t.finish(r);
        safeStop(t, to, reason);
        archive(t);
        AutomationEvent.Type type = to == TaskState.COMPLETED ? AutomationEvent.Type.COMPLETED
            : to == TaskState.CANCELLED ? AutomationEvent.Type.CANCELLED : AutomationEvent.Type.FAILED;
        emit(type, t, reason);
    }

    private void safeStop(AutomationTask t, TaskState s, String reason) {
        try { t.onStop(s, reason); } catch (RuntimeException ignored) { /* cleanup must never crash the client */ }
    }

    private void archive(AutomationTask t) {
        history.add(t);
        while (history.size() > HISTORY_MAX) history.remove(0);
    }

    private void emit(AutomationEvent.Type type, AutomationTask t, String msg) {
        AutomationEvent e = new AutomationEvent(type, t, msg);
        for (Consumer<AutomationEvent> l : new ArrayList<>(listeners)) {
            try { l.accept(e); } catch (RuntimeException ignored) { }
        }
    }
}
