package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * World to screen projection for 2D overlays. It is computed from the player's eye position, view angles and the FOV option,
 * so it only matches the real camera in first person. Sprint/speed FOV effects are not included (small drift is possible).
 */
public final class Project {
    private Project() { }

    private static Vec3 eye = Vec3.ZERO, fwd = Vec3.ZERO, right = Vec3.ZERO, up = Vec3.ZERO;
    private static double tanX, tanY;
    private static int sw, sh;
    public static float yaw;

    /** Prepares the frame. Returns false when the overlay should not be drawn (third person, no player). */
    public static boolean begin(Minecraft mc, LocalPlayer p, float pt, int w, int h) {
        if (p == null || !mc.options.getCameraType().isFirstPerson()) return false;
        sw = w; sh = h;
        eye = p.getEyePosition(pt);
        yaw = p.getViewYRot(pt);
        double yr = Math.toRadians(yaw), xr = Math.toRadians(p.getViewXRot(pt));
        fwd = new Vec3(-Math.sin(yr) * Math.cos(xr), -Math.sin(xr), Math.cos(yr) * Math.cos(xr));
        right = new Vec3(-Math.cos(yr), 0, -Math.sin(yr));
        up = right.cross(fwd);
        tanY = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
        tanX = tanY * (w / (double) h);
        return true;
    }

    public static Vec3 eye() { return eye; }

    /** {screenX, screenY, depth} or null when the point is behind the camera. */
    public static double[] point(double x, double y, double z) {
        Vec3 d = new Vec3(x - eye.x, y - eye.y, z - eye.z);
        double depth = d.dot(fwd);
        if (depth < 0.05) return null;
        double sx = sw / 2.0 + (d.dot(right) / depth) / tanX * (sw / 2.0);
        double sy = sh / 2.0 - (d.dot(up) / depth) / tanY * (sh / 2.0);
        return new double[]{sx, sy, depth};
    }

    /** The 8 projected corners of a box, or null if any corner is behind the camera. */
    public static double[][] corners(AABB b) {
        double[][] out = new double[8][];
        int i = 0;
        for (int ix = 0; ix < 2; ix++) for (int iy = 0; iy < 2; iy++) for (int iz = 0; iz < 2; iz++) {
            double[] pt = point(ix == 0 ? b.minX : b.maxX, iy == 0 ? b.minY : b.maxY, iz == 0 ? b.minZ : b.maxZ);
            if (pt == null) return null;
            out[i++] = pt;
        }
        return out;
    }

    /** Screen rectangle {minX, minY, maxX, maxY} around a box, or null if not fully in front of the camera. */
    public static float[] rect(AABB b) {
        double[][] c = corners(b);
        if (c == null) return null;
        double x1 = Double.MAX_VALUE, y1 = Double.MAX_VALUE, x2 = -Double.MAX_VALUE, y2 = -Double.MAX_VALUE;
        for (double[] p : c) {
            x1 = Math.min(x1, p[0]); y1 = Math.min(y1, p[1]);
            x2 = Math.max(x2, p[0]); y2 = Math.max(y2, p[1]);
        }
        return new float[]{(float) x1, (float) y1, (float) x2, (float) y2};
    }

    public static boolean onScreen(float[] r) {
        return r[2] >= 0 && r[3] >= 0 && r[0] <= sw && r[1] <= sh;
    }

    public static int width() { return sw; }
    public static int height() { return sh; }
}
