package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Small helper modules that share one tick and one overlay: AutoClicker, InventoryHelper, CrystalHelper (hints only,
 * never places or breaks anything) and TargetHUD. Settings live in Config; nothing here sends packets by itself.
 */
public final class Extras {
    private Extras() { }

    private static final Random RND = new Random();

    // ------------------------------------------------------------------ AutoClicker

    private static long clickAt;

    /** CPS between Min and Max with a random interval; one click per tick at most; never sleeps. */
    private static void autoClicker(Minecraft mc, LocalPlayer p) {
        Module m = Config.CLICKER;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive()) { clickAt = 0; return; }
        boolean right = m.get(2).i() == 1;
        if (m.get(3).i() == 1 && !(right ? mc.options.keyUse.isDown() : mc.options.keyAttack.isDown())) { clickAt = 0; return; }
        long now = System.currentTimeMillis();
        double lo = Math.min(m.get(0).value, m.get(1).value), hi = Math.max(m.get(0).value, m.get(1).value);
        if (clickAt == 0) { clickAt = now + nextDelay(lo, hi); return; }
        if (now < clickAt) return;
        clickAt = now + nextDelay(lo, hi);
        if (right) {
            if (!p.isUsingItem()) mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
            return;
        }
        HitResult h = mc.hitResult;
        if (!(h instanceof EntityHitResult eh) || !(eh.getEntity() instanceof LivingEntity le)) return;
        if (!CheatMod.basicTarget(le, p, m.get(5).i() == 1, m.get(6).i() == 1)) return;
        if (m.get(4).i() == 1 && p.getAttackStrengthScale(0.5f) < 0.9f) { clickAt = now + 25; return; } // wait for the cooldown
        mc.gameMode.attack(p, le);
        p.swing(InteractionHand.MAIN_HAND);
    }

    /** Random delay in ms for a CPS range (pure maths, no side effects). */
    static long nextDelay(double minCps, double maxCps) {
        double cps = minCps + RND.nextDouble() * Math.max(0, maxCps - minCps);
        return (long) (1000.0 / Math.max(1.0, cps));
    }

    // ------------------------------------------------------------------ Inventory Helper

    private static int freeSlots = -1, invTick;
    private static boolean lowWarned, sortKeyPrev;
    private static final List<int[]> sortPlan = new ArrayList<>();
    private static int sortWait;

    private static void inventoryHelper(Minecraft mc, LocalPlayer p) {
        Module m = Config.INVHELPER;
        if (++invTick % 10 == 0 || freeSlots < 0) {
            int f = 0;
            for (int i = 0; i < 36; i++) if (p.getInventory().getItem(i).isEmpty()) f++;
            freeSlots = f;
            int warnAt = m.get(0).i();
            if (f <= warnAt && !lowWarned) { lowWarned = true; Toasts.warn("Inventory", String.format(Lang.t("inv.low"), f)); }
            else if (f > warnAt + 1) lowWarned = false;
        }
        // sorting only runs with the inventory screen open and the cursor empty; one swap (3 clicks) every N ticks
        if (!(mc.screen instanceof InventoryScreen) || mc.gameMode == null) { sortPlan.clear(); sortKeyPrev = false; return; }
        long win = GLFW.glfwGetCurrentContext();
        int key = m.get(2).i();
        boolean down = win != 0 && key > 0 && GLFW.glfwGetKey(win, key) == GLFW.GLFW_PRESS;
        if (down && !sortKeyPrev && sortPlan.isEmpty() && p.containerMenu.getCarried().isEmpty()) {
            String[] keys = new String[27];
            for (int i = 0; i < 27; i++) keys[i] = itemKey(p.getInventory().getItem(9 + i));
            List<int[]> plan = InvSort.plan(keys);
            sortPlan.addAll(plan);
            Toasts.info("Inventory", plan.isEmpty() ? Lang.t("inv.sorted") : String.format(Lang.t("inv.sorting"), plan.size()));
        }
        sortKeyPrev = down;
        if (sortPlan.isEmpty()) return;
        if (!p.containerMenu.getCarried().isEmpty()) { sortPlan.clear(); return; } // something is on the cursor: stop, never fight the player
        if (sortWait > 0) { sortWait--; return; }
        int[] s = sortPlan.remove(0);
        int a = 9 + s[0], b = 9 + s[1];   // main inventory slots share their number with the inventory menu (9..35)
        int id = p.inventoryMenu.containerId;
        mc.gameMode.handleInventoryMouseClick(id, a, 0, ClickType.PICKUP, p);
        mc.gameMode.handleInventoryMouseClick(id, b, 0, ClickType.PICKUP, p);
        mc.gameMode.handleInventoryMouseClick(id, a, 0, ClickType.PICKUP, p);
        sortWait = Math.max(0, m.get(3).i() - 1);
        if (sortPlan.isEmpty()) Toasts.info("Inventory", Lang.t("inv.done"));
    }
    private static String itemKey(ItemStack s) {
        if (s.isEmpty()) return "";
        return BuiltInRegistries.ITEM.getKey(s.getItem()).toString();
    }

    // ------------------------------------------------------------------ Crystal Helper (hints only)

    private static final List<String> crystalLines = new ArrayList<>();
    private static BlockPos bestSpot;
    private static int crystalTick;

    private static void crystalHelper(Minecraft mc, LocalPlayer p) {
        Module m = Config.CRYSTAL;
        if (++crystalTick % Math.max(5, m.get(6).i()) != 0) return;
        crystalLines.clear(); bestSpot = null;
        int diff = mc.level.getDifficulty().getId();
        double hp = p.getHealth() + p.getAbsorptionAmount();

        // enemies in range (players only, friends ignored)
        List<Player> enemies = new ArrayList<>();
        double er = m.get(1).value;
        for (Player o : mc.level.players()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            if (m.get(7).i() == 1 && Config.isFriend(o)) continue;
            if (p.distanceTo(o) <= er) enemies.add(o);
        }

        // crystals that are already placed near you
        double warnR = m.get(3).value;
        for (EndCrystal c : mc.level.getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(warnR), e -> e.isAlive())) {
            double d = CrystalMath.distance(p.getX(), p.getY(), p.getZ(), c.getX(), c.getY(), c.getZ());
            double self = CrystalMath.rawDamage(d, 1.0, diff);
            crystalLines.add(String.format(Lang.t("cr.near"), d, self) + (self >= hp ? " !!" : ""));
            if (crystalLines.size() >= 3) break;
        }

        // spots: obsidian/bedrock with two free blocks above
        if (!enemies.isEmpty()) {
            int r = m.get(0).i();
            BlockPos base = p.blockPosition();
            BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
            double bestScore = -999; BlockPos best = null; double bestEnemy = 0, bestSelf = 0;
            for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
                q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                BlockState b = mc.level.getBlockState(q);
                if (!b.is(Blocks.OBSIDIAN) && !b.is(Blocks.BEDROCK)) continue;
                if (!mc.level.getBlockState(q.above()).isAir() || !mc.level.getBlockState(q.above(2)).isAir()) continue;
                double cx = q.getX() + 0.5, cy = q.getY() + 1.0, cz = q.getZ() + 0.5;
                double self = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), cx, cy, cz), 1.0, diff);
                double enemy = 0;
                for (Player o : enemies) enemy = Math.max(enemy, CrystalMath.rawDamage(CrystalMath.distance(o.getX(), o.getY(), o.getZ(), cx, cy, cz), 1.0, diff));
                double sc = CrystalMath.score(enemy, self, hp, m.get(2).value);
                if (sc > bestScore) { bestScore = sc; best = q.immutable(); bestEnemy = enemy; bestSelf = self; }
            }
            if (best != null && bestScore > 0) {
                bestSpot = best;
                crystalLines.add(String.format(Lang.t("cr.best"), best.getX(), best.getY(), best.getZ(), bestEnemy, bestSelf));
                crystalLines.add(Lang.t("cr.note"));
            }
        }
    }

    // ------------------------------------------------------------------ Target HUD

    private static LivingEntity target;
    private static long targetSeen;
    private static float shownHealth = -1;
    private static float appear;

    private static void targetHud(Minecraft mc, LocalPlayer p) {
        Module m = Config.TARGETHUD;
        HitResult h = mc.hitResult;
        if (h instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le && le.isAlive() && le != p
            && (m.get(8).i() == 0 || le instanceof Player)) {
            if (le != target) shownHealth = -1;
            target = le; targetSeen = System.currentTimeMillis();
        }
        LivingEntity aura = Combat.auraTarget();
        if (aura != null && aura.isAlive()) { if (aura != target) shownHealth = -1; target = aura; targetSeen = System.currentTimeMillis(); }
        if (target != null && (!target.isAlive() || target.isRemoved() || System.currentTimeMillis() - targetSeen > m.get(7).value * 1000)) target = null;
    }

    private static void renderTarget(GuiGraphics g, Minecraft mc, LocalPlayer p) {
        Module m = Config.TARGETHUD;
        appear = Mth.clamp(appear + (target != null ? 0.15f : -0.15f), 0f, 1f);
        if (appear <= 0f) return;
        LivingEntity t = target;
        if (t == null) return;
        float hp = t.getHealth(), max = Math.max(1f, t.getMaxHealth());
        shownHealth = shownHealth < 0 ? hp : shownHealth + (hp - shownHealth) * 0.15f;
        float scale = m.get(2).f();
        float op = (float) m.get(3).value * appear;
        int w = 130, h = 14 + 10 + (m.get(4).i() == 1 ? 10 : 0) + (m.get(5).i() == 1 ? 10 : 0) + (m.get(6).i() == 1 ? 10 : 0) + 4;
        int sw = g.guiWidth(), sh = g.guiHeight();
        int x = (int) ((sw - w * scale) * m.get(0).value / scale), y = (int) ((sh - h * scale) * m.get(1).value / scale);
        g.pose().pushMatrix();
        g.pose().scale(scale, scale);
        g.fill(x, y, x + w, y + h, Ui.c(Ui.bg(), 0.75f * op));
        g.fill(x, y, x + 2, y + h, Ui.c(Ui.accent(), op));
        int ty = y + 3;
        Ui.text(g, t.getName().getString(), x + 6, ty, Ui.c(0xFFFFFF, op)); ty += 11;
        float frac = Mth.clamp(shownHealth / max, 0f, 1f);
        g.fill(x + 6, ty, x + w - 6, ty + 4, Ui.c(Ui.border(), op));
        g.fill(x + 6, ty, x + 6 + (int) ((w - 12) * frac), ty + 4, Ui.c(frac > 0.5f ? 0x55FF55 : frac > 0.25f ? 0xFFAA00 : 0xFF5555, op));
        ty += 6;
        Ui.text(g, String.format(java.util.Locale.ROOT, "%.1f / %.1f", hp, max), x + 6, ty, Ui.c(0xDDDDDD, op)); ty += 10;
        if (m.get(4).i() == 1) { Ui.text(g, Lang.t("th.armor") + " " + t.getArmorValue(), x + 6, ty, Ui.c(0xBBBBBB, op)); ty += 10; }
        if (m.get(5).i() == 1) { Ui.text(g, String.format(java.util.Locale.ROOT, "%.1f m", (double) p.distanceTo(t)), x + 6, ty, Ui.c(0xBBBBBB, op)); ty += 10; }
        if (m.get(6).i() == 1) {
            ItemStack it = t.getMainHandItem();
            Ui.text(g, it.isEmpty() ? "-" : it.getHoverName().getString(), x + 6, ty, Ui.c(0xBBBBBB, op));
        }
        g.pose().popMatrix();
    }

    // ------------------------------------------------------------------ entry points

    /** Game tick (called from CheatMod.tick, game thread). */
    public static void tick(Minecraft mc, LocalPlayer p) {
        if (Config.CLICKER.enabled) { long t = Perf.start(); autoClicker(mc, p); Perf.end("AutoClicker", t); } else clickAt = 0;
        if (Config.INVHELPER.enabled) { long t = Perf.start(); inventoryHelper(mc, p); Perf.end("InventoryHelper", t); } else { freeSlots = -1; sortPlan.clear(); }
        if (Config.CRYSTAL.enabled) { long t = Perf.start(); crystalHelper(mc, p); Perf.end("CrystalHelper", t); } else { crystalLines.clear(); bestSpot = null; }
        if (Config.TARGETHUD.enabled) targetHud(mc, p); else target = null;
        if (Config.AUTOGAPPLE.enabled) AutoGapple.tick(mc, p); else AutoGapple.stop(mc);
        if (Config.HOLEESP.enabled) HoleEsp.tick(mc, p); else HoleEsp.clear();
        if (Config.HOTBARBINDS.enabled) HotbarBinds.tick(mc, p);
        if (Config.AUTOARMOR.enabled) AutoArmor.tick(mc, p);
        if (Config.AUTOSURROUND.enabled) AutoSurround.tick(mc, p); else AutoSurround.stop();
        Combat.tick(mc, p);
        Pve.tick(mc, p);
        // tasks tick while any module that can start one is on; with all of them off everything is stopped
        if (Config.AUTONAV.enabled || Config.AUTOMINE.enabled || Config.WARDENGUARD.enabled || Config.AUTOWARDEN.enabled) AutoNav.tick(mc, p); else AutoNav.stop(mc);
    }

    public static void stopAll(Minecraft mc) {
        AutoNav.stop(mc);
        sortPlan.clear();
        crystalLines.clear(); bestSpot = null; target = null; clickAt = 0;
    }

    /** HUD overlay (registered once in CheatMod). */
    public static void render(GuiGraphics g, net.minecraft.client.DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (Config.panic || p == null || mc.level == null || mc.options.hideGui || mc.screen instanceof HudEditorScreen) return;
        if (Config.TARGETHUD.enabled || appear > 0f) renderTarget(g, mc, p);

        List<String> lines = new ArrayList<>();
        if (Config.INVHELPER.enabled && Config.INVHELPER.get(1).i() == 1 && freeSlots >= 0) lines.add(String.format(Lang.t("inv.free"), freeSlots));
        if (Config.AUTONAV.enabled && !AutoNav.status().isEmpty()) lines.add("AutoNav: " + AutoNav.status() + (AutoNav.active() ? "  (/glstop)" : ""));
        if (Config.CRYSTAL.enabled && Config.CRYSTAL.get(4).i() == 1) lines.addAll(crystalLines);
        int y = 40;
        for (String s : lines) { g.fill(2, y - 1, 6 + Ui.font().width(s) + 2, y + 10, Ui.c(Ui.bg(), 0.6f)); Ui.text(g, s, 5, y, Ui.c(0xFFFFFF, 1f)); y += 12; }
        Pve.render(g, y);

        if (Config.HOLEESP.enabled) HoleEsp.render(g, mc, p, delta.getGameTimeDeltaPartialTick(false));

        // best crystal spot marker (screen overlay, first person)
        if (Config.CRYSTAL.enabled && Config.CRYSTAL.get(5).i() == 1 && bestSpot != null
            && Project.begin(mc, p, delta.getGameTimeDeltaPartialTick(false), g.guiWidth(), g.guiHeight())) {
            double[] s = Project.point(bestSpot.getX() + 0.5, bestSpot.getY() + 1.0, bestSpot.getZ() + 0.5);
            if (s != null) { int sx = (int) s[0], sy = (int) s[1]; g.fill(sx - 3, sy - 3, sx + 4, sy + 4, Ui.c(Ui.accent(), 0.9f)); }
        }
    }
}
