package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/**
 * Eats a golden apple when health is low: picks the slot, holds the use key until the apple is eaten (or the time limit ends),
 * puts the previous slot back and waits a cool-down. The enchanted apple is used in an emergency, the normal one otherwise.
 * Not an anticheat bypass; it does what a player pressing the keys would do.
 */
public final class AutoGapple {
    private AutoGapple() { }

    private static final GappleLogic LOGIC = new GappleLogic();
    private static int prevSlot = -1;
    private static boolean holding;

    private static int findSlot(LocalPlayer p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(item)) return i;
        return -1;
    }

    private static int pickSlot(LocalPlayer p, double hp, double emergency) {
        int plain = findSlot(p, Items.GOLDEN_APPLE), ench = findSlot(p, Items.ENCHANTED_GOLDEN_APPLE);
        if (hp <= emergency) return ench >= 0 ? ench : plain;
        return plain >= 0 ? plain : ench;
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.AUTOGAPPLE;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isSpectator()) { release(mc, p); return; }
        double hp = p.getHealth(), abs = p.getAbsorptionAmount();
        boolean enemyNear = true;
        if (m.get(5).i() == 1) {
            enemyNear = false;
            for (Player o : mc.level.players()) if (o != p && o.isAlive() && !Config.isFriend(o) && p.distanceTo(o) <= m.get(6).value) { enemyNear = true; break; }
        }
        int slot = pickSlot(p, hp, m.get(1).value);
        GappleLogic.Action a = LOGIC.step(hp, abs, p.isUsingItem(), slot >= 0 || holding, enemyNear,
            m.get(0).value, m.get(2).value, m.get(3).i(), m.get(4).i());
        switch (a) {
            case START -> {
                prevSlot = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                mc.options.keyUse.setDown(true);       // the client releases the item as soon as the key is up
                holding = true;
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
            }
            case STOP -> release(mc, p);
            default -> { if (holding && LOGIC.phase == GappleLogic.Phase.EATING) mc.options.keyUse.setDown(true); }
        }
    }

    /** Lets go of the use key and restores the slot that was selected before eating. Safe to call any time. */
    public static void release(Minecraft mc, LocalPlayer p) {
        if (holding && mc != null && mc.options != null) mc.options.keyUse.setDown(false);
        if (holding && prevSlot >= 0 && p != null) p.getInventory().setSelectedSlot(prevSlot);
        holding = false; prevSlot = -1;
        if (!holding) LOGIC.phase = LOGIC.phase == GappleLogic.Phase.EATING ? GappleLogic.Phase.COOLDOWN : LOGIC.phase;
    }

    public static void stop(Minecraft mc) { release(mc, mc == null ? null : mc.player); LOGIC.reset(); }
}
