package com.ghostline.mod;

/** Collects many "please save" requests into one write: the first request starts a delay, later ones ride along. */
public final class Debounce {
    private final long delayMs;
    private boolean dirty;
    private long dueAt;

    public Debounce(long delayMs) { this.delayMs = delayMs; }

    public synchronized void mark(long now) {
        if (!dirty) { dirty = true; dueAt = now + delayMs; }
    }

    /** True exactly once when changes are pending and the delay has passed. */
    public synchronized boolean take(long now) {
        if (dirty && now >= dueAt) { dirty = false; return true; }
        return false;
    }

    /** True once if anything is pending, regardless of the delay (game closing). */
    public synchronized boolean takeNow() {
        boolean d = dirty;
        dirty = false;
        return d;
    }

    public synchronized boolean pending() { return dirty; }
}
