package com.ghostline.mod.mixin;

import com.ghostline.mod.SkyFog;
import net.minecraft.world.attribute.EnvironmentAttribute;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Level-side attribute reads: getDimensionValue(attribute) (not positional). Optional mixin (require = 0). */
@Mixin(targets = "net.minecraft.world.attribute.EnvironmentAttributeSystem")
public class EnvironmentAttributeSystemMixin {
    @Inject(method = "getDimensionValue", at = @At("RETURN"), cancellable = true, require = 0)
    private void ghostline$dimension(EnvironmentAttribute<?> attribute, CallbackInfoReturnable<Object> cir) {
        Object v = SkyFog.override(attribute);
        if (v != null) cir.setReturnValue(v);
    }
}
