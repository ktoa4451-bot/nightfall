package com.ghostline.mod.automation;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Text lines for the Automation Dashboard (HUD and /gltasks). Pure formatting, no Minecraft types. */
public final class TaskReport {
    private TaskReport() { }

    public static String duration(long ms) {
        long s = Math.max(0, ms) / 1000;
        return s >= 60 ? String.format(Locale.ROOT, "%dm%02ds", s / 60, s % 60) : s + "s";
    }

    public static String line(AutomationTask t, long now) {
        StringBuilder sb = new StringBuilder(t.name).append(" [").append(t.state()).append(']');
        if (t.state() == TaskState.RUNNING || t.state() == TaskState.PAUSED) {
            sb.append(' ').append(duration(t.runningMs(now)));
            if (!t.stage().isEmpty()) sb.append("  ").append(t.stage());
        } else if (t.state().isFinished()) {
            String why = t.result() != null ? t.result().message() : t.stopReason();
            if (why != null && !why.isEmpty()) sb.append("  ").append(why);
        }
        return sb.toString();
    }

    /** Running tasks first, then queued ones, then the last {@code history} finished tasks (newest first). */
    public static List<String> lines(TaskManager tm, long now, int history) {
        List<String> out = new ArrayList<>();
        for (AutomationTask t : tm.running()) out.add(line(t, now));
        for (AutomationTask t : tm.queued()) out.add(line(t, now));
        List<AutomationTask> done = tm.finished();
        for (int i = done.size() - 1, k = 0; i >= 0 && k < history; i--, k++) out.add(line(done.get(i), now));
        return out;
    }
}
