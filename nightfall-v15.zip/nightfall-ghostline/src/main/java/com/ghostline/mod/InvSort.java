package com.ghostline.mod;

import java.util.ArrayList;
import java.util.List;

/** Pure sorting plan for Inventory Helper: which slots to swap so items end up grouped by item id. No Minecraft types. */
public final class InvSort {
    private InvSort() { }

    /** Empty slots use this key and therefore end up last. */
    public static final String EMPTY = "\uFFFF";

    /**
     * keys[i] is the sort key of slot i ("" or null = empty). Returns swaps {a, b} (a &lt; b) to apply in order.
     * Selection sort: at most n-1 swaps. Slots with equal keys are never swapped with each other, so partial stacks
     * of the same item are never merged or split by the plan.
     */
    public static List<int[]> plan(String[] keys) {
        int n = keys.length;
        String[] k = new String[n];
        for (int i = 0; i < n; i++) k[i] = keys[i] == null || keys[i].isEmpty() ? EMPTY : keys[i];
        List<int[]> out = new ArrayList<>();
        for (int i = 0; i < n - 1; i++) {
            int best = i;
            for (int j = i + 1; j < n; j++) if (k[j].compareTo(k[best]) < 0) best = j;
            if (best != i && !k[best].equals(k[i])) {
                String t = k[i]; k[i] = k[best]; k[best] = t;
                out.add(new int[]{i, best});
            }
        }
        return out;
    }

    public static boolean isSorted(String[] keys) { return plan(keys).isEmpty(); }
}
