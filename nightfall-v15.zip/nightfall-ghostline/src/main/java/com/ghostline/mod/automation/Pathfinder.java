package com.ghostline.mod.automation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * A* over standing positions on the surface. A position (x,y,z) is standable when the block below is SOLID,
 * and the two blocks of the body (y, y+1) are AIR (or WATER when allowed). Moves: 4 directions, step up by
 * up to maxStep blocks (jump), drop down by up to maxFall blocks. Diagonals are not used (no corner cutting).
 * Unknown blocks are never walked through. The search stops after maxNodes expansions or maxMillis.
 * Block queries are cached for the duration of one search.
 */
public final class Pathfinder {
    public static final class Options {
        public int maxNodes = 20000;
        public long maxMillis = 40;
        public int maxStep = 1;      // blocks climbed in one move (vanilla jump = 1)
        public int maxFall = 3;      // blocks dropped in one move
        public boolean allowWater = false;
        public double waterCost = 4.0;
        public boolean allowBreak = false;    // dig through BREAKABLE blocks (tunnelling)
        public double breakCost = 6.0;        // extra cost per dug block: walking around is preferred
        public boolean allowClimb = true;     // ladders, vines, scaffolding
        public boolean acceptPartial = false; // when no full route exists, return the closest reachable node
    }

    private record Node(int x, int y, int z, double g, double f, Node parent) { }

    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    private final WorldView world;
    private final Options opt;
    private final Map<Long, WorldView.Kind> cache = new HashMap<>();

    public Pathfinder(WorldView world, Options opt) { this.world = world; this.opt = opt == null ? new Options() : opt; }

    private static long key(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38) | ((long) (z & 0x3FFFFFF) << 12) | (y & 0xFFF);
    }

    private WorldView.Kind kind(int x, int y, int z) {
        return cache.computeIfAbsent(key(x, y, z), k -> {
            try { WorldView.Kind v = world.kind(x, y, z); return v == null ? WorldView.Kind.UNKNOWN : v; }
            catch (RuntimeException e) { return WorldView.Kind.UNKNOWN; }
        });
    }

    private boolean bodyFree(int x, int y, int z) {
        WorldView.Kind a = kind(x, y, z), b = kind(x, y + 1, z);
        boolean aOk = a == WorldView.Kind.AIR || a == WorldView.Kind.CLIMB || (opt.allowWater && a == WorldView.Kind.WATER) || (opt.allowBreak && a == WorldView.Kind.BREAKABLE);
        boolean bOk = b == WorldView.Kind.AIR || b == WorldView.Kind.CLIMB || (opt.allowWater && b == WorldView.Kind.WATER) || (opt.allowBreak && b == WorldView.Kind.BREAKABLE);
        return aOk && bOk;
    }

    /** True when a player can stand with feet in block (x,y,z). */
    public boolean standable(int x, int y, int z) {
        if (!bodyFree(x, y, z)) return false;
        if (opt.allowClimb && kind(x, y, z) == WorldView.Kind.CLIMB) return true; // hanging on a ladder
        WorldView.Kind below = kind(x, y - 1, z);
        if (below == WorldView.Kind.SOLID || below == WorldView.Kind.BREAKABLE) return true;
        return opt.allowWater && below == WorldView.Kind.WATER && kind(x, y, z) == WorldView.Kind.WATER; // swimming
    }

    private double stepCost(int x, int y, int z) {
        double c = kind(x, y, z) == WorldView.Kind.WATER ? opt.waterCost : 1.0;
        if (opt.allowBreak) {
            if (kind(x, y, z) == WorldView.Kind.BREAKABLE) c += opt.breakCost;
            if (kind(x, y + 1, z) == WorldView.Kind.BREAKABLE) c += opt.breakCost;
        }
        return c;
    }

    /** Like bodyFree but nothing has to be dug: used for falling, where a block in the way would stop the fall. */
    private boolean bodyOpen(int x, int y, int z) {
        WorldView.Kind a = kind(x, y, z), b = kind(x, y + 1, z);
        boolean aOk = a == WorldView.Kind.AIR || a == WorldView.Kind.CLIMB || (opt.allowWater && a == WorldView.Kind.WATER);
        boolean bOk = b == WorldView.Kind.AIR || b == WorldView.Kind.CLIMB || (opt.allowWater && b == WorldView.Kind.WATER);
        return aOk && bOk;
    }

    public Path find(int sx, int sy, int sz, int gx, int gy, int gz) {
        long t0 = System.nanoTime();
        cache.clear();
        if (!standable(sx, sy, sz)) return Path.none(Path.Status.INVALID, 0, "start is not a safe standing position");
        if (!standable(gx, gy, gz)) return Path.none(Path.Status.INVALID, 0, "goal is not a safe standing position (unknown, blocked or dangerous)");
        if (sx == gx && sy == gy && sz == gz) return new Path(Path.Status.FOUND, List.of(new int[]{sx, sy, sz}), 0, "already there");

        PriorityQueue<Node> open = new PriorityQueue<>((a, b) -> Double.compare(a.f, b.f));
        Map<Long, Double> best = new HashMap<>();
        Node start = new Node(sx, sy, sz, 0, h(sx, sy, sz, gx, gy, gz), null);
        open.add(start);
        best.put(key(sx, sy, sz), 0.0);
        Node closest = start; double closestH = start.f;
        int expanded = 0;

        while (!open.isEmpty()) {
            if (expanded >= opt.maxNodes) return partialOrNone(closest, expanded, Path.Status.BUDGET, "node budget exceeded");
            if (expanded > 0 && (expanded & 63) == 0 && (System.nanoTime() - t0) / 1_000_000L > opt.maxMillis)
                return partialOrNone(closest, expanded, Path.Status.BUDGET, "time budget exceeded");
            Node cur = open.poll();
            Double known = best.get(key(cur.x, cur.y, cur.z));
            if (known != null && cur.g > known + 1e-9) continue; // stale entry
            expanded++;
            if (cur.x == gx && cur.y == gy && cur.z == gz) return new Path(Path.Status.FOUND, build(cur), expanded, "ok");
            double hh = h(cur.x, cur.y, cur.z, gx, gy, gz);
            if (hh < closestH) { closestH = hh; closest = cur; }

            List<int[]> nbr = new ArrayList<>(6);
            for (int[] d : DIRS) {
                int nx = cur.x + d[0], nz = cur.z + d[1];
                // try the level first, then climbing, then dropping
                int ny = Integer.MIN_VALUE;
                if (standable(nx, cur.y, nz)) ny = cur.y;
                else {
                    for (int up = 1; up <= opt.maxStep && ny == Integer.MIN_VALUE; up++) {
                        // headroom above the current block is needed to jump
                        if (bodyClearAbove(cur.x, cur.y, cur.z, up) && standable(nx, cur.y + up, nz)) ny = cur.y + up;
                    }
                    for (int down = 1; down <= opt.maxFall && ny == Integer.MIN_VALUE; down++) {
                        // the column we fall through must be free
                        if (!bodyOpen(nx, cur.y, nz)) break;
                        if (standable(nx, cur.y - down, nz)) ny = cur.y - down;
                        else if (!fallThrough(nx, cur.y - down, nz)) break;
                    }
                }
                if (ny != Integer.MIN_VALUE) nbr.add(new int[]{nx, ny, nz});
            }
            if (opt.allowClimb && kind(cur.x, cur.y, cur.z) == WorldView.Kind.CLIMB) {
                if (kind(cur.x, cur.y + 1, cur.z) == WorldView.Kind.CLIMB && bodyFree(cur.x, cur.y + 1, cur.z)) nbr.add(new int[]{cur.x, cur.y + 1, cur.z});
                if (kind(cur.x, cur.y - 1, cur.z) == WorldView.Kind.CLIMB && bodyFree(cur.x, cur.y - 1, cur.z)) nbr.add(new int[]{cur.x, cur.y - 1, cur.z});
            }
            for (int[] nb : nbr) {
                int nx = nb[0], ny = nb[1], nz = nb[2];
                double ladder = (kind(nx, ny, nz) == WorldView.Kind.CLIMB && nx == cur.x && nz == cur.z) ? 0.5 : 0;
                double g = cur.g + stepCost(nx, ny, nz) + Math.abs(ny - cur.y) * 0.5 + ladder;
                Long nk = key(nx, ny, nz);
                Double old = best.get(nk);
                if (old != null && old <= g) continue;
                best.put(nk, g);
                open.add(new Node(nx, ny, nz, g, g + h(nx, ny, nz, gx, gy, gz), cur));
            }
        }
        return partialOrNone(closest, expanded, Path.Status.NO_PATH, "no safe route");
    }

    private boolean bodyClearAbove(int x, int y, int z, int up) {
        for (int i = 0; i < up; i++) if (kind(x, y + 2 + i, z) != WorldView.Kind.AIR) return false;
        return true;
    }

    private boolean fallThrough(int x, int y, int z) { return bodyOpen(x, y, z) && kind(x, y - 1, z) == WorldView.Kind.AIR; }

    private static double h(int x, int y, int z, int gx, int gy, int gz) {
        return Math.abs(x - gx) + Math.abs(z - gz) + Math.abs(y - gy) * 0.5;
    }

    private Path partialOrNone(Node closest, int expanded, Path.Status why, String reason) {
        if (!opt.acceptPartial) return Path.none(why, expanded, reason);
        List<int[]> out = build(closest);
        if (out.size() < 2) return Path.none(why, expanded, reason);
        return new Path(Path.Status.PARTIAL, out, expanded, reason + " (partial route to the closest reachable point)");
    }

    private static List<int[]> build(Node node) {
        List<int[]> out = new ArrayList<>();
        for (Node n = node; n != null; n = n.parent) out.add(new int[]{n.x, n.y, n.z});
        Collections.reverse(out);
        return out;
    }
}
