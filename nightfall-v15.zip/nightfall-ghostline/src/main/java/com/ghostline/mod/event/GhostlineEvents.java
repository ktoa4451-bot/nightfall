package com.ghostline.mod.event;

/** Central buses. CLIENT_TICK is posted once per client tick from CheatMod (game thread). */
public final class GhostlineEvents {
    private GhostlineEvents() { }
    public static final EventBus<ClientTickEvent> CLIENT_TICK = new EventBus<>();
}
