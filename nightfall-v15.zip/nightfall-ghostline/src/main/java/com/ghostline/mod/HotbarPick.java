package com.ghostline.mod;

import java.util.Locale;
import java.util.Map;

/** Pure item matching for HotbarBinds: short names like "sword", "gapple", "pearl" -> item registry paths. */
public final class HotbarPick {
    private HotbarPick() { }

    private static final Map<String, String[]> ALIASES = Map.ofEntries(
        Map.entry("gapple", new String[]{"golden_apple", "enchanted_golden_apple"}),
        Map.entry("pearl", new String[]{"ender_pearl"}),
        Map.entry("crystal", new String[]{"end_crystal"}),
        Map.entry("rocket", new String[]{"firework_rocket"}),
        Map.entry("totem", new String[]{"totem_of_undying"}),
        Map.entry("obsidian", new String[]{"obsidian"}),
        Map.entry("web", new String[]{"cobweb"}),
        Map.entry("pot", new String[]{"splash_potion", "lingering_potion", "potion"}),
        Map.entry("xp", new String[]{"experience_bottle"}),
        Map.entry("shield", new String[]{"shield"}),
        Map.entry("bow", new String[]{"bow", "crossbow"}));

    /** True when the item path fits the query: an alias, a suffix like "sword" ("_sword") or an exact registry path. */
    public static boolean matches(String path, String query) {
        if (path == null || query == null) return false;
        String q = query.trim().toLowerCase(Locale.ROOT).replace("minecraft:", "");
        if (q.isEmpty()) return false;
        String[] al = ALIASES.get(q);
        if (al != null) { for (String x : al) if (path.equals(x)) return true; return false; }
        return path.equals(q) || path.endsWith("_" + q);
    }

    /** First hotbar slot (0..8) holding a matching item, searching from just after {@code from} so that repeated presses cycle. -1 if none. */
    public static int find(String[] hotbarPaths, String query, int from) {
        int n = hotbarPaths.length;
        for (int k = 1; k <= n; k++) {
            int i = ((from < 0 ? -1 : from) + k) % n;
            if (matches(hotbarPaths[i], query)) return i;
        }
        return -1;
    }
}
