package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * KillAura and AutoCrystal. Both stay inside vanilla limits on purpose: attack reach 3 by default, the attack cooldown is
 * respected, the target must be visible, turning is smooth and every action has a delay. This is NOT an anticheat bypass:
 * servers with an anticheat can still flag or ban it. Friends (NoFriendDamage) are never targeted.
 */
public final class Combat {
    private Combat() { }

    private static int auraTick, crystalTick;
    private static LivingEntity auraTarget;

    // ================================================================== KillAura

    private static boolean visible(Minecraft mc, LocalPlayer p, Vec3 point) {
        return mc.level.clip(new ClipContext(p.getEyePosition(), point, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.MISS;
    }

    private static void killAura(Minecraft mc, LocalPlayer p) {
        Module m = Config.KILLAURA;
        auraTarget = null;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isUsingItem() || p.isSpectator()) return;
        double range = m.get(0).value;
        Vec3 eye = p.getEyePosition();
        List<LivingEntity> ents = new ArrayList<>();
        List<AuraTargets.Cand> cands = new ArrayList<>();
        for (LivingEntity e : mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range + 2), x -> CheatMod.basicTarget(x, p, m.get(3).i() == 1, m.get(4).i() == 1))) {
            Vec3 aim = e.getBoundingBox().getCenter();
            double dist = Math.sqrt(e.getBoundingBox().distanceToSqr(eye));
            float yaw = (float) (Math.toDegrees(Math.atan2(aim.z - eye.z, aim.x - eye.x)) - 90.0);
            double ang = Math.abs(Mth.wrapDegrees(yaw - p.getYRot()));
            ents.add(e);
            cands.add(new AuraTargets.Cand(ents.size() - 1, dist, e.getHealth(), ang, visible(mc, p, aim)));
        }
        int i = AuraTargets.pick(cands, range, m.get(1).value, m.get(2).i(), m.get(6).i() == 1);
        if (i < 0) return;
        LivingEntity t = ents.get(i);
        auraTarget = t;
        // turn smoothly toward the target
        Vec3 aim = t.getBoundingBox().getCenter();
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = Mth.clamp((float) (-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)))), -90f, 90f);
        float step = (float) m.get(7).value;
        p.setYRot(p.getYRot() + Mth.clamp(Mth.wrapDegrees(yaw - p.getYRot()), -step, step));
        p.setXRot(p.getXRot() + Mth.clamp(pitch - p.getXRot(), -step, step));
        // hit only when the cooldown is ready and (by default) the crosshair really is on the target
        if (p.getAttackStrengthScale(0.5f) < (m.get(5).i() == 1 ? 0.92f : 0.0f)) return;
        if (m.get(8).i() == 1 && !(mc.hitResult instanceof EntityHitResult eh && eh.getEntity() == t)) return;
        mc.gameMode.attack(p, t);
        p.swing(InteractionHand.MAIN_HAND);
    }

    // ================================================================== AutoCrystal

    private static void autoCrystal(Minecraft mc, LocalPlayer p) {
        Module m = Config.AUTOCRYSTAL;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isUsingItem()) return;
        if (++crystalTick % Math.max(1, m.get(0).i()) != 0) return;
        int diff = mc.level.getDifficulty().getId();
        double hp = p.getHealth() + p.getAbsorptionAmount();
        double reach = m.get(1).value, minEnemy = m.get(2).value, maxSelf = m.get(3).value, margin = m.get(4).value;

        List<Player> enemies = new ArrayList<>();
        for (Player o : mc.level.players())
            if (o != p && o.isAlive() && !o.isSpectator() && !Config.isFriend(o) && p.distanceTo(o) <= 12.0) enemies.add(o);
        if (enemies.isEmpty()) return;

        // 1) break a crystal that hurts an enemy and is safe for you
        for (EndCrystal c : mc.level.getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(reach), Entity::isAlive)) {
            if (p.getEyePosition().distanceTo(c.getBoundingBox().getCenter()) > reach || !visible(mc, p, c.getBoundingBox().getCenter())) continue;
            double self = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), c.getX(), c.getY(), c.getZ()), 1.0, diff);
            double enemy = 0;
            for (Player o : enemies) enemy = Math.max(enemy, CrystalMath.rawDamage(CrystalMath.distance(o.getX(), o.getY(), o.getZ(), c.getX(), c.getY(), c.getZ()), 1.0, diff));
            if (AuraTargets.crystalWorth(enemy, self, hp, minEnemy, maxSelf, margin)) {
                mc.gameMode.attack(p, c);
                p.swing(InteractionHand.MAIN_HAND);
                return; // one action per step
            }
        }

        // 2) place a crystal on the best obsidian/bedrock spot (needs crystals in the main hand)
        if (m.get(5).i() == 1) selectCrystalSlot(p);
        if (!p.getMainHandItem().is(Items.END_CRYSTAL)) return;
        int r = (int) Math.ceil(reach);
        BlockPos base = p.blockPosition(), best = null;
        double bestScore = -999;
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
            BlockState b = mc.level.getBlockState(q);
            if (!b.is(Blocks.OBSIDIAN) && !b.is(Blocks.BEDROCK)) continue;
            if (!mc.level.getBlockState(q.above()).isAir() || !mc.level.getBlockState(q.above(2)).isAir()) continue;
            Vec3 top = new Vec3(q.getX() + 0.5, q.getY() + 1.0, q.getZ() + 0.5);
            if (p.getEyePosition().distanceTo(top) > reach) continue;
            if (!mc.level.getEntitiesOfClass(Entity.class, new AABB(q.getX(), q.getY() + 1, q.getZ(), q.getX() + 1, q.getY() + 3, q.getZ() + 1), e -> true).isEmpty()) continue;
            double self = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), top.x, top.y, top.z), 1.0, diff);
            double enemy = 0;
            for (Player o : enemies) enemy = Math.max(enemy, CrystalMath.rawDamage(CrystalMath.distance(o.getX(), o.getY(), o.getZ(), top.x, top.y, top.z), 1.0, diff));
            if (!AuraTargets.crystalWorth(enemy, self, hp, minEnemy, maxSelf, margin)) continue;
            double sc = CrystalMath.score(enemy, self, hp, 1.5);
            if (sc > bestScore) { bestScore = sc; best = q.immutable(); }
        }
        if (best == null) return;
        Vec3 face = new Vec3(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(face, Direction.UP, best, false));
        p.swing(InteractionHand.MAIN_HAND);
    }

    private static void selectCrystalSlot(LocalPlayer p) {
        if (p.getMainHandItem().is(Items.END_CRYSTAL)) return;
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(Items.END_CRYSTAL)) { p.getInventory().setSelectedSlot(i); return; }
    }


    // ================================================================== ElytraTarget

    private static ElytraOrbit.State etState = ElytraOrbit.State.ORBIT;
    private static int etTicks, etSince = 999, etUsed, etRestore = -1, etDeployTick;
    private static boolean etJumpHeld, etHit, etNoRockets, etLowHp;

    private static void etReset() { etState = ElytraOrbit.State.ORBIT; etTicks = 0; etSince = 999; etUsed = 0; etHit = false; etNoRockets = false; etLowHp = false; }

    private static boolean nearGround(Minecraft mc, LocalPlayer p) {
        Vec3 a = p.position(), b = a.add(0, -7, 0);
        return mc.level.clip(new ClipContext(a, b, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p)).getType() == HitResult.Type.BLOCK;
    }

    /** Flies in circles around the nearest player, dives in for a hit when the attack is ready and uses fireworks to keep speed. */
    private static void elytraTarget(Minecraft mc, LocalPlayer p) {
        Module m = Config.ELYTRATARGET;
        if (etJumpHeld) { mc.options.keyJump.setDown(false); etJumpHeld = false; }
        if (etRestore >= 0) { p.getInventory().setSelectedSlot(etRestore); etRestore = -1; }
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isSpectator()) return;
        if (p.getHealth() < m.get(7).value) { if (!etLowHp) { etLowHp = true; Toasts.warn("ElytraTarget", Lang.t("et.lowhp")); } return; }
        etLowHp = false;

        Player target = null; double bd = m.get(0).value;
        for (Player o : mc.level.players()) {
            if (o == p || !o.isAlive() || o.isSpectator() || Config.isFriend(o)) continue;
            double d = p.distanceTo(o);
            if (d < bd) { bd = d; target = o; }
        }
        if (target == null) { etReset(); return; }

        if (!p.isFallFlying()) {
            // start gliding: one jump press in the air while falling, only when an elytra is worn
            if (m.get(8).i() == 1 && p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA) && !p.onGround() && !p.isInWater()
                && p.getDeltaMovement().y < -0.1 && ++etDeployTick % 10 == 0) { mc.options.keyJump.setDown(true); etJumpHeld = true; }
            return;
        }

        Vec3 eye = p.getEyePosition();
        double dist = Math.sqrt(target.getBoundingBox().distanceToSqr(eye));
        boolean ready = p.getAttackStrengthScale(0.5f) >= 0.92f;
        ElytraOrbit.State ns = ElytraOrbit.next(etState, etTicks, dist, ready, etHit, m.get(4).i(), m.get(1).value * 3.0);
        if (ns != etState) { etState = ns; etTicks = 0; etHit = false; } else etTicks++;
        etSince++;

        double[] v = ElytraOrbit.desired(p.getX(), p.getY(), p.getZ(), target.getX(), target.getY(), target.getZ(),
            m.get(1).value, m.get(2).value, m.get(3).i() == 0, etState);
        if (nearGround(mc, p) && p.getDeltaMovement().y < 0 && etState == ElytraOrbit.State.ORBIT) { // never dive into the floor while circling
            v[1] = Math.max(v[1], 0.35);
            double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); v[0] /= l; v[1] /= l; v[2] /= l;
        }
        // wall ahead? look along the wanted direction and steer away from the surface that is hit
        double look = 12.0;
        Vec3 from = p.position().add(0, p.getBbHeight() * 0.5, 0);
        BlockHitResult wall = mc.level.clip(new ClipContext(from, from.add(v[0] * look, v[1] * look, v[2] * look), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (wall.getType() == HitResult.Type.BLOCK && etState == ElytraOrbit.State.ORBIT) {
            double closeness = 1.0 - from.distanceTo(wall.getLocation()) / look;
            Direction fd = wall.getDirection();
            v = ElytraOrbit.avoid(v, new double[]{fd.getStepX(), fd.getStepY(), fd.getStepZ()}, closeness);
        }
        float step = (float) m.get(10).value;
        p.setYRot(p.getYRot() + Mth.clamp(Mth.wrapDegrees((float) ElytraOrbit.yawDeg(v) - p.getYRot()), -step, step));
        p.setXRot(p.getXRot() + Mth.clamp((float) ElytraOrbit.pitchDeg(v) - p.getXRot(), -step, step));

        if (dist <= m.get(11).value && ready && visible(mc, p, target.getBoundingBox().getCenter())) {
            mc.gameMode.attack(p, target);
            p.swing(InteractionHand.MAIN_HAND);
            etHit = true;
        }

        double speed = p.getDeltaMovement().length();
        if (ElytraOrbit.needRocket(speed, m.get(5).value, etSince, m.get(6).i(), etUsed, m.get(9).i())) {
            if (useRocket(mc, p)) { etSince = 0; etUsed++; }
            else if (!etNoRockets) { etNoRockets = true; Toasts.warn("ElytraTarget", Lang.t("et.norockets")); }
        }
    }

    /** Uses a firework rocket: off hand first, otherwise a hotbar slot (the previous slot is restored on the next tick). */
    private static boolean useRocket(Minecraft mc, LocalPlayer p) {
        if (p.getOffhandItem().is(Items.FIREWORK_ROCKET)) { mc.gameMode.useItem(p, InteractionHand.OFF_HAND); return true; }
        if (p.getMainHandItem().is(Items.FIREWORK_ROCKET)) { mc.gameMode.useItem(p, InteractionHand.MAIN_HAND); return true; }
        for (int i = 0; i < 9; i++) {
            if (p.getInventory().getItem(i).is(Items.FIREWORK_ROCKET)) {
                etRestore = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(i);
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                return true;
            }
        }
        return false;
    }

    public static void stopElytra(Minecraft mc) {
        etReset();
        if (etJumpHeld && mc != null && mc.options != null) { mc.options.keyJump.setDown(false); etJumpHeld = false; }
    }

    // ================================================================== entry

    public static void tick(Minecraft mc, LocalPlayer p) {
        if (Config.KILLAURA.enabled && ++auraTick % Math.max(1, Config.KILLAURA.get(9).i()) == 0) { long t = Perf.start(); killAura(mc, p); Perf.end("KillAura", t); }
        else if (!Config.KILLAURA.enabled) auraTarget = null;
        if (Config.AUTOCRYSTAL.enabled) { long t = Perf.start(); autoCrystal(mc, p); Perf.end("AutoCrystal", t); }
        if (Config.ELYTRATARGET.enabled) { long t = Perf.start(); elytraTarget(mc, p); Perf.end("ElytraTarget", t); } else stopElytra(mc);
    }

    public static LivingEntity auraTarget() { return auraTarget; }
}
