package com.ghostline.mod.event;

import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/** Minimal event bus: a failing listener never stops the others (and never crashes the game). */
public final class EventBus<T> {
    private final CopyOnWriteArrayList<Consumer<T>> listeners = new CopyOnWriteArrayList<>();

    /** Adds a listener once; the same instance is never registered twice. */
    public void subscribe(Consumer<T> l) { if (l != null) listeners.addIfAbsent(l); }
    public void unsubscribe(Consumer<T> l) { listeners.remove(l); }
    public int listenerCount() { return listeners.size(); }
    public void clear() { listeners.clear(); }

    public void post(T event) {
        for (Consumer<T> l : listeners) {
            try { l.accept(event); }
            catch (RuntimeException e) { System.err.println("[Ghostline] event listener failed: " + e); }
        }
    }
}
