package com.ghostline.mod.automation;

/** Event sent by the TaskManager to listeners (notifications, HUD, other modules). */
public record AutomationEvent(Type type, AutomationTask task, String message) {
    public enum Type { STARTED, PAUSED, RESUMED, COMPLETED, FAILED, CANCELLED, STAGE }
}
