package com.ghostline.mod.automation;

/**
 * Decides when a walking task should pause because of danger (hostile mob close) and when it may resume.
 * Pausing is immediate; resuming needs {@code calmMs} without danger so the task does not flicker.
 * A task that stays paused longer than {@code giveUpMs} should be failed by the caller (returns GIVE_UP once).
 */
public final class PauseGate {
    public enum Action { NONE, PAUSE, RESUME, GIVE_UP }

    private final long calmMs, giveUpMs;
    private boolean paused;
    private long pausedAt, lastDanger;

    public PauseGate(long calmMs, long giveUpMs) { this.calmMs = Math.max(0, calmMs); this.giveUpMs = Math.max(0, giveUpMs); }

    public boolean paused() { return paused; }
    public void reset() { paused = false; pausedAt = 0; lastDanger = 0; }

    public Action update(boolean danger, long now) {
        if (danger) lastDanger = now;
        if (!paused) {
            if (danger) { paused = true; pausedAt = now; return Action.PAUSE; }
            return Action.NONE;
        }
        if (giveUpMs > 0 && now - pausedAt >= giveUpMs) { paused = false; return Action.GIVE_UP; }
        if (!danger && now - lastDanger >= calmMs) { paused = false; return Action.RESUME; }
        return Action.NONE;
    }
}
