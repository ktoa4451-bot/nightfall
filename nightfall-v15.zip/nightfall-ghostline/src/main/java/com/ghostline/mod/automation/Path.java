package com.ghostline.mod.automation;

import java.util.List;

/** Result of a path search. nodes are the standing positions (feet block) from start to goal. */
public record Path(Status status, List<int[]> nodes, int expanded, String reason) {
    public enum Status { FOUND, PARTIAL, NO_PATH, BUDGET, INVALID }
    public boolean found() { return status == Status.FOUND; }
    public int length() { return nodes.size(); }
    public static Path none(Status s, int expanded, String why) { return new Path(s, List.of(), expanded, why); }
}
