package com.ghostline.mod.automation;

/** Outcome of an operation: a success flag plus a human readable reason (shown in HUD / toasts). */
public record AutomationResult(boolean ok, String message) {
    public static AutomationResult success(String msg) { return new AutomationResult(true, msg == null ? "" : msg); }
    public static AutomationResult failure(String msg) { return new AutomationResult(false, msg == null ? "unknown error" : msg); }
}
