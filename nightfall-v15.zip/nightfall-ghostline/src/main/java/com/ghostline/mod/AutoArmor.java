package com.ghostline.mod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;

/**
 * Puts on the best armor from the inventory: fills empty armor slots and replaces clearly worse pieces. One swap per step,
 * never while a screen is open or the cursor holds an item. Inventory-menu slots: head 5, chest 6, legs 7, feet 8.
 */
public final class AutoArmor {
    private AutoArmor() { }

    private static int tick;
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private static String path(ItemStack s) { return s.isEmpty() ? null : BuiltInRegistries.ITEM.getKey(s.getItem()).getPath(); }

    private static double score(ItemStack s) {
        String pa = path(s);
        return pa == null ? -1.0 : ArmorLogic.score(pa, s.isDamageableItem() ? s.getDamageValue() : 0, s.isDamageableItem() ? s.getMaxDamage() : 0);
    }

    public static void tick(Minecraft mc, LocalPlayer p) {
        Module m = Config.AUTOARMOR;
        if (++tick % Math.max(1, m.get(0).i()) != 0) return;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isSpectator() || !p.containerMenu.getCarried().isEmpty()) return;
        boolean keepElytra = m.get(1).i() == 1;
        double margin = m.get(2).value;
        for (int a = 0; a < 4; a++) {
            ItemStack worn = p.getItemBySlot(SLOTS[a]);
            if (a == ArmorLogic.CHEST && keepElytra && "elytra".equals(path(worn))) continue; // do not take the elytra off
            double cur = score(worn);
            int bestInv = -1; double best = cur;
            for (int i = 9; i < 45; i++) { // menu slots: 9..35 main inventory, 36..44 hotbar
                ItemStack c = p.inventoryMenu.getSlot(i).getItem();
                if (c.isEmpty() || ArmorLogic.slotOf(path(c), false) != a) continue;
                double sc = score(c);
                if (sc > best && ArmorLogic.better(sc, cur, worn.isEmpty() ? -1.0 : margin)) { best = sc; bestInv = i; }
            }
            if (bestInv < 0) continue;
            int id = p.inventoryMenu.containerId, armorSlot = 5 + a;
            mc.gameMode.handleInventoryMouseClick(id, bestInv, 0, ClickType.PICKUP, p);   // take the new piece
            mc.gameMode.handleInventoryMouseClick(id, armorSlot, 0, ClickType.PICKUP, p); // swap with the worn one
            if (!p.containerMenu.getCarried().isEmpty()) mc.gameMode.handleInventoryMouseClick(id, bestInv, 0, ClickType.PICKUP, p); // old piece goes where the new one was
            return; // one swap per step
        }
    }
}
