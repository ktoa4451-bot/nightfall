package com.ghostline.mod;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/** Pure planning for AutoSurround: which cells around the feet still need a block and which of them can be placed now. */
public final class SurroundLogic {
    private SurroundLogic() { }

    private static final int[][] SIDES = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    /** Cells next to the player's feet (same y) that are not solid yet. */
    public static List<int[]> missing(int px, int py, int pz, Predicate<int[]> solid) {
        List<int[]> out = new ArrayList<>();
        for (int[] s : SIDES) {
            int[] c = {px + s[0], py, pz + s[1]};
            if (!solid.test(c)) out.add(c);
        }
        return out;
    }

    /** A cell can be filled from above when the block under it is solid (we click its top face). */
    public static boolean canPlace(int[] cell, Predicate<int[]> solid) { return solid.test(new int[]{cell[0], cell[1] - 1, cell[2]}); }

    /** Up to {@code max} cells to place this step, placeable ones only. Order is stable (east, west, south, north). */
    public static List<int[]> plan(int px, int py, int pz, Predicate<int[]> solid, int max) {
        List<int[]> out = new ArrayList<>();
        for (int[] c : missing(px, py, pz, solid)) {
            if (out.size() >= Math.max(1, max)) break;
            if (canPlace(c, solid)) out.add(c);
        }
        return out;
    }

    /** True when all four sides are solid. */
    public static boolean complete(int px, int py, int pz, Predicate<int[]> solid) { return missing(px, py, pz, solid).isEmpty(); }
}
