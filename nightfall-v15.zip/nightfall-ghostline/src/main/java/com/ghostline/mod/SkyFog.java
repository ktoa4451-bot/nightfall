package com.ghostline.mod;

import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributes;

/**
 * Custom sky, fog and cloud values for Minecraft 1.21.11, where sky/fog/cloud colours and fog distances come from the
 * "environment attribute" system. The two mixins in ghostline.sky.mixins.json call {@link #override} for every attribute read;
 * a returned value replaces the original, null keeps it. If a target of those mixins does not exist in your exact game
 * version they simply do nothing (the config is optional), and the rest of the mod is not affected.
 */
public final class SkyFog {
    private SkyFog() { }

    private static int rgb(Module m, int firstIdx) { return SkyColors.argb(m.get(firstIdx).i(), m.get(firstIdx + 1).i(), m.get(firstIdx + 2).i()); }

    private static int color(Module m, boolean on, int idx) {
        if (m.get(17).i() == 1) return SkyColors.rainbow(System.currentTimeMillis(), (long) (m.get(18).value * 1000), 0.55f, 1f);
        return rgb(m, idx);
    }

    /** @return the replacement value or null to keep the game's own value. */
    public static Object override(EnvironmentAttribute<?> a) {
        Module m = Config.SKYFOG;
        if (Config.panic || !m.enabled || a == null) return null;
        if (a == EnvironmentAttributes.SKY_COLOR && m.get(0).i() == 1) return color(m, true, 1);
        if (a == EnvironmentAttributes.FOG_COLOR && m.get(4).i() == 1) return color(m, true, 5);
        if (a == EnvironmentAttributes.CLOUD_COLOR && m.get(11).i() == 1) return rgb(m, 12);
        if (a == EnvironmentAttributes.STAR_BRIGHTNESS && m.get(15).i() == 1) return m.get(16).f();
        if (m.get(8).i() == 1) {
            float[] r = SkyColors.fogRange(m.get(9).f(), m.get(10).f());
            if (a == EnvironmentAttributes.FOG_START_DISTANCE) return r[0];
            if (a == EnvironmentAttributes.FOG_END_DISTANCE) return r[1];
        }
        return null;
    }
}
