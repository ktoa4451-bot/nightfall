package com.ghostline.mod.automation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Loot Tracker core. Feed it inventory snapshots (item id -> count); it records only CONFIRMED increases
 * (what really appeared in your inventory). Decreases (dropping, crafting, placing) are never counted as loot.
 */
public final class LootLog {
    public record Entry(long time, String item, int count) { }

    private final Map<String, Integer> last = new HashMap<>();
    private final Map<String, Integer> total = new LinkedHashMap<>();
    private final List<Entry> journal = new ArrayList<>();
    private final int journalMax;
    private boolean primed;

    public LootLog(int journalMax) { this.journalMax = Math.max(10, journalMax); }

    /** First snapshot only sets the baseline. Returns the gains of this snapshot. */
    public Map<String, Integer> update(Map<String, Integer> now, long time) {
        Map<String, Integer> gains = new LinkedHashMap<>();
        if (primed) {
            for (Map.Entry<String, Integer> e : now.entrySet()) {
                int diff = e.getValue() - last.getOrDefault(e.getKey(), 0);
                if (diff > 0) {
                    gains.put(e.getKey(), diff);
                    total.merge(e.getKey(), diff, Integer::sum);
                    journal.add(new Entry(time, e.getKey(), diff));
                    while (journal.size() > journalMax) journal.remove(0);
                }
            }
        }
        last.clear(); last.putAll(now);
        primed = true;
        return gains;
    }

    /** Forget the baseline (world change, death): the next snapshot is not counted. */
    public void rebase() { primed = false; last.clear(); }

    public void reset() { rebase(); total.clear(); journal.clear(); }

    public Map<String, Integer> totals() { return new LinkedHashMap<>(total); }
    public List<Entry> journal() { return List.copyOf(journal); }

    public List<Map.Entry<String, Integer>> top(int n, Set<String> filter) {
        List<Map.Entry<String, Integer>> l = new ArrayList<>();
        for (Map.Entry<String, Integer> e : total.entrySet()) if (filter == null || filter.isEmpty() || filter.contains(e.getKey())) l.add(Map.entry(e.getKey(), e.getValue()));
        l.sort((a, b) -> b.getValue() - a.getValue());
        return l.size() > n ? l.subList(0, n) : l;
    }
}
