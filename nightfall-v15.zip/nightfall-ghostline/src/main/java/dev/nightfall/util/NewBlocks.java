package dev.nightfall.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Remembers which block positions (packed as longs) were already seen and reports the ones that appear later.
 * The first call only records what is already there, so blocks that were standing before the module started are never "new".
 * A position that disappears is forgotten, so placing a block there again counts as new again.
 */
public final class NewBlocks {
    private final Set<Long> known = new HashSet<>();
    private boolean primed;

    public List<Long> update(Collection<Long> current) {
        List<Long> fresh = new ArrayList<>();
        Set<Long> now = new HashSet<>(current);
        for (Long c : now) if (known.add(c) && primed) fresh.add(c);
        known.retainAll(now);
        primed = true;
        return fresh;
    }

    public void reset() { known.clear(); primed = false; }
}
