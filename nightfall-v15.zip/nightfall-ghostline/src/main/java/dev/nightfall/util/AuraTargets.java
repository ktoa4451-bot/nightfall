package dev.nightfall.util;

import java.util.List;

/** Pure target-selection and crystal-worth logic (no Minecraft types, so it can be unit tested). */
public final class AuraTargets {
    private AuraTargets() { }

    public static final int DISTANCE = 0;
    public static final int HEALTH = 1;
    public static final int ANGLE = 2;

    /** index: position in the caller's entity list; angle: absolute degrees away from the view direction. */
    public record Cand(int index, double dist, double health, double angle, boolean visible) { }

    /** Returns the index of the best candidate, or -1 when none qualifies. fov is the full view cone in degrees. */
    public static int pick(List<Cand> cands, double range, double fov, int mode, boolean visibleOnly) {
        Cand best = null;
        double bestKey = Double.MAX_VALUE;
        for (Cand c : cands) {
            if (c.dist() > range) continue;
            if (fov < 360.0 && c.angle() > fov / 2.0) continue;
            if (visibleOnly && !c.visible()) continue;
            double key = switch (mode) {
                case HEALTH -> c.health();
                case ANGLE -> c.angle();
                default -> c.dist();
            };
            if (key < bestKey) { bestKey = key; best = c; }
        }
        return best == null ? -1 : best.index();
    }

    /** A crystal is worth using when it hurts the enemy enough, stays under the self-damage cap and leaves a safety margin. */
    public static boolean crystalWorth(double enemyDmg, double selfDmg, double selfHealth,
                                       double minEnemy, double maxSelf, double margin) {
        if (enemyDmg < minEnemy) return false;
        if (selfDmg > maxSelf) return false;
        return selfDmg + margin < selfHealth;
    }
}
