package dev.nightfall.bridge;

import com.ghostline.mod.Config;
import com.ghostline.mod.Lang;
import dev.nightfall.module.Category;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;

/**
 * A Ghostline module shown in the Nightfall menu. It holds no state of its own: enabled flag, key and every setting
 * read and write the Ghostline module directly, so Ghostline's own code and its config file keep working unchanged.
 */
public final class GhostModule extends dev.nightfall.module.Module {
    public final com.ghostline.mod.Module g;

    public GhostModule(com.ghostline.mod.Module g, Category category) {
        super(g.name, "", category);
        this.g = g;
        for (com.ghostline.mod.Setting s : g.settings) {
            Setting<?> w = GhostBridge.wrap(s);
            if (w != null) settings.add(w);
        }
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override public String getName() { return Lang.mod(g); }
    @Override public String getDescription() { return Lang.desc(g); }
    @Override public boolean isEnabled() { return g.toggleable && g.enabled; }

    @Override
    public void setEnabled(boolean value) {
        if (!g.toggleable || g.enabled == value) return;
        g.enabled = value;
        Config.save();
    }

    /** Switches the module, or for action-only modules (Panic) runs the action. */
    @Override
    public void toggle() {
        if (!g.toggleable) {
            Minecraft mc = Minecraft.getInstance();
            if (g.action != null && mc.player != null) g.action.accept(mc);
            return;
        }
        setEnabled(!g.enabled);
    }

    @Override public int getKeyBind() { return g.bind > 0 ? g.bind : -1; }
    @Override public void setKeyBind(int key) { g.bind = key > 0 ? key : -1; Config.save(); }
}
