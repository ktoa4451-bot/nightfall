package dev.nightfall.bridge;

import com.ghostline.mod.Config;
import com.ghostline.mod.Lang;
import dev.nightfall.NightfallClient;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.ModuleManager;
import dev.nightfall.module.Setting;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** Puts the Ghostline modules into the Nightfall module list (and so into the Nightfall menu). */
public final class GhostBridge {
    private GhostBridge() { }

    /** Ghostline modules that are not shown because the Nightfall module of the same job replaces them. */
    private static final Set<String> HIDDEN = Set.of("CrystalHelper");

    public static void register(ModuleManager mm) {
        List<com.ghostline.mod.Module> all = new ArrayList<>(Config.ALL);
        all.addAll(Config.EXTRA);
        for (com.ghostline.mod.Module g : all) {
            if (HIDDEN.contains(g.name)) continue;
            mm.register(new GhostModule(g, category(g.category)));
        }
        Config.CRYSTAL.enabled = false;   // its hints are part of the Nightfall CrystalHelper now
    }

    static Category category(int c) {
        return switch (c) {
            case 0 -> Category.COMBAT;
            case 1 -> Category.MOVEMENT;
            case 2 -> Category.PLAYER;
            case 3 -> Category.VISUALS;
            case 8 -> Category.COSMETICS;
            default -> Category.MISC;      // 4 misc, 5 theme, 6 HUD and notifications
        };
    }

    /** Names of the enabled Nightfall (not Ghostline) modules, for the Ghostline HUD module list. */
    public static List<String> nightfallEnabledNames() {
        List<String> out = new ArrayList<>();
        NightfallClient nf = NightfallClient.getInstance();
        if (nf == null) return out;
        for (Module m : nf.moduleManager.getModules()) if (!(m instanceof GhostModule) && m.isEnabled()) out.add(m.getName());
        return out;
    }

    /** Panic: switch every Nightfall module off. */
    public static void disableNightfall() {
        NightfallClient nf = NightfallClient.getInstance();
        if (nf == null) return;
        for (Module m : nf.moduleManager.getModules()) if (!(m instanceof GhostModule) && m.isEnabled()) m.setEnabled(false);
    }

    static Setting<?> wrap(com.ghostline.mod.Setting s) {
        if (s.isKey) return new GKey(s);
        if (s.isText) return new GText(s);
        if (s.isBool()) return new GBool(s);
        if (s.options != null) return new GMode(s);
        return new GNum(s);
    }

    // ------------------------------------------------------------------ setting adapters (they read and write the Ghostline setting)

    static final class GBool extends Setting.BooleanSetting {
        private final com.ghostline.mod.Setting g;
        GBool(com.ghostline.mod.Setting g) { super(g.name, g.def >= 0.5); this.g = g; }
        @Override public String getName() { return Lang.set(g); }
        @Override public Boolean getValue() { return g.value >= 0.5; }
        @Override public void setValue(Boolean v) { g.value = v ? 1 : 0; Config.save(); }
        @Override public void resetToDefault() { g.reset(); Config.save(); }
    }

    static final class GNum extends Setting.DoubleSetting {
        private final com.ghostline.mod.Setting g;
        GNum(com.ghostline.mod.Setting g) { super(g.name, g.def, g.min, g.max); this.g = g; }
        @Override public String getName() { return Lang.set(g); }
        @Override public Double getValue() { return g.value; }
        @Override public void setValue(Double v) { g.value = clamp(v); Config.save(); }
        @Override public double snap(double v) {
            double r = g.step > 0 ? Math.round((v - g.min) / g.step) * g.step + g.min : v;
            return Math.round(clamp(r) * 1e6) / 1e6;
        }
        @Override public String display() { return g.display(); }
        @Override public void resetToDefault() { g.reset(); Config.save(); }
        private double clamp(double v) { return Math.max(g.min, Math.min(g.max, v)); }
    }

    static final class GMode extends Setting.ModeSetting {
        private final com.ghostline.mod.Setting g;
        GMode(com.ghostline.mod.Setting g) { super(g.name, g.options, g.i()); this.g = g; }
        @Override public String getName() { return Lang.set(g); }
        @Override public Integer getValue() { return Math.max(0, Math.min(g.options.length - 1, g.i())); }
        @Override public void setValue(Integer v) { g.value = Math.max(0, Math.min(g.options.length - 1, v)); Config.save(); }
        @Override public String display() { return g.display(); }
        @Override public void resetToDefault() { g.reset(); Config.save(); }
    }

    static final class GKey extends Setting.KeySetting {
        private final com.ghostline.mod.Setting g;
        GKey(com.ghostline.mod.Setting g) { super(g.name); this.g = g; }
        @Override public String getName() { return Lang.set(g); }
        @Override public Integer getValue() { return g.i(); }
        @Override public void setValue(Integer v) { g.value = v; Config.save(); }
        @Override public String display() { return Config.keyName(g.i()); }
        @Override public void resetToDefault() { g.reset(); Config.save(); }
    }

    static final class GText extends Setting.TextSetting {
        private final com.ghostline.mod.Setting g;
        GText(com.ghostline.mod.Setting g) { super(g.name, "", g.secret); this.g = g; }
        @Override public String getName() { return Lang.set(g); }
        @Override public String getValue() { return g.text; }
        @Override public void setValue(String v) { g.text = v == null ? "" : v; if (!g.noSave) Config.save(); }
        @Override public void resetToDefault() { g.reset(); if (!g.noSave) Config.save(); }
    }
}
