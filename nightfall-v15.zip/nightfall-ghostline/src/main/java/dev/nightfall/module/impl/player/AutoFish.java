package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;

/** Cast the rod yourself once. When the bobber dips (a bite) it reels in and casts again. */
public class AutoFish extends Module implements Tickable {
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 12, 4, 40);   // ticks before the next cast
    private int cooldown;
    private boolean recast;

    public AutoFish() {
        super("AutoFish", "Reels in on a bite and casts again.", Category.PLAYER);
        settings.add(delay);
    }

    @Override public void onEnable() { cooldown = 0; recast = false; }
    @Override public void onDisable() { recast = false; }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
        InteractionHand hand = p.getMainHandItem().is(Items.FISHING_ROD) ? InteractionHand.MAIN_HAND
            : p.getOffhandItem().is(Items.FISHING_ROD) ? InteractionHand.OFF_HAND : null;
        if (hand == null) return;
        if (cooldown > 0) { cooldown--; return; }
        var hook = p.fishing;
        if (hook == null) {
            if (recast) { mc.gameMode.useItem(p, hand); recast = false; cooldown = 10; }
            return;
        }
        if (hook.tickCount > 25 && hook.isInWater() && hook.getDeltaMovement().y < -0.045) {
            mc.gameMode.useItem(p, hand);
            recast = true;
            cooldown = delay.getValue();
        }
    }
}
