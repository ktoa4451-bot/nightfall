package dev.nightfall.module;

public class Setting<T> {
    private final String name;
    private final T defaultValue;
    private T value;

    public Setting(String name, T defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getName() { return name; }
    public T getValue() { return value; }
    public void setValue(T value) { this.value = value; }
    public T getDefaultValue() { return defaultValue; }
    /** Text to show instead of the raw value (null = the menu formats it itself). */
    public String display() { return null; }
    public void resetToDefault() { setValue(defaultValue); }

    public static class BooleanSetting extends Setting<Boolean> {
        public BooleanSetting(String name, boolean def) {
            super(name, def);
        }
    }

    public static class DoubleSetting extends Setting<Double> {
        private final double min;
        private final double max;

        public DoubleSetting(String name, double def, double min, double max) {
            super(name, def);
            this.min = min;
            this.max = max;
        }

        public double getMin() { return min; }
        public double getMax() { return max; }
        /** Rounds a slider position to a value this setting accepts. */
        public double snap(double v) { return Math.round(v * 100.0) / 100.0; }
    }

    public static class IntSetting extends Setting<Integer> {
        private final int min;
        private final int max;

        public IntSetting(String name, int def, int min, int max) {
            super(name, def);
            this.min = min;
            this.max = max;
        }

        public int getMin() { return min; }
        public int getMax() { return max; }
    }

    /** A choice from a fixed list (value = index). */
    public static class ModeSetting extends Setting<Integer> {
        private final String[] options;

        public ModeSetting(String name, String[] options, int def) {
            super(name, def);
            this.options = options;
        }

        public String[] getOptions() { return options; }
    }

    /** A keyboard key (GLFW code, -1 = none). */
    public static class KeySetting extends Setting<Integer> {
        public KeySetting(String name) { super(name, -1); }
    }

    /** Free text (tokens, names, lists). */
    public static class TextSetting extends Setting<String> {
        private final boolean secret;

        public TextSetting(String name, String def, boolean secret) {
            super(name, def);
            this.secret = secret;
        }

        public boolean isSecret() { return secret; }
    }
}
