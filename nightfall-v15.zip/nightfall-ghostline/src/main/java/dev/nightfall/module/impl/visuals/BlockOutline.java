package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** Outline (and optional fill) of the block you look at (drawn by render/VisualFx). */
public class BlockOutline extends Module {
    public final Setting.BooleanSetting fill = new Setting.BooleanSetting("Fill", true);
    public final Setting.IntSetting fillAlpha = new Setting.IntSetting("FillAlpha", 20, 5, 60);

    public BlockOutline() {
        super("BlockOutline", "Outline and overlay of the targeted block.", Category.VISUALS);
        settings.add(fill); settings.add(fillAlpha);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
