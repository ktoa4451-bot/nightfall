package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** The crosshair looks through entities to the block behind them (mining, opening, placing). Called from GameRenderer.pick. */
public class NoEntityTrace extends Module {
    private static NoEntityTrace instance;
    private final Setting.BooleanSetting keepSword = new Setting.BooleanSetting("KeepSword", true);

    public NoEntityTrace() {
        super("NoEntityTrace", "Aim through entities at the block behind them.", Category.PLAYER);
        settings.add(keepSword);
        instance = this;
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    public static void apply(Minecraft mc, float partial) {
        NoEntityTrace m = instance;
        LocalPlayer p = mc.player;
        if (m == null || !m.isEnabled() || p == null || mc.level == null || !(mc.hitResult instanceof EntityHitResult)) return;
        if (m.keepSword.getValue() && p.getMainHandItem().is(ItemTags.SWORDS)) return;
        HitResult b = p.pick(p.blockInteractionRange(), partial, false);
        if (b.getType() == HitResult.Type.BLOCK) mc.hitResult = b;
    }
}
