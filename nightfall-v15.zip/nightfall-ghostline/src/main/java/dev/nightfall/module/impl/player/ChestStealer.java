package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ClickType;

/** While a chest (or barrel / ender chest) is open it moves its items to your inventory, one item per few ticks. */
public class ChestStealer extends Module implements Tickable {
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 2, 0, 10);
    private final Setting.BooleanSetting autoClose = new Setting.BooleanSetting("AutoClose", false);
    private int wait;

    public ChestStealer() {
        super("ChestStealer", "Takes all items out of an open chest.", Category.PLAYER);
        settings.add(delay); settings.add(autoClose);
    }

    @Override public void onEnable() { wait = 0; }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.screen == null || !(p.containerMenu instanceof ChestMenu cm)) return;
        if (++wait <= delay.getValue()) return;
        wait = 0;
        int chestSlots = cm.getRowCount() * 9;
        boolean any = false;
        for (int i = 0; i < chestSlots; i++) {
            if (!cm.getSlot(i).hasItem()) continue;
            any = true;
            if (p.getInventory().getFreeSlot() < 0) return;               // inventory is full
            mc.gameMode.handleInventoryMouseClick(cm.containerId, i, 0, ClickType.QUICK_MOVE, p);
            return;
        }
        if (!any && autoClose.getValue()) p.closeContainer();
    }
}
