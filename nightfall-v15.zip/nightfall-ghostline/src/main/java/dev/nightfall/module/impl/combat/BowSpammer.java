package dev.nightfall.module.impl.combat;

import dev.nightfall.mixin.client.MinecraftAccessor;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;

/** Hold the bow: it is released after a few ticks of charge and drawn again at once, while a player is close. */
public class BowSpammer extends Module implements Tickable {
    private final Setting.IntSetting charge = new Setting.IntSetting("Charge", 5, 1, 18);
    private final Setting.IntSetting range = new Setting.IntSetting("Range", 12, 0, 40);   // 0 = no distance check

    public BowSpammer() {
        super("BowSpammer", "Rapid bow shots (release after N ticks) when a player is near.", Category.COMBAT);
        settings.add(charge); settings.add(range);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    private boolean playerNear(Minecraft mc, LocalPlayer p) {
        if (range.getValue() == 0) return true;
        for (Player o : mc.level.players()) if (o != p && o.isAlive() && p.distanceTo(o) <= range.getValue()) return true;
        return false;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
        boolean bow = p.getMainHandItem().is(Items.BOW) || p.getOffhandItem().is(Items.BOW);
        if (!bow || !mc.options.keyUse.isDown() || !playerNear(mc, p)) return;
        ((MinecraftAccessor) mc).nightfall$setRightClickDelay(0);
        if (p.isUsingItem() && p.getUseItem().is(Items.BOW) && p.getTicksUsingItem() >= charge.getValue()) {
            mc.gameMode.releaseUsingItem(p);
        }
    }
}
