package dev.nightfall.module.impl.misc;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;

/** One-shot module (put a key on it): writes your coordinates "x y z" to the chat, then switches itself off. */
public class CordDropper extends Module implements Tickable {
    private boolean pending;

    public CordDropper() { super("CordDropper", "Sends your coordinates to the chat (use a keybind).", Category.MISC); }

    @Override public void onEnable() { pending = true; }
    @Override public void onDisable() { pending = false; }

    @Override
    public void onTick(Minecraft mc) {
        if (!pending) return;
        pending = false;
        if (mc.player != null && mc.getConnection() != null) {
            mc.getConnection().sendChat(mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ());
        }
        setEnabled(false);
    }
}
