package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionResult;

/** Plays a sound of your choice when you hit something. */
public class HitSound extends Module {
    private static final String[] NAMES = {"Orb", "ArrowHit", "LevelUp", "Anvil", "Bell", "Pickup"};
    private final Setting.ModeSetting mode = new Setting.ModeSetting("Mode", NAMES, 0);
    private final Setting.IntSetting volume = new Setting.IntSetting("Volume", 15, 0, 30);
    private final Setting.DoubleSetting pitch = new Setting.DoubleSetting("Pitch", 1.0, 0.5, 2.0);

    public HitSound() {
        super("HitSound", "Plays a sound when you hit an entity.", Category.COMBAT);
        settings.add(mode); settings.add(volume); settings.add(pitch);
        AttackEntityCallback.EVENT.register((p, w, h, e, hit) -> {
            if (isEnabled()) play();
            return InteractionResult.PASS;
        });
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    private SoundEvent sound() {
        switch (mode.getValue()) {
            case 1: return SoundEvents.ARROW_HIT_PLAYER;
            case 2: return SoundEvents.PLAYER_LEVELUP;
            case 3: return SoundEvents.ANVIL_LAND;
            case 4: return SoundEvents.BELL_BLOCK;
            case 5: return SoundEvents.ITEM_PICKUP;
            default: return SoundEvents.EXPERIENCE_ORB_PICKUP;
        }
    }

    private void play() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || volume.getValue() <= 0) return;
        mc.player.playSound(sound(), volume.getValue() / 15f, pitch.getValue().floatValue());
    }
}
