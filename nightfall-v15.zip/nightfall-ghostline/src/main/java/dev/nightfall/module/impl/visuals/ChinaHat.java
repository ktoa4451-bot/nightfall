package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** A cone-shaped hat drawn over the heads of other players (drawn by render/VisualFx; it is not shown on yourself in third person). */
public class ChinaHat extends Module {
    public final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 40.0, 8.0, 96.0);

    public ChinaHat() {
        super("ChinaHat", "Cone hat over other players' heads.", Category.VISUALS);
        settings.add(range);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
