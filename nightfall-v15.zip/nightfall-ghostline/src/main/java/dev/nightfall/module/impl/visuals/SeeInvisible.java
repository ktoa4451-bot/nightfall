package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** Boxes with a name over invisible players and mobs (drawn by render/VisualFx). */
public class SeeInvisible extends Module {
    public final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 48.0, 8.0, 128.0);

    public SeeInvisible() {
        super("SeeInvisible", "Marks invisible entities.", Category.VISUALS);
        settings.add(range);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
