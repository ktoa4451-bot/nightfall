package dev.nightfall.module.impl.combat;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * Makes other players easier to hit: the "target" box that the crosshair uses is widened by Expand blocks on every side.
 * Only what your client aims at changes (the real hitbox is not touched); the server still checks reach as usual,
 * so hits that are further out than the server allows are simply not registered.
 */
public class Hitboxes extends Module {
    public final Setting.DoubleSetting expand = new Setting.DoubleSetting("Expand", 0.2, 0.0, 1.0);
    public final Setting.BooleanSetting playersOnly = new Setting.BooleanSetting("PlayersOnly", true);
    public final Setting.BooleanSetting skipFriends = new Setting.BooleanSetting("SkipFriends", true);

    public Hitboxes() {
        super("Hitboxes", "Widens the aiming box of other players so they are easier to hit.", Category.COMBAT);
        settings.add(expand); settings.add(playersOnly); settings.add(skipFriends);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    /** Extra pick radius (blocks) for this entity; called from EntityPickRadiusMixin. */
    public static float extra(Entity e) {
        NightfallClient nf = NightfallClient.getInstance();
        if (nf == null || com.ghostline.mod.Config.panic) return 0f;
        var m = nf.moduleManager.getByName("Hitboxes").orElse(null);
        if (!(m instanceof Hitboxes h) || !h.isEnabled()) return 0f;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || e == mc.player || !(e instanceof LivingEntity)) return 0f;
        if (h.playersOnly.getValue() && !(e instanceof Player)) return 0f;
        if (h.skipFriends.getValue() && com.ghostline.mod.Config.isFriend(e)) return 0f;
        return h.expand.getValue().floatValue();
    }
}
