package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** A pulsing red frame and "LOW HP" on the screen when your health drops to the set value (drawn by render/VisualFx). */
public class HpAlert extends Module {
    public final Setting.IntSetting health = new Setting.IntSetting("Health", 8, 1, 20);

    public HpAlert() {
        super("HpAlert", "Warns when your health is low.", Category.VISUALS);
        settings.add(health);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
