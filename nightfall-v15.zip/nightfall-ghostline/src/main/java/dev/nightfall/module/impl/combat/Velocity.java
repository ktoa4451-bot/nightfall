package dev.nightfall.module.impl.combat;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.world.phys.Vec3;

/** Reduces the knockback you take: after the server's motion packet for you, your motion is scaled by Horizontal / Vertical percent (0 = no knockback). */
public class Velocity extends Module {
    public final Setting.IntSetting horizontal = new Setting.IntSetting("Horizontal", 0, 0, 100);
    public final Setting.IntSetting vertical = new Setting.IntSetting("Vertical", 0, 0, 100);

    /** Motion before the packet was handled (set by the mixin). */
    public static Vec3 before;

    public Velocity() {
        super("Velocity", "Reduces knockback (Horizontal / Vertical in percent).", Category.COMBAT);
        settings.add(horizontal); settings.add(vertical);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    private static Velocity active() {
        NightfallClient nf = NightfallClient.getInstance();
        if (nf == null || com.ghostline.mod.Config.panic) return null;
        return nf.moduleManager.getByName("Velocity").orElse(null) instanceof Velocity v && v.isEnabled() ? v : null;
    }

    public static void remember() {
        Minecraft mc = Minecraft.getInstance();
        before = active() != null && mc.player != null ? mc.player.getDeltaMovement() : null;
    }

    public static void apply() {
        Velocity v = active();
        Minecraft mc = Minecraft.getInstance();
        Vec3 b = before;
        before = null;
        if (v == null || b == null || mc.player == null) return;
        Vec3 after = mc.player.getDeltaMovement();
        if (after.equals(b)) return;                         // the packet was not about you
        mc.player.setDeltaMovement(after.x * v.horizontal.getValue() / 100.0, after.y * v.vertical.getValue() / 100.0, after.z * v.horizontal.getValue() / 100.0);
    }
}
