package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.DeathScreen;

/** Presses "Respawn" for you on the death screen after a short delay. */
public class AutoRespawn extends Module implements Tickable {
    private final Setting.IntSetting delay = new Setting.IntSetting("DelayTicks", 20, 0, 100);
    private int waited;

    public AutoRespawn() {
        super("AutoRespawn", "Respawns automatically on the death screen.", Category.PLAYER);
        settings.add(delay);
    }

    @Override public void onEnable() { waited = 0; }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || !(mc.screen instanceof DeathScreen)) { waited = 0; return; }
        if (++waited >= delay.getValue()) { mc.player.respawn(); waited = 0; }
    }
}
