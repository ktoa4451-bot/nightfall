package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** You are not pushed by water, other players or blocks you stand inside (the mixins read the flags below). */
public class NoPush extends Module {
    private static NoPush instance;
    private final Setting.BooleanSetting water = new Setting.BooleanSetting("Water", true);
    private final Setting.BooleanSetting players = new Setting.BooleanSetting("Players", true);
    private final Setting.BooleanSetting blocks = new Setting.BooleanSetting("Blocks", true);

    public NoPush() {
        super("NoPush", "No push from water, players and blocks.", Category.PLAYER);
        settings.add(water); settings.add(players); settings.add(blocks);
        instance = this;
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    private static boolean on() { return instance != null && instance.isEnabled(); }
    public static boolean noWater() { return on() && instance.water.getValue(); }
    public static boolean noPlayers() { return on() && instance.players.getValue(); }
    public static boolean noBlocks() { return on() && instance.blocks.getValue(); }
}
