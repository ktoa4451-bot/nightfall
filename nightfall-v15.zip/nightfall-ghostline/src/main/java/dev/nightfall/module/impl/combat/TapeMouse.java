package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/** Hold the attack button: you hit the entity under the crosshair exactly when the weapon cooldown is full. */
public class TapeMouse extends Module implements Tickable {
    public TapeMouse() { super("TapeMouse", "Hold attack: hits with a full cooldown.", Category.COMBAT); }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive() || p.isUsingItem()) return;
        if (!mc.options.keyAttack.isDown()) return;
        if (!(mc.hitResult instanceof EntityHitResult eh) || !(eh.getEntity() instanceof LivingEntity t) || t == p || !t.isAlive()) return;
        if (p.getAttackStrengthScale(0.5f) < 1f) return;
        mc.gameMode.attack(p, t);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
