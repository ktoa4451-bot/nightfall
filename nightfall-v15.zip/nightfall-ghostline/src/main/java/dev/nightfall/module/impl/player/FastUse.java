package dev.nightfall.module.impl.player;

import dev.nightfall.mixin.client.MinecraftAccessor;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/** Shortens the wait between two right clicks while you hold blocks, end crystals or experience bottles. */
public class FastUse extends Module implements Tickable {
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 1, 0, 4);
    private final Setting.BooleanSetting blocks = new Setting.BooleanSetting("Blocks", true);
    private final Setting.BooleanSetting crystals = new Setting.BooleanSetting("Crystals", true);
    private final Setting.BooleanSetting exp = new Setting.BooleanSetting("Exp", true);

    public FastUse() {
        super("FastUse", "Shorter delay between right clicks for blocks, crystals and exp bottles.", Category.PLAYER);
        settings.add(delay); settings.add(blocks); settings.add(crystals); settings.add(exp);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    private boolean applies(Item it) {
        return (blocks.getValue() && it instanceof BlockItem)
            || (crystals.getValue() && it == Items.END_CRYSTAL)
            || (exp.getValue() && it == Items.EXPERIENCE_BOTTLE);
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) return;
        if (!applies(p.getMainHandItem().getItem()) && !applies(p.getOffhandItem().getItem())) return;
        MinecraftAccessor acc = (MinecraftAccessor) mc;
        if (acc.nightfall$getRightClickDelay() > delay.getValue()) acc.nightfall$setRightClickDelay(delay.getValue());
    }
}
