package dev.nightfall.module.impl.combat;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Item;

/** Where an item can be used from: the offhand, the selected slot, or another hotbar slot (selected for the moment of the use, then restored). */
final class ItemHand {
    final InteractionHand hand;
    private final int slot;      // hotbar slot to select first, -1 = no switch needed

    private ItemHand(InteractionHand hand, int slot) { this.hand = hand; this.slot = slot; }

    static ItemHand find(LocalPlayer p, Item item) {
        if (p.getOffhandItem().is(item)) return new ItemHand(InteractionHand.OFF_HAND, -1);
        if (p.getMainHandItem().is(item)) return new ItemHand(InteractionHand.MAIN_HAND, -1);
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(item)) return new ItemHand(InteractionHand.MAIN_HAND, i);
        return null;
    }

    void use(LocalPlayer p, Runnable action) {
        int prev = -1;
        if (slot >= 0) { prev = p.getInventory().getSelectedSlot(); p.getInventory().setSelectedSlot(slot); }
        action.run();
        if (slot >= 0) p.getInventory().setSelectedSlot(prev);
    }
}
