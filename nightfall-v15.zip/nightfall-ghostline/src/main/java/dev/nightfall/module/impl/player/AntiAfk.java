package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;

/** Every few seconds makes a small jump so the server does not kick you for being idle. */
public class AntiAfk extends Module implements Tickable {
    private final Setting.IntSetting seconds = new Setting.IntSetting("EverySeconds", 20, 5, 120);
    private int ticks;
    private boolean pressed;

    public AntiAfk() {
        super("AntiAfk", "Jumps now and then so you are not kicked as AFK.", Category.PLAYER);
        settings.add(seconds);
    }

    @Override public void onEnable() { ticks = 0; }
    @Override public void onDisable() { release(Minecraft.getInstance()); }

    private void release(Minecraft mc) {
        if (pressed && mc != null && mc.options != null) { mc.options.keyJump.setDown(false); pressed = false; }
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.screen != null) { release(mc); return; }
        if (pressed) { release(mc); return; }
        if (++ticks >= seconds.getValue() * 20 && mc.player.onGround()) {
            mc.options.keyJump.setDown(true);
            pressed = true;
            ticks = 0;
        }
    }
}
