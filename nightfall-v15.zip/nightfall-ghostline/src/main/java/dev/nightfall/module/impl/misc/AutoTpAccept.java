package dev.nightfall.module.impl.misc;

import com.ghostline.mod.Config;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;

import java.util.Locale;

/** Answers a teleport request in chat with /tpaccept. With FriendsOnly it only accepts when a name from your friends list is in the message. */
public class AutoTpAccept extends Module {
    private final Setting.BooleanSetting friendsOnly = new Setting.BooleanSetting("FriendsOnly", true);
    private long last;

    public AutoTpAccept() {
        super("AutoTpAccept", "Accepts teleport requests (/tpaccept).", Category.MISC);
        settings.add(friendsOnly);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (overlay || !isEnabled() || Config.panic) return;
            String t = message.getString().toLowerCase(Locale.ROOT);
            if (!(t.contains("tpa") || t.contains("teleport") || t.contains("телепорт"))) return;
            if (!(t.contains("request") || t.contains("запрос") || t.contains("/tpaccept") || t.contains("хочет"))) return;
            if (friendsOnly.getValue()) {
                boolean friend = false;
                for (String f : Config.FRIENDS_SET) if (!f.isEmpty() && t.contains(f)) { friend = true; break; }
                if (!friend) return;
            }
            long now = System.currentTimeMillis();
            Minecraft mc = Minecraft.getInstance();
            if (now - last < 2000 || mc.player == null) return;
            last = now;
            mc.execute(() -> { if (mc.player != null) mc.player.connection.sendCommand("tpaccept"); });
        });
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
