package dev.nightfall.module;

public enum Category {
    COMBAT("Combat"),
    VISUALS("Visuals"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    MISC("Misc"),
    COSMETICS("Cosmetics");

    private final String displayName;

    Category(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }
}