package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.NewBlocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Place a respawn anchor and this module fills it with glowstone for you (up to 4 charges, glowstone from the hotbar or offhand).
 * It only charges; setting the anchor off is up to you. One glowstone is used at a time and the next one only after the
 * anchor visibly gained a charge: clicking an already full anchor with glowstone makes it explode outside the Nether.
 */
public class AnchorHelper extends Module implements Tickable {
    public final Setting.DoubleSetting reach = new Setting.DoubleSetting("Reach", 4.5, 2.0, 6.0);
    public final Setting.IntSetting chargeTo = new Setting.IntSetting("ChargeTo", 4, 1, 4);
    public final Setting.IntSetting delay = new Setting.IntSetting("Delay", 2, 1, 10);
    public final Setting.BooleanSetting onlyNew = new Setting.BooleanSetting("OnlyNewAnchors", true);

    private final NewBlocks anchorWatch = new NewBlocks();
    private final Map<Long, Integer> pending = new LinkedHashMap<>();   // anchor position -> tick when we give up
    private long waitPos = Long.MIN_VALUE;                              // anchor we clicked and wait for the new charge on
    private int waitCharge, waitUntil, tick;

    public AnchorHelper() {
        super("AnchorHelper", "Fills a respawn anchor you place with glowstone (up to 4 charges).", Category.COMBAT);
        settings.add(reach); settings.add(chargeTo); settings.add(delay); settings.add(onlyNew);
    }

    @Override public void onEnable() { reset(); }
    @Override public void onDisable() { reset(); }

    private void reset() { tick = 0; pending.clear(); anchorWatch.reset(); waitPos = Long.MIN_VALUE; }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;
        tick++;

        // find anchors around you; with OnlyNewAnchors only the ones that appear after the module started (the ones you place)
        int scan = (int) Math.ceil(reach.getValue()) + 2;
        BlockPos base = p.blockPosition();
        List<Long> now = new ArrayList<>();
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (int dx = -scan; dx <= scan; dx++) for (int dy = -scan; dy <= scan; dy++) for (int dz = -scan; dz <= scan; dz++) {
            q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
            if (mc.level.getBlockState(q).is(Blocks.RESPAWN_ANCHOR)) now.add(q.asLong());
        }
        if (onlyNew.getValue()) for (long l : anchorWatch.update(now)) pending.put(l, tick + 600);
        else for (long l : now) pending.putIfAbsent(l, tick + 600);

        if (mc.screen != null || !p.isAlive() || p.isSpectator() || pending.isEmpty()) return;

        // after a click wait until the client sees the new charge (or give up on that anchor), never click blind
        if (waitPos != Long.MIN_VALUE) {
            BlockState s = mc.level.getBlockState(BlockPos.of(waitPos));
            if (!s.is(Blocks.RESPAWN_ANCHOR)) { pending.remove(waitPos); waitPos = Long.MIN_VALUE; }
            else if (s.getValue(RespawnAnchorBlock.CHARGE) > waitCharge) waitPos = Long.MIN_VALUE;
            else if (tick > waitUntil) { pending.remove(waitPos); waitPos = Long.MIN_VALUE; }
            else return;
        }
        if (tick % delay.getValue() != 0) return;

        ItemHand hand = ItemHand.find(p, Items.GLOWSTONE);
        var it = pending.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            BlockPos pos = BlockPos.of(e.getKey());
            BlockState s = mc.level.getBlockState(pos);
            if (tick > e.getValue() || !s.is(Blocks.RESPAWN_ANCHOR)) { it.remove(); continue; }
            int charge = s.getValue(RespawnAnchorBlock.CHARGE);
            if (charge >= chargeTo.getValue()) { it.remove(); continue; }
            if (hand == null) return;
            Vec3 center = Vec3.atCenterOf(pos);
            if (p.getEyePosition().distanceTo(center) > reach.getValue()) continue;
            Vec3 hit = center.add(0, 0.5, 0);
            hand.use(p, () -> mc.gameMode.useItemOn(p, hand.hand, new BlockHitResult(hit, Direction.UP, pos, false)));
            p.swing(hand.hand);
            waitPos = e.getKey(); waitCharge = charge; waitUntil = tick + 20;
            return;
        }
    }
}
