package dev.nightfall.module.impl.misc;

import com.ghostline.mod.Config;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

/** When another player comes within Range blocks, sends a leave command (/hub, /spawn, /lobby or /home) once and switches itself off. */
public class AutoLeave extends Module implements Tickable {
    private static final String[] COMMANDS = {"hub", "spawn", "lobby", "home"};
    private final Setting.IntSetting range = new Setting.IntSetting("Range", 10, 3, 50);
    private final Setting.IntSetting command = new Setting.IntSetting("Command", 0, 0, 3);   // 0 /hub, 1 /spawn, 2 /lobby, 3 /home
    private final Setting.BooleanSetting ignoreFriends = new Setting.BooleanSetting("IgnoreFriends", true);

    public AutoLeave() {
        super("AutoLeave", "Sends /hub (or /spawn, /lobby, /home) when a player comes close.", Category.MISC);
        settings.add(range); settings.add(command); settings.add(ignoreFriends);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.screen != null) return;
        double r2 = (double) range.getValue() * range.getValue();
        for (Player o : mc.level.players()) {
            if (o == mc.player || !o.isAlive() || o.isSpectator()) continue;
            if (ignoreFriends.getValue() && Config.isFriend(o)) continue;
            if (mc.player.distanceToSqr(o) > r2) continue;
            mc.player.connection.sendCommand(COMMANDS[Math.max(0, Math.min(COMMANDS.length - 1, command.getValue()))]);
            setEnabled(false);
            return;
        }
    }
}
