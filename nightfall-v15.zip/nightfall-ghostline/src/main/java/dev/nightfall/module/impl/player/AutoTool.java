package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

/** While you hold the attack button on a block, the fastest tool from the hotbar is selected; the old slot comes back when you let go. */
public class AutoTool extends Module implements Tickable {
    private int restore = -1;

    public AutoTool() { super("AutoTool", "Selects the best tool for the block you mine.", Category.PLAYER); }

    @Override public void onEnable() { restore = -1; }
    @Override public void onDisable() { back(Minecraft.getInstance()); }

    private void back(Minecraft mc) {
        if (restore >= 0 && mc.player != null) mc.player.getInventory().setSelectedSlot(restore);
        restore = -1;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) { restore = -1; return; }
        boolean mining = mc.options.keyAttack.isDown() && mc.hitResult instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK;
        if (!mining) { back(mc); return; }
        BlockState st = mc.level.getBlockState(((BlockHitResult) mc.hitResult).getBlockPos());
        if (st.isAir()) return;
        int cur = p.getInventory().getSelectedSlot(), best = cur;
        float bestSpeed = p.getInventory().getItem(cur).getDestroySpeed(st);
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getItem(i);
            float sp = s.getDestroySpeed(st);
            if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
        }
        if (best != cur) {
            if (restore < 0) restore = cur;
            p.getInventory().setSelectedSlot(best);
        }
    }
}
