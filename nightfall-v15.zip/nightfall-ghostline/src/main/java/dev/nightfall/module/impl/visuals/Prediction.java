package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** Path and landing spot of arrows, tridents, pearls, snowballs, eggs and exp bottles in flight (drawn by render/VisualFx). */
public class Prediction extends Module {
    public final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 64.0, 16.0, 160.0);

    public Prediction() {
        super("Prediction", "Shows where flying projectiles will land.", Category.VISUALS);
        settings.add(range);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
