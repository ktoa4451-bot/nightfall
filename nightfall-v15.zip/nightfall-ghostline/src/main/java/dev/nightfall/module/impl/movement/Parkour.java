package dev.nightfall.module.impl.movement;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/** Jumps for you at the edge of a block while you are walking or sprinting forward (not while sneaking). */
public class Parkour extends Module implements Tickable {
    private final Setting.DoubleSetting lead = new Setting.DoubleSetting("EdgeLead", 2.5, 1.0, 5.0);
    private boolean pressed;

    public Parkour() {
        super("Parkour", "Auto-jump at the edge of a block.", Category.MOVEMENT);
        settings.add(lead);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { release(Minecraft.getInstance()); }

    private void release(Minecraft mc) {
        if (pressed && mc != null && mc.options != null) { mc.options.keyJump.setDown(false); pressed = false; }
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) { release(mc); return; }
        if (pressed) { release(mc); return; }
        if (!p.onGround() || p.isShiftKeyDown() || p.isInWater() || p.isInLava() || p.getAbilities().flying) return;
        Vec3 v = p.getDeltaMovement();
        if (v.x * v.x + v.z * v.z < 0.0025) return;                      // standing still
        BlockPos below = BlockPos.containing(p.getX() + v.x * lead.getValue(), p.getY() - 0.5, p.getZ() + v.z * lead.getValue());
        if (mc.level.getBlockState(below).getCollisionShape(mc.level, below).isEmpty()) {
            mc.options.keyJump.setDown(true);
            pressed = true;
        }
    }
}
