package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

import java.util.ArrayList;
import java.util.List;

/** A ring that spreads on the ground where you jump and where you land (drawn by render/VisualFx). */
public class JumpCircle extends Module implements Tickable {
    public record Ring(double x, double y, double z, long bornNanos, boolean landing) { }

    public final Setting.DoubleSetting radius = new Setting.DoubleSetting("Radius", 1.4, 0.5, 3.0);
    public final Setting.DoubleSetting seconds = new Setting.DoubleSetting("Time", 1.0, 0.3, 3.0);
    public final Setting.BooleanSetting landing = new Setting.BooleanSetting("Landing", true);

    private static final List<Ring> RINGS = new ArrayList<>();
    private boolean wasGround = true;
    private double airTop;

    public JumpCircle() {
        super("JumpCircle", "Ring under you when you jump and land.", Category.VISUALS);
        settings.add(radius); settings.add(seconds); settings.add(landing);
    }

    @Override public void onEnable() { wasGround = true; }
    @Override public void onDisable() { synchronized (RINGS) { RINGS.clear(); } }

    /** Copy of the rings that are still alive; old ones are dropped here. */
    public List<Ring> alive(long now) {
        long life = (long) (seconds.getValue() * 1e9);
        synchronized (RINGS) {
            RINGS.removeIf(r -> now - r.bornNanos() > life);
            return new ArrayList<>(RINGS);
        }
    }

    private void add(Ring r) {
        synchronized (RINGS) { RINGS.add(r); if (RINGS.size() > 16) RINGS.remove(0); }
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) { wasGround = true; return; }
        boolean g = p.onGround();
        long now = System.nanoTime();
        if (wasGround && !g && p.getDeltaMovement().y > 0.05) { add(new Ring(p.getX(), p.getY() + 0.02, p.getZ(), now, false)); airTop = p.getY(); }
        else if (!g) airTop = Math.max(airTop, p.getY());
        if (!wasGround && g && landing.getValue() && airTop - p.getY() > 0.6) add(new Ring(p.getX(), p.getY() + 0.02, p.getZ(), now, true));
        wasGround = g;
    }
}
