package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** Arrows around the crosshair that point at players around you (drawn by render/VisualFx). */
public class Arrows extends Module {
    public final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 64.0, 8.0, 160.0);
    public final Setting.IntSetting size = new Setting.IntSetting("Size", 6, 3, 14);
    public final Setting.IntSetting radius = new Setting.IntSetting("Radius", 30, 10, 48);       // % of the smaller screen side
    public final Setting.BooleanSetting distance = new Setting.BooleanSetting("Distance", true);

    public Arrows() {
        super("Arrows", "Arrows around the crosshair that point at players.", Category.VISUALS);
        settings.add(range); settings.add(size); settings.add(radius); settings.add(distance);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
