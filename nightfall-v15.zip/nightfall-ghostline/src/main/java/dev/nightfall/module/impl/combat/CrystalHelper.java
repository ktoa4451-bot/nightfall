package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.AuraTargets;
import dev.nightfall.util.CrystalMath;
import dev.nightfall.util.NewBlocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Shows the best crystal spot and crystal damage (hints), and with AutoPlace on it puts an end crystal on obsidian that another
 * player has just placed near you (needs crystals in the hotbar or offhand). It only places; breaking is up to you or AutoCrystal.
 * Damage figures are estimates: armor, enchantments and walls are not included.
 */
public class CrystalHelper extends Module implements Tickable {
    public final Setting.IntSetting radius = new Setting.IntSetting("Radius", 4, 2, 6);
    public final Setting.IntSetting enemyRange = new Setting.IntSetting("EnemyRange", 10, 4, 12);
    public final Setting.DoubleSetting selfWeight = new Setting.DoubleSetting("SelfDamageWeight", 1.5, 0.5, 4.0);
    public final Setting.BooleanSetting autoPlace = new Setting.BooleanSetting("AutoPlace", true);
    public final Setting.DoubleSetting reach = new Setting.DoubleSetting("PlaceReach", 4.5, 2.0, 6.0);
    public final Setting.DoubleSetting triggerRange = new Setting.DoubleSetting("EnemyNearObsidian", 6.0, 2.0, 10.0);
    public final Setting.DoubleSetting minEnemyDmg = new Setting.DoubleSetting("MinEnemyDmg", 4.0, 0.0, 36.0);
    public final Setting.DoubleSetting maxSelfDmg = new Setting.DoubleSetting("MaxSelfDmg", 6.0, 0.0, 36.0);
    public final Setting.IntSetting delay = new Setting.IntSetting("Delay", 2, 1, 10);

    public static final List<String> LINES = new ArrayList<>();
    public static volatile BlockPos bestSpot;

    private final NewBlocks obsidianWatch = new NewBlocks();
    private final Map<Long, Integer> pending = new LinkedHashMap<>();   // obsidian position -> tick when it expires
    private int tick;

    public CrystalHelper() {
        super("CrystalHelper", "Crystal hints; AutoPlace puts a crystal on obsidian a player just placed.", Category.COMBAT);
        settings.add(radius); settings.add(enemyRange); settings.add(selfWeight);
        settings.add(autoPlace); settings.add(reach); settings.add(triggerRange); settings.add(minEnemyDmg); settings.add(maxSelfDmg); settings.add(delay);
    }

    @Override public void onEnable() { tick = 0; pending.clear(); obsidianWatch.reset(); }
    @Override public void onDisable() { LINES.clear(); bestSpot = null; pending.clear(); obsidianWatch.reset(); }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        tick++;
        if (autoPlace.getValue() && mc.gameMode != null && mc.screen == null && p.isAlive() && !p.isSpectator()) autoPlace(mc, p);
        if (tick % 10 == 0) hints(mc, p);
    }

    // ------------------------------------------------------------------ AutoPlace

    private void autoPlace(Minecraft mc, LocalPlayer p) {
        // 1) watch for obsidian that appears near an enemy (scanned a little wider than the reach so walking never makes old blocks "new")
        if (tick % 2 == 0) {
            int scan = (int) Math.ceil(reach.getValue()) + 3;
            BlockPos base = p.blockPosition();
            List<Long> now = new ArrayList<>();
            BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
            for (int dx = -scan; dx <= scan; dx++) for (int dy = -scan; dy <= scan; dy++) for (int dz = -scan; dz <= scan; dz++) {
                q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                if (mc.level.getBlockState(q).is(Blocks.OBSIDIAN)) now.add(q.asLong());
            }
            for (long l : obsidianWatch.update(now)) {
                BlockPos pos = BlockPos.of(l);
                if (Math.abs(pos.getX() - base.getX()) <= 1 && Math.abs(pos.getZ() - base.getZ()) <= 1 && Math.abs(pos.getY() - base.getY()) <= 1) continue;   // your own surround
                if (p.getEyePosition().distanceTo(Vec3.atCenterOf(pos)) > reach.getValue() + 1.5) continue;
                boolean enemyNear = false;
                for (Player o : mc.level.players())
                    if (o != p && o.isAlive() && !o.isSpectator() && o.distanceToSqr(Vec3.atCenterOf(pos)) <= triggerRange.getValue() * triggerRange.getValue()) { enemyNear = true; break; }
                if (enemyNear) pending.put(l, tick + 40);
            }
        }
        if (pending.isEmpty() || tick % delay.getValue() != 0) return;

        // 2) place one crystal on the first pending obsidian that is still valid
        ItemHand hand = ItemHand.find(p, Items.END_CRYSTAL);
        int diff = mc.level.getDifficulty().getId();
        double hp = p.getHealth() + p.getAbsorptionAmount();
        List<Player> enemies = new ArrayList<>();
        for (Player o : mc.level.players()) if (o != p && o.isAlive() && !o.isSpectator() && p.distanceTo(o) <= 14.0) enemies.add(o);

        var it = pending.entrySet().iterator();
        while (it.hasNext()) {
            var e = it.next();
            BlockPos base = BlockPos.of(e.getKey());
            if (tick > e.getValue() || !mc.level.getBlockState(base).is(Blocks.OBSIDIAN)) { it.remove(); continue; }
            if (hand == null) return;
            Vec3 top = new Vec3(base.getX() + 0.5, base.getY() + 1.0, base.getZ() + 0.5);
            if (p.getEyePosition().distanceTo(top) > reach.getValue()) continue;
            if (!mc.level.getBlockState(base.above()).isAir() || !mc.level.getBlockState(base.above(2)).isAir()) continue;
            if (!mc.level.getEntitiesOfClass(Entity.class, new AABB(base.getX(), base.getY() + 1, base.getZ(), base.getX() + 1, base.getY() + 3, base.getZ() + 1), x -> true).isEmpty()) continue;
            double self = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), top.x, top.y, top.z), 1.0, diff);
            double enemy = 0;
            for (Player o : enemies) enemy = Math.max(enemy, CrystalMath.rawDamage(CrystalMath.distance(o.getX(), o.getY(), o.getZ(), top.x, top.y, top.z), 1.0, diff));
            if (!AuraTargets.crystalWorth(enemy, self, hp, minEnemyDmg.getValue(), maxSelfDmg.getValue(), 2.0)) continue;
            hand.use(p, () -> mc.gameMode.useItemOn(p, hand.hand, new BlockHitResult(top, Direction.UP, base, false)));
            p.swing(hand.hand);
            it.remove();
            return;
        }
    }

    // ------------------------------------------------------------------ hints

    private void hints(Minecraft mc, LocalPlayer p) {
        List<String> lines = new ArrayList<>();
        BlockPos spot = null;
        int diff = mc.level.getDifficulty().getId();
        double hp = p.getHealth() + p.getAbsorptionAmount();
        for (EndCrystal c : mc.level.getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(8), Entity::isAlive)) {
            double d = CrystalMath.distance(p.getX(), p.getY(), p.getZ(), c.getX(), c.getY(), c.getZ());
            double self = CrystalMath.rawDamage(d, 1.0, diff);
            lines.add(String.format(Locale.ROOT, "Crystal %.1f m: up to %.0f damage to you%s", d, self, self >= hp ? " !!" : ""));
            if (lines.size() >= 3) break;
        }
        List<Player> enemies = new ArrayList<>();
        for (Player o : mc.level.players()) if (o != p && o.isAlive() && !o.isSpectator() && p.distanceTo(o) <= enemyRange.getValue()) enemies.add(o);
        if (!enemies.isEmpty()) {
            int r = radius.getValue();
            BlockPos base = p.blockPosition();
            BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
            double best = -999, bestEnemy = 0, bestSelf = 0;
            for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
                q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                BlockState b = mc.level.getBlockState(q);
                if (!b.is(Blocks.OBSIDIAN) && !b.is(Blocks.BEDROCK)) continue;
                if (!mc.level.getBlockState(q.above()).isAir() || !mc.level.getBlockState(q.above(2)).isAir()) continue;
                double cx = q.getX() + 0.5, cy = q.getY() + 1.0, cz = q.getZ() + 0.5;
                double self = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), cx, cy, cz), 1.0, diff);
                double enemy = 0;
                for (Player o : enemies) enemy = Math.max(enemy, CrystalMath.rawDamage(CrystalMath.distance(o.getX(), o.getY(), o.getZ(), cx, cy, cz), 1.0, diff));
                double sc = CrystalMath.score(enemy, self, hp, selfWeight.getValue());
                if (sc > best) { best = sc; spot = q.immutable(); bestEnemy = enemy; bestSelf = self; }
            }
            if (spot != null && best > 0) lines.add(String.format(Locale.ROOT, "Best spot %s: enemy up to %.0f, you up to %.0f (no armor)", spot.toShortString(), bestEnemy, bestSelf));
            else spot = null;
        }
        synchronized (LINES) { LINES.clear(); LINES.addAll(lines); }
        bestSpot = spot;
    }
}
