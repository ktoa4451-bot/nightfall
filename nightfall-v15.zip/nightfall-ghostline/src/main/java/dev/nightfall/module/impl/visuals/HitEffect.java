package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;

/** Particles around the entity you hit. Client side only: nobody else sees them. */
public class HitEffect extends Module {
    private final Setting.ModeSetting mode = new Setting.ModeSetting("Mode", new String[]{"Crit", "Magic", "Heart", "Flame", "Totem"}, 0);
    private final Setting.IntSetting count = new Setting.IntSetting("Count", 10, 1, 30);

    public HitEffect() {
        super("HitEffect", "Particles when you hit an entity.", Category.VISUALS);
        settings.add(mode); settings.add(count);
        AttackEntityCallback.EVENT.register((p, w, h, e, hit) -> {
            if (isEnabled()) spawn(e);
            return InteractionResult.PASS;
        });
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    private ParticleOptions particle() {
        switch (mode.getValue()) {
            case 1: return ParticleTypes.ENCHANTED_HIT;
            case 2: return ParticleTypes.HEART;
            case 3: return ParticleTypes.FLAME;
            case 4: return ParticleTypes.TOTEM_OF_UNDYING;
            default: return ParticleTypes.CRIT;
        }
    }

    private void spawn(Entity e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || e == null) return;
        ParticleOptions pt = particle();
        for (int i = 0; i < count.getValue(); i++) {
            double x = e.getX() + (Math.random() - 0.5) * e.getBbWidth();
            double y = e.getY() + Math.random() * e.getBbHeight();
            double z = e.getZ() + (Math.random() - 0.5) * e.getBbWidth();
            mc.level.addParticle(pt, x, y, z, (Math.random() - 0.5) * 0.4, Math.random() * 0.3, (Math.random() - 0.5) * 0.4);
        }
    }
}
