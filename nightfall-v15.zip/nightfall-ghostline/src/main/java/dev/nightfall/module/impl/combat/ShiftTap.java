package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.world.InteractionResult;

/** Crouches for a moment right after you hit something. */
public class ShiftTap extends Module implements Tickable {
    private final Setting.IntSetting ticks = new Setting.IntSetting("Ticks", 1, 1, 5);
    private int left;
    private boolean holding;

    public ShiftTap() {
        super("ShiftTap", "Crouches briefly after a hit.", Category.COMBAT);
        settings.add(ticks);
        AttackEntityCallback.EVENT.register((p, w, h, e, hit) -> {
            if (isEnabled()) left = ticks.getValue();
            return InteractionResult.PASS;
        });
    }

    @Override public void onEnable() { left = 0; }
    @Override public void onDisable() { release(Minecraft.getInstance()); left = 0; }

    private void release(Minecraft mc) {
        if (holding && mc.options != null) mc.options.keyShift.setDown(false);
        holding = false;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null || mc.player.isSpectator()) { release(mc); left = 0; return; }
        if (left > 0) {
            mc.options.keyShift.setDown(true);
            holding = true;
            left--;
        } else release(mc);
    }
}
