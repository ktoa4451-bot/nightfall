package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BedBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EnderChestBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Right click does not open chests, doors, buttons, tables and so on (hold shift to still use them). */
public class NoInteract extends Module {
    public NoInteract() {
        super("NoInteract", "Blocks right-click interaction with chests, doors, buttons etc. (not while sneaking).", Category.PLAYER);
        UseBlockCallback.EVENT.register((p, w, h, hit) -> {
            if (!isEnabled() || p.isShiftKeyDown()) return InteractionResult.PASS;
            return interactive(w, hit.getBlockPos()) ? InteractionResult.FAIL : InteractionResult.PASS;
        });
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    private static boolean interactive(Level w, BlockPos pos) {
        BlockState s = w.getBlockState(pos);
        Block b = s.getBlock();
        return s.getMenuProvider(w, pos) != null
            || b instanceof DoorBlock || b instanceof TrapDoorBlock || b instanceof FenceGateBlock
            || b instanceof ButtonBlock || b instanceof LeverBlock || b instanceof BedBlock || b instanceof EnderChestBlock;
    }
}
