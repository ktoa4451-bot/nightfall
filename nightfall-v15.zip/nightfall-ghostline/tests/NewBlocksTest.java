import dev.nightfall.util.NewBlocks;

import java.util.List;

public class NewBlocksTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }

    public static void main(String[] a) {
        NewBlocks nb = new NewBlocks();
        check("first call only records, nothing is new", nb.update(List.of(1L, 2L)).isEmpty());
        check("same blocks again are not new", nb.update(List.of(1L, 2L)).isEmpty());
        List<Long> f = nb.update(List.of(1L, 2L, 3L));
        check("a block that appears is reported once", f.size() == 1 && f.get(0) == 3L);
        check("and not reported again", nb.update(List.of(1L, 2L, 3L)).isEmpty());
        nb.update(List.of(1L, 2L));
        check("a block removed and placed again is new again", nb.update(List.of(1L, 2L, 3L)).size() == 1);
        nb.reset();
        check("after reset the next call only records", nb.update(List.of(9L)).isEmpty());
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
