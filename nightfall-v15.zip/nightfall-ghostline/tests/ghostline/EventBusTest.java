import com.ghostline.mod.event.EventBus;
import java.util.*;
import java.util.function.Consumer;
public class EventBusTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    public static void main(String[] a) {
        EventBus<String> bus = new EventBus<>(); List<String> got = new ArrayList<>();
        Consumer<String> l = got::add;
        bus.subscribe(l); bus.subscribe(l); bus.subscribe(null);
        check("same listener registered once, null ignored", bus.listenerCount() == 1);
        bus.subscribe(s -> { throw new IllegalStateException("bad listener"); });
        bus.subscribe(s -> got.add(s + "!"));
        bus.post("x");
        check("a failing listener does not stop the others", got.equals(List.of("x", "x!")));
        bus.unsubscribe(l); got.clear(); bus.post("y");
        check("unsubscribe works", got.equals(List.of("y!")));
        bus.clear(); check("clear", bus.listenerCount() == 0);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
