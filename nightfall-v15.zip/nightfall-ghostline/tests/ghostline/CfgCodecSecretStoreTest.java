import com.ghostline.mod.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class CfgCodecSecretStoreTest {
    static int pass, fail;
    static void check(String name, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + name); }
    static byte[] b(String s) { return s.getBytes(StandardCharsets.UTF_8); }

    public static void main(String[] a) throws Exception {
        Map<String, CfgCodec.Spec> schema = new HashMap<>();
        schema.put("Fly.on", CfgCodec.Spec.flag());
        schema.put("Fly.Speed", CfgCodec.Spec.number(0.1, 5));
        schema.put("Fly.Mode", CfgCodec.Spec.number(0, 2));
        schema.put("HUD.Title", CfgCodec.Spec.text());
        schema.put("BaseFinder.Telegram token", CfgCodec.Spec.sensitive());

        Map<String, String> vals = new LinkedHashMap<>();
        vals.put("Fly.on", "true"); vals.put("Fly.Speed", "2.5"); vals.put("Fly.Mode", "1.0"); vals.put("HUD.Title", "Привет мир \\ тест");
        String file = CfgCodec.write(vals, "1.0.0", "1.21.11");

        CfgCodec.Result r = CfgCodec.parse(b(file), schema, true);
        check("valid file accepted", r.ok() && r.values.size() == 4);
        check("text with backslash and unicode round-trips", "Привет мир \\ тест".equals(r.values.get("HUD.Title")));
        check("newline in text is sanitised on write", CfgCodec.parse(b(CfgCodec.write(Map.of("HUD.Title","a\nb"),"1","2")), schema, true).values.get("HUD.Title").equals("a b"));
        check("header read", r.format == 1 && r.mod.equals("1.0.0") && r.mc.equals("1.21.11"));

        // tampering
        check("edited value -> checksum mismatch", !CfgCodec.parse(b(file.replace("Fly.Speed=2.5", "Fly.Speed=4.9")), schema, true).ok());
        check("truncated file rejected", !CfgCodec.parse(b(file.substring(0, file.length() - 12)), schema, true).ok());
        // forged checksum but out of range value
        String body = "Fly.Speed=999\n";
        String forged = "#GHOSTLINE-CFG\nformat=1\nmod=x\nmc=y\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body;
        r = CfgCodec.parse(b(forged), schema, true);
        check("valid checksum but out-of-range value rejected", !r.ok() && r.firstError().contains("out of range"));
        body = "Fly.Speed=NaN\n";
        check("NaN rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true).ok());
        body = "Fly.Speed=1e999\n";
        check("huge exponent rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true).ok());
        body = "Fly.Mode=7\n";
        check("enum index out of range rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true).ok());
        body = "Fly.on=maybe\n";
        check("bad flag rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true).ok());
        body = "HUD.Title=" + "x".repeat(300) + "\n";
        check("overlong text rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true).ok());
        body = "Fly.Speed=1\nFly.Speed=2\n";
        check("duplicate key rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true).ok());

        // sensitive keys must never be imported
        body = "Fly.Speed=1\nBaseFinder.Telegram token=EVIL\n";
        r = CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true);
        check("sensitive key skipped, not applied", r.ok() && r.skippedSensitive == 1 && !r.values.containsKey("BaseFinder.Telegram token"));
        body = "Fly.Speed=1\nUnknown.Thing=5\n";
        r = CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true);
        check("unknown key ignored and counted", r.ok() && r.unknown == 1 && r.values.size() == 1);

        // structure / version
        check("wrong magic rejected", !CfgCodec.parse(b("hello\nworld"), schema, true).ok());
        check("newer format rejected", !CfgCodec.parse(b(file.replace("format=1", "format=9")), schema, true).ok());
        check("format 0 rejected", !CfgCodec.parse(b(file.replace("format=1", "format=0")), schema, true).ok());
        check("missing checksum rejected when required", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\n---\nFly.Speed=1\n"), schema, true).ok());
        check("missing checksum allowed for legacy", CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\n---\nFly.Speed=1\n"), schema, false).ok());
        check("empty rejected", !CfgCodec.parse(new byte[0], schema, true).ok());
        check("oversize rejected", !CfgCodec.parse(new byte[CfgCodec.MAX_BYTES + 1], schema, true).ok());
        check("binary garbage rejected", !CfgCodec.parse(new byte[]{(byte) 0xFF, (byte) 0xFE, 0, 1, 2, (byte) 0xC3, 0x28}, schema, true).ok());
        check("NUL byte rejected", !CfgCodec.parse(b(file + "\0"), schema, true).ok());
        body = "Bad\u0001Key=1\n";
        check("control char in key rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true).ok());
        body = "../../etc/passwd=1\n";
        check("path-like key rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\nsha256=" + CfgCodec.sha256(body) + "\n---\n" + body), schema, true).ok());
        check("no known settings rejected", !CfgCodec.parse(b("#GHOSTLINE-CFG\nformat=1\n---\nUnknown.A=1\n"), schema, false).ok());

        // fuzz: random mutations must never throw and never produce ok with out-of-range values
        Random rnd = new Random(42);
        int thrown = 0, accepted = 0;
        byte[] base = b(file);
        for (int i = 0; i < 20000; i++) {
            byte[] m = base.clone();
            int n = 1 + rnd.nextInt(4);
            for (int k = 0; k < n; k++) m[rnd.nextInt(m.length)] = (byte) rnd.nextInt(256);
            try {
                CfgCodec.Result x = CfgCodec.parse(m, schema, true);
                if (x.ok()) { accepted++; String sp = x.values.get("Fly.Speed"); if (sp != null) { double d = Double.parseDouble(sp); if (d < 0.1 - 1e-9 || d > 5 + 1e-9) thrown += 1000; } }
            } catch (Throwable t) { thrown++; }
        }
        check("fuzz 20000 mutations: no exceptions, no invalid values (accepted=" + accepted + ")", thrown == 0);

        // ---- SecretStore
        Path tmp = Files.createTempDirectory("gl");
        SecretStore.init(tmp);
        String enc = SecretStore.encrypt("123456:ABC-secret-token");
        check("encrypted has prefix and hides token", enc.startsWith("enc1:") && !enc.contains("secret") && !enc.contains("123456"));
        check("decrypt round trip", SecretStore.decrypt(enc).equals("123456:ABC-secret-token"));
        check("two encryptions differ (random IV)", !SecretStore.encrypt("x").equals(SecretStore.encrypt("x")));
        check("legacy plain text passes through", SecretStore.decrypt("plainvalue").equals("plainvalue"));
        check("tampered ciphertext -> empty, no exception", SecretStore.decrypt(enc.substring(0, enc.length() - 6) + "AAAAAA").isEmpty());
        check("garbage after prefix -> empty", SecretStore.decrypt("enc1:%%%").isEmpty());
        check("empty stays empty", SecretStore.encrypt("").isEmpty());
        SecretStore.init(Files.createTempDirectory("gl2")); // other dir = other salt = other key
        check("other salt cannot decrypt", SecretStore.decrypt(enc).isEmpty());
        System.out.println("\n" + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
}
