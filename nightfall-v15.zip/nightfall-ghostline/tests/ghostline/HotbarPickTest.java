import com.ghostline.mod.HotbarPick;

public class HotbarPickTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    public static void main(String[] a) {
        check("suffix: sword matches every sword, not a swordfish-like name", HotbarPick.matches("diamond_sword", "sword") && HotbarPick.matches("netherite_sword", "SWORD") && !HotbarPick.matches("sword_x", "sword") && !HotbarPick.matches("pickaxe", "axe") && HotbarPick.matches("diamond_axe", "axe"));
        check("pickaxe vs axe are different", HotbarPick.matches("iron_pickaxe", "pickaxe") && !HotbarPick.matches("iron_pickaxe", "axe"));
        check("aliases", HotbarPick.matches("golden_apple", "gapple") && HotbarPick.matches("enchanted_golden_apple", "gapple") && HotbarPick.matches("ender_pearl", "pearl") && HotbarPick.matches("end_crystal", "crystal") && HotbarPick.matches("firework_rocket", "rocket") && HotbarPick.matches("totem_of_undying", "totem"));
        check("an alias matches only its items", !HotbarPick.matches("apple", "gapple") && !HotbarPick.matches("ender_eye", "pearl") && HotbarPick.matches("crossbow", "bow"));
        check("exact registry path with prefix", HotbarPick.matches("shulker_box", "minecraft:shulker_box") && !HotbarPick.matches("shulker_box", ""));
        check("null and empty are safe", !HotbarPick.matches(null, "sword") && !HotbarPick.matches("sword", null) && !HotbarPick.matches("diamond_sword", "  "));
        String[] hb = {null, "diamond_sword", "ender_pearl", "golden_apple", "iron_sword", null, "ender_pearl", null, "end_crystal"};
        check("find: first match after the current slot", HotbarPick.find(hb, "sword", 0) == 1 && HotbarPick.find(hb, "pearl", 0) == 2);
        check("find: repeated press cycles through matching stacks", HotbarPick.find(hb, "sword", 1) == 4 && HotbarPick.find(hb, "sword", 4) == 1 && HotbarPick.find(hb, "pearl", 2) == 6 && HotbarPick.find(hb, "pearl", 6) == 2);
        check("find: wraps around the hotbar", HotbarPick.find(hb, "crystal", 8) == 8 && HotbarPick.find(hb, "gapple", 5) == 3);
        check("find: nothing -> -1", HotbarPick.find(hb, "totem", 0) == -1 && HotbarPick.find(new String[9], "sword", -1) == -1);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
