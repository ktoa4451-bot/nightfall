import com.ghostline.mod.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class FriendsProtocolTest {
    static int pass, fail;
    static String BASE = "http://127.0.0.1:18787";
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }

    static Map<String,String> http(String path, String body, String token, String method) throws Exception {
        HttpURLConnection c = (HttpURLConnection) URI.create(BASE + path).toURL().openConnection();
        c.setRequestMethod(method);
        if (token != null) c.setRequestProperty("Authorization", "Bearer " + token);
        if (body != null) { c.setDoOutput(true); c.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8)); }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        String t = new String(in.readAllBytes(), StandardCharsets.UTF_8);
        Map<String,String> m = MiniJson.decode(t); if (m == null) m = new HashMap<>();
        m.put("_code", String.valueOf(code));
        return m;
    }

    static class User implements SocialClient.Listener {
        String name, token; SocialClient c;
        BlockingQueue<Map<String,String>> q = new LinkedBlockingQueue<>();
        volatile String state = "";
        public void onEvent(Map<String,String> e) { q.add(e); }
        public void onState(String s) { state = s; }
        Map<String,String> next(String type, int ms) throws Exception {
            long end = System.currentTimeMillis() + ms;
            while (System.currentTimeMillis() < end) {
                Map<String,String> e = q.poll(100, TimeUnit.MILLISECONDS);
                if (e != null && type.equals(e.get("type"))) return e;
            }
            return null;
        }
        Map<String,String> send(Object... kv) throws Exception {
            Map<String,Object> m = new LinkedHashMap<>(); for (int i = 0; i < kv.length; i += 2) m.put((String) kv[i], kv[i+1]);
            CompletableFuture<Map<String,String>> f = new CompletableFuture<>(); c.send(m, f::complete); return f.get(5, TimeUnit.SECONDS);
        }
    }

    static User login(String name, String pass) throws Exception {
        http("/api/register", "{\"user\":\"" + name + "\",\"pass\":\"" + pass + "\"}", null, "POST");
        Map<String,String> p = http("/api/pair", "{\"user\":\"" + name + "\",\"pass\":\"" + pass + "\"}", null, "POST");
        Map<String,String> cl = SocialClient.claim(BASE, p.get("code"));
        User u = new User(); u.name = name; u.token = cl.get("token");
        u.c = new SocialClient(BASE, u.token, u); u.c.start();
        if (u.next("hello", 4000) == null) throw new IllegalStateException("no hello for " + name);
        return u;
    }

    public static void main(String[] a) throws Exception {
        // URL checks
        check("https accepted", SocialClient.checkUrl("https://example.com/").equals("https://example.com"));
        check("http localhost accepted", SocialClient.checkUrl("http://localhost:8787").equals("http://localhost:8787"));
        boolean rej = false; try { SocialClient.checkUrl("http://example.com"); } catch (IllegalArgumentException e) { rej = true; }
        check("plain http to remote host rejected", rej);
        rej = false; try { SocialClient.checkUrl("https://user:pw@example.com"); } catch (IllegalArgumentException e) { rej = true; }
        check("url with credentials rejected", rej);
        rej = false; try { SocialClient.checkUrl("ftp://example.com"); } catch (IllegalArgumentException e) { rej = true; }
        check("other scheme rejected", rej);

        // MiniJson
        check("json roundtrip", "a\"b\\c\nd".equals(MiniJson.decode(MiniJson.encode(new LinkedHashMap<>(Map.of("k", "a\"b\\c\nd")))).get("k")));
        check("json nested rejected", MiniJson.decode("{\"a\":{\"b\":1}}") == null);
        check("json garbage rejected", MiniJson.decode("{{{") == null && MiniJson.decode("") == null && MiniJson.decode(null) == null);

        // accounts
        check("short password rejected", http("/api/register", "{\"user\":\"Shorty\",\"pass\":\"abc\"}", null, "POST").get("_code").equals("400"));
        check("bad nickname rejected", http("/api/register", "{\"user\":\"a b\",\"pass\":\"password123\"}", null, "POST").get("_code").equals("400"));
        User al = login("Alice", "alicepass123"), bo = login("Bobby", "bobbypass123"), ca = login("Carol", "carolpass123");
        check("wrong password -> 401", http("/api/pair", "{\"user\":\"Alice\",\"pass\":\"nope12345\"}", null, "POST").get("_code").equals("401"));
        Map<String,String> p = http("/api/pair", "{\"user\":\"Alice\",\"pass\":\"alicepass123\"}", null, "POST");
        check("pairing code claimed once", SocialClient.claim(BASE, p.get("code")).containsKey("token"));
        check("pairing code is single use", SocialClient.claim(BASE, p.get("code")).containsKey("error"));
        check("bad pairing code rejected", SocialClient.claim(BASE, "ZZZZZZZZ").containsKey("error"));
        check("no token -> 401", http("/api/send", "{}", null, "POST").get("_code").equals("401"));
        check("fake token -> 401", http("/api/send", "{}", "deadbeef", "POST").get("_code").equals("401"));

        // friends
        check("friend request sent", al.send("type", "friend.add", "name", "Bobby").containsKey("ok"));
        check("bob receives request", bo.next("friend.request", 3000) != null);
        check("chat before friendship refused", al.send("type", "chat", "to", "Bobby", "text", "hi").get("_code") == null && "403".equals(al.send("type", "chat", "to", "Bobby", "text", "hi").get("status")));
        check("bob accepts", bo.send("type", "friend.accept", "name", "Alice").containsKey("ok"));
        check("alice gets friend.added", al.next("friend.added", 3000) != null);
        Map<String,String> st = al.next("friend.state", 3000);
        al.send("type", "friend.add", "name", "Carol"); ca.send("type", "friend.accept", "name", "Alice");

        // chat
        al.send("type", "chat", "to", "Bobby", "text", "hello bob");
        Map<String,String> m = bo.next("chat", 3000);
        check("private chat delivered", m != null && "hello bob".equals(m.get("text")) && "Alice".equals(m.get("from")) && "private".equals(m.get("scope")));
        check("carol did not get bob's private chat", ca.next("chat", 600) == null);
        al.send("type", "chat", "to", "*", "text", "hi all");
        check("broadcast to all friends", bo.next("chat", 3000) != null && ca.next("chat", 3000) != null);
        check("control chars stripped", "x y".equals(((Supplier) () -> { try { al.send("type","chat","to","Bobby","text","x\u0001y"); Map<String,String> e = bo.next("chat", 3000); return e == null ? null : e.get("text"); } catch (Exception ex) { return null; } }).get()));
        check("stranger cannot message", "403".equals(ca.send("type", "chat", "to", "Bobby", "text", "yo").get("status")));

        // status + privacy
        bo.q.clear(); al.q.clear();
        bo.send("type", "status", "state", "busy", "note", "raiding");
        Map<String,String> s1 = al.next("friend.state", 3000);
        check("status change reaches friends", s1 != null && "busy".equals(s1.get("state")) && "raiding".equals(s1.get("note")));
        bo.send("type", "status", "state", "invisible");
        Map<String,String> s2 = al.next("friend.state", 3000);
        check("invisible looks offline to friends", s2 != null && "offline".equals(s2.get("state")));
        bo.send("type", "status", "state", "online");
        bo.send("type", "privacy", "showOnline", "nobody", "friendRequests", "nobody");
        Map<String,String> s3 = null; for (int i = 0; i < 4 && (s3 == null || !"offline".equals(s3.get("state"))); i++) s3 = al.next("friend.state", 1500);
        check("privacy 'nobody' hides online status", s3 != null && "offline".equals(s3.get("state")));
        User dave = login("Dave", "davepass1234");
        check("friend requests can be disabled", "403".equals(dave.send("type", "friend.add", "name", "Bobby").get("status")));
        check("bad status falls back to online", bo.send("type", "status", "state", "hacker").containsKey("ok"));
        bo.send("type", "privacy", "showOnline", "friends", "friendRequests", "everyone");

        // help + coordinates
        al.q.clear(); bo.q.clear(); ca.q.clear();
        Map<String,String> h = al.send("type", "help", "text", "Under attack", "coords", false, "x", 100, "y", 64, "z", -200, "dim", "overworld");
        Map<String,String> hb = bo.next("help", 3000);
        check("help without consent has no coordinates", hb != null && !hb.containsKey("x") && "Under attack".equals(hb.get("text")) && "false".equals(h.get("coords")));
        Thread.sleep(50);
        Map<String,String> h2 = al.send("type", "help", "text", "With coords", "coords", true, "x", 100, "y", 64, "z", -200, "dim", "overworld");
        Map<String,String> hc = ca.next("help", 3000);
        while (hc != null && !"With coords".equals(hc.get("text"))) hc = ca.next("help", 1500);
        check("help with consent forwards coordinates", hc != null && "100".equals(hc.get("x")) && "-200".equals(hc.get("z")) && "overworld".equals(hc.get("dim")));
        check("dave (not a friend) got no help", dave.next("help", 600) == null);
        Map<String,String> h3 = al.send("type", "help", "coords", true, "x", 1e12, "y", 1, "z", 1);
        check("absurd coordinates dropped", "false".equals(h3.get("coords")) || "429".equals(h3.get("status")));
        Map<String,String> h4 = al.send("type", "help", "text", "again");
        check("help requests are rate limited", "429".equals(h4.get("status")));

        // abuse
        check("oversized body rejected", http("/api/send", "{\"type\":\"chat\",\"text\":\"" + "x".repeat(6000) + "\"}", al.token, "POST").get("_code").equals("413"));
        check("bad json rejected", http("/api/send", "not json", al.token, "POST").get("_code").equals("400"));
        check("unknown type rejected", "400".equals(al.send("type", "drop_tables").get("status")));
        int blocked = 0; for (int i = 0; i < 8; i++) if (http("/api/pair", "{\"user\":\"Alice\",\"pass\":\"wrongwrong1\"}", null, "POST").get("_code").equals("429")) blocked++;
        check("password guessing is rate limited", blocked > 0);

        // removal + logout
        check("remove friend", al.send("type", "friend.remove", "name", "Carol").containsKey("ok"));
        check("removed friend is notified", ca.next("friend.removed", 3000) != null);
        check("chat after removal refused", "403".equals(al.send("type", "chat", "to", "Carol", "text", "x").get("status")));
        al.c.logout();
        check("token revoked after logout", http("/api/send", "{}", al.token, "POST").get("_code").equals("401"));
        al.c.stop(); bo.c.stop(); ca.c.stop(); dave.c.stop();
        check("client reports stopped", al.state.equals("stopped"));
        System.out.println("\n" + pass + " passed, " + fail + " failed");
        System.exit(fail == 0 ? 0 : 1);
    }
    interface Supplier { String get(); }
}
