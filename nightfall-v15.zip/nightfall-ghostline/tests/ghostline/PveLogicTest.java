import com.ghostline.mod.SkyColors;
import com.ghostline.mod.automation.*;
import java.util.*;

public class PveLogicTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    static Map<String, Integer> m(Object... kv) { Map<String, Integer> r = new LinkedHashMap<>(); for (int i = 0; i < kv.length; i += 2) r.put((String) kv[i], (Integer) kv[i + 1]); return r; }

    public static void main(String[] a) {
        // ResourcePlan
        List<String> err = new ArrayList<>();
        Map<String, Integer> p = ResourcePlan.parse("Diamond:3, minecraft:iron_ingot:8;stick\nbad id!:2, gold:x, coal:0, diamond:2", err);
        check("parse: ids lowercased, prefix stripped, merged", p.equals(m("diamond", 5, "iron_ingot", 8, "stick", 1)));
        check("parse: bad entries reported (3)", err.size() == 3);
        check("parse null/empty", ResourcePlan.parse(null, null).isEmpty() && ResourcePlan.parse("  ,; ", null).isEmpty());
        check("missing / complete", ResourcePlan.missing(p, m("diamond", 2, "iron_ingot", 20)).equals(m("diamond", 3, "stick", 1)) && ResourcePlan.complete(p, m("diamond", 5, "iron_ingot", 8, "stick", 1)));
        check("format round trip", ResourcePlan.parse(ResourcePlan.format(p), null).equals(p));
        StringBuilder big = new StringBuilder(); for (int i = 0; i < 200; i++) big.append("item").append(i).append(":1,");
        check("entry limit enforced", ResourcePlan.parse(big.toString(), new ArrayList<>()).size() == ResourcePlan.MAX_ENTRIES);

        // LootLog
        LootLog log = new LootLog(20);
        check("first snapshot is only a baseline", log.update(m("dirt", 10), 1).isEmpty());
        check("gain is counted", log.update(m("dirt", 12, "diamond", 1), 2).equals(m("dirt", 2, "diamond", 1)));
        check("decrease (drop/craft) is not loot", log.update(m("dirt", 5, "diamond", 1), 3).isEmpty());
        check("regain after a decrease counts again", log.update(m("dirt", 6, "diamond", 1), 4).equals(m("dirt", 1)));
        check("totals", log.totals().equals(m("dirt", 3, "diamond", 1)));
        log.rebase(); check("rebase: next snapshot not counted", log.update(m("dirt", 99), 5).isEmpty() && log.totals().get("dirt") == 3);
        check("top n with filter", log.top(5, Set.of("diamond")).size() == 1 && log.top(1, null).get(0).getKey().equals("dirt"));
        LootLog small = new LootLog(10); small.update(m(), 0); for (int i = 1; i <= 50; i++) small.update(m("x", i), i);
        check("journal is bounded", small.journal().size() == 10);
        log.reset(); check("reset clears everything", log.totals().isEmpty() && log.journal().isEmpty());

        // MineTargets on a flat world with a stone block at (10,63,10) (feet level 63, floor 62)
        WorldView w = (x, y, z) -> (x == 10 && y == 63 && z == 10) ? WorldView.Kind.SOLID : (y < 63 ? WorldView.Kind.SOLID : WorldView.Kind.AIR);
        Pathfinder pf = new Pathfinder(w, null);
        List<int[]> sp = MineTargets.standSpots(pf, 10, 63, 10, 0, 63, 0);
        check("stand spots found around the block", !sp.isEmpty());
        boolean allOk = true; for (int[] s : sp) { if (!pf.standable(s[0], s[1], s[2])) allOk = false; if (s[0] == 10 && s[2] == 10) allOk = false; }
        check("all spots standable and not inside the block", allOk);
        check("nearest spot first", sp.get(0)[0] <= sp.get(sp.size() - 1)[0] + 4 && Math.abs(sp.get(0)[0] - 0) + Math.abs(sp.get(0)[2] - 0) <= Math.abs(sp.get(sp.size() - 1)[0]) + Math.abs(sp.get(sp.size() - 1)[2]));
        WorldView allSolid = (x, y, z) -> WorldView.Kind.SOLID;
        check("buried block with no free neighbours: no spots", MineTargets.standSpots(new Pathfinder(allSolid, null), 5, 5, 5, 0, 0, 0).isEmpty());

        // WardenFsm
        WardenFsm f = new WardenFsm(); f.mode = WardenFsm.Mode.EVADE; f.escapeAvailable = true;
        f.step(5); check("disabled ignores everything", f.state == WardenFsm.State.DISABLED);
        f.enable(true); check("enable -> IDLE", f.state == WardenFsm.State.IDLE);
        f.step(Double.NaN); check("no warden: stays IDLE", f.state == WardenFsm.State.IDLE);
        f.step(30); check("seen far: DETECTED, no warning yet", f.state == WardenFsm.State.DETECTED && !f.justWarned);
        f.step(18); check("inside warn distance: WARNING once", f.state == WardenFsm.State.WARNING && f.justWarned);
        f.step(17); check("no repeated warning flag", !f.justWarned);
        f.step(10); check("inside evade distance with a route: EVADING", f.state == WardenFsm.State.EVADING && f.wantEvade());
        f.step(14); check("hysteresis: still EVADING at 14 (limit 12*1.5=18)", f.state == WardenFsm.State.EVADING);
        f.step(25); check("far enough: back to WARNING", f.state == WardenFsm.State.WARNING);
        f.step(Double.NaN); check("lost: SAFE", f.state == WardenFsm.State.SAFE);
        for (int i = 0; i < 60; i++) f.step(Double.NaN);
        check("calm long enough: IDLE", f.state == WardenFsm.State.IDLE);
        f.escapeAvailable = false; f.step(10); f.step(10);
        check("no escape route: WARNING only, never EVADING", f.state == WardenFsm.State.WARNING);
        WardenFsm alert = new WardenFsm(); alert.enable(true); alert.step(5); alert.step(5);
        check("ALERT mode never evades", alert.state == WardenFsm.State.WARNING);
        alert.pause(true); alert.step(3); check("PAUSED ignores", alert.state == WardenFsm.State.PAUSED);
        alert.pause(false); check("unpause -> IDLE", alert.state == WardenFsm.State.IDLE);
        alert.enable(false); check("disable", alert.state == WardenFsm.State.DISABLED);
        WardenFsm far = new WardenFsm(); far.enable(true); far.step(500); check("outside the radius is ignored", far.state == WardenFsm.State.IDLE);

        // SkyColors
        check("argb: opaque, channels clamped", SkyColors.argb(1, 2, 3) == 0xFF010203 && SkyColors.argb(-5, 300, 0) == 0xFF00FF00);
        check("rainbow: starts red, a third round later green, two thirds blue", SkyColors.rainbow(0, 9000, 1f, 1f) == 0xFFFF0000 && SkyColors.rainbow(3000, 9000, 1f, 1f) == 0xFF00FF00 && SkyColors.rainbow(6000, 9000, 1f, 1f) == 0xFF0000FF);
        check("rainbow: wraps and stays valid for any time", SkyColors.rainbow(9000, 9000, 1f, 1f) == SkyColors.rainbow(0, 9000, 1f, 1f) && (SkyColors.rainbow(123456789L, 5000, 0.5f, 1f) >>> 24) == 0xFF);
        check("hsb: saturation 0 is grey, brightness 0 is black", SkyColors.hsb(0.3f, 0f, 0.5f) == SkyColors.argb(128, 128, 128) && SkyColors.hsb(0.7f, 1f, 0f) == 0xFF000000);
        float[] fr = SkyColors.fogRange(50, 20);
        check("fog range: end is always at least 4 behind start, no negatives", fr[1] >= fr[0] + 4 && SkyColors.fogRange(-5, 10)[0] == 0f && SkyColors.fogRange(10, 100)[1] == 100f);

        // PauseGate
        PauseGate g = new PauseGate(1500, 30000);
        check("gate: no danger -> nothing", g.update(false, 0) == PauseGate.Action.NONE && !g.paused());
        check("gate: danger -> PAUSE at once", g.update(true, 1000) == PauseGate.Action.PAUSE && g.paused());
        check("gate: danger continues -> nothing new", g.update(true, 2000) == PauseGate.Action.NONE);
        check("gate: calm for less than 1.5 s -> still paused", g.update(false, 3000) == PauseGate.Action.NONE && g.paused());
        check("gate: danger comes back, calm timer restarts", g.update(true, 3200) == PauseGate.Action.NONE && g.update(false, 4500) == PauseGate.Action.NONE);
        check("gate: calm for 1.5 s -> RESUME once", g.update(false, 4800) == PauseGate.Action.RESUME && !g.paused() && g.update(false, 5000) == PauseGate.Action.NONE);
        PauseGate g2 = new PauseGate(1500, 30000); g2.update(true, 0);
        for (long tt = 1000; tt < 30000; tt += 1000) g2.update(true, tt);
        check("gate: mob never leaves -> GIVE_UP after 30 s", g2.update(true, 30000) == PauseGate.Action.GIVE_UP && !g2.paused());
        g2.update(true, 31000); g2.reset(); check("gate: reset clears the state", !g2.paused());

        // Waypoints
        Waypoints wp = new Waypoints();
        check("waypoint set ok", wp.set("Home", 10, 64, -5, "minecraft:overworld") == null && wp.get("HOME").x() == 10);
        check("waypoint: bad names rejected", wp.set("bad name", 0, 0, 0, "") != null && wp.set("", 0, 0, 0, "") != null && wp.set("x".repeat(30), 0, 0, 0, "") != null);
        wp.set("mine", 1, 2, 3, "a;b=c,d");
        Waypoints back = Waypoints.parse(wp.format());
        check("waypoint: format/parse round trip (dimension text sanitised)", back.all().size() == 2 && back.get("mine").z() == 3 && !back.get("mine").dim().contains(";"));
        check("waypoint: broken data skipped, not fatal", Waypoints.parse("x=1,2;ok=1,2,3,d;=5,5,5;q=a,b,c;;").all().size() == 1);
        check("waypoint: remove", wp.remove("home") && !wp.remove("home") && wp.get("home") == null);
        Waypoints full = new Waypoints(); String last = null; for (int i = 0; i < 40; i++) last = full.set("p" + i, i, 0, 0, "");
        check("waypoint: limit enforced", full.all().size() == Waypoints.MAX && last != null && full.set("p0", 9, 9, 9, "") == null);

        // TaskReport
        TaskManager tm = new TaskManager();
        AutomationTask demo = new AutomationTask("Demo", 1, 0) {
            protected AutomationResult onStart(long n) { return AutomationResult.success("go"); }
            protected AutomationResult onTick(long n) { return n > 5000 ? AutomationResult.success("all done") : null; }
            protected void onStop(TaskState s, String r) { }
        };
        tm.submit(demo);
        check("report: queued task shown", TaskReport.lines(tm, 0, 3).get(0).startsWith("Demo [IDLE]"));
        tm.tick(1000, true);
        check("report: running task with time", TaskReport.lines(tm, 4000, 3).get(0).startsWith("Demo [RUNNING] 3s"));
        tm.tick(6000, true);
        check("report: finished task shows its result", TaskReport.lines(tm, 7000, 3).get(0).equals("Demo [COMPLETED]  all done"));
        check("report: history limit and duration format", TaskReport.lines(tm, 7000, 0).isEmpty() && TaskReport.duration(125000).equals("2m05s") && TaskReport.duration(-5) .equals("0s"));

        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
