import com.ghostline.mod.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
public class DebounceAsyncPerfTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    public static void main(String[] a) throws Exception {
        // ---- Debounce: a slider drag = thousands of save() calls
        Debounce d = new Debounce(400);
        int writes = 0; long t = 0;
        for (int i = 0; i < 5000; i++) { t += 1; d.mark(t); if (d.take(t)) writes++; }   // 5 s of dragging, one change per ms
        check("5000 changes over 5 s -> " + writes + " writes (instead of 5000)", writes >= 11 && writes <= 13);
        Debounce d2 = new Debounce(400); d2.mark(0); d2.mark(100); d2.mark(399);
        check("not due before the delay", !d2.take(399));
        check("due once after the delay", d2.take(400) && !d2.take(401));
        Debounce d3 = new Debounce(400); d3.mark(0);
        check("takeNow flushes pending changes at shutdown, once", d3.takeNow() && !d3.takeNow() && !d3.take(10_000));
        check("no changes -> never due", !new Debounce(10).take(1_000_000));

        // ---- Async: shared threads, ordered I/O
        int before = Thread.activeCount();
        List<Integer> order = Collections.synchronizedList(new ArrayList<>());
        for (int i = 0; i < 2000; i++) { final int k = i; Async.io(() -> order.add(k)); }
        Async.flushIo(5000);
        boolean ordered = order.size() == 2000; for (int i = 0; i < order.size() && ordered; i++) ordered = order.get(i) == i;
        check("2000 io tasks run in order on one thread", ordered);
        AtomicInteger ran = new AtomicInteger();
        for (int i = 0; i < 500; i++) Async.net(ran::incrementAndGet);
        for (int i = 0; i < 100 && ran.get() < 500; i++) Thread.sleep(20);
        int after = Thread.activeCount();
        check("500 net tasks done, thread count grew by " + (after - before) + " (a thread per task would be 500)", ran.get() == 500 && after - before <= 5);
        AtomicInteger conc = new AtomicInteger(), max = new AtomicInteger(); CountDownLatch done = new CountDownLatch(9);
        for (int i = 0; i < 9; i++) Async.net(() -> { int c = conc.incrementAndGet(); max.accumulateAndGet(c, Math::max); try { Thread.sleep(50); } catch (Exception e) { } conc.decrementAndGet(); done.countDown(); });
        done.await(5, TimeUnit.SECONDS);
        check("net pool is bounded (max parallel = " + max.get() + ")", max.get() <= 3 && max.get() >= 2);
        AtomicBoolean afterThrow = new AtomicBoolean();
        Async.io(() -> { throw new RuntimeException("boom"); });
        Async.io(() -> afterThrow.set(true)); Async.flushIo(2000);
        check("a failing task does not kill the worker", afterThrow.get());
        long t0 = System.nanoTime(); Async.io(() -> { try { Thread.sleep(150); } catch (Exception e) { } }); Async.flushIo(2000);
        check("flushIo waits for queued work", System.nanoTime() - t0 >= 140_000_000L);
        long t1 = System.nanoTime(); for (int i = 0; i < 10000; i++) Async.io(() -> { }); long enqueue = System.nanoTime() - t1;
        check("enqueueing 10000 writes costs the caller " + enqueue / 1_000_000 + " ms in total (never blocks)", enqueue < 500_000_000L);
        Async.flushIo(5000);

        // ---- Perf
        Perf.reset();
        check("disabled Perf costs nothing", Perf.start() == 0L);
        Perf.enabled = true;
        long p1 = Perf.start(); Thread.sleep(5); Perf.end("slow", p1);
        long p2 = Perf.start(); Perf.end("fast", p2);
        List<String> rep = Perf.report();
        check("report sorted by average cost, slowest first", rep.size() == 2 && rep.get(0).startsWith("slow") && rep.get(1).startsWith("fast"));
        Perf.end("ignored", 0L);
        check("end() with a disabled start is ignored", Perf.report().size() == 2);
        Perf.reset(); check("reset clears", Perf.report().isEmpty());
        System.out.println("\n" + pass + " passed, " + fail + " failed"); System.exit(fail == 0 ? 0 : 1);
    }
}
