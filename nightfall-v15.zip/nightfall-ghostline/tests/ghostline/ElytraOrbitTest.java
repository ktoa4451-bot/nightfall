import com.ghostline.mod.ElytraOrbit;
import com.ghostline.mod.ElytraOrbit.State;

public class ElytraOrbitTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    static double len(double[] v) { return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); }

    public static void main(String[] a) {
        // target at origin, we are 6 blocks east (radius 6): flying clockwise seen from above means going toward -z... check tangent is perpendicular to the radius
        double[] v = ElytraOrbit.desired(6, 70, 0, 0, 70, 0, 6, 0, true, State.ORBIT);
        check("orbit: unit vector", Math.abs(len(v) - 1) < 1e-9);
        check("orbit at the right radius: moves along the tangent (no radial part)", Math.abs(v[0]) < 1e-9 && Math.abs(v[2]) > 0.99);
        double[] ccw = ElytraOrbit.desired(6, 70, 0, 0, 70, 0, 6, 0, false, State.ORBIT);
        check("clockwise and counter-clockwise go opposite ways", v[2] * ccw[2] < 0);
        double[] far = ElytraOrbit.desired(12, 70, 0, 0, 70, 0, 6, 0, true, State.ORBIT);
        check("too far out: pulled inward (negative x)", far[0] < 0);
        double[] near = ElytraOrbit.desired(2, 70, 0, 0, 70, 0, 6, 0, true, State.ORBIT);
        check("too close in: pushed outward (positive x)", near[0] > 0);
        double[] up = ElytraOrbit.desired(6, 60, 0, 0, 70, 0, 6, 0, true, State.ORBIT), down = ElytraOrbit.desired(6, 80, 0, 0, 70, 0, 6, 0, true, State.ORBIT);
        check("below the wanted height: climbs; above: dives", up[1] > 0 && down[1] < 0);
        check("height offset is respected", ElytraOrbit.desired(6, 70, 0, 0, 70, 0, 6, 4, true, State.ORBIT)[1] > 0);
        double[] onTop = ElytraOrbit.desired(0, 70, 0, 0, 70, 0, 6, 0, true, State.ORBIT);
        check("exactly above the target: still a valid unit direction", Math.abs(len(onTop) - 1) < 1e-9 && !Double.isNaN(onTop[0]));
        double[] s = ElytraOrbit.desired(10, 70, 0, 0, 64, 0, 6, 0, true, State.STRIKE);
        check("strike: straight at the target (west and down)", s[0] < -0.85 && s[1] < 0 && Math.abs(len(s) - 1) < 1e-9);
        // yaw/pitch: Minecraft yaw 0 = +z (south), -90 = +x (east)... our formula
        check("yaw for +z is 0, for -x is 90 and for +x is -90", Math.abs(ElytraOrbit.yawDeg(new double[]{0, 0, 1})) < 1e-9 && Math.abs(ElytraOrbit.yawDeg(new double[]{-1, 0, 0}) - 90) < 1e-9 && Math.abs(ElytraOrbit.yawDeg(new double[]{1, 0, 0}) + 90) < 1e-9);
        check("pitch: up is negative, down positive", ElytraOrbit.pitchDeg(new double[]{0, 1, 0}) < -89 && ElytraOrbit.pitchDeg(new double[]{0, -1, 0}) > 89 && Math.abs(ElytraOrbit.pitchDeg(new double[]{0, 0, 1})) < 1e-9);
        // state machine
        check("orbit stays orbit before strikeAfter", ElytraOrbit.next(State.ORBIT, 10, 6, true, false, 20, 20) == State.ORBIT);
        check("orbit -> strike when ready and close enough", ElytraOrbit.next(State.ORBIT, 20, 6, true, false, 20, 20) == State.STRIKE);
        check("no strike when the attack is on cooldown or too far", ElytraOrbit.next(State.ORBIT, 99, 6, false, false, 20, 20) == State.ORBIT && ElytraOrbit.next(State.ORBIT, 99, 50, true, false, 20, 20) == State.ORBIT);
        check("strike -> orbit after a hit", ElytraOrbit.next(State.STRIKE, 3, 2, true, true, 20, 20) == State.ORBIT);
        check("strike -> orbit after passing through", ElytraOrbit.next(State.STRIKE, 3, 0.5, true, false, 20, 20) == State.ORBIT);
        check("strike -> orbit on timeout", ElytraOrbit.next(State.STRIKE, ElytraOrbit.STRIKE_MAX_TICKS, 8, true, false, 20, 20) == State.ORBIT && ElytraOrbit.next(State.STRIKE, 5, 8, true, false, 20, 20) == State.STRIKE);
        // wall avoidance
        double[] ahead = {1, 0, 0}, wallN = {-1, 0, 0};
        double[] av = ElytraOrbit.avoid(ahead, wallN, 1.0);
        check("avoid: turns away from the wall and climbs, still a unit vector", av[0] < 0.5 && av[1] > 0.2 && Math.abs(len(av) - 1) < 1e-9);
        double[] far2 = ElytraOrbit.avoid(ahead, wallN, 0.0);
        check("avoid: wall far away changes nothing", Math.abs(far2[0] - 1) < 1e-9 && Math.abs(far2[1]) < 1e-9);
        check("avoid: stronger when closer", ElytraOrbit.avoid(ahead, wallN, 1.0)[0] < ElytraOrbit.avoid(ahead, wallN, 0.4)[0]);
        double[] glanc = ElytraOrbit.avoid(new double[]{0, 0, 1}, new double[]{1, 0, 0}, 0.8);
        check("avoid: side wall pushes sideways", glanc[0] > 0.3);
        // fireworks
        check("rocket: only when slow", ElytraOrbit.needRocket(0.5, 1.0, 100, 15, 0, 10) && !ElytraOrbit.needRocket(1.4, 1.0, 100, 15, 0, 10));
        check("rocket: respects the gap and the budget", !ElytraOrbit.needRocket(0.5, 1.0, 5, 15, 0, 10) && !ElytraOrbit.needRocket(0.5, 1.0, 100, 15, 10, 10));
        // simulation: a point flying along the desired vector at constant speed stays near the orbit radius
        double x = 9, y = 70, z = 0, sp = 1.0; double maxDev = 0;
        for (int t = 0; t < 400; t++) { double[] d = ElytraOrbit.desired(x, y, z, 0, 70, 0, 6, 0, true, State.ORBIT); x += d[0] * sp; y += d[1] * sp; z += d[2] * sp; if (t > 150) maxDev = Math.max(maxDev, Math.abs(Math.hypot(x, z) - 6)); }
        check("simulation: after settling the flight path stays within 3 blocks of the radius (dev " + String.format("%.2f", maxDev) + ")", maxDev < 3.0 && Math.abs(y - 70) < 3);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
