import com.ghostline.mod.*;
import java.util.*;
public class HudLayoutToastQueueTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    public static void main(String[] a) {
        // ---------------- HudLayout
        check("default layout serialises to empty", HudLayout.serialize().isEmpty());
        HudLayout.Entry w = HudLayout.get("watermark");
        HudLayout.setPosition(w, 100, 50, 200, 16, 640, 360);
        check("position stored as fractions", w.custom && Math.abs(w.fx - 100f / 440f) < 1e-6 && Math.abs(w.fy - 50f / 344f) < 1e-6);
        int[] p = HudLayout.position(w, 200, 16, 640, 360);
        check("position round trip", p[0] == 100 && p[1] == 50);
        int[] p2 = HudLayout.position(w, 200, 16, 1280, 720);
        check("position adapts to a bigger window (same relative place)", Math.abs(p2[0] - 245) <= 1 && p2[0] > p[0]);
        HudLayout.setPosition(w, -500, 9999, 200, 16, 640, 360);
        check("positions are clamped to 0..1", w.fx == 0f && w.fy == 1f);
        w.scale = HudLayout.clampScale(9f); check("scale clamped to max", w.scale == 2.0f);
        check("scale clamped to min", HudLayout.clampScale(0.01f) == 0.5f);
        check("NaN scale -> 1", HudLayout.clampScale(Float.NaN) == 1f);
        w.scale = 1.3f;
        HudLayout.get("coords").enabled = false;
        String s = HudLayout.serialize();
        HudLayout.resetAll();
        check("reset clears everything", HudLayout.serialize().isEmpty() && !HudLayout.get("watermark").custom);
        int bad = HudLayout.parse(s);
        check("parse restores layout", bad == 0 && HudLayout.get("watermark").custom && HudLayout.get("watermark").scale == 1.3f && !HudLayout.get("coords").enabled);
        check("serialise is stable", s.equals(HudLayout.serialize()));
        bad = HudLayout.parse("watermark,1,0.5,0.5,1.0,1;bogus,1,0,0,1,1;coords,2,0,0,1,1;armor,1,abc,0,1,1;target,1,0.2,0.2");
        check("bad entries skipped (" + bad + ")", bad == 4 && HudLayout.get("watermark").custom);
        HudLayout.parse("watermark,1,9.5,-3,7.0,1");
        check("out-of-range values clamped", HudLayout.get("watermark").fx == 1f && HudLayout.get("watermark").fy == 0f && HudLayout.get("watermark").scale == 2.0f);
        check("oversized text refused", HudLayout.parse("x".repeat(5000)) == 1);
        check("null/blank ok", HudLayout.parse(null) == 0 && HudLayout.parse("  ") == 0);
        Random r = new Random(3); int ex = 0;
        for (int i = 0; i < 20000; i++) { StringBuilder b = new StringBuilder(); for (int k = 0; k < 80; k++) b.append("0123456789.,;-abwx".charAt(r.nextInt(18))); try { HudLayout.parse(b.toString()); } catch (Throwable t) { ex++; } }
        check("fuzz 20000 random layouts: no exceptions", ex == 0);
        HudLayout.resetAll();

        // ---------------- ToastQueue
        ToastQueue q = new ToastQueue();
        long t0 = 1000;
        for (int i = 0; i < 6; i++) q.push(ToastQueue.Type.INFO, "T", "msg" + i, 4000, false, t0);
        q.update(t0, 3);
        check("max visible respected", q.visible().size() == 3 && q.pendingCount() == 3);
        check("order is first in first out", q.visible().get(0).text.equals("msg0"));
        q.update(t0 + 4000 + ToastQueue.EXIT_MS + 1, 3);
        check("finished toasts are removed and queue advances", q.visible().size() == 3 && q.visible().get(0).text.equals("msg3"));
        q.clear();
        q.push(ToastQueue.Type.INFO, "T", "same", 3000, false, t0); q.update(t0, 4);
        q.push(ToastQueue.Type.INFO, "T", "same", 3000, false, t0 + 500);
        check("identical toast is merged (x2)", q.visible().size() == 1 && q.visible().get(0).count == 2);
        long end1 = q.visible().get(0).endAt;
        check("merge extends the lifetime", end1 == t0 + 500 + 3000);
        q.push(ToastQueue.Type.WARN, "T", "same", 3000, false, t0 + 600);
        check("different type is not merged", q.pendingCount() == 1);
        q.clear();
        for (int i = 0; i < 4; i++) q.push(ToastQueue.Type.INFO, "T", "n" + i, 3000, false, t0);
        q.push(ToastQueue.Type.WARN, "HELP", "urgent", 3000, true, t0);
        q.update(t0, 1);
        check("urgent toast jumps the queue", q.visible().get(0).text.equals("urgent"));
        q.clear();
        for (int i = 0; i < 500; i++) q.push(ToastQueue.Type.INFO, "T", "x" + i, 3000, false, t0);
        check("pending queue is bounded", q.pendingCount() <= ToastQueue.MAX_PENDING);
        q.clear();
        q.push(ToastQueue.Type.INFO, "T", "anim", 2000, false, 0); q.update(0, 4);
        ToastQueue.Toast t = q.visible().get(0);
        check("animation: starts hidden", ToastQueue.presence(t, 0) == 0f);
        check("animation: fully shown after enter", ToastQueue.presence(t, ToastQueue.ENTER_MS) == 1f && ToastQueue.presence(t, 1000) == 1f);
        float mid = ToastQueue.presence(t, ToastQueue.ENTER_MS / 2);
        check("animation: eased in between (" + mid + ")", mid > 0.5f && mid < 1f);
        check("animation: exit goes back to 0", ToastQueue.presence(t, 2000 + ToastQueue.EXIT_MS) == 0f && ToastQueue.presence(t, 2000 + ToastQueue.EXIT_MS / 2) > 0f);
        check("progress bar 1 -> 0", ToastQueue.remaining(t, 0) == 1f && Math.abs(ToastQueue.remaining(t, 1000) - 0.5f) < 1e-6 && ToastQueue.remaining(t, 5000) == 0f);
        q.clear(); q.push(ToastQueue.Type.INFO, "T", "d", 5, false, 0); q.update(0, 1);
        check("duration lower bound", q.visible().get(0).durationMs >= 800);
        q.clear(); q.push(ToastQueue.Type.INFO, null, null, 99_999_999, false, 0); q.update(0, 1);
        check("duration upper bound and null text ok", q.visible().get(0).durationMs <= 30_000);
        // concurrency
        ToastQueue cq = new ToastQueue(); List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < 4; i++) { final int id = i; Thread th = new Thread(() -> { for (int k = 0; k < 2000; k++) { cq.push(ToastQueue.Type.INFO, "T", "c" + id + "_" + (k % 50), 2000, false, k); cq.update(k, 3); cq.visible(); } }); ts.add(th); th.start(); }
        boolean ok = true; try { for (Thread th : ts) th.join(); } catch (Exception e) { ok = false; }
        check("4 threads pushing/updating: no exceptions, bounded", ok && cq.visible().size() <= 3);
        System.out.println("\n" + pass + " passed, " + fail + " failed"); System.exit(fail == 0 ? 0 : 1);
    }
}
