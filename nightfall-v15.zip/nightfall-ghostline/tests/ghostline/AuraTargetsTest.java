import com.ghostline.mod.AuraTargets;
import com.ghostline.mod.AuraTargets.Cand;
import java.util.*;

public class AuraTargetsTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    public static void main(String[] a) {
        List<Cand> c = List.of(new Cand(1, 2.5, 20, 40, true), new Cand(2, 1.5, 18, 100, true), new Cand(3, 2.0, 4, 10, true), new Cand(4, 5.0, 1, 0, true));
        check("distance mode picks the closest in range", AuraTargets.pick(c, 3.0, 360, AuraTargets.DISTANCE, false) == 1);
        check("health mode picks the weakest in range", AuraTargets.pick(c, 3.0, 360, AuraTargets.HEALTH, false) == 2);
        check("angle mode picks the one nearest the crosshair", AuraTargets.pick(c, 3.0, 360, AuraTargets.ANGLE, false) == 2);
        check("out of range is never picked (id 4 has 1 hp but is 5 m away)", AuraTargets.pick(c, 3.0, 360, AuraTargets.HEALTH, false) != 3);
        check("nothing in range -> -1", AuraTargets.pick(c, 1.0, 360, AuraTargets.DISTANCE, false) == -1 && AuraTargets.pick(List.of(), 3, 360, 0, false) == -1);
        check("fov 90 keeps only angle <= 45", AuraTargets.pick(c, 3.0, 90, AuraTargets.DISTANCE, false) == 2 && AuraTargets.pick(List.of(new Cand(9, 1, 20, 60, true)), 3, 90, 0, false) == -1);
        List<Cand> v = List.of(new Cand(1, 1.0, 20, 0, false), new Cand(2, 2.0, 20, 0, true));
        check("needVisible skips targets behind walls", AuraTargets.pick(v, 3, 360, 0, true) == 1 && AuraTargets.pick(v, 3, 360, 0, false) == 0);
        List<Cand> tie = List.of(new Cand(1, 2.0, 10, 5, true), new Cand(2, 1.0, 10, 5, true));
        check("tie on the key falls back to distance", AuraTargets.pick(tie, 3, 360, AuraTargets.HEALTH, false) == 1);
        check("crystal: enough damage, safe -> go", AuraTargets.crystalWorth(12, 2, 20, 6, 6, 2));
        check("crystal: too little enemy damage -> no", !AuraTargets.crystalWorth(3, 1, 20, 6, 6, 2));
        check("crystal: too much self damage -> no", !AuraTargets.crystalWorth(30, 8, 20, 6, 6, 2));
        check("crystal: would leave you at the margin -> no", !AuraTargets.crystalWorth(30, 5, 6, 6, 6, 2) && AuraTargets.crystalWorth(30, 3, 6, 6, 6, 2));
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
