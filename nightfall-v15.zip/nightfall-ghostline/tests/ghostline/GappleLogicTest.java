import com.ghostline.mod.GappleLogic;
import com.ghostline.mod.GappleLogic.Action;
import com.ghostline.mod.GappleLogic.Phase;

public class GappleLogicTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    static Action s(GappleLogic g, double hp, double abs, boolean using, boolean have, boolean allowed) { return g.step(hp, abs, using, have, allowed, 10, 4, 30, 50); }

    public static void main(String[] a) {
        GappleLogic g = new GappleLogic();
        check("healthy: nothing", s(g, 20, 0, false, true, true) == Action.NONE && g.phase == Phase.IDLE);
        check("low health but no apple: nothing", s(g, 5, 0, false, false, true) == Action.NONE);
        check("low health but not allowed (no enemy near): nothing", s(g, 5, 0, false, true, false) == Action.NONE);
        check("absorption already high: do not eat again", s(g, 5, 4, false, true, true) == Action.NONE);
        check("low health + apple: START", s(g, 8, 0, false, true, true) == Action.START && g.phase == Phase.EATING);
        check("holding while the apple is being eaten", s(g, 8, 0, true, true, true) == Action.NONE && s(g, 8, 0, true, true, true) == Action.NONE && g.phase == Phase.EATING);
        Action f1 = s(g, 14, 4, false, true, true); Action f2 = s(g, 14, 4, false, true, true);
        check("apple finished (not using any more): STOP -> cooldown (short grace period first)", f1 == Action.NONE && f2 == Action.STOP && g.phase == Phase.COOLDOWN);
        boolean noEat = true; for (int i = 0; i < 29; i++) if (s(g, 3, 0, false, true, true) != Action.NONE) noEat = false;
        check("no new START during the cool-down", noEat && g.phase == Phase.COOLDOWN);
        s(g, 3, 0, false, true, true);
        check("cool-down over: IDLE again and eats when still low", g.phase == Phase.IDLE && s(g, 3, 0, false, true, true) == Action.START);
        GappleLogic h = new GappleLogic(); s(h, 5, 0, false, true, true);
        Action last = Action.NONE; int n = 0; while (last != Action.STOP && n < 100) { last = s(h, 5, 0, true, true, true); n++; }
        check("stuck 'using' state is cut off after maxEat ticks (" + n + ")", last == Action.STOP && n <= 51);
        GappleLogic k = new GappleLogic(); s(k, 5, 0, false, true, true);
        check("conditions disappear mid-eat (enemy gone): STOP", s(k, 5, 0, true, true, false) == Action.STOP);
        k.reset(); check("reset", k.phase == Phase.IDLE);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
