import com.ghostline.mod.*;
import java.util.*;

public class InvSortCrystalMathTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    static String[] apply(String[] k, List<int[]> plan) { String[] c = k.clone(); for (int[] s : plan) { String t = c[s[0]]; c[s[0]] = c[s[1]]; c[s[1]] = t; } return c; }

    public static void main(String[] a) {
        String[] k = {"minecraft:stone", null, "minecraft:apple", "minecraft:stone", "", "minecraft:bread", "minecraft:apple"};
        List<int[]> plan = InvSort.plan(k);
        String[] r = apply(k, plan);
        boolean ordered = true; for (int i = 0; i + 1 < r.length; i++) { String x = r[i] == null || r[i].isEmpty() ? InvSort.EMPTY : r[i], y = r[i + 1] == null || r[i + 1].isEmpty() ? InvSort.EMPTY : r[i + 1]; if (x.compareTo(y) > 0) ordered = false; }
        check("plan sorts by id, empty slots last", ordered);
        check("at most n-1 swaps (" + plan.size() + ")", plan.size() <= k.length - 1);
        check("sorted input -> empty plan", InvSort.plan(r).isEmpty() && InvSort.isSorted(r));
        check("equal keys are never swapped with each other", InvSort.plan(new String[]{"a", "a", "a"}).isEmpty());
        check("all empty -> empty plan", InvSort.plan(new String[]{null, "", null}).isEmpty());
        Random rnd = new Random(7); boolean okAll = true;
        for (int t = 0; t < 300 && okAll; t++) {
            String[] x = new String[27]; for (int i = 0; i < 27; i++) x[i] = rnd.nextInt(4) == 0 ? null : "item" + rnd.nextInt(8);
            String[] y = apply(x, InvSort.plan(x));
            List<String> ax = new ArrayList<>(), ay = new ArrayList<>();
            for (String s : x) ax.add(s == null ? "" : s); for (String s : y) ay.add(s == null ? "" : s);
            Collections.sort(ax); Collections.sort(ay);
            okAll = ax.equals(ay) && InvSort.isSorted(y);   // same items, nothing lost, result sorted
        }
        check("300 random inventories: nothing lost or duplicated, always sorted", okAll);

        // crystal damage: vanilla values for normal difficulty
        check("distance 0 normal: 85 (upper bound)", CrystalMath.rawDamage(0, 1, 2) == 85);
        check("distance 12+: no damage", CrystalMath.rawDamage(12, 1, 2) == 0 && CrystalMath.rawDamage(30, 1, 2) == 0);
        check("damage falls with distance", CrystalMath.rawDamage(2, 1, 2) > CrystalMath.rawDamage(5, 1, 2) && CrystalMath.rawDamage(5, 1, 2) > CrystalMath.rawDamage(9, 1, 2));
        check("peaceful 0, hard 1.5x", CrystalMath.rawDamage(3, 1, 0) == 0 && CrystalMath.rawDamage(3, 1, 3) == CrystalMath.rawDamage(3, 1, 2) * 1.5);
        check("exposure scales damage down", CrystalMath.rawDamage(3, 0.5, 2) < CrystalMath.rawDamage(3, 1, 2) && CrystalMath.rawDamage(3, 0, 2) == 0);
        check("score: a spot that can kill you is rejected", CrystalMath.score(30, 20, 20, 1) == -1000.0);
        check("score: safer spot with same enemy damage wins", CrystalMath.score(20, 2, 20, 1) > CrystalMath.score(20, 8, 20, 1));
        check("distance helper", Math.abs(CrystalMath.distance(0, 0, 0, 3, 4, 0) - 5) < 1e-9);
        System.out.println(pass + " passed, " + fail + " failed");
        if (fail > 0) System.exit(1);
    }
}
