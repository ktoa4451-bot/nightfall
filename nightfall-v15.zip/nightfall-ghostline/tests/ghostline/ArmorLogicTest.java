import com.ghostline.mod.ArmorLogic;

public class ArmorLogicTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    public static void main(String[] a) {
        check("slots", ArmorLogic.slotOf("netherite_helmet", false) == 0 && ArmorLogic.slotOf("iron_chestplate", false) == 1 && ArmorLogic.slotOf("golden_leggings", false) == 2 && ArmorLogic.slotOf("leather_boots", false) == 3 && ArmorLogic.slotOf("turtle_helmet", false) == 0);
        check("not armor: -1 (sword, null, pumpkin)", ArmorLogic.slotOf("diamond_sword", false) == -1 && ArmorLogic.slotOf(null, false) == -1 && ArmorLogic.slotOf("carved_pumpkin", false) == -1);
        check("elytra is a chest piece only when asked", ArmorLogic.slotOf("elytra", false) == -1 && ArmorLogic.slotOf("elytra", true) == 1);
        double nNew = ArmorLogic.score("netherite_chestplate", 0, 592), dNew = ArmorLogic.score("diamond_chestplate", 0, 528), iNew = ArmorLogic.score("iron_chestplate", 0, 240), lNew = ArmorLogic.score("leather_chestplate", 0, 80);
        check("tiers: netherite > diamond > iron > leather", nNew > dNew && dNew > iNew && iNew > lNew);
        check("a half-worn diamond piece still beats a new iron one", ArmorLogic.score("diamond_boots", 200, 429) > ArmorLogic.score("iron_boots", 0, 195));
        check("a nearly broken piece is worthless (even netherite)", ArmorLogic.score("netherite_helmet", 360, 363) == 0.0);
        check("durability breaks ties inside one tier", ArmorLogic.score("iron_leggings", 10, 225) > ArmorLogic.score("iron_leggings", 150, 225));
        check("better(): needs the margin", ArmorLogic.better(4.9, 4.0, 0.5) && !ArmorLogic.better(4.3, 4.0, 0.5) && ArmorLogic.better(0.1, -1.0, -1.0));
        check("two equal pieces never swap", !ArmorLogic.better(ArmorLogic.score("iron_helmet", 0, 165), ArmorLogic.score("iron_helmet", 0, 165), 0.3));
        check("unbreakable items (maxDamage 0) score by tier only", Math.abs(ArmorLogic.score("diamond_helmet", 0, 0) - 4.9) < 1e-9);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
