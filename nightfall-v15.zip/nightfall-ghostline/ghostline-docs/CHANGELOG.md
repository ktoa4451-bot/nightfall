# 1.8.1 - build fix (NOT built: no Gradle/Minecraft in the authoring sandbox)

Fixed: version 1.5.3 had added a second Config.WAYPOINTS field and a second module named "Waypoints" next to the existing one (compile error and a config name clash). The extra module is gone; `/glpoint set|del|list|go` now works on the existing waypoint list (the one with its own window and HUD), without dimension memory.

# 1.8.0 - custom sky, fog, weather (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- CustomSky module: sky, fog and cloud colours (RGB), fog start/end distance, star brightness and an optional rainbow for sky and fog. It hooks the 1.21.11 environment attribute system (SKY_COLOR, FOG_COLOR, CLOUD_COLOR, FOG_START/END_DISTANCE, STAR_BRIGHTNESS) through two mixins in their own OPTIONAL config (ghostline.sky.mixins.json, required: false, require = 0): if those targets differ in your exact game version they do nothing and the rest of the mod is unaffected. Targets taken from the 1.21.11 mappings: EnvironmentAttributeProbe.getValue(attribute, float) and EnvironmentAttributeSystem.getDimensionValue(attribute).
- Weather got Rain strength and Thunder strength sliders (client side only).
- SkyColors helper (colours, rainbow, fog range) with 5 logic checks. Not tested in game.

# 1.7.6 - HotbarBinds (NOT built: no Gradle/Minecraft in the authoring sandbox)

- HotbarBinds: 4 key binds, each selects the matching hotbar item by short name (sword, gapple, pearl, crystal, rocket, totem, pot, web, shield, bow, axe, ...); pressing again cycles through several stacks. Only selects a slot, never with a screen open. 10 logic checks. Not tested in game.

# 1.7.5 - HoleESP (NOT built: no Gradle/Minecraft in the authoring sandbox)

- HoleESP: marks 1x1 holes near you (green = all bedrock, orange = bedrock/obsidian, red = closed but breakable, optional). Scan every N ticks, at most 40 marks, screen overlay. 10 logic checks. Not tested in game.

# 1.7.4 - AutoSurround (NOT built: no Gradle/Minecraft in the authoring sandbox)

- AutoSurround: keeps obsidian on the four sides of your feet. Plans only cells that have a block under them (clicks the top face), a few blocks per step, skips cells with an entity in them, restores the slot, stops when you move unless you stand still. 8 logic checks. Not tested in game.

# 1.7.3 - AutoArmor (NOT built: no Gradle/Minecraft in the authoring sandbox)

- AutoArmor: wears the best armor found in the inventory (tier + durability left; a nearly broken piece counts as worthless), fills empty slots, replaces only clearly better pieces, keeps the elytra on by default, one swap per step, never with a screen open or an item on the cursor. 10 logic checks. Not tested in game.

# 1.7.2 - AutoGapple (NOT built: no Gradle/Minecraft in the authoring sandbox)

- AutoGapple: eats a golden apple at low health (picks the hotbar slot, holds the use key until eaten, restores the slot, cool-down; enchanted apple in an emergency; skips when absorption is already high; optional "only with enemies near"). State machine has 11 logic checks. Not tested in game.

# 1.7.1

- ElytraTarget avoids walls: it looks 12 blocks along the wanted direction and steers away from the surface it would hit (and climbs). Not used during the strike dive. 4 new logic checks. Not tested in game.

# 1.7.0 - ElytraTarget (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- ElytraTarget: while gliding it circles the nearest non-friend player at the set radius, dives in for a hit once the attack is ready (after the strike delay), returns to orbiting after the hit/pass, and fires a rocket when speed drops below "Min speed" (off hand first, then hotbar; budget per target; warns when out of rockets). Optional auto deploy (one jump press in the air), pulls up near the ground, pauses below the HP limit. 20 logic checks incl. a flight simulation.
- Not tested in game, no wall avoidance, NOT an anticheat bypass: servers with an anticheat can flag or ban it.

# 1.6.1

- TargetHUD shows the KillAura target while KillAura has one (otherwise the entity under the crosshair, as before).

# 1.6.0 - KillAura + AutoCrystal (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- KillAura: picks the best target (distance / health / angle, FOV, line of sight, friends excluded), turns smoothly and hits when the cooldown is ready; by default only when the crosshair is on the target; vanilla reach 3.
- AutoCrystal: breaks crystals and places them on obsidian/bedrock only when the enemy takes at least "Min enemy damage", you take at most "Max self damage" and would stay above "Safety margin" HP (upper-bound estimate, no armor); one action per delay.
- AuraTargetsTest (12 checks). These modules are NOT an anticheat bypass and were not tested in game: servers with an anticheat can flag or ban them.

# 1.5.8 - pause near hostile mobs (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- AutoNav (and every task that walks through it: AutoMine, AutoWarden, WardenGuard) pauses while a hostile mob is within "Mob pause range", resumes after 1.5 s of calm, and cancels the task if the mob stays for 30 s. PauseGate logic has 8 checks. Not tested in game.

# 1.5.7 - walker polish (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- Walker sprints on straight stretches (setting "Sprint on straight routes", needs food above 6, off when turning, climbing or in water) and keeps swimming up in water when the route allows water.
- Not tested in game.

# 1.5.6 - tunnelling (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- Pathfinder can dig: BREAKABLE blocks cost extra, so walking around is preferred; it never plans a fall through blocks that still have to be dug. 7 new logic checks.
- AutoMine setting "Tunnel through rock" (off by default): digs a route to ores that cannot be reached on foot. A block is only dug when it is not bedrock/unbreakable, not a chest or other block entity, has no liquid next to it, no sand/gravel above it, and all neighbours are loaded; the same check runs again right before each dig. The Walker digs with the best hotbar tool and respects the per-block time limit.
- Not tested in game.

# 1.5.5 - drop collection + profiles (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- AutoMine picks up the drops of the block it just mined (setting "Collect drops": nearest item within a few blocks, max 6 s, skipped when unreachable).
- `/glprofile save|load|delete <name>` and `/glprofile list`: named setting profiles on top of the existing export/import (same validation, secrets are never exported).
- Not tested in game.

# 1.5.4 - AutoWarden without Baritone (NOT built: no Gradle/Minecraft in the authoring sandbox)

Changed
- AutoWarden now walks to the farm point with the built-in Automation API by default (new setting "Navigation": Ghostline / Baritone). When the route task ends or stalls it asks again every 4 s; threat handling, eating, death/respawn and Telegram are unchanged. Baritone is only required when you pick it.
- `AutoNav.goWalk()`: starts a walking task regardless of the AutoNav module state (used by AutoWarden).
- Not tested in game: the walking itself.

# 1.5.3 - waypoints (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- Waypoints module: `/glpoint set|del|list|go <name>`, nearest point + distance on the HUD, points saved in the config (dimension is remembered, `go` refuses another dimension). 6 new logic checks (suites total 279).

# 1.5.2 - ladders + task dashboard (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- Pathfinder climbs ladders, vines and scaffolding (up and down, setting "Climb ladders and vines"); Walker holds jump/forward on a ladder. 6 new logic checks.
- TaskDashboard module and `/gltasks`: running, queued and last finished tasks with stage, time and result. TaskReport tests included.
- Test suites now 273 checks, all pass.

# 1.5.1 - PvE assistants on the Automation API (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- AutoMine `/glmine ids [radius] [preview]`: finds matching blocks, picks a reachable standing spot (own A*), walks, picks the best hotbar tool, mines with a line-of-sight check; skips blocks that cannot be reached (no tunnelling), stops on full inventory / worn tool / hostile mob / timeout.
- WardenGuard (+ `/glescape set|check|go`): state machine DISABLED-IDLE-DETECTED-WARNING-EVADING-SAFE with hysteresis; Alert / Assist / Evade modes. No guarantee, keep your own escape plan.
- MobTracker, LootTracker (`/glloot`), CombatAssist reminders, ResourcePlan (`/glplan`), AutoEnd info + `/glend` checklist.
- AutoNav Walker extracted so every task walks the same way. Tests: PveLogicTest (36 checks); suite total 263.

# 1.5.0 - Automation API + helper modules (NOT built: no Gradle/Minecraft in the authoring sandbox)

New
- Automation API (`automation/`, pure Java, covered by 44 logic checks): TaskManager (priorities, pause/resume/cancel, timeouts that ignore pauses,
  exactly one movement task at a time, exceptions -> FAILED + cleanup, emergency stop), A* Pathfinder (surface walking, jump 1, fall up to N,
  lava/fire/cactus avoided, unknown/unloaded blocks never walked, node + time budget, optional partial route).
- AutoNav module + `/glgo x y z [preview]`, `/glstop`: Preview draws the route (screen overlay), Walk follows it with smooth turning,
  stuck detection, bounded re-planning, stop on low HP / death / world loss / open screen.
- AutoClicker (random CPS between Min and Max, hold-to-click, attack cooldown respected), InventoryHelper (low-slot warning, free slots on HUD,
  sort key with the inventory screen open: main inventory only, one swap per N ticks, aborts if the cursor holds an item),
  CrystalHelper (hints only: best obsidian/bedrock spot + damage upper bound, never places or hits anything), TargetHUD (animated health, armor, distance, held item).
- Event bus (`event/`): CLIENT_TICK posted every client tick.
- Tests: AutomationTest, InvSortCrystalMathTest, EventBusTest (tools/run-tests.sh: 227 checks in total, all pass).

Not done (needs real work and in-game testing): Dashboard, AI Aura / AI Training, Theme Studio, Profile Manager UI, Auto Mine, Auto End, Loot Tracker,
Resource Planner, Escape Assistant, Mob Tracker, BaseFinder -> AutoNav hand-off, AutoWarden on the new API (it still uses Baritone).

# Changelog

## 1.4.0 - Mega Update (parts 1-4)

> Status: the sources are complete; the Gradle build has not been run by the author of this update (no network in the
> authoring environment). Build it with the included GitHub Actions workflow and check the "Verify jar" step.

### New modules
- **BaseFinder** - scans loaded chunks for player-made blocks (score), marks containers (Chest ESP), groups them, notifies in chat / toasts / your own Telegram bot, keeps a journal. Works only on data the client has.
- **TreeFarm** - finds trees, picks an axe, chops the trunk within reach, collects logs, stops on danger / no tool / full inventory / lost path, shows statistics.
- **PlayerESP** - Box, Corners, 3D, Filled, Tracers, Arrows, Health, Armor, Names (screen overlay, first person).
- **Weather** - client-side clear / rain / thunder.
- **FriendsHelp** - friends, statuses, chat and help requests through a Ghostline server (`server/`). Coordinates only on your explicit confirmation. Passwords never reach the game.
- **RaidAssistant** - saved bases with a second point and route, valuables list, loot accounting, wear / totem / slot warnings, container hints, optional auto-take and auto-return (off by default), emergency stop.
- **InvisibilityHelper** - own invisibility timer and reminders, potion count, players the server flags as invisible.
- **Notifications** - toast queue with animations, per-source switches.

### Interface
- **HUD editor** (menu > HUD, `/glhud`, or a key): drag, snap, resize, show/hide, reset; positions saved as screen fractions.
- Watermark in three styles (Ghostline / Compact / Minimal) with FPS, version, ping, nick, clock.
- Module manager: favorites, sorting (A-Z / enabled first / favorites first), better search, hotkey conflict check, duplicate highlighting.
- Menu: animated page changes and search results, animation speed setting, tooltips, adaptive layout (tested for 320x240 and up).

### Config Manager
- Export / import `.cfg` files (format version, checksum, strict validation), share codes `GL1.`, backups before import.
- Tokens, chat ids and server addresses are never exported or imported; an import can neither switch on automation nor steal your hotkeys.
- Tokens in `ghostline.properties` are stored encrypted. A damaged settings file is set aside as `ghostline.properties.corrupt`.

### Performance
- Config saves are batched and written off the game thread; file and network work uses shared background pools.
- ESP entity query once per tick; cached HUD lists; adaptive BaseFinder scan budget; `/glperf` shows per-module cost.

### Fixes
- Watermark settings were unreachable in the menu (they are on the HUD page now).
- Raid stop key no longer fires while typing in chat or binding keys.
- AutoWarden sends Telegram through the shared, redirect-safe sender.

### Known limitations
- Not verified in a real client: visuals of the HUD editor / toasts / menu animations, TreeFarm and Raid behaviour, performance numbers.
- No time-of-day or particle settings, no in-world (3D) ESP outlines, TreeFarm cuts only logs within arm's reach.
- No Event Bus: Fabric's client tick and HUD callbacks are the only event sources.
