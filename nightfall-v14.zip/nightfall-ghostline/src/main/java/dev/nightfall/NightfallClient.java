package dev.nightfall;

import dev.nightfall.config.ConfigManager;
import com.mojang.blaze3d.platform.InputConstants;
import dev.nightfall.event.EventHandler;
import dev.nightfall.module.ModuleManager;
import dev.nightfall.module.impl.combat.*;
import dev.nightfall.module.impl.misc.Fullbright;
import dev.nightfall.module.impl.misc.WaypointCommands;
import dev.nightfall.module.impl.misc.Waypoints;
import dev.nightfall.module.impl.movement.*;
import dev.nightfall.module.impl.player.AutoArmor;
import dev.nightfall.module.impl.player.AutoGapple;
import dev.nightfall.module.impl.player.AutoTool;
import dev.nightfall.module.impl.player.Nuker;
import dev.nightfall.module.impl.player.Scaffold;
import dev.nightfall.module.impl.visuals.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NightfallClient implements ClientModInitializer {
    public static final String MOD_ID = "nightfall";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static NightfallClient instance;

    public ModuleManager moduleManager;
    public ConfigManager configManager;
    public EventHandler eventHandler;
    public KeyMapping openGuiKey;

    public static NightfallClient getInstance() {
        return instance;
    }

    @Override
    public void onInitializeClient() {
        instance = this;

        // Менеджеры
        configManager = new ConfigManager();
        moduleManager = new ModuleManager();
        eventHandler = new EventHandler();

        // Duplicates of Ghostline modules (KillAura, AimAssist, AutoCrystal, ElytraTarget, TriggerBot, AutoTotem, Surround, AutoPearl, ESP, HoleESP,
        // CustomSky, TargetHud, Sprint, Speed, AutoGapple, AutoArmor, AutoTool, Fullbright, Waypoints) are not registered: the Ghostline version is used.

        // === COMBAT ===
        moduleManager.register(new ReachDisplay());
        moduleManager.register(new ShieldBreaker());
        moduleManager.register(new HitSelect());
        moduleManager.register(new WTap());
        moduleManager.register(new MaceHelper());
        moduleManager.register(new AutoPotion());
        moduleManager.register(new Offhand());
        moduleManager.register(new AutoWeb());
        moduleManager.register(new CrystalHelper());
        moduleManager.register(new AnchorHelper());
        moduleManager.register(new Hitboxes());
        moduleManager.register(new Velocity());

        // === VISUALS ===
        moduleManager.register(new CpsCounter());
        moduleManager.register(new Keystrokes());
        moduleManager.register(new CustomCrosshair());
        moduleManager.register(new ItemESP());
        moduleManager.register(new TargetInfo());
        moduleManager.register(new CombatLog());
        moduleManager.register(new XRay());

        // === MOVEMENT ===
        moduleManager.register(new Step());
        moduleManager.register(new SafeWalk());
        moduleManager.register(new Jesus());
        moduleManager.register(new Spider());
        moduleManager.register(new ElytraFly());
        moduleManager.register(new Parkour());

        // === PLAYER ===
        moduleManager.register(new Scaffold());
        moduleManager.register(new Nuker());
        moduleManager.register(new dev.nightfall.module.impl.player.AutoRespawn());
        moduleManager.register(new dev.nightfall.module.impl.player.AntiAfk());
        moduleManager.register(new dev.nightfall.module.impl.player.FastUse());
        moduleManager.register(new dev.nightfall.module.impl.player.FreeCam());
        moduleManager.register(new dev.nightfall.module.impl.combat.HitSound());
        moduleManager.register(new dev.nightfall.module.impl.combat.ShiftTap());
        moduleManager.register(new dev.nightfall.module.impl.combat.TapeMouse());
        moduleManager.register(new dev.nightfall.module.impl.combat.BowSpammer());
        moduleManager.register(new dev.nightfall.module.impl.player.NoInteract());
        moduleManager.register(new dev.nightfall.module.impl.player.NoEntityTrace());
        moduleManager.register(new dev.nightfall.module.impl.player.NoPush());
        moduleManager.register(new dev.nightfall.module.impl.visuals.HpAlert());
        moduleManager.register(new dev.nightfall.module.impl.visuals.Arrows());
        moduleManager.register(new dev.nightfall.module.impl.visuals.BlockOutline());
        moduleManager.register(new dev.nightfall.module.impl.visuals.JumpCircle());
        moduleManager.register(new dev.nightfall.module.impl.visuals.ChinaHat());
        moduleManager.register(new dev.nightfall.module.impl.visuals.Prediction());
        moduleManager.register(new dev.nightfall.module.impl.visuals.SeeInvisible());
        moduleManager.register(new dev.nightfall.module.impl.visuals.HitEffect());

        // === MISC ===

        // === MISC ===
        moduleManager.register(new dev.nightfall.module.impl.misc.AutoLeave());
        moduleManager.register(new dev.nightfall.module.impl.misc.AutoTpAccept());

        // Ghostline modules (shown in the same menu)
        dev.nightfall.bridge.GhostBridge.register(moduleManager);

        // Клавиша меню
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
        "key.nightfall.opengui",
        InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_RIGHT_SHIFT,
        KeyMapping.Category.MISC
       ));

        // Тик
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            eventHandler.onTick(client);
            while (openGuiKey.consumeClick()) {
                if (client.screen == null) {
                    dev.nightfall.gui.ClickGUI.open();
                }
            }
        });

        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING.register(c -> configManager.save("default"));

        // HUD и Рендер
        new dev.nightfall.hud.HudManager().register();
        dev.nightfall.render.WorldRenderer.register();

        // Конфиг
        configManager.load("default");

        LOGGER.info("Nightfall Client initialized. Modules: {}", moduleManager.getModules().size());
    }
}