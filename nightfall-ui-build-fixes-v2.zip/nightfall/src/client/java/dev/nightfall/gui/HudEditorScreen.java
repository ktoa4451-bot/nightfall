package dev.nightfall.gui;

import dev.nightfall.NightfallClient;
import dev.nightfall.hud.element.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class HudEditorScreen extends Screen {
    private final ArrayListElement arrayList = new ArrayListElement();
    private final WatermarkElement watermark = new WatermarkElement();
    private final CpsElement cps = new CpsElement();
    private final KeystrokesElement keystrokes = new KeystrokesElement();
    private Object dragging;
    private double lastX, lastY;

    public HudEditorScreen() { super(Component.literal("HUD Editor")); }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        for (int i=0;i<width;i+=20) g.fill(i,0,i+1,height,0x22FFFFFF);
        for (int i=0;i<height;i+=20) g.fill(0,i,width,i+1,0x22FFFFFF);
        // HUD preview is rendered by the in-game HUD; keep this editor screen API-compatible.
        g.drawString(font, "HUD Editor - ESC to exit", 10, 10, 0xFFFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        if (event.button() == 0) { dragging = watermark; lastX = event.x(); lastY = event.y(); return true; }
        return super.mouseClicked(event, doubleClick);
    }
    @Override public boolean mouseDragged(MouseButtonEvent event, double dx, double dy) {
        if (dragging != null) {
            int x = (int)(event.x()); int y = (int)(event.y());
            if (dragging instanceof WatermarkElement e) e.setPosition(x,y);
            lastX = event.x(); lastY = event.y(); return true;
        }
        return super.mouseDragged(event, dx, dy);
    }
    @Override public boolean mouseReleased(MouseButtonEvent event) { dragging = null; return super.mouseReleased(event); }
    @Override public void onClose() { NightfallClient.getInstance().configManager.save("hud_layout"); super.onClose(); }
    @Override public boolean isPauseScreen() { return false; }
}
