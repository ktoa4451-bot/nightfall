package dev.nightfall.render;

/** Rendering hook disabled pending migration to the Minecraft 1.21.11 render pipeline. */
public final class WorldRenderer {
    private WorldRenderer() {}
    public static void register() { }
}
