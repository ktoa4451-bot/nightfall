#!/bin/sh
# Pure-Java logic tests (no Minecraft needed). They test the maths in dev.nightfall.util, not the game behaviour.
set -e
cd "$(dirname "$0")/.."
OUT=$(mktemp -d)
SRC=src/main/java/dev/nightfall/util
if command -v javac >/dev/null 2>&1; then JC="javac"; else JC="java -m jdk.compiler/com.sun.tools.javac.Main"; fi
$JC -d "$OUT" $SRC/SurroundLogic.java $SRC/HoleLogic.java $SRC/SkyColors.java $SRC/Waypoints.java $SRC/MoveMath.java $SRC/CritLogic.java $SRC/MaceMath.java $SRC/OffhandLogic.java $SRC/DamageLog.java $SRC/CrystalMath.java $SRC/FallTracker.java $SRC/OreKinds.java $SRC/CubeCursor.java $SRC/Anim.java $SRC/AuraTargets.java tests/*.java
for t in HoleLogicTest SurroundLogicTest UtilTest PvpLogicTest XrayTest AnimTest; do java -cp "$OUT" $t | tail -1; done
echo ALL TESTS PASSED
