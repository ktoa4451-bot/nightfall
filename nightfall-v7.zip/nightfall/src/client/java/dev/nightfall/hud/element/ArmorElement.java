package dev.nightfall.hud.element;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

public class ArmorElement implements HudElement {
    private int x = 10;
    private int y = 10;

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        EquipmentSlot[] slots = {
                EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
        };

        int currentY = y;
        for (EquipmentSlot slot : slots) {
            ItemStack stack = client.player.getItemBySlot(slot);
            if (stack.isEmpty()) continue;

            int maxDamage = stack.getMaxDamage();
            int currentDamage = stack.getDamageValue();
            int durability = maxDamage - currentDamage;
            float percent = maxDamage > 0 ? (float) durability / maxDamage : 1.0f;

            // Фон
            g.fill(x, currentY, x + 80, currentY + 18, 0xCC15151C);
            // Название предмета
            g.drawString(client.font, stack.getHoverName().getString(), x + 4, currentY + 2, 0xFFFFFFFF);
            // Полоса прочности
            int barWidth = (int) (72 * percent);
            int color = percent > 0.5f ? 0xFF55FF55 : (percent > 0.25f ? 0xFFFFFF55 : 0xFFFF5555);
            g.fill(x + 4, currentY + 12, x + 76, currentY + 15, 0xFF333333);
            g.fill(x + 4, currentY + 12, x + 4 + barWidth, currentY + 15, color);

            currentY += 20;
        }
    }
}