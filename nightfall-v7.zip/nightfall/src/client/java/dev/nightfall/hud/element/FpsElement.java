package dev.nightfall.hud.element;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class FpsElement implements HudElement {
    private int x = 4;
    private int y = 22;

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        String text = "FPS: " + client.getFps();
        int width = client.font.width(text) + 8;

        g.fill(x, y, x + width, y + 14, 0x90000000);
        g.drawString(client.font, text, x + 4, y + 3, 0xFFFFFFFF);
    }
}