package dev.nightfall.hud.element;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.core.Direction;

public class CoordsElement implements HudElement {
    private int x = 4;
    private int y = 40;

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        double px = client.player.getX();
        double py = client.player.getY();
        double pz = client.player.getZ();
        Direction dir = client.player.getDirection();

        String text = String.format("XYZ: %.1f, %.1f, %.1f [%s]", px, py, pz, dir.getName());
        int width = client.font.width(text) + 8;

        g.fill(x, y, x + width, y + 14, 0x90000000);
        g.drawString(client.font, text, x + 4, y + 3, 0xFFFFFFFF);
    }
}