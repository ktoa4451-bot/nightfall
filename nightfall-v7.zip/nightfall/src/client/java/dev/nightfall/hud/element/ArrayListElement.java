package dev.nightfall.hud.element;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.Module;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ArrayListElement implements HudElement {
    private int x = 0;
    private int y = 5;

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        List<Module> active = NightfallClient.getInstance().moduleManager.getModules().stream()
                .filter(Module::isEnabled)
                .sorted(Comparator.comparingInt(m -> -client.font.width(m.getName())))
                .collect(Collectors.toList());

        int screenWidth = client.getWindow().getGuiScaledWidth();
        int baseX = x > 0 ? x : screenWidth - 2;
        int currentY = y;

        for (Module m : active) {
            String name = m.getName();
            int width = client.font.width(name) + 6;
            int drawX = baseX - width;

            g.fill(drawX, currentY, baseX, currentY + 12, 0x90000000);
            g.drawString(client.font, name, drawX + 3, currentY + 2, 0xFF7C5CFF);
            currentY += 12;
        }
    }
}