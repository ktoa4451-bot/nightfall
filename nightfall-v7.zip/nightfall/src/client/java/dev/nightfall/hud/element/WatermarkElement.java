package dev.nightfall.hud.element;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class WatermarkElement implements HudElement {
    private int x = 4;
    private int y = 4;

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        String text = "Nightfall 1.0.0";
        int width = client.font.width(text) + 6;

        g.fill(x, y, x + width, y + 14, 0x90000000);
        g.fill(x, y, x + 2, y + 14, 0xFF7C5CFF);
        g.drawString(client.font, text, x + 4, y + 3, 0xFFFFFFFF);
    }
}