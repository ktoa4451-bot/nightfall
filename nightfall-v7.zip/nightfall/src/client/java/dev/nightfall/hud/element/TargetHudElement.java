package dev.nightfall.hud.element;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.TargetHud;
import dev.nightfall.module.Setting;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.LivingEntity;

public class TargetHudElement implements HudElement {
    private int x = 20;
    private int y = 20;

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }
    public int getY() { return y; }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        TargetHud mod = (TargetHud) NightfallClient.getInstance().moduleManager
                .getByName("TargetHud").orElse(null);
        if (mod == null || !mod.isEnabled()) return;

        LivingEntity target = mod.getTarget();
        if (target == null) return;

        Minecraft client = Minecraft.getInstance();
        int baseX = x;
        int baseY = y;

        String name = target.getName().getString();
        float hp = target.getHealth();
        float maxHp = target.getMaxHealth();

        g.fill(baseX, baseY, baseX + 140, baseY + 40, 0xCC15151C);
        g.drawString(client.font, name, baseX + 6, baseY + 4, 0xFFFFFFFF);

        int barW = 128;
        int filled = (int) (barW * Math.min(1f, hp / Math.max(0.01f, maxHp)));
        g.fill(baseX + 6, baseY + 20, baseX + 6 + barW, baseY + 26, 0xFF331111);
        g.fill(baseX + 6, baseY + 20, baseX + 6 + filled, baseY + 26, 0xFFFF3355);

        g.drawString(client.font, String.format("%.1f", hp), baseX + 6, baseY + 30, 0xFFFFAAAA);
        double dist = client.player != null ? client.player.distanceTo(target) : 0;
        g.drawString(client.font, String.format("%.1fm", dist), baseX + 100, baseY + 30, 0xFFAAAAFF);
    }
}