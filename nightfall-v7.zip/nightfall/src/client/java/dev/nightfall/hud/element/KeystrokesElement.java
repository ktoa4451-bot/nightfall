package dev.nightfall.hud.element;

import dev.nightfall.NightfallClient;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class KeystrokesElement implements HudElement {
    private int x = 10;
    private int y = -80; // отступ от низа, если отрицательный

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        var mod = NightfallClient.getInstance().moduleManager.getByName("Keystrokes").orElse(null);
        if (mod == null || !mod.isEnabled()) return;

        Minecraft client = Minecraft.getInstance();
        int baseX = x;
        int baseY = y < 0 ? client.getWindow().getGuiScaledHeight() + y : y;

        drawKey(g, client, baseX + 20, baseY, 18, 18, "W", client.options.keyUp.isDown());
        drawKey(g, client, baseX, baseY + 20, 18, 18, "A", client.options.keyLeft.isDown());
        drawKey(g, client, baseX + 20, baseY + 20, 18, 18, "S", client.options.keyDown.isDown());
        drawKey(g, client, baseX + 40, baseY + 20, 18, 18, "D", client.options.keyRight.isDown());
        drawKey(g, client, baseX, baseY + 40, 58, 14, "SPACE", client.options.keyJump.isDown());
    }

    private void drawKey(GuiGraphics g, Minecraft client, int x, int y, int w, int h,
                         String label, boolean pressed) {
        g.fill(x, y, x + w, y + h, pressed ? 0xFF7C5CFF : 0xCC1A1A22);
        int tw = client.font.width(label);
        g.drawString(client.font, label, x + (w - tw) / 2, y + (h - 8) / 2, 0xFFFFFFFF);
    }
}