package dev.nightfall.hud.element;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;

import java.util.Collection;

public class PotionElement implements HudElement {
    private int x = 10;
    private int y = 220;

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }
    public int getX() { return x; }
    public int getY() { return y; }

    @Override
    public void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        Collection<MobEffectInstance> effects = client.player.getActiveEffects();
        if (effects.isEmpty()) return;

        int currentY = y;
        for (MobEffectInstance effect : effects) {
            String name = effect.getEffect().value().getDisplayName().getString();
            int duration = effect.getDuration();
            int seconds = duration / 20;
            int minutes = seconds / 60;
            seconds = seconds % 60;

            String text = String.format("%s %d:%02d", name, minutes, seconds);
            int width = client.font.width(text) + 8;

            // Фон
            g.fill(x, currentY, x + width, currentY + 14, 0x90000000);
            // Акцентная полоска
            g.fill(x, currentY, x + 2, currentY + 14, 0xFF7C5CFF);
            // Текст
            g.drawString(client.font, text, x + 4, currentY + 3, 0xFFFFFFFF);

            currentY += 16;
        }
    }
}