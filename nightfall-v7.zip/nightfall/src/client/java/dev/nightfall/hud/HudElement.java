package dev.nightfall.hud;

public abstract class HudElement {
    protected int x, y;

    public HudElement(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() { return x; }
    public int getY() { return y; }
    
    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract int getWidth();
    public abstract int getHeight();
}