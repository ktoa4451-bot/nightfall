package dev.nightfall.render;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

public final class Ui {
    private Ui() { }

    public static final int TEXT = 0xE9E9F2, MUTED = 0x8B8B9C, DANGER = 0xD9707C;
    public static int ACCENT = 0x7C5CFF;

    public static Font font() { return Minecraft.getInstance().font; }
    public static int tw(String s) { return font().width(s); }

    public static void text(GuiGraphics g, String s, int x, int y, int color) { g.drawString(font(), s, x, y, color, false); }

    public static int c(int rgb, float a) {
        int al = Math.max(4, Math.min(255, (int) (a * 255f)));
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int c1, int c2, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = (int) (((c1 >> 16) & 0xFF) * (1 - t) + ((c2 >> 16) & 0xFF) * t);
        int g = (int) (((c1 >> 8) & 0xFF) * (1 - t) + ((c2 >> 8) & 0xFF) * t);
        int b = (int) ((c1 & 0xFF) * (1 - t) + (c2 & 0xFF) * t);
        return (r << 16) | (g << 8) | b;
    }

    public static void line(GuiGraphics g, int x0, int y0, int x1, int y1, int color) {
        int sw = g.guiWidth(), sh = g.guiHeight();
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
        int err = dx + dy;
        int steps = 0;
        while (steps++ < 3000) {
            if (x0 >= 0 && y0 >= 0 && x0 < sw && y0 < sh) g.fill(x0, y0, x0 + 1, y0 + 1, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    public static void box(GuiGraphics g, int x1, int y1, int x2, int y2, int t, int color) {
        g.fill(x1, y1, x2, y1 + t, color);
        g.fill(x1, y2 - t, x2, y2, color);
        g.fill(x1, y1 + t, x1 + t, y2 - t, color);
        g.fill(x2 - t, y1 + t, x2, y2 - t, color);
    }
}