package dev.nightfall.render;

import dev.nightfall.NightfallClient;
import dev.nightfall.util.HoleLogic;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** Safe-hole markers on the screen (visible through walls). scan() runs from the HoleESP module tick, render() from the HUD. */
public final class HoleEsp {
    private HoleEsp() { }

    private record Hole(int x, int y, int z, int type) { }
    private static final List<Hole> HOLES = new ArrayList<>();

    private static int kindOf(Minecraft mc, BlockPos.MutableBlockPos q, int x, int y, int z) {
        if (mc.level.isOutsideBuildHeight(y) || !mc.level.getChunkSource().hasChunk(x >> 4, z >> 4)) return HoleLogic.OTHER;
        q.set(x, y, z);
        BlockState s = mc.level.getBlockState(q);
        if (s.isAir()) return HoleLogic.AIR;
        if (s.is(Blocks.BEDROCK)) return HoleLogic.BEDROCK;
        if (s.is(Blocks.OBSIDIAN) || s.is(Blocks.CRYING_OBSIDIAN)) return HoleLogic.OBSIDIAN;
        return s.getCollisionShape(mc.level, q).isEmpty() ? HoleLogic.AIR : HoleLogic.OTHER;
    }

    public static void clear() { HOLES.clear(); }

    public static void scan(Minecraft mc, LocalPlayer p, int r, boolean showUnsafe) {
        HOLES.clear();
        BlockPos base = p.blockPosition();
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) for (int dy = -3; dy <= 3; dy++) for (int dz = -r; dz <= r; dz++) {
            final int x = base.getX() + dx, y = base.getY() + dy, z = base.getZ() + dz;
            if (kindOf(mc, q, x, y, z) != HoleLogic.AIR || kindOf(mc, q, x, y - 1, z) == HoleLogic.AIR) continue;
            int t = HoleLogic.classify(i -> kindOf(mc, q, x + i / 12 - 1, y + (i / 3) % 4 - 1, z + i % 3 - 1));
            if (t == HoleLogic.NONE || (t == HoleLogic.UNSAFE && !showUnsafe)) continue;
            HOLES.add(new Hole(x, y, z, t));
            if (HOLES.size() >= 40) return;
        }
    }

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        var mod = NightfallClient.getInstance().moduleManager.getByName("HoleESP").orElse(null);
        LocalPlayer p = mc.player;
        if (mod == null || !mod.isEnabled() || p == null || HOLES.isEmpty() || !Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;
        for (Hole h : HOLES) {
            double[] s = Project.point(h.x() + 0.5, h.y() + 0.05, h.z() + 0.5);
            if (s == null) continue;
            int col = h.type() == HoleLogic.BEDROCK_HOLE ? 0x55FF55 : h.type() == HoleLogic.MIXED_SAFE ? 0xFFAA00 : 0xFF5555;
            g.fill((int) s[0] - 4, (int) s[1] - 2, (int) s[0] + 5, (int) s[1] + 3, Ui.c(col, 0.8f));
        }
    }
}
