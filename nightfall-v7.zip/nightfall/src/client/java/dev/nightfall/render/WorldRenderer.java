package dev.nightfall.render;

import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexFormat;
import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.ESP;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public final class WorldRenderer {
    private static ByteBufferBuilder allocator;
    private static BufferBuilder buffer;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            Minecraft client = Minecraft.getInstance();
            if (client.level == null || client.player == null) return;

            ESP esp = (ESP) NightfallClient.getInstance().moduleManager.getByName("ESP").orElse(null);
            if (esp == null || !esp.isEnabled()) return;

            PoseStack matrices = context.matrixStack();
            Vec3 camera = context.camera().getPosition();
            matrices.pushPose();
            matrices.translate(-camera.x, -camera.y, -camera.z);

            if (allocator == null) allocator = new ByteBufferBuilder(1536);
            if (buffer == null) buffer = new BufferBuilder(allocator, VertexFormat.Mode.DEBUG_LINES, VertexFormat.builder().build());

            Matrix4f mat = matrices.last().pose();
            Vec3 eye = client.player.getEyePosition();
            double maxRange = esp.getRange();

            for (Entity entity : client.level.entitiesForRendering()) {
                if (!(entity instanceof Player) || entity == client.player || !entity.isAlive()) continue;
                if (client.player.distanceTo(entity) > maxRange) continue;

                if (esp.isTracers()) {
                    // Линия от глаз игрока до центра сущности
                    Vec3 target = entity.getBoundingBox().getCenter();
                    buffer.addVertex(mat, (float) eye.x, (float) eye.y, (float) eye.z).setColor(1f, 0f, 0f, 1f);
                    buffer.addVertex(mat, (float) target.x, (float) target.y, (float) target.z).setColor(1f, 0f, 0f, 1f);
                }

                if (esp.isBoxes()) {
                    // Рамка вокруг сущности (12 линий)
                    AABB box = entity.getBoundingBox();
                    drawBox(buffer, mat, box, 0f, 1f, 0f, 1f);
                }
            }

            // Отрисовка пока не реализована — нужен точный вызов draw() из RenderPipeline
            buffer = null;
            matrices.popPose();
        });
    }

    private static void drawBox(BufferBuilder buf, Matrix4f mat, AABB box, float r, float g, float b, float a) {
        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        // Нижний прямоугольник
        line(buf, mat, x1, y1, z1, x2, y1, z1, r, g, b, a);
        line(buf, mat, x2, y1, z1, x2, y1, z2, r, g, b, a);
        line(buf, mat, x2, y1, z2, x1, y1, z2, r, g, b, a);
        line(buf, mat, x1, y1, z2, x1, y1, z1, r, g, b, a);
        // Верхний прямоугольник
        line(buf, mat, x1, y2, z1, x2, y2, z1, r, g, b, a);
        line(buf, mat, x2, y2, z1, x2, y2, z2, r, g, b, a);
        line(buf, mat, x2, y2, z2, x1, y2, z2, r, g, b, a);
        line(buf, mat, x1, y2, z2, x1, y2, z1, r, g, b, a);
        // Вертикальные стойки
        line(buf, mat, x1, y1, z1, x1, y2, z1, r, g, b, a);
        line(buf, mat, x2, y1, z1, x2, y2, z1, r, g, b, a);
        line(buf, mat, x2, y1, z2, x2, y2, z2, r, g, b, a);
        line(buf, mat, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void line(BufferBuilder buf, Matrix4f mat, float x1, float y1, float z1,
                             float x2, float y2, float z2, float r, float g, float b, float a) {
        buf.addVertex(mat, x1, y1, z1).setColor(r, g, b, a);
        buf.addVertex(mat, x2, y2, z2).setColor(r, g, b, a);
    }
}