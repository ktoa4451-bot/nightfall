package dev.nightfall.render;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.combat.CrystalHelper;
import dev.nightfall.module.impl.combat.MaceHelper;
import dev.nightfall.module.impl.visuals.CombatLog;
import dev.nightfall.module.impl.visuals.TargetInfo;
import dev.nightfall.util.DamageLog;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Text lines of CrystalHelper, TargetInfo, MaceHelper and CombatLog on the left of the screen, plus the best-crystal-spot marker. */
public final class PvpOverlay {
    private PvpOverlay() { }

    private static boolean on(String name) { var m = NightfallClient.getInstance().moduleManager.getByName(name); return m.isPresent() && m.get().isEnabled(); }

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.options.hideGui) return;
        List<String> lines = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        if (on("TargetInfo")) synchronized (TargetInfo.LINES) { for (String s : TargetInfo.LINES) { lines.add(s); colors.add(0xFFFFFF); } }
        if (on("MaceHelper") && MaceHelper.lastBonus > 0 && !p.onGround()) { lines.add(String.format(Locale.ROOT, "Mace smash: +%.0f damage", MaceHelper.lastBonus)); colors.add(0xFFD84A); }
        if (on("CrystalHelper")) synchronized (CrystalHelper.LINES) { for (String s : CrystalHelper.LINES) { lines.add(s); colors.add(s.endsWith("!!") ? 0xFF5555 : 0xFFFFFF); } }
        int y = 40;
        for (int i = 0; i < lines.size(); i++) {
            String s = lines.get(i);
            g.fill(2, y - 1, 6 + Ui.tw(s) + 2, y + 10, Ui.c(0x000000, 0.55f));
            Ui.text(g, s, 5, y, Ui.c(colors.get(i), 1f));
            y += 12;
        }
        if (on("CombatLog")) {
            long now = System.currentTimeMillis();
            for (DamageLog.Entry e : CombatLog.LOG.alive(now)) {
                float a = CombatLog.LOG.alpha(e, now);
                if (a <= 0f) continue;
                int col = e.text().startsWith("You") ? 0xFF7777 : 0x77FF99;
                Ui.text(g, e.text(), 5, y, Ui.c(col, a));
                y += 11;
            }
        }
        BlockPos spot = CrystalHelper.bestSpot;
        if (on("CrystalHelper") && spot != null && Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) {
            double[] s = Project.point(spot.getX() + 0.5, spot.getY() + 1.0, spot.getZ() + 0.5);
            if (s != null) g.fill((int) s[0] - 3, (int) s[1] - 3, (int) s[0] + 4, (int) s[1] + 4, Ui.c(Ui.ACCENT, 0.95f));
        }
    }
}
