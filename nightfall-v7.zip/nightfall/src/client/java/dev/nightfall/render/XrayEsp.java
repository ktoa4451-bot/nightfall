package dev.nightfall.render;

import dev.nightfall.NightfallClient;
import dev.nightfall.util.CubeCursor;
import dev.nightfall.util.OreKinds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Ore markers on the screen. scanStep() looks at a limited number of cells per tick; when a full pass ends the results replace the old ones. */
public final class XrayEsp {
    private XrayEsp() { }

    private static CubeCursor cursor;
    private static int cursorRadius;
    private static List<int[]> building = new ArrayList<>();
    private static volatile List<int[]> shown = List.of();
    private static final Map<Block, Integer> KIND = new HashMap<>();

    public static void reset() { cursor = null; building = new ArrayList<>(); shown = List.of(); KIND.clear(); }

    private static int kindOf(Block b) { return KIND.computeIfAbsent(b, k -> OreKinds.classify(BuiltInRegistries.BLOCK.getKey(k).getPath())); }

    public static void scanStep(Minecraft mc, LocalPlayer p, int radius, int budget, int maxMarks, boolean[] want) {
        if (cursor == null || cursorRadius != radius) { cursor = new CubeCursor(radius); cursorRadius = radius; building = new ArrayList<>(); }
        BlockPos base = p.blockPosition();
        BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
        for (int n = 0; n < budget; n++) {
            int[] o = cursor.next();
            if (o == null) {                                    // pass finished: keep the closest marks
                building.sort((a, b) -> Integer.compare(d2(a, base), d2(b, base)));
                shown = building.size() > maxMarks ? new ArrayList<>(building.subList(0, maxMarks)) : building;
                building = new ArrayList<>();
                return;
            }
            int x = base.getX() + o[0], y = base.getY() + o[1], z = base.getZ() + o[2];
            if (mc.level.isOutsideBuildHeight(y) || !mc.level.getChunkSource().hasChunk(x >> 4, z >> 4)) continue;
            q.set(x, y, z);
            int k = kindOf(mc.level.getBlockState(q).getBlock());
            if (k >= 0 && want[k]) building.add(new int[]{x, y, z, k});
        }
    }

    private static int d2(int[] a, BlockPos b) { int dx = a[0] - b.getX(), dy = a[1] - b.getY(), dz = a[2] - b.getZ(); return dx * dx + dy * dy + dz * dz; }

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        var mod = NightfallClient.getInstance().moduleManager.getByName("XRay");
        LocalPlayer p = mc.player;
        List<int[]> list = shown;
        if (mod.isEmpty() || !mod.get().isEnabled() || p == null || list.isEmpty() || !Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;
        for (int[] b : list) {
            float[] r = Project.rect(new AABB(b[0], b[1], b[2], b[0] + 1, b[1] + 1, b[2] + 1));
            if (r == null || !Project.onScreen(r)) continue;
            int x1 = (int) r[0], y1 = (int) r[1], x2 = Math.max(x1 + 3, (int) r[2]), y2 = Math.max(y1 + 3, (int) r[3]);
            Ui.box(g, x1, y1, x2, y2, 1, Ui.c(OreKinds.COLORS[b[3]], 0.95f));
        }
    }
}
