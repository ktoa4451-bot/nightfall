package dev.nightfall.render;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.ItemESP;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import java.util.Set;

/** Boxes and names for dropped items, drawn on the screen so they show through walls. */
public final class ItemEsp {
    private ItemEsp() { }

    private static final Set<String> VALUABLE = Set.of("diamond", "diamond_block", "netherite_ingot", "netherite_scrap", "ancient_debris", "emerald",
        "totem_of_undying", "elytra", "enchanted_golden_apple", "golden_apple", "ender_pearl", "end_crystal", "firework_rocket", "experience_bottle");

    private static boolean valuable(ItemStack s) {
        String path = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
        return VALUABLE.contains(path) || path.startsWith("netherite_") || path.startsWith("diamond_");
    }

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        ItemESP mod = (ItemESP) NightfallClient.getInstance().moduleManager.getByName("ItemESP").orElse(null);
        LocalPlayer p = mc.player;
        if (mod == null || !mod.isEnabled() || p == null || mc.level == null || !Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;
        double range = mod.range.getValue();
        for (ItemEntity it : mc.level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(range), e -> e.isAlive())) {
            ItemStack st = it.getItem();
            boolean v = valuable(st);
            if (mod.onlyValuable.getValue() && !v) continue;
            AABB bb = it.getBoundingBox().inflate(0.1);
            float[] r = Project.rect(bb);
            if (r == null || !Project.onScreen(r)) continue;
            int x1 = (int) r[0], y1 = (int) r[1], w = Math.max(4, (int) (r[2] - r[0])), h = Math.max(4, (int) (r[3] - r[1]));
            int col = v ? 0xFFFFD84A : 0xFFFFFFFF;
            Ui.box(g, x1, y1, x1 + w, y1 + h, 1, Ui.c(col & 0xFFFFFF, 0.9f));
            if (mod.showNames.getValue()) {
                String s = st.getHoverName().getString() + (st.getCount() > 1 ? " x" + st.getCount() : "");
                Ui.text(g, s, x1 + w / 2 - Ui.tw(s) / 2, y1 - 10, Ui.c(col & 0xFFFFFF, 1f));
            }
        }
    }
}
