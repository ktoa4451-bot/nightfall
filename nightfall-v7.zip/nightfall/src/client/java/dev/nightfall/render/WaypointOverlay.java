package dev.nightfall.render;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.misc.WaypointStore;
import dev.nightfall.module.impl.misc.Waypoints;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;

import java.util.Locale;

/** Draws every saved point of the current dimension: a marker, its name and the distance. */
public final class WaypointOverlay {
    private WaypointOverlay() { }

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        Waypoints mod = (Waypoints) NightfallClient.getInstance().moduleManager.getByName("Waypoints").orElse(null);
        LocalPlayer p = mc.player;
        if (mod == null || !mod.isEnabled() || p == null || mc.level == null || !Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;
        String dim = mc.level.dimension().toString().replaceAll("[;=,\\s]", "_");
        for (var w : WaypointStore.get().all()) {
            if (!w.dim().isEmpty() && !w.dim().equals(dim)) continue;
            double dist = Math.sqrt(p.distanceToSqr(w.x() + 0.5, w.y(), w.z() + 0.5));
            if (dist > mod.maxDistance.getValue()) continue;
            double[] s = Project.point(w.x() + 0.5, w.y() + 1.0, w.z() + 0.5);
            if (s == null) continue;
            int x = (int) s[0], y = (int) s[1];
            g.fill(x - 2, y - 2, x + 3, y + 3, Ui.c(Ui.ACCENT, 0.95f));
            String label = w.name() + "  " + String.format(Locale.ROOT, "%.0f m", dist);
            Ui.text(g, label, x - Ui.tw(label) / 2, y - 12, Ui.c(0xFFFFFF, 1f));
        }
    }
}
