package dev.nightfall.render;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.ESP;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public final class PlayerEsp {
    private PlayerEsp() { }

    private static long cacheTick = Long.MIN_VALUE;
    private static List<LivingEntity> cache = List.of();
    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null) return;
        
        ESP mod = (ESP) NightfallClient.getInstance().moduleManager.getByName("ESP").orElse(null);
        if (mod == null || !mod.isEnabled()) return;

        if (!Project.begin(mc, p, pt, g.guiWidth(), g.guiHeight())) return;

        boolean tracers = mod.isTracers();
        boolean boxes = mod.isBoxes();
        double maxD = mod.getRange();
        int color = 0x7C5CFF; // Фиолетовый акцент

        long gt = mc.level.getGameTime();
        if (gt != cacheTick) {
            cache = mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(maxD),
                e -> e != p && e.isAlive() && !e.isSpectator() && !(e instanceof ArmorStand) && e instanceof Player);
            cacheTick = gt;
        }

        int sw = g.guiWidth(), sh = g.guiHeight();
        for (LivingEntity e : cache) {
            if (!e.isAlive()) continue;
            double d = p.distanceTo(e);
            if (d > maxD) continue;

            Vec3 off = new Vec3(Mth.lerp(pt, e.xo, e.getX()) - e.getX(), Mth.lerp(pt, e.yo, e.getY()) - e.getY(), Mth.lerp(pt, e.zo, e.getZ()) - e.getZ());
            AABB bb = e.getBoundingBox().move(off);
            float frac = Mth.clamp(e.getHealth() / Math.max(1f, e.getMaxHealth()), 0f, 1f);
            int col = 0xFF000000 | Ui.mix(0xFF4040, 0x40FF60, frac);

            float[] r = Project.rect(bb);
            if (r == null || !Project.onScreen(r)) {
                if (tracers) arrow(g, bb.getCenter(), color, (int) d, sw, sh);
                continue;
            }
            int x1 = (int) r[0], y1 = (int) r[1], x2 = (int) r[2], y2 = (int) r[3];
            int w = Math.max(4, x2 - x1), h = Math.max(4, y2 - y1);

            if (tracers) {
                double[] feet = Project.point(bb.getCenter().x, bb.minY, bb.getCenter().z);
                if (feet != null) Ui.line(g, sw / 2, sh - 1, (int) feet[0], (int) feet[1], Ui.c(color, 0.8f));
            }

            if (boxes) {
                Ui.box(g, x1, y1, x1 + w, y1 + h, 1, col);
                
                // Имя и здоровье
                String s = e.getName().getString() + " " + (int) d + "m " + (int) Math.ceil(e.getHealth()) + " HP";
                Ui.text(g, s, x1 + w / 2 - Ui.tw(s) / 2, y1 - 10, col);
            }
        }
    }

    private static void arrow(GuiGraphics g, Vec3 target, int rgb, int dist, int sw, int sh) {
        Vec3 eye = Project.eye();
        double dx = target.x - eye.x, dz = target.z - eye.z;
        double ty = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
        double rel = Math.toRadians(Mth.wrapDegrees((float) ty - Project.yaw));
        double rad = Math.min(sw, sh) * 0.36;
        double ux = Math.sin(rel), uy = -Math.cos(rel);
        int cx = (int) (sw / 2.0 + ux * rad), cy = (int) (sh / 2.0 + uy * rad);
        int col = Ui.c(rgb, 0.95f);
        int tipX = (int) (cx + ux * 7), tipY = (int) (cy + uy * 7);
        int ax = (int) (cx - uy * 5), ay = (int) (cy + ux * 5);
        int bx = (int) (cx + uy * 5), by = (int) (cy - ux * 5);
        Ui.line(g, tipX, tipY, ax, ay, col);
        Ui.line(g, tipX, tipY, bx, by, col);
        Ui.line(g, ax, ay, bx, by, col);
        String s = dist + "m";
        Ui.text(g, s, cx - Ui.tw(s) / 2, cy + (uy > 0 ? -12 : 9), col);
    }
}