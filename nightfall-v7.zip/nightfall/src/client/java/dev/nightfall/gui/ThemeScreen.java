package dev.nightfall.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ThemeScreen extends Screen {
    public ThemeScreen() {
        super(Component.literal("Theme Studio"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        String[] themes = {"Purple", "Cyan", "Crimson", "Emerald", "Midnight"};
        for (int i = 0; i < themes.length; i++) {
            String theme = themes[i];
            this.addRenderableWidget(Button.builder(Component.literal(theme), b -> {
                ThemeManager.applyTheme(theme);
                Minecraft.getInstance().setScreen(new ClickGUI());
            }).bounds(cx - 100, cy - 60 + (i * 25), 200, 20).build());
        }

        this.addRenderableWidget(Button.builder(Component.literal("Back"), b -> {
            Minecraft.getInstance().setScreen(new ClickGUI());
        }).bounds(cx - 100, cy + 80, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, "Theme Studio", this.width / 2, 40, ThemeManager.TEXT_WHITE);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}