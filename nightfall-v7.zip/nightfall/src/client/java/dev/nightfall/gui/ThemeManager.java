package dev.nightfall.gui;

public class ThemeManager {
    public static int ACCENT = 0xFF7C5CFF;
    public static int BG_DARK = 0xEE0A0A0F;
    public static int PANEL_BG = 0xFF15151C;
    public static int TEXT_WHITE = 0xFFFFFFFF;
    public static int TEXT_GRAY = 0xFFAAAAAA;
    public static int HOVER = 0xFF2A2A38;

    public static void applyTheme(String themeName) {
        switch (themeName.toLowerCase()) {
            case "purple":
                ACCENT = 0xFF7C5CFF; // Фиолетовый
                break;
            case "cyan":
                ACCENT = 0xFF00E5FF; // Циан
                break;
            case "crimson":
                ACCENT = 0xFFFF3355; // Малиновый
                break;
            case "emerald":
                ACCENT = 0xFF00FF88; // Изумрудный
                break;
            case "midnight":
                ACCENT = 0xFF4444AA; // Тёмно-синий
                break;
            default:
                ACCENT = 0xFF7C5CFF; // По умолчанию — фиолетовый
                break;
        }
    }
}