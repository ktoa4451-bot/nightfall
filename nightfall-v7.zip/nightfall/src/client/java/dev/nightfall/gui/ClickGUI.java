package dev.nightfall.gui;

import com.mojang.blaze3d.platform.InputConstants;
import dev.nightfall.NightfallClient;
import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.util.Anim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Module menu. A centred window that fades in, category tabs with a sliding underline, soft-cornered module cards with animated switches,
 * settings that unfold smoothly (switches, sliders for decimals and whole numbers, keybind, reset) and smooth scrolling.
 * Left click switches a module, right click opens its settings. Everything is saved when the menu closes.
 */
public class ClickGUI extends Screen {
    private enum Kind { MODULE, BOOL, DOUBLE, INT, BIND, RESET }

    private static final class Row {
        final Kind kind; final Module module; final Setting<?> setting; final int y, h, clipTop, clipBottom;
        Row(Kind kind, Module module, Setting<?> setting, int y, int h, int clipTop, int clipBottom) {
            this.kind = kind; this.module = module; this.setting = setting; this.y = y; this.h = h; this.clipTop = clipTop; this.clipBottom = clipBottom;
        }
    }

    private static final int HEAD = 26, GAP = 4;

    private Category selected = Category.COMBAT;
    private Module expanded;
    private Module listening;
    private Row dragging;
    private int contentH;
    private float scroll, scrollTarget, openT, tabX = -1, tabW;
    private long last = System.nanoTime();
    private final Map<Object, Float> hover = new IdentityHashMap<>();
    private final Map<Module, Float> expandT = new IdentityHashMap<>();
    private final Map<Module, Float> enableT = new IdentityHashMap<>();
    private final Map<Setting<?>, Float> switchT = new IdentityHashMap<>();
    private final Map<Module, Object> bindKeys = new IdentityHashMap<>();

    private Object bindKey(Module m) { return bindKeys.computeIfAbsent(m, x -> new Object()); }

    public ClickGUI() { super(Component.literal("Nightfall")); }

    public static void open() { Minecraft.getInstance().setScreen(new ClickGUI()); }

    // ------------------------------------------------------------------ geometry

    private int ww() { return Math.min(560, this.width - 24); }
    private int wh() { return Math.min(360, this.height - 24); }
    private int wx() { return (this.width - ww()) / 2; }
    private int wy() { return (this.height - wh()) / 2 + (int) ((1f - Anim.easeOutCubic(openT)) * 14f); }
    private int tabsY() { return wy() + 38; }
    private int top() { return wy() + 72; }
    private int bottom() { return wy() + wh() - 26; }
    private int lx() { return wx() + 14; }
    private int lw() { return ww() - 28 - 6; }

    private static int rowH(Kind k) { return k == Kind.DOUBLE || k == Kind.INT ? 24 : 20; }

    private static List<Setting<?>> shown(Module m) {
        List<Setting<?>> out = new ArrayList<>();
        for (Setting<?> s : m.settings) if (s instanceof Setting.BooleanSetting || s instanceof Setting.DoubleSetting || s instanceof Setting.IntSetting) out.add(s);
        return out;
    }

    private static Kind kindOf(Setting<?> s) { return s instanceof Setting.BooleanSetting ? Kind.BOOL : s instanceof Setting.DoubleSetting ? Kind.DOUBLE : Kind.INT; }

    private static int fullH(Module m) {
        int h = 4;
        for (Setting<?> s : shown(m)) h += rowH(kindOf(s));
        return h + 20 + 22;     // bind row + reset row
    }

    private List<Row> layout() {
        List<Row> rows = new ArrayList<>();
        int y = top() - (int) scroll;
        for (Module m : NightfallClient.getInstance().moduleManager.getByCategory(selected)) {
            rows.add(new Row(Kind.MODULE, m, null, y, HEAD, y, y + HEAD));
            float t = Anim.easeOutCubic(expandT.getOrDefault(m, 0f));
            int vis = (int) (fullH(m) * t);
            if (t > 0.001f) {
                int ry = y + HEAD + 4;
                for (Setting<?> s : shown(m)) { Kind k = kindOf(s); rows.add(new Row(k, m, s, ry, rowH(k), y + HEAD, y + HEAD + vis)); ry += rowH(k); }
                rows.add(new Row(Kind.BIND, m, null, ry, 20, y + HEAD, y + HEAD + vis)); ry += 20;
                rows.add(new Row(Kind.RESET, m, null, ry, 22, y + HEAD, y + HEAD + vis));
            }
            y += HEAD + vis + GAP;
        }
        contentH = y + (int) scroll - top();
        return rows;
    }

    private static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }

    private static String keyName(int key) {
        if (key < 0) return "none";
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) return "RSHIFT";
        if (key == GLFW.GLFW_KEY_LEFT_SHIFT) return "LSHIFT";
        try { return InputConstants.Type.KEYSYM.getOrCreate(key).getName().replace("key.keyboard.", "").replace("key.mouse.", "mouse ").toUpperCase(Locale.ROOT); }
        catch (RuntimeException e) { return "KEY " + key; }
    }

    // ------------------------------------------------------------------ drawing helpers

    private float anim(Map<Object, Float> m, Object k, float target, float dt, float speed) {
        float v = Anim.approach(m.getOrDefault(k, 0f), target, dt, speed);
        m.put(k, v);
        return v;
    }

    /** Fill with softly cut corners (2 px), the cheapest way to get rounded cards with plain rectangles. */
    private static void rr(GuiGraphics g, int x, int y, int w, int h, int col) {
        if (w < 5 || h < 5) { g.fill(x, y, x + w, y + h, col); return; }
        g.fill(x + 2, y, x + w - 2, y + h, col);
        g.fill(x, y + 2, x + w, y + h - 2, col);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, col);
    }

    private void pill(GuiGraphics g, int x, int y, float on, float a) {
        int w = 26, h = 12;
        rr(g, x, y, w, h, Anim.fade(Anim.mix(0xFF2C2C3A, ThemeManager.ACCENT, on), a));
        int kx = x + 2 + (int) ((w - h) * on);
        rr(g, kx, y + 2, 8, 8, Anim.fade(Anim.mix(0xFFB8B8C8, 0xFFFFFFFF, on), a));
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        long now = System.nanoTime();
        float dt = Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        openT = Anim.approach(openT, 1f, dt, 14f);
        float a = Anim.easeOutCubic(openT);
        scroll = Anim.approach(scroll, scrollTarget, dt, 18f);

        g.fill(0, 0, this.width, this.height, ((int) (0xA8 * a) << 24) | 0x05050A);
        int wx = wx(), wy = wy(), ww = ww(), wh = wh();
        rr(g, wx - 1, wy - 1, ww + 2, wh + 2, Anim.fade(Anim.mix(ThemeManager.ACCENT, 0xFF000000, 0.55f), a));
        rr(g, wx, wy, ww, wh, Anim.fade(0xFF111119, a));
        g.fill(wx + 6, wy + 30, wx + ww - 6, wy + 31, Anim.fade(0x22FFFFFF, a));

        // header: title and the two tool buttons
        g.drawString(this.font, "NIGHTFALL", wx + 16, wy + 12, Anim.fade(ThemeManager.TEXT_WHITE, a));
        g.fill(wx + 16, wy + 23, wx + 16 + this.font.width("NIGHTFALL"), wy + 24, Anim.fade(ThemeManager.ACCENT, a));
        int bx = wx + ww - 16;
        for (String t : new String[]{"Theme", "HUD"}) {
            int tw = this.font.width(t) + 14;
            bx -= tw;
            boolean hv = in(mouseX, mouseY, bx, wy + 8, tw, 16);
            float h = anim(hover, t, hv ? 1f : 0f, dt, 16f);
            rr(g, bx, wy + 8, tw, 16, Anim.fade(Anim.mix(0xFF1D1D29, 0xFF2A2A3C, h), a));
            g.drawString(this.font, t, bx + 7, wy + 12, Anim.fade(Anim.mix(ThemeManager.TEXT_GRAY, ThemeManager.TEXT_WHITE, h), a));
            bx -= 6;
        }

        // tabs with a sliding underline
        int tx = wx + 16, ty = tabsY();
        int sx = -1, sw = 0;
        for (Category c : Category.values()) {
            String label = c.getDisplayName();
            int tw = this.font.width(label);
            boolean sel = c == selected, hv = in(mouseX, mouseY, tx - 6, ty - 3, tw + 12, 20);
            float h = anim(hover, c, hv || sel ? 1f : 0f, dt, 16f);
            g.drawString(this.font, label, tx, ty + 3, Anim.fade(Anim.mix(ThemeManager.TEXT_GRAY, ThemeManager.TEXT_WHITE, h), a));
            if (sel) { sx = tx; sw = tw; }
            tx += tw + 22;
        }
        if (sx >= 0) {
            tabX = tabX < 0 ? sx : Anim.approach(tabX, sx, dt, 18f);
            tabW = tabW <= 0 ? sw : Anim.approach(tabW, sw, dt, 18f);
            g.fill((int) tabX, ty + 16, (int) (tabX + tabW), ty + 18, Anim.fade(ThemeManager.ACCENT, a));
        }

        // module list
        List<Row> rows = layout();
        int viewH = bottom() - top();
        int maxScroll = Math.max(0, contentH - viewH);
        scrollTarget = Mth.clamp(scrollTarget, 0, maxScroll);
        if (scroll > maxScroll) scroll = maxScroll;
        String tip = null;
        int lx = lx(), lw = lw();
        g.enableScissor(wx + 4, top(), wx + ww - 4, bottom());
        for (Row r : rows) {
            if (r.kind == Kind.MODULE) {
                Module m = r.module;
                float en = anim2(enableT, m, m.isEnabled() ? 1f : 0f, dt, 12f);
                float ex = anim2(expandT, m, m == expanded ? 1f : 0f, dt, 12f);
                if (r.y + r.h < top() || r.y > bottom()) continue;
                boolean hv = in(mouseX, mouseY, lx, r.y, lw, HEAD) && mouseY >= top() && mouseY <= bottom();
                float h = anim(hover, m, hv ? 1f : 0f, dt, 16f);
                int bg = Anim.mix(Anim.mix(0xFF191923, 0xFF222231, h), Anim.mix(0xFF191923, ThemeManager.ACCENT, 0.22f), en);
                rr(g, lx, r.y, lw, HEAD, Anim.fade(bg, a));
                g.fill(lx, r.y + 4, lx + 2, r.y + HEAD - 4, Anim.fade(ThemeManager.ACCENT, a * en));
                g.drawString(this.font, m.getName(), lx + 10, r.y + 9, Anim.fade(Anim.mix(0xFFC9C9D6, 0xFFFFFFFF, Math.max(h, en)), a));
                int rx = lx + lw - 10;
                g.drawString(this.font, ex > 0.5f ? "v" : ">", rx - this.font.width(">"), r.y + 9, Anim.fade(ThemeManager.TEXT_GRAY, a));
                rx -= 18;
                pill(g, rx - 26, r.y + 7, en, a);
                rx -= 34;
                if (m.getKeyBind() >= 0) {
                    String kn = keyName(m.getKeyBind());
                    int kw = this.font.width(kn) + 8;
                    rr(g, rx - kw, r.y + 6, kw, 14, Anim.fade(0xFF2A2A3A, a));
                    g.drawString(this.font, kn, rx - kw + 4, r.y + 9, Anim.fade(ThemeManager.TEXT_GRAY, a));
                }
                if (hv) tip = m.getDescription();
            } else {
                if (r.clipBottom <= r.clipTop) continue;
                int cy1 = Math.max(r.clipTop, top()), cy2 = Math.min(r.clipBottom, bottom());
                if (cy2 <= cy1) continue;
                g.enableScissor(lx, cy1, lx + lw, cy2);
                drawSetting(g, r, mouseX, mouseY, dt, a, lx, lw);
                g.disableScissor();
            }
        }
        g.disableScissor();

        if (maxScroll > 0) {
            int barH = Math.max(18, viewH * viewH / Math.max(viewH, contentH));
            int barY = top() + (int) ((viewH - barH) * (scroll / maxScroll));
            rr(g, wx + ww - 9, barY, 3, barH, Anim.fade(ThemeManager.ACCENT, a * 0.8f));
        }
        g.fill(wx + 6, bottom() + 4, wx + ww - 6, bottom() + 5, Anim.fade(0x22FFFFFF, a));
        g.drawString(this.font, tip != null ? tip : "LMB switch   RMB settings   wheel scroll", wx + 16, bottom() + 11, Anim.fade(ThemeManager.TEXT_GRAY, a));
        super.render(g, mouseX, mouseY, partial);
    }

    private float anim2(Map<Module, Float> m, Module k, float target, float dt, float speed) {
        float v = Anim.approach(m.getOrDefault(k, 0f), target, dt, speed);
        m.put(k, v);
        return v;
    }

    @SuppressWarnings("unchecked")
    private void drawSetting(GuiGraphics g, Row r, int mouseX, int mouseY, float dt, float a, int lx, int lw) {
        int x = lx + 8, w = lw - 16;
        boolean hv = in(mouseX, mouseY, x, r.y, w, r.h) && mouseY > r.clipTop && mouseY < r.clipBottom;
        Object key = r.setting != null ? r.setting : (r.kind == Kind.BIND ? bindKey(r.module) : (Object) r.kind);
        float h = anim(hover, key, hv ? 1f : 0f, dt, 16f);
        int rowBg = Anim.mix(0xFF15151E, 0xFF1D1D29, h);
        g.fill(lx, r.y - 2, lx + lw, r.y + r.h, Anim.fade(0xFF13131B, a));
        switch (r.kind) {
            case BOOL -> {
                Setting<Boolean> b = (Setting<Boolean>) r.setting;
                float on = Anim.approach(switchT.getOrDefault(b, b.getValue() ? 1f : 0f), b.getValue() ? 1f : 0f, dt, 14f);
                switchT.put(b, on);
                rr(g, x, r.y, w, r.h - 2, Anim.fade(rowBg, a));
                g.drawString(this.font, r.setting.getName(), x + 8, r.y + 6, Anim.fade(ThemeManager.TEXT_WHITE, a));
                pill(g, x + w - 34, r.y + 3, on, a);
            }
            case DOUBLE, INT -> {
                double min, max, val;
                if (r.setting instanceof Setting.DoubleSetting ds) { min = ds.getMin(); max = ds.getMax(); val = ds.getValue(); }
                else { Setting.IntSetting is = (Setting.IntSetting) r.setting; min = is.getMin(); max = is.getMax(); val = is.getValue(); }
                rr(g, x, r.y, w, r.h - 2, Anim.fade(rowBg, a));
                g.drawString(this.font, r.setting.getName(), x + 8, r.y + 4, Anim.fade(ThemeManager.TEXT_WHITE, a));
                String vt = r.kind == Kind.INT ? String.valueOf((int) val) : String.format(Locale.ROOT, "%.2f", val);
                g.drawString(this.font, vt, x + w - 8 - this.font.width(vt), r.y + 4, Anim.fade(ThemeManager.ACCENT, a));
                int tx = x + 8, tw = w - 16, ty = r.y + 16;
                float pct = (float) Mth.clamp((val - min) / Math.max(1e-9, max - min), 0, 1);
                rr(g, tx, ty, tw, 3, Anim.fade(0xFF2C2C3A, a));
                rr(g, tx, ty, Math.max(3, (int) (tw * pct)), 3, Anim.fade(ThemeManager.ACCENT, a));
                int kx = tx + (int) ((tw - 6) * pct);
                rr(g, kx, ty - 2, 6, 7, Anim.fade(Anim.mix(0xFFCFCFE0, 0xFFFFFFFF, h), a));
            }
            case BIND -> {
                boolean lis = listening == r.module;
                rr(g, x, r.y, w, r.h - 2, Anim.fade(lis ? Anim.mix(0xFF15151E, ThemeManager.ACCENT, 0.45f) : rowBg, a));
                String t = lis ? "Press a key   Esc cancel   Backspace clear" : "Keybind";
                g.drawString(this.font, t, x + 8, r.y + 6, Anim.fade(ThemeManager.TEXT_WHITE, a));
                if (!lis) { String kn = keyName(r.module.getKeyBind()); g.drawString(this.font, kn, x + w - 8 - this.font.width(kn), r.y + 6, Anim.fade(ThemeManager.ACCENT, a)); }
            }
            case RESET -> {
                rr(g, x, r.y + 2, w, r.h - 4, Anim.fade(rowBg, a));
                g.drawString(this.font, "Reset to defaults", x + 8, r.y + 7, Anim.fade(Anim.mix(ThemeManager.TEXT_GRAY, 0xFFFF7788, h), a));
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ input

    private boolean rightButton() {
        long win = GLFW.glfwGetCurrentContext();
        return win != 0 && GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
    }

    private void setSlider(Row r, double mx) {
        int tx = lx() + 8 + 8, tw = lw() - 16 - 16;
        double pct = Mth.clamp((mx - tx) / Math.max(1, tw), 0, 1);
        if (r.setting instanceof Setting.DoubleSetting ds) {
            double v = ds.getMin() + (ds.getMax() - ds.getMin()) * pct;
            ds.setValue(Math.round(v * 100.0) / 100.0);
        } else if (r.setting instanceof Setting.IntSetting is) {
            is.setValue((int) Math.round(is.getMin() + (is.getMax() - is.getMin()) * pct));
        }
    }

    @SuppressWarnings("unchecked")
    private static void reset(Module m) { for (Setting<?> s : m.settings) ((Setting<Object>) s).setValue(s.getDefaultValue()); }

    @Override
    @SuppressWarnings("unchecked")
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        double mx = event.x(), my = event.y();
        boolean right = rightButton();
        int wx = wx(), wy = wy(), ww = ww();
        int bx = wx + ww - 16;
        for (String t : new String[]{"Theme", "HUD"}) {
            int tw = this.font.width(t) + 14;
            bx -= tw;
            if (in(mx, my, bx, wy + 8, tw, 16)) { Minecraft.getInstance().setScreen(t.equals("HUD") ? new HudEditorScreen() : new ThemeScreen()); return true; }
            bx -= 6;
        }
        int tx = wx + 16, ty = tabsY();
        for (Category c : Category.values()) {
            int tw = this.font.width(c.getDisplayName());
            if (in(mx, my, tx - 6, ty - 3, tw + 12, 20)) { selected = c; expanded = null; scrollTarget = 0; scroll = 0; listening = null; return true; }
            tx += tw + 22;
        }
        if (my < top() || my > bottom()) return super.mouseClicked(event, doubleClick);
        int lx = lx(), lw = lw();
        for (Row r : layout()) {
            if (r.kind == Kind.MODULE) {
                if (!in(mx, my, lx, r.y, lw, HEAD)) continue;
                if (right) { expanded = expanded == r.module ? null : r.module; listening = null; } else r.module.toggle();
                return true;
            }
            if (my < r.clipTop || my > r.clipBottom || !in(mx, my, lx + 8, r.y, lw - 16, r.h)) continue;
            switch (r.kind) {
                case BOOL -> { Setting<Boolean> b = (Setting<Boolean>) r.setting; b.setValue(!b.getValue()); }
                case DOUBLE, INT -> { dragging = r; setSlider(r, mx); }
                case BIND -> listening = listening == r.module ? null : r.module;
                case RESET -> reset(r.module);
                default -> { }
            }
            return true;
        }
        listening = null;
        return super.mouseClicked(event, doubleClick);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent event, double dragX, double dragY) {
        if (dragging != null) { setSlider(dragging, event.x()); return true; }
        return super.mouseDragged(event, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent event) {
        dragging = null;
        return super.mouseReleased(event);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
        scrollTarget = Mth.clamp(scrollTarget - (float) (scrollY * 34), 0, Math.max(0, contentH - (bottom() - top())));
        return true;
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int key = event.key();
        if (listening != null) {
            if (key != GLFW.GLFW_KEY_ESCAPE) listening.setKeyBind(key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? -1 : key);
            listening = null;
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public void onClose() {
        try { NightfallClient.getInstance().configManager.save("default"); } catch (RuntimeException ignored) { }
        super.onClose();
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
