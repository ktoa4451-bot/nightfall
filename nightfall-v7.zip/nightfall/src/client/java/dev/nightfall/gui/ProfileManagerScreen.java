package dev.nightfall.gui;

import dev.nightfall.NightfallClient;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ProfileManagerScreen extends Screen {
    public ProfileManagerScreen() {
        super(Component.literal("Profiles"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int cy = this.height / 2;

        this.addRenderableWidget(Button.builder(Component.literal("Save Default"), b -> {
            NightfallClient.getInstance().configManager.save("default");
            Minecraft.getInstance().setScreen(null);
        }).bounds(cx - 100, cy - 40, 200, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Load Default"), b -> {
            NightfallClient.getInstance().configManager.load("default");
            Minecraft.getInstance().setScreen(null);
        }).bounds(cx - 100, cy - 10, 200, 20).build());

        this.addRenderableWidget(Button.builder(Component.literal("Close"), b -> {
            Minecraft.getInstance().setScreen(null);
        }).bounds(cx - 100, cy + 20, 200, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, "Config Profiles", this.width / 2, 40, 0xFFFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}