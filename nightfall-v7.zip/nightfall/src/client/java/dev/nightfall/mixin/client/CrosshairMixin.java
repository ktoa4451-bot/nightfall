package dev.nightfall.mixin.client;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.CustomCrosshair;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Gui.class)
public class CrosshairMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void onRenderCrosshair(GuiGraphics g, DeltaTracker deltaTracker, CallbackInfo ci) {
        var mod = NightfallClient.getInstance().moduleManager.getByName("CustomCrosshair").orElse(null);
        if (mod instanceof CustomCrosshair cc && cc.isEnabled()) {
            cc.render(g);
            ci.cancel(); // Отменяем ванильный прицел
        }
    }
}