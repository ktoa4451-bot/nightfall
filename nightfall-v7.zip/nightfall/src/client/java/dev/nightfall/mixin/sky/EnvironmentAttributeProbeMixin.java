package dev.nightfall.mixin.sky;

import dev.nightfall.util.SkyFog;
import net.minecraft.world.attribute.EnvironmentAttribute;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Camera-side attribute reads (fog, sky): getValue(attribute, partialTick). Optional (require = 0). */
@Mixin(targets = "net.minecraft.world.attribute.EnvironmentAttributeProbe")
public class EnvironmentAttributeProbeMixin {
    @Inject(method = "getValue", at = @At("RETURN"), cancellable = true, require = 0)
    private void nightfall$value(EnvironmentAttribute<?> attribute, float partialTick, CallbackInfoReturnable<Object> cir) {
        Object v = SkyFog.override(attribute);
        if (v != null) cir.setReturnValue(v);
    }
}
