package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.render.HoleEsp;
import net.minecraft.client.Minecraft;

/** Marks safe 1x1 holes near you: green = all bedrock, orange = bedrock/obsidian, red = closed but breakable (optional). */
public class HoleESP extends Module implements Tickable {
    public final Setting.IntSetting radius = new Setting.IntSetting("Radius", 8, 3, 12);
    public final Setting.IntSetting updateEvery = new Setting.IntSetting("UpdateEvery", 20, 5, 60);
    public final Setting.BooleanSetting showUnsafe = new Setting.BooleanSetting("ShowUnsafe", false);
    private int tick;

    public HoleESP() {
        super("HoleESP", "Highlights safe holes.", Category.VISUALS);
        settings.add(radius); settings.add(updateEvery); settings.add(showUnsafe);
    }

    @Override public void onEnable() { tick = 0; }
    @Override public void onDisable() { HoleEsp.clear(); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        if (++tick % updateEvery.getValue() != 0) return;
        HoleEsp.scan(mc, mc.player, radius.getValue(), showUnsafe.getValue());
    }
}
