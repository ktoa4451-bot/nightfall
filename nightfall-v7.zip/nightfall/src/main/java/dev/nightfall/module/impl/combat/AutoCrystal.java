package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

public class AutoCrystal extends Module {
    private final Setting.DoubleSetting reach = new Setting.DoubleSetting("Reach", 4.0, 1.0, 6.0);
    private final Setting.DoubleSetting minEnemyDmg = new Setting.DoubleSetting("MinEnemyDmg", 6.0, 0.0, 36.0);
    private final Setting.DoubleSetting maxSelfDmg = new Setting.DoubleSetting("MaxSelfDmg", 4.0, 0.0, 36.0);

    public AutoCrystal() {
        super("AutoCrystal", "Training crystal placement (local only).", Category.COMBAT);
        settings.add(reach);
        settings.add(minEnemyDmg);
        settings.add(maxSelfDmg);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public double getReach() { return reach.getValue(); }
    public double getMinEnemyDmg() { return minEnemyDmg.getValue(); }
    public double getMaxSelfDmg() { return maxSelfDmg.getValue(); }
}