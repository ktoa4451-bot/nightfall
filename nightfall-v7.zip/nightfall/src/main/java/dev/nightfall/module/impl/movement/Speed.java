package dev.nightfall.module.impl.movement;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.MoveMath;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/** Sets your horizontal speed (blocks per tick) while you hold a movement key. Sprinting is about 0.28. */
public class Speed extends Module implements Tickable {
    private final Setting.DoubleSetting speed = new Setting.DoubleSetting("Speed", 0.32, 0.1, 0.8);
    private final Setting.BooleanSetting inAir = new Setting.BooleanSetting("InAir", true);

    public Speed() {
        super("Speed", "Faster horizontal movement.", Category.MOVEMENT);
        settings.add(speed); settings.add(inAir);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null || !p.isAlive() || p.isFallFlying() || p.isInWater() || p.isInLava() || p.onClimbable()) return;
        if (!inAir.getValue() && !p.onGround()) return;
        double f = (mc.options.keyUp.isDown() ? 1 : 0) - (mc.options.keyDown.isDown() ? 1 : 0);
        double s = (mc.options.keyLeft.isDown() ? 1 : 0) - (mc.options.keyRight.isDown() ? 1 : 0);
        double[] v = MoveMath.horizontal(f, s, p.getYRot(), speed.getValue());
        if (v[0] == 0 && v[1] == 0) return;
        Vec3 cur = p.getDeltaMovement();
        p.setDeltaMovement(v[0], cur.y, v[1]);
    }
}
