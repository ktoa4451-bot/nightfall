package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

public class AutoGapple extends Module {
    private final Setting.DoubleSetting eatBelow = new Setting.DoubleSetting("EatBelow", 10.0, 1.0, 20.0);
    private final Setting.DoubleSetting emergency = new Setting.DoubleSetting("Emergency", 5.0, 1.0, 20.0);
    private final Setting.DoubleSetting skipAbsorb = new Setting.DoubleSetting("SkipAbsorb", 2.0, 0.0, 20.0);
    private final Setting.IntSetting cooldown = new Setting.IntSetting("Cooldown", 40, 10, 200);
    private final Setting.IntSetting maxEat = new Setting.IntSetting("MaxEat", 40, 20, 100);
    private final Setting.BooleanSetting onlyNearEnemy = new Setting.BooleanSetting("OnlyNearEnemy", false);
    private final Setting.DoubleSetting enemyRange = new Setting.DoubleSetting("EnemyRange", 8.0, 1.0, 20.0);

    private final GappleLogic logic = new GappleLogic();
    private int prevSlot = -1;
    private boolean holding;

    public AutoGapple() {
        super("AutoGapple", "Eats a golden apple when health is low.", Category.PLAYER);
        settings.add(eatBelow);
        settings.add(emergency);
        settings.add(skipAbsorb);
        settings.add(cooldown);
        settings.add(maxEat);
        settings.add(onlyNearEnemy);
        settings.add(enemyRange);
    }

    @Override
    public void onEnable() {
        holding = false;
        prevSlot = -1;
        logic.reset();
    }

    @Override
    public void onDisable() {
        release(Minecraft.getInstance());
        logic.reset();
    }

    public void onTick(Minecraft mc) {
        if (!isEnabled() || mc.player == null || mc.level == null) return;
        LocalPlayer p = mc.player;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isSpectator()) {
            release(mc);
            return;
        }

        double hp = p.getHealth(), abs = p.getAbsorptionAmount();
        boolean enemyNear = true;

        if (onlyNearEnemy.getValue()) {
            enemyNear = false;
            for (Player o : mc.level.players()) {
                if (o != p && o.isAlive() && p.distanceTo(o) <= enemyRange.getValue()) {
                    enemyNear = true;
                    break;
                }
            }
        }

        int slot = pickSlot(p, hp, emergency.getValue());
        GappleLogic.Action a = logic.step(hp, abs, p.isUsingItem(), slot >= 0 || holding, enemyNear,
                eatBelow.getValue(), skipAbsorb.getValue(), cooldown.getValue(), maxEat.getValue());

        switch (a) {
            case START -> {
                prevSlot = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(slot);
                mc.options.keyUse.setDown(true);
                holding = true;
                mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
            }
            case STOP -> release(mc);
            default -> {
                if (holding && logic.phase == GappleLogic.Phase.EATING) {
                    mc.options.keyUse.setDown(true);
                }
            }
        }
    }

    private void release(Minecraft mc) {
        if (holding && mc != null && mc.options != null) mc.options.keyUse.setDown(false);
        if (holding && prevSlot >= 0 && mc != null && mc.player != null) {
            mc.player.getInventory().setSelectedSlot(prevSlot);
        }
        holding = false;
        prevSlot = -1;
        if (logic.phase == GappleLogic.Phase.EATING) {
            logic.phase = GappleLogic.Phase.COOLDOWN;
        }
    }

    private int findSlot(LocalPlayer p, Item item) {
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(item)) return i;
        return -1;
    }

    private int pickSlot(LocalPlayer p, double hp, double emergency) {
        int plain = findSlot(p, Items.GOLDEN_APPLE);
        int ench = findSlot(p, Items.ENCHANTED_GOLDEN_APPLE);
        if (hp <= emergency) return ench >= 0 ? ench : plain;
        return plain >= 0 ? plain : ench;
    }
}