package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.CrystalMath;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Hints only (places and breaks nothing): the best obsidian/bedrock spot for a crystal near an enemy and the damage of crystals near you. Estimates ignore armor and walls. */
public class CrystalHelper extends Module implements Tickable {
    public final Setting.IntSetting radius = new Setting.IntSetting("Radius", 4, 2, 6);
    public final Setting.IntSetting enemyRange = new Setting.IntSetting("EnemyRange", 10, 4, 12);
    public final Setting.DoubleSetting selfWeight = new Setting.DoubleSetting("SelfDamageWeight", 1.5, 0.5, 4.0);
    public static final List<String> LINES = new ArrayList<>();
    public static volatile BlockPos bestSpot;
    private int tick;

    public CrystalHelper() {
        super("CrystalHelper", "Shows the best crystal spot and crystal damage (hints only).", Category.COMBAT);
        settings.add(radius); settings.add(enemyRange); settings.add(selfWeight);
    }

    @Override public void onEnable() { tick = 0; }
    @Override public void onDisable() { LINES.clear(); bestSpot = null; }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || ++tick % 10 != 0) return;
        List<String> lines = new ArrayList<>();
        BlockPos spot = null;
        int diff = mc.level.getDifficulty().getId();
        double hp = p.getHealth() + p.getAbsorptionAmount();
        for (EndCrystal c : mc.level.getEntitiesOfClass(EndCrystal.class, p.getBoundingBox().inflate(8), Entity::isAlive)) {
            double d = CrystalMath.distance(p.getX(), p.getY(), p.getZ(), c.getX(), c.getY(), c.getZ());
            double self = CrystalMath.rawDamage(d, 1.0, diff);
            lines.add(String.format(Locale.ROOT, "Crystal %.1f m: up to %.0f damage to you%s", d, self, self >= hp ? " !!" : ""));
            if (lines.size() >= 3) break;
        }
        List<Player> enemies = new ArrayList<>();
        for (Player o : mc.level.players()) if (o != p && o.isAlive() && !o.isSpectator() && p.distanceTo(o) <= enemyRange.getValue()) enemies.add(o);
        if (!enemies.isEmpty()) {
            int r = radius.getValue();
            BlockPos base = p.blockPosition();
            BlockPos.MutableBlockPos q = new BlockPos.MutableBlockPos();
            double best = -999, bestEnemy = 0, bestSelf = 0;
            for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
                q.set(base.getX() + dx, base.getY() + dy, base.getZ() + dz);
                BlockState b = mc.level.getBlockState(q);
                if (!b.is(Blocks.OBSIDIAN) && !b.is(Blocks.BEDROCK)) continue;
                if (!mc.level.getBlockState(q.above()).isAir() || !mc.level.getBlockState(q.above(2)).isAir()) continue;
                double cx = q.getX() + 0.5, cy = q.getY() + 1.0, cz = q.getZ() + 0.5;
                double self = CrystalMath.rawDamage(CrystalMath.distance(p.getX(), p.getY(), p.getZ(), cx, cy, cz), 1.0, diff);
                double enemy = 0;
                for (Player o : enemies) enemy = Math.max(enemy, CrystalMath.rawDamage(CrystalMath.distance(o.getX(), o.getY(), o.getZ(), cx, cy, cz), 1.0, diff));
                double sc = CrystalMath.score(enemy, self, hp, selfWeight.getValue());
                if (sc > best) { best = sc; spot = q.immutable(); bestEnemy = enemy; bestSelf = self; }
            }
            if (spot != null && best > 0) lines.add(String.format(Locale.ROOT, "Best spot %s: enemy up to %.0f, you up to %.0f (no armor)", spot.toShortString(), bestEnemy, bestSelf));
            else spot = null;
        }
        synchronized (LINES) { LINES.clear(); LINES.addAll(lines); }
        bestSpot = spot;
    }
}
