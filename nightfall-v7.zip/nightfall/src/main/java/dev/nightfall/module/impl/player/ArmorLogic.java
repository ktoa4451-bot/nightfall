package dev.nightfall.module.impl.player;

public final class ArmorLogic {
    private ArmorLogic() { }

    public static final int HEAD = 0, CHEST = 1, LEGS = 2, FEET = 3;

    public static int slotOf(String path, boolean elytraIsChest) {
        if (path == null) return -1;
        if (path.endsWith("_helmet") || path.equals("turtle_helmet")) return HEAD;
        if (path.endsWith("_chestplate")) return CHEST;
        if (path.endsWith("_leggings")) return LEGS;
        if (path.endsWith("_boots")) return FEET;
        if (elytraIsChest && path.equals("elytra")) return CHEST;
        return -1;
    }

    private static double tier(String path) {
        if (path.startsWith("netherite_")) return 5.0;
        if (path.startsWith("diamond_")) return 4.0;
        if (path.startsWith("iron_")) return 3.0;
        if (path.startsWith("chainmail_")) return 2.5;
        if (path.startsWith("golden_")) return 2.0;
        if (path.equals("turtle_helmet")) return 2.0;
        if (path.startsWith("leather_")) return 1.0;
        return 0.5;
    }

    public static double score(String path, int damage, int maxDamage) {
        double left = maxDamage > 0 ? Math.max(0.0, 1.0 - (double) damage / maxDamage) : 1.0;
        if (maxDamage > 0 && left < 0.05) return 0.0;
        return tier(path) + left * 0.9;
    }

    public static boolean better(double candidate, double current, double margin) {
        return candidate > current + margin;
    }
}