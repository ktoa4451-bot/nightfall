package dev.nightfall.module.impl.misc;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import net.minecraft.client.Minecraft;

public class Fullbright extends Module {
    private double oldGamma = 1.0;

    public Fullbright() {
        super("Fullbright", "Makes the world bright.", Category.MISC);
    }

    @Override
    public void onEnable() {
        Minecraft client = Minecraft.getInstance();
        if (client.options != null) {
            oldGamma = client.options.gamma().get();
            client.options.gamma().set(15.0);
        }
    }

    @Override
    public void onDisable() {
        Minecraft client = Minecraft.getInstance();
        if (client.options != null) {
            client.options.gamma().set(oldGamma);
        }
    }
}