package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

public class TargetHud extends Module {
    public TargetHud() {
        super("TargetHud", "Displays info about the entity you look at.", Category.VISUALS);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public LivingEntity getTarget() {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null) return null;

        Entity hit = client.crosshairPickEntity;
        if (hit instanceof LivingEntity living && living != client.player) {
            return living;
        }

        LivingEntity closest = null;
        double best = 4.0;
        for (Entity e : client.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity living) || living == client.player) continue;
            double d = client.player.distanceTo(living);
            if (d < best) {
                best = d;
                closest = living;
            }
        }
        return closest;
    }
}