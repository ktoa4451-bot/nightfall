package dev.nightfall.module.impl.movement;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import net.minecraft.client.Minecraft;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Automatically keeps you sprinting.", Category.MOVEMENT);
    }

    @Override
    public void onEnable() {
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            client.options.keySprint.setDown(true);
        }
    }

    @Override
    public void onDisable() {
        Minecraft client = Minecraft.getInstance();
        if (client.player != null) {
            client.options.keySprint.setDown(false);
        }
    }

    public void onTick(Minecraft client) {
        if (isEnabled() && client.player != null) {
            client.options.keySprint.setDown(true);
        }
    }
}