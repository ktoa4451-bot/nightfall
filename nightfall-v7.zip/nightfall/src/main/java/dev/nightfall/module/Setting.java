package dev.nightfall.module;

public class Setting<T> {
    private final String name;
    private final T defaultValue;
    private T value;

    public Setting(String name, T defaultValue) {
        this.name = name;
        this.defaultValue = defaultValue;
        this.value = defaultValue;
    }

    public String getName() { return name; }
    public T getValue() { return value; }
    public void setValue(T value) { this.value = value; }
    public T getDefaultValue() { return defaultValue; }

    public static class BooleanSetting extends Setting<Boolean> {
        public BooleanSetting(String name, boolean def) {
            super(name, def);
        }
    }

    public static class DoubleSetting extends Setting<Double> {
        private final double min;
        private final double max;

        public DoubleSetting(String name, double def, double min, double max) {
            super(name, def);
            this.min = min;
            this.max = max;
        }

        public double getMin() { return min; }
        public double getMax() { return max; }
    }

    public static class IntSetting extends Setting<Integer> {
        private final int min;
        private final int max;

        public IntSetting(String name, int def, int min, int max) {
            super(name, def);
            this.min = min;
            this.max = max;
        }

        public int getMin() { return min; }
        public int getMax() { return max; }
    }
}