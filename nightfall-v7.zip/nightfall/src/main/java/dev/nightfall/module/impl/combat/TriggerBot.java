package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

/** Hits whatever the crosshair is on, once the attack cooldown is ready. Turns nothing: you aim, it clicks. */
public class TriggerBot extends Module implements Tickable {
    private final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 3.0, 2.0, 4.0);
    private final Setting.DoubleSetting cooldown = new Setting.DoubleSetting("Cooldown", 0.92, 0.5, 1.0);
    private final Setting.BooleanSetting players = new Setting.BooleanSetting("Players", true);
    private final Setting.BooleanSetting mobs = new Setting.BooleanSetting("Mobs", false);

    public TriggerBot() {
        super("TriggerBot", "Attacks the entity under the crosshair when the cooldown is ready.", Category.COMBAT);
        settings.add(range); settings.add(cooldown); settings.add(players); settings.add(mobs);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive() || p.isUsingItem()) return;
        HitResult h = mc.hitResult;
        if (!(h instanceof EntityHitResult eh) || !(eh.getEntity() instanceof LivingEntity t)) return;
        if (t == p || !t.isAlive() || t instanceof ArmorStand) return;
        if (!(t instanceof Player ? players.getValue() : mobs.getValue())) return;
        if (p.distanceTo(t) > range.getValue()) return;
        if (p.getAttackStrengthScale(0.5f) < cooldown.getValue()) return;
        mc.gameMode.attack(p, t);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
