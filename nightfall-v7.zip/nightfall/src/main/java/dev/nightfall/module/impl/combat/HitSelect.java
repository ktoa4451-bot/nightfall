package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.CritLogic;
import dev.nightfall.util.FallTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.EntityHitResult;

/** Hits the entity under the crosshair only when it would be a critical hit; if no crit comes within MaxWait it hits anyway, so it never stalls a fight. */
public class HitSelect extends Module implements Tickable {
    private final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 3.0, 2.0, 4.0);
    private final Setting.IntSetting maxWait = new Setting.IntSetting("MaxWaitMs", 350, 0, 1000);
    private final Setting.BooleanSetting players = new Setting.BooleanSetting("Players", true);
    private final Setting.BooleanSetting mobs = new Setting.BooleanSetting("Mobs", false);
    private final FallTracker fall = new FallTracker();
    private long readySince;

    public HitSelect() {
        super("HitSelect", "Attacks on critical hits; falls back to a normal hit after MaxWaitMs.", Category.COMBAT);
        settings.add(range); settings.add(maxWait); settings.add(players); settings.add(mobs);
    }

    @Override public void onEnable() { readySince = 0; fall.reset(); }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive() || p.isUsingItem()) return;
        double f = fall.update(p.onGround(), p.onClimbable() || p.isInWater() || p.isPassenger(), p.getY());
        if (!(mc.hitResult instanceof EntityHitResult eh) || !(eh.getEntity() instanceof LivingEntity t) || t == p || !t.isAlive() || t instanceof ArmorStand) { readySince = 0; return; }
        if (!(t instanceof Player ? players.getValue() : mobs.getValue()) || p.distanceTo(t) > range.getValue()) { readySince = 0; return; }
        boolean ready = p.getAttackStrengthScale(0.5f) >= 0.92f;
        long now = System.currentTimeMillis();
        if (!ready) { readySince = 0; return; }
        if (readySince == 0) readySince = now;
        boolean crit = CritLogic.isCrit(f, p.onGround(), p.onClimbable(), p.isInWater(), p.hasEffect(MobEffects.BLINDNESS), p.isPassenger(), p.getDeltaMovement().y);
        if (CritLogic.shouldHit(true, crit, now - readySince, maxWait.getValue())) {
            mc.gameMode.attack(p, t);
            p.swing(InteractionHand.MAIN_HAND);
            readySince = 0;
        }
    }
}
