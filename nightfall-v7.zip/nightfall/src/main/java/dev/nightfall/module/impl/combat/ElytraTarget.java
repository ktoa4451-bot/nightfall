package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

public class ElytraTarget extends Module {
    private final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 64.0, 10.0, 128.0);
    private final Setting.DoubleSetting radius = new Setting.DoubleSetting("Radius", 6.0, 2.0, 20.0);
    private final Setting.DoubleSetting height = new Setting.DoubleSetting("Height", 2.0, -3.0, 8.0);
    private final Setting.DoubleSetting minHealth = new Setting.DoubleSetting("MinHealth", 6.0, 0.0, 20.0);
    private final Setting.DoubleSetting minSpeed = new Setting.DoubleSetting("MinSpeed", 0.25, 0.1, 1.0);
    private final Setting.IntSetting maxRockets = new Setting.IntSetting("MaxRockets", 16, 0, 64);
    private final Setting.BooleanSetting autoDeploy = new Setting.BooleanSetting("AutoDeploy", true);
    private final Setting.DoubleSetting attackReach = new Setting.DoubleSetting("AttackReach", 3.0, 1.0, 6.0);
    private final Setting.DoubleSetting rotationSpeed = new Setting.DoubleSetting("RotSpeed", 30.0, 1.0, 180.0);

    public ElytraTarget() {
        super("ElytraTarget", "Orbit target on elytra and strike (local only).", Category.COMBAT);
        settings.add(range);
        settings.add(radius);
        settings.add(height);
        settings.add(minHealth);
        settings.add(minSpeed);
        settings.add(maxRockets);
        settings.add(autoDeploy);
        settings.add(attackReach);
        settings.add(rotationSpeed);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public double getRange() { return range.getValue(); }
    public double getRadius() { return radius.getValue(); }
    public double getHeight() { return height.getValue(); }
    public double getMinHealth() { return minHealth.getValue(); }
    public double getMinSpeed() { return minSpeed.getValue(); }
    public int getMaxRockets() { return maxRockets.getValue(); }
    public boolean isAutoDeploy() { return autoDeploy.getValue(); }
    public double getAttackReach() { return attackReach.getValue(); }
    public double getRotationSpeed() { return rotationSpeed.getValue(); }
}