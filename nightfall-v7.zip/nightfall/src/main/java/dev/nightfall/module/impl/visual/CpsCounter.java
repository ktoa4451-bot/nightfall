package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;

import java.util.ArrayDeque;
import java.util.Deque;

public class CpsCounter extends Module {
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();

    public CpsCounter() {
        super("CpsCounter", "Tracks clicks per second.", Category.VISUALS);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public void onClick(boolean left) {
        if (!isEnabled()) return;
        (left ? leftClicks : rightClicks).addLast(System.currentTimeMillis());
    }

    public int getLeftCps() {
        trim(leftClicks);
        return leftClicks.size();
    }

    public int getRightCps() {
        trim(rightClicks);
        return rightClicks.size();
    }

    private void trim(Deque<Long> q) {
        long now = System.currentTimeMillis();
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.pollFirst();
    }
}