package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** Boxes and names for dropped items (drawn by render/ItemEsp). */
public class ItemESP extends Module {
    public final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 32.0, 8.0, 96.0);
    public final Setting.BooleanSetting showNames = new Setting.BooleanSetting("ShowNames", true);
    public final Setting.BooleanSetting onlyValuable = new Setting.BooleanSetting("OnlyValuable", false);

    public ItemESP() {
        super("ItemESP", "Highlights dropped items.", Category.VISUALS);
        settings.add(range); settings.add(showNames); settings.add(onlyValuable);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
