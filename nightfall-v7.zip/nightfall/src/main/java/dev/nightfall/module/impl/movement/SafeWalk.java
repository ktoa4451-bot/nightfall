package dev.nightfall.module.impl.movement;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/** Holds sneak by itself when your next step would take you off an edge, so you never fall by walking. */
public class SafeWalk extends Module implements Tickable {
    private boolean forced;

    public SafeWalk() { super("SafeWalk", "Stops you at edges.", Category.MOVEMENT); }

    @Override public void onEnable() { forced = false; }
    @Override public void onDisable() { release(Minecraft.getInstance()); }

    private void release(Minecraft mc) {
        if (forced && mc != null && mc.options != null) mc.options.keyShift.setDown(false);
        forced = false;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) { release(mc); return; }
        if (!p.onGround()) { release(mc); return; }
        Vec3 v = p.getDeltaMovement();
        boolean edge = mc.level.noCollision(p, p.getBoundingBox().move(v.x * 3.0, -0.6, v.z * 3.0));
        if (edge) { mc.options.keyShift.setDown(true); forced = true; }
        else release(mc);
    }
}
