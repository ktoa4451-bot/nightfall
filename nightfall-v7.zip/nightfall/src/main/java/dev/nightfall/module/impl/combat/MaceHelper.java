package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.FallTracker;
import dev.nightfall.util.MaceMath;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;

/** With a mace in hand: swings at the entity under the crosshair once the fall is long enough for the smash bonus (vanilla formula). */
public class MaceHelper extends Module implements Tickable {
    private final Setting.DoubleSetting minBonus = new Setting.DoubleSetting("MinBonusDamage", 12.0, 4.0, 40.0);
    private final Setting.DoubleSetting reach = new Setting.DoubleSetting("Reach", 3.0, 2.0, 4.0);
    private final FallTracker fall = new FallTracker();
    public static volatile double lastBonus;

    public MaceHelper() {
        super("MaceHelper", "Smash with the mace when the fall is long enough.", Category.COMBAT);
        settings.add(minBonus); settings.add(reach);
    }

    @Override public void onEnable() { fall.reset(); }
    @Override public void onDisable() { lastBonus = 0; }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
        double f = fall.update(p.onGround(), p.onClimbable() || p.isInWater() || p.isPassenger() || p.isFallFlying(), p.getY());
        lastBonus = MaceMath.bonusDamage(f);
        if (!p.getMainHandItem().is(Items.MACE) || p.onGround()) return;
        if (!(mc.hitResult instanceof EntityHitResult eh) || !(eh.getEntity() instanceof LivingEntity t) || t == p || !t.isAlive() || t instanceof ArmorStand) return;
        if (p.distanceTo(t) > reach.getValue() || p.getAttackStrengthScale(0.5f) < 0.92f) return;
        if (!MaceMath.worthSmash(f, minBonus.getValue())) return;
        mc.gameMode.attack(p, t);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
