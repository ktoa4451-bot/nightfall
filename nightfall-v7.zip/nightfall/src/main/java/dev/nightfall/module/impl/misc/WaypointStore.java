package dev.nightfall.module.impl.misc;

import dev.nightfall.util.Waypoints;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Loads and saves the waypoint list (one text line, see util.Waypoints). A broken or missing file just gives an empty list. */
public final class WaypointStore {
    private WaypointStore() { }

    private static Waypoints cache;

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("nightfall").resolve("waypoints.txt"); }

    public static synchronized Waypoints get() {
        if (cache == null) {
            try { cache = Files.exists(file()) ? Waypoints.parse(Files.readString(file())) : new Waypoints(); }
            catch (IOException | RuntimeException e) { cache = new Waypoints(); }
        }
        return cache;
    }

    public static synchronized void save() {
        try { Files.createDirectories(file().getParent()); Files.writeString(file(), get().format()); }
        catch (IOException ignored) { }
    }
}
