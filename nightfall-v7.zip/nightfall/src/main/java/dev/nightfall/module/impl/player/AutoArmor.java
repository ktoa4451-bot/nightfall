package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;

public class AutoArmor extends Module {
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 2, 1, 20);
    private final Setting.BooleanSetting keepElytra = new Setting.BooleanSetting("KeepElytra", true);
    private final Setting.DoubleSetting margin = new Setting.DoubleSetting("Margin", 0.5, 0.0, 2.0);

    private int tick;

    public AutoArmor() {
        super("AutoArmor", "Equips the best armor from inventory.", Category.PLAYER);
        settings.add(delay);
        settings.add(keepElytra);
        settings.add(margin);
    }

    @Override public void onEnable() { tick = 0; }
    @Override public void onDisable() {}

    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private String path(ItemStack s) {
        return s.isEmpty() ? null : BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
    }

    private double score(ItemStack s) {
        String pa = path(s);
        return pa == null ? -1.0 : ArmorLogic.score(pa, s.isDamageableItem() ? s.getDamageValue() : 0, s.isDamageableItem() ? s.getMaxDamage() : 0);
    }

    public void onTick(Minecraft mc) {
        if (!isEnabled() || mc.player == null || mc.level == null) return;
        LocalPlayer p = mc.player;
        if (++tick % Math.max(1, delay.getValue()) != 0) return;
        if (mc.screen != null || mc.gameMode == null || !p.isAlive() || p.isSpectator() || !p.containerMenu.getCarried().isEmpty()) return;

        boolean keepEl = keepElytra.getValue();
        double marginVal = margin.getValue();

        for (int a = 0; a < 4; a++) {
            ItemStack worn = p.getItemBySlot(SLOTS[a]);
            if (a == ArmorLogic.CHEST && keepEl && "elytra".equals(path(worn))) continue;

            double cur = score(worn);
            int bestInv = -1;
            double best = cur;

            for (int i = 9; i < 45; i++) {
                ItemStack c = p.inventoryMenu.getSlot(i).getItem();
                if (c.isEmpty() || ArmorLogic.slotOf(path(c), false) != a) continue;
                double sc = score(c);
                if (sc > best && ArmorLogic.better(sc, cur, worn.isEmpty() ? -1.0 : marginVal)) {
                    best = sc;
                    bestInv = i;
                }
            }

            if (bestInv < 0) continue;

            int id = p.inventoryMenu.containerId, armorSlot = 5 + a;
            mc.gameMode.handleInventoryMouseClick(id, bestInv, 0, ClickType.PICKUP, p);
            mc.gameMode.handleInventoryMouseClick(id, armorSlot, 0, ClickType.PICKUP, p);
            if (!p.containerMenu.getCarried().isEmpty()) {
                mc.gameMode.handleInventoryMouseClick(id, bestInv, 0, ClickType.PICKUP, p);
            }
            return;
        }
    }
}