package dev.nightfall.module.impl.player;

public final class GappleLogic {
    public enum Phase { IDLE, EATING, COOLDOWN }
    public enum Action { NONE, START, STOP }

    public Phase phase = Phase.IDLE;
    private int ticks;

    public void reset() { phase = Phase.IDLE; ticks = 0; }

    public Action step(double hp, double absorption, boolean usingItem, boolean haveGapple, boolean allowed,
                       double eatBelow, double skipAbsorb, int cooldown, int maxEat) {
        switch (phase) {
            case IDLE -> {
                if (allowed && haveGapple && hp <= eatBelow && absorption < skipAbsorb) { phase = Phase.EATING; ticks = 0; return Action.START; }
            }
            case EATING -> {
                ticks++;
                if ((!usingItem && ticks > 3) || ticks > maxEat || !allowed) { phase = Phase.COOLDOWN; ticks = 0; return Action.STOP; }
            }
            case COOLDOWN -> { if (++ticks >= cooldown) { phase = Phase.IDLE; ticks = 0; } }
        }
        return Action.NONE;
    }
}