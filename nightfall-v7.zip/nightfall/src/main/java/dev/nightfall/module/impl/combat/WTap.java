package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

/** After you hit something (the attack cooldown drops from full to empty) the sprint is dropped for one tick and given back the next, which resets the sprint knockback. */
public class WTap extends Module implements Tickable {
    private float prev = 1f;
    private int phase;      // 0 idle, 1 sprint was dropped, give it back next tick

    public WTap() { super("WTap", "Resets sprint after each hit.", Category.COMBAT); }

    @Override public void onEnable() { prev = 1f; phase = 0; }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) return;
        float s = p.getAttackStrengthScale(0f);
        if (phase == 1) {
            if (mc.options.keyUp.isDown() && p.getFoodData().getFoodLevel() > 6 && !p.isUsingItem()) p.setSprinting(true);
            phase = 0;
        } else if (prev > 0.8f && s < 0.3f && p.isSprinting()) {
            p.setSprinting(false);
            phase = 1;
        }
        prev = s;
    }
}
