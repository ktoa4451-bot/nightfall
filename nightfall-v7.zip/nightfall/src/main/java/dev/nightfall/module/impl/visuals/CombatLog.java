package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.DamageLog;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/** Short on-screen log of health changes: yours and your target's ("You -4.5 HP", "Steve -3.0 HP"). Entries fade after LifeSeconds. */
public class CombatLog extends Module implements Tickable {
    public final Setting.DoubleSetting life = new Setting.DoubleSetting("LifeSeconds", 6.0, 2.0, 20.0);
    public final Setting.DoubleSetting minChange = new Setting.DoubleSetting("MinChange", 0.5, 0.1, 4.0);
    public static final DamageLog LOG = new DamageLog(6, 6000);
    private double prevSelf = -1, prevTarget = -1;
    private LivingEntity target;

    public CombatLog() {
        super("CombatLog", "Log of health changes in a fight.", Category.VISUALS);
        settings.add(life); settings.add(minChange);
    }

    @Override public void onEnable() { prevSelf = -1; prevTarget = -1; target = null; }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        long now = System.currentTimeMillis();
        double self = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        if (prevSelf >= 0) { String t = DamageLog.change(prevSelf, self, minChange.getValue()); if (t != null) LOG.add(now, "You " + t); }
        prevSelf = self;
        if (mc.hitResult instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le && le != mc.player && le.isAlive()) {
            if (le != target) { target = le; prevTarget = -1; }
        }
        if (target != null && target.isAlive() && !target.isRemoved()) {
            double th = target.getHealth() + target.getAbsorptionAmount();
            if (prevTarget >= 0) { String t = DamageLog.change(prevTarget, th, minChange.getValue()); if (t != null) LOG.add(now, target.getName().getString() + " " + t); }
            prevTarget = th;
        } else { target = null; prevTarget = -1; }
    }
}
