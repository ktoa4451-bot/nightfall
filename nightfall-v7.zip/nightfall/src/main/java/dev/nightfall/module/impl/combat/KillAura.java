package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

public class KillAura extends Module {
    private final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 3.0, 1.0, 6.0);
    private final Setting.DoubleSetting fov = new Setting.DoubleSetting("FOV", 360.0, 30.0, 360.0);
    private final Setting.BooleanSetting playersOnly = new Setting.BooleanSetting("Players", true);
    private final Setting.BooleanSetting visibleOnly = new Setting.BooleanSetting("Visible", true);
    private final Setting.BooleanSetting requireCrosshair = new Setting.BooleanSetting("Crosshair", true);
    private final Setting.DoubleSetting rotationSpeed = new Setting.DoubleSetting("RotSpeed", 30.0, 1.0, 180.0);

    public KillAura() {
        super("KillAura", "Training aura (local only).", Category.COMBAT);
        settings.add(range);
        settings.add(fov);
        settings.add(playersOnly);
        settings.add(visibleOnly);
        settings.add(requireCrosshair);
        settings.add(rotationSpeed);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public double getRange() { return range.getValue(); }
    public double getFov() { return fov.getValue(); }
    public boolean isPlayersOnly() { return playersOnly.getValue(); }
    public boolean isVisibleOnly() { return visibleOnly.getValue(); }
    public boolean isRequireCrosshair() { return requireCrosshair.getValue(); }
    public double getRotationSpeed() { return rotationSpeed.getValue(); }
}