package dev.nightfall.module.impl.movement;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/** While gliding and holding forward, pushes you along the way you look up to MaxSpeed (blocks per tick); needs no fireworks. */
public class ElytraFly extends Module implements Tickable {
    private final Setting.DoubleSetting boost = new Setting.DoubleSetting("Boost", 0.04, 0.01, 0.15);
    private final Setting.DoubleSetting maxSpeed = new Setting.DoubleSetting("MaxSpeed", 1.6, 0.8, 3.0);

    public ElytraFly() {
        super("ElytraFly", "Elytra flight without fireworks.", Category.MOVEMENT);
        settings.add(boost); settings.add(maxSpeed);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null || !p.isFallFlying() || !mc.options.keyUp.isDown()) return;
        Vec3 v = p.getDeltaMovement();
        if (v.length() >= maxSpeed.getValue()) return;
        p.setDeltaMovement(v.add(p.getLookAngle().scale(boost.getValue())));
    }
}
