package dev.nightfall.module;

import net.minecraft.client.Minecraft;

/** A module that wants a call every client tick while it is enabled (EventHandler calls it). */
public interface Tickable {
    void onTick(Minecraft mc);
}
