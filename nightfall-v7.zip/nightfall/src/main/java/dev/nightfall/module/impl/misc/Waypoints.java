package dev.nightfall.module.impl.misc;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** Named points drawn on the screen with their distance. Manage them with /nfpoint set|del|list (stored in config/nightfall/waypoints.txt). */
public class Waypoints extends Module {
    public final Setting.DoubleSetting maxDistance = new Setting.DoubleSetting("MaxDistance", 2000.0, 100.0, 10000.0);

    public Waypoints() {
        super("Waypoints", "Named points with distance markers.", Category.MISC);
        settings.add(maxDistance);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
