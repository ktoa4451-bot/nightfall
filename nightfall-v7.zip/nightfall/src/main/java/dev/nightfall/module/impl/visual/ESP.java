package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

public class ESP extends Module {
    private final Setting.BooleanSetting tracers = new Setting.BooleanSetting("Tracers", true);
    private final Setting.BooleanSetting boxes = new Setting.BooleanSetting("Boxes", true);
    private final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 64.0, 16.0, 256.0);

    public ESP() {
        super("ESP", "Renders boxes and tracers.", Category.VISUALS);
        settings.add(tracers);
        settings.add(boxes);
        settings.add(range);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public boolean isTracers() { return tracers.getValue(); }
    public boolean isBoxes() { return boxes.getValue(); }
    public double getRange() { return range.getValue(); }
}