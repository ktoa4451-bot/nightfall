package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.block.state.BlockState;

/** Breaks the nearest block around you, one at a time, within Radius. Never touches bedrock or the block you stand on (IgnoreBelow). */
public class Nuker extends Module implements Tickable {
    private final Setting.IntSetting radius = new Setting.IntSetting("Radius", 3, 1, 4);
    private final Setting.BooleanSetting ignoreBelow = new Setting.BooleanSetting("IgnoreBelow", true);
    private BlockPos current;

    public Nuker() {
        super("Nuker", "Breaks blocks around you.", Category.PLAYER);
        settings.add(radius); settings.add(ignoreBelow);
    }

    @Override public void onEnable() { current = null; }
    @Override public void onDisable() { Minecraft mc = Minecraft.getInstance(); if (mc.gameMode != null) mc.gameMode.stopDestroyBlock(); current = null; }

    private boolean ok(Minecraft mc, LocalPlayer p, BlockPos b) {
        BlockState s = mc.level.getBlockState(b);
        if (s.isAir() || !s.getFluidState().isEmpty() || s.getDestroySpeed(mc.level, b) < 0) return false;
        if (ignoreBelow.getValue() && b.getX() == p.getBlockX() && b.getZ() == p.getBlockZ() && b.getY() < p.getBlockY()) return false;
        return p.getEyePosition().distanceTo(net.minecraft.world.phys.Vec3.atCenterOf(b)) <= 4.5;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
        if (current != null && !ok(mc, p, current)) { mc.gameMode.stopDestroyBlock(); current = null; }
        if (current == null) {
            double best = 1e18; BlockPos base = p.blockPosition();
            int r = radius.getValue();
            for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
                BlockPos b = base.offset(dx, dy, dz);
                if (!ok(mc, p, b)) continue;
                double d = b.distSqr(base);
                if (d < best) { best = d; current = b; }
            }
        }
        if (current == null) return;
        Direction dir = Direction.getApproximateNearest(p.getX() - current.getX() - 0.5, p.getEyeY() - current.getY() - 0.5, p.getZ() - current.getZ() - 0.5);
        mc.gameMode.continueDestroyBlock(current, dir);
        p.swing(InteractionHand.MAIN_HAND);
    }
}
