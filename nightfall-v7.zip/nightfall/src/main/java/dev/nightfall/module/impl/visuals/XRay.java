package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.render.XrayEsp;
import dev.nightfall.util.OreKinds;
import net.minecraft.client.Minecraft;

/**
 * X-ray as an overlay: ores around you are marked on the screen through the rock. It does not change the world rendering, and it can only
 * show blocks the server has really sent (servers with anti-xray hide them). The scan is spread over many ticks.
 */
public class XRay extends Module implements Tickable {
    public final Setting.IntSetting radius = new Setting.IntSetting("Radius", 20, 6, 40);
    public final Setting.IntSetting maxMarks = new Setting.IntSetting("MaxMarks", 120, 20, 400);
    public final Setting.IntSetting budget = new Setting.IntSetting("CellsPerTick", 6000, 1000, 20000);
    public final Setting.BooleanSetting[] ore = new Setting.BooleanSetting[OreKinds.COUNT];

    public XRay() {
        super("XRay", "Marks ores through walls (overlay).", Category.VISUALS);
        settings.add(radius); settings.add(maxMarks); settings.add(budget);
        boolean[] def = {false, false, false, true, false, false, true, true, false, true};
        for (int i = 0; i < OreKinds.COUNT; i++) { ore[i] = new Setting.BooleanSetting(OreKinds.NAMES[i], def[i]); settings.add(ore[i]); }
    }

    @Override public void onEnable() { XrayEsp.reset(); }
    @Override public void onDisable() { XrayEsp.reset(); }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        boolean[] want = new boolean[OreKinds.COUNT];
        for (int i = 0; i < OreKinds.COUNT; i++) want[i] = ore[i].getValue();
        XrayEsp.scanStep(mc, mc.player, radius.getValue(), budget.getValue(), maxMarks.getValue(), want);
    }
}
