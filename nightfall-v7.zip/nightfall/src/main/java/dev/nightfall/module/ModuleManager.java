package dev.nightfall.module;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return modules;
    }

    public List<Module> getByCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) out.add(m);
        }
        return out;
    }

    public Optional<Module> getByName(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) return Optional.of(m);
        }
        return Optional.empty();
    }

    public void onKey(int keyCode) {
        for (Module m : modules) {
            if (m.getKeyBind() == keyCode) m.toggle();
        }
    }
}