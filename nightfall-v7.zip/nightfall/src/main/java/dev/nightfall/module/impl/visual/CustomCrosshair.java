package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;

public class CustomCrosshair extends Module {
    private final Setting.BooleanSetting dot = new Setting.BooleanSetting("Dot", true);
    private final Setting.IntSetting gap = new Setting.IntSetting("Gap", 4, 0, 10);
    private final Setting.IntSetting length = new Setting.IntSetting("Length", 6, 2, 15);
    private final Setting.IntSetting thickness = new Setting.IntSetting("Thickness", 1, 1, 4);

    public CustomCrosshair() {
        super("CustomCrosshair", "Replaces vanilla crosshair.", Category.VISUALS);
        settings.add(dot);
        settings.add(gap);
        settings.add(length);
        settings.add(thickness);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public void render(GuiGraphics g) {
        Minecraft client = Minecraft.getInstance();
        int cx = client.getWindow().getGuiScaledWidth() / 2;
        int cy = client.getWindow().getGuiScaledHeight() / 2;
        int color = 0xFFFFFFFF;
        int t = thickness.getValue();

        // Центральная точка
        if (dot.getValue()) {
            g.fill(cx - t / 2, cy - t / 2, cx + t / 2 + 1, cy + t / 2 + 1, color);
        }

        int g_ = gap.getValue();
        int l = length.getValue();

        // Верхняя линия
        g.fill(cx - t / 2, cy - g_ - l, cx + t / 2 + 1, cy - g_, color);
        // Нижняя линия
        g.fill(cx - t / 2, cy + g_, cx + t / 2 + 1, cy + g_ + l, color);
        // Левая линия
        g.fill(cx - g_ - l, cy - t / 2, cx - g_, cy + t / 2 + 1, color);
        // Правая линия
        g.fill(cx + g_, cy - t / 2, cx + g_ + l, cy + t / 2 + 1, color);
    }
}