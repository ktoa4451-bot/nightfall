package dev.nightfall.module.impl.movement;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.phys.Vec3;

/** Climb walls while you hold forward against them. */
public class Spider extends Module implements Tickable {
    private final Setting.DoubleSetting speed = new Setting.DoubleSetting("ClimbSpeed", 0.2, 0.05, 0.5);

    public Spider() {
        super("Spider", "Climb walls.", Category.MOVEMENT);
        settings.add(speed);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null || p.isFallFlying() || p.isInWater()) return;
        if (!p.horizontalCollision || !mc.options.keyUp.isDown()) return;
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(v.x, speed.getValue(), v.z);
    }
}
