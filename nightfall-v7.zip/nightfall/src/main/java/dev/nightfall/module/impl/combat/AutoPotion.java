package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionContents;
import net.minecraft.world.item.alchemy.Potions;
import net.minecraft.world.item.ItemStack;

/** Throws a splash healing potion at your feet when health is low (hotbar only). The previous slot and your pitch are restored on the next tick. */
public class AutoPotion extends Module implements Tickable {
    private final Setting.DoubleSetting healBelow = new Setting.DoubleSetting("HealBelow", 8.0, 2.0, 19.0);
    private final Setting.IntSetting cooldown = new Setting.IntSetting("CooldownTicks", 40, 10, 200);
    private int since = 999, restoreSlot = -1;
    private float restorePitch = Float.NaN;

    public AutoPotion() {
        super("AutoPotion", "Throws a healing potion when you are low.", Category.COMBAT);
        settings.add(healBelow); settings.add(cooldown);
    }

    @Override public void onEnable() { since = 999; restoreSlot = -1; restorePitch = Float.NaN; }
    @Override public void onDisable() { }

    private static boolean isHealing(ItemStack s) {
        if (!s.is(Items.SPLASH_POTION)) return false;
        PotionContents pc = s.get(DataComponents.POTION_CONTENTS);
        if (pc == null || pc.potion().isEmpty()) return false;
        var pot = pc.potion().get().value();
        return pot == Potions.HEALING.value() || pot == Potions.STRONG_HEALING.value();
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) return;
        if (restoreSlot >= 0) { p.getInventory().setSelectedSlot(restoreSlot); restoreSlot = -1; }
        if (!Float.isNaN(restorePitch)) { p.setXRot(restorePitch); restorePitch = Float.NaN; }
        since++;
        if (mc.screen != null || !p.isAlive() || since < cooldown.getValue()) return;
        if (p.getHealth() > healBelow.getValue()) return;
        for (int i = 0; i < 9; i++) {
            if (!isHealing(p.getInventory().getItem(i))) continue;
            restoreSlot = p.getInventory().getSelectedSlot();
            restorePitch = p.getXRot();
            p.getInventory().setSelectedSlot(i);
            p.setXRot(90f);                                   // look at your feet so the splash lands on you
            mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
            since = 0;
            return;
        }
    }
}
