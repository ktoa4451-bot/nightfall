package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;

/** Custom sky, fog and cloud colours, fog distance and an optional rainbow. Applied by the optional mixins (see SkyFog). */
public class CustomSky extends Module {
    public final Setting.BooleanSetting sky = new Setting.BooleanSetting("CustomSky", false);
    public final Setting.IntSetting skyR = new Setting.IntSetting("SkyR", 120, 0, 255), skyG = new Setting.IntSetting("SkyG", 60, 0, 255), skyB = new Setting.IntSetting("SkyB", 200, 0, 255);
    public final Setting.BooleanSetting fog = new Setting.BooleanSetting("CustomFog", false);
    public final Setting.IntSetting fogR = new Setting.IntSetting("FogR", 90, 0, 255), fogG = new Setting.IntSetting("FogG", 60, 0, 255), fogB = new Setting.IntSetting("FogB", 160, 0, 255);
    public final Setting.BooleanSetting fogDist = new Setting.BooleanSetting("CustomFogDistance", false);
    public final Setting.IntSetting fogStart = new Setting.IntSetting("FogStart", 16, 0, 512), fogEnd = new Setting.IntSetting("FogEnd", 96, 8, 1024);
    public final Setting.BooleanSetting clouds = new Setting.BooleanSetting("CustomClouds", false);
    public final Setting.IntSetting cloudR = new Setting.IntSetting("CloudR", 255, 0, 255), cloudG = new Setting.IntSetting("CloudG", 200, 0, 255), cloudB = new Setting.IntSetting("CloudB", 255, 0, 255);
    public final Setting.BooleanSetting rainbow = new Setting.BooleanSetting("Rainbow", false);
    public final Setting.IntSetting rainbowSeconds = new Setting.IntSetting("RainbowSeconds", 12, 2, 60);

    public CustomSky() {
        super("CustomSky", "Your own sky, fog and clouds.", Category.VISUALS);
        settings.add(sky); settings.add(skyR); settings.add(skyG); settings.add(skyB);
        settings.add(fog); settings.add(fogR); settings.add(fogG); settings.add(fogB);
        settings.add(fogDist); settings.add(fogStart); settings.add(fogEnd);
        settings.add(clouds); settings.add(cloudR); settings.add(cloudG); settings.add(cloudB);
        settings.add(rainbow); settings.add(rainbowSeconds);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }
}
