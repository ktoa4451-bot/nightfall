package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;

public class Keystrokes extends Module {
    public Keystrokes() {
        super("Keystrokes", "Renders WASD / jump / mouse keys.", Category.VISUALS);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}
}