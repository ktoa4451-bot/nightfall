package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Items;

/** Keeps a totem of undying in the off hand: takes one from the inventory when the off hand has none. One swap per delay, inventory menu slot 45 is the off hand. */
public class AutoTotem extends Module implements Tickable {
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 4, 1, 20);
    private final Setting.DoubleSetting healthBelow = new Setting.DoubleSetting("HealthBelow", 20.0, 2.0, 20.0);
    private int tick;

    public AutoTotem() {
        super("AutoTotem", "Keeps a totem in your off hand.", Category.COMBAT);
        settings.add(delay); settings.add(healthBelow);
    }

    @Override public void onEnable() { tick = 0; }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
        if (++tick % delay.getValue() != 0) return;
        if (p.getHealth() + p.getAbsorptionAmount() > healthBelow.getValue()) return;
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING) || !p.containerMenu.getCarried().isEmpty()) return;
        int from = -1;
        for (int i = 9; i < 45; i++) if (p.inventoryMenu.getSlot(i).getItem().is(Items.TOTEM_OF_UNDYING)) { from = i; break; }
        if (from < 0) return;
        int id = p.inventoryMenu.containerId;
        mc.gameMode.handleInventoryMouseClick(id, from, 0, ClickType.PICKUP, p);
        mc.gameMode.handleInventoryMouseClick(id, 45, 0, ClickType.PICKUP, p);
        if (!p.containerMenu.getCarried().isEmpty()) mc.gameMode.handleInventoryMouseClick(id, from, 0, ClickType.PICKUP, p);
    }
}
