package dev.nightfall.module.impl.movement;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.phys.Vec3;

/** Keeps you floating on the surface of water (hold sneak to sink). */
public class Jesus extends Module implements Tickable {
    private final Setting.DoubleSetting lift = new Setting.DoubleSetting("Lift", 0.11, 0.02, 0.3);

    public Jesus() {
        super("Jesus", "Float on water.", Category.MOVEMENT);
        settings.add(lift);
    }

    @Override public void onEnable() { }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null || mc.options.keyShift.isDown() || p.isFallFlying()) return;
        if (!p.isInWater() || p.isInLava()) return;
        boolean headOut = !mc.level.getFluidState(p.blockPosition().above()).is(FluidTags.WATER);
        Vec3 v = p.getDeltaMovement();
        p.setDeltaMovement(v.x, headOut ? 0.0 : lift.getValue(), v.z);
    }
}
