package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;

public class ReachDisplay extends Module {
    private final Setting.BooleanSetting chat =
            new Setting.BooleanSetting("Chat", false);

    private Entity lastTarget;
    private double lastDistance;
    private long lastHitTime;

    public ReachDisplay() {
        super("ReachDisplay", "Shows distance to last hit target.", Category.COMBAT);
        settings.add(chat);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public void onAttack(Entity target) {
        if (!isEnabled() || target == null) return;
        Minecraft client = Minecraft.getInstance();
        if (client.player == null) return;

        lastTarget = target;
        lastDistance = client.player.distanceTo(target);
        lastHitTime = System.currentTimeMillis();

        if (chat.getValue()) {
            client.player.displayClientMessage(
                    Component.literal(String.format("Reach: %.2f", lastDistance)),
                    true
            );
        }
    }

    public Entity getLastTarget() { return lastTarget; }
    public double getLastDistance() { return lastDistance; }
    public long getLastHitTime() { return lastHitTime; }

    public boolean hasRecentHit() {
        return lastTarget != null && System.currentTimeMillis() - lastHitTime < 3000;
    }
}