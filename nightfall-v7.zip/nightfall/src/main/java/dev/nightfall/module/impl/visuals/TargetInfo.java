package dev.nightfall.module.impl.visuals;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Text panel about the entity under your crosshair: health, armor points, items in both hands and distance. It stays for MemorySeconds after you look away. */
public class TargetInfo extends Module implements Tickable {
    public final Setting.DoubleSetting memory = new Setting.DoubleSetting("MemorySeconds", 3.0, 1.0, 10.0);
    public static final List<String> LINES = new ArrayList<>();
    private LivingEntity target;
    private long seen;

    public TargetInfo() {
        super("TargetInfo", "Health, armor, hands and distance of your target.", Category.VISUALS);
        settings.add(memory);
    }

    @Override public void onEnable() { target = null; }
    @Override public void onDisable() { synchronized (LINES) { LINES.clear(); } }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null || mc.level == null) return;
        long now = System.currentTimeMillis();
        if (mc.hitResult instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le && le != mc.player && le.isAlive()) { target = le; seen = now; }
        if (target != null && (!target.isAlive() || target.isRemoved() || now - seen > memory.getValue() * 1000)) target = null;
        List<String> out = new ArrayList<>();
        if (target != null) {
            out.add(target.getName().getString() + String.format(Locale.ROOT, "  %.1f/%.1f HP  armor %d  %.1f m",
                target.getHealth(), target.getMaxHealth(), target.getArmorValue(), (double) mc.player.distanceTo(target)));
            String main = target.getMainHandItem().isEmpty() ? "-" : target.getMainHandItem().getHoverName().getString();
            String off = target.getOffhandItem().isEmpty() ? "-" : target.getOffhandItem().getHoverName().getString();
            out.add("Main hand: " + main + "   Off hand: " + off);
        }
        synchronized (LINES) { LINES.clear(); LINES.addAll(out); }
    }
}
