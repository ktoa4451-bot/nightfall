package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.util.MathUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

public class AimAssist extends Module {
    private final Setting.DoubleSetting range =
            new Setting.DoubleSetting("Range", 4.5, 1.0, 8.0);
    private final Setting.DoubleSetting strength =
            new Setting.DoubleSetting("Strength", 0.3, 0.0, 1.0);

    public AimAssist() {
        super("AimAssist", "Assists aim toward nearest target in training mode.", Category.COMBAT);
        settings.add(range);
        settings.add(strength);
    }

    @Override public void onEnable() {}
    @Override public void onDisable() {}

    public void onTick(Minecraft client) {
        if (!isEnabled() || client.player == null || client.level == null) return;

        Entity target = findTarget(client);
        if (target == null) return;

        Vec3 eye = client.player.getEyePosition();
        Vec3 targetPos = target.getBoundingBox().getCenter();
        Vec3 delta = targetPos.subtract(eye);

        double targetYaw = Math.toDegrees(Math.atan2(-delta.x, delta.z));
        double targetPitch = Math.toDegrees(-Math.atan2(delta.y,
                Math.sqrt(delta.x * delta.x + delta.z * delta.z)));

        float s = (float) (strength.getValue() * 0.15);
        float newYaw = client.player.getYRot()
                + MathUtil.wrap((float) targetYaw - client.player.getYRot()) * s;
        float newPitch = client.player.getXRot()
                + MathUtil.wrap((float) targetPitch - client.player.getXRot()) * s;

        client.player.setYRot(newYaw);
        client.player.setXRot(newPitch);
    }

    private Entity findTarget(Minecraft client) {
        Entity closest = null;
        double closestDist = range.getValue();

        for (Entity e : client.level.entitiesForRendering()) {
            if (!(e instanceof LivingEntity)) continue;
            if (e == client.player) continue;

            double d = client.player.distanceTo(e);
            if (d < closestDist) {
                closestDist = d;
                closest = e;
            }
        }
        return closest;
    }
}