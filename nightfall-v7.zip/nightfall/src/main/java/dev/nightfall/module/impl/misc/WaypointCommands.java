package dev.nightfall.module.impl.misc;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.nightfall.util.Waypoints;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.util.stream.Collectors;

/** /nfpoint set <name> | del <name> | list */
public final class WaypointCommands {
    private WaypointCommands() { }

    private static void say(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[Nightfall] " + s), false);
    }

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommandManager.literal("nfpoint")
            .then(ClientCommandManager.literal("set").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                Minecraft mc = Minecraft.getInstance();
                if (mc.player == null || mc.level == null) return 0;
                BlockPos b = mc.player.blockPosition();
                String err = WaypointStore.get().set(StringArgumentType.getString(c, "name"), b.getX(), b.getY(), b.getZ(), mc.level.dimension().toString());
                if (err != null) { say(err); return 0; }
                WaypointStore.save();
                say("point saved: " + StringArgumentType.getString(c, "name").toLowerCase() + " " + b.toShortString());
                return 1;
            })))
            .then(ClientCommandManager.literal("del").then(ClientCommandManager.argument("name", StringArgumentType.word()).executes(c -> {
                boolean ok = WaypointStore.get().remove(StringArgumentType.getString(c, "name"));
                WaypointStore.save();
                say(ok ? "point deleted" : "no such point");
                return ok ? 1 : 0;
            })))
            .then(ClientCommandManager.literal("list").executes(c -> {
                var l = WaypointStore.get().all();
                say(l.isEmpty() ? "no points yet: /nfpoint set <name>"
                    : l.stream().map(p -> p.name() + " " + p.x() + " " + p.y() + " " + p.z()).collect(Collectors.joining(" | ")));
                return 1;
            })));
    }
}
