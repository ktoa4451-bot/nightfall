package dev.nightfall.module.impl.movement;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;

/** Raises your step height attribute so you walk up blocks without jumping. The original value is restored when the module is switched off. */
public class Step extends Module implements Tickable {
    private final Setting.DoubleSetting height = new Setting.DoubleSetting("Height", 1.0, 0.6, 2.5);
    private double original = -1;

    public Step() {
        super("Step", "Walk up blocks without jumping.", Category.MOVEMENT);
        settings.add(height);
    }

    @Override public void onEnable() { original = -1; }

    @Override
    public void onDisable() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || original < 0) return;
        AttributeInstance a = mc.player.getAttribute(Attributes.STEP_HEIGHT);
        if (a != null) a.setBaseValue(original);
        original = -1;
    }

    @Override
    public void onTick(Minecraft mc) {
        if (mc.player == null) return;
        AttributeInstance a = mc.player.getAttribute(Attributes.STEP_HEIGHT);
        if (a == null) return;
        if (original < 0) original = a.getBaseValue();
        a.setBaseValue(height.getValue());
    }
}
