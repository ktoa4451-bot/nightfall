package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.EntityHitResult;

/** When the player under your crosshair is blocking with a shield, selects an axe from the hotbar; puts your slot back when they stop. */
public class ShieldBreaker extends Module implements Tickable {
    private final Setting.BooleanSetting restore = new Setting.BooleanSetting("RestoreSlot", true);
    private int prevSlot = -1;

    public ShieldBreaker() {
        super("ShieldBreaker", "Switches to an axe while the target blocks with a shield.", Category.COMBAT);
        settings.add(restore);
    }

    @Override public void onEnable() { prevSlot = -1; }
    @Override public void onDisable() { back(Minecraft.getInstance()); }

    private void back(Minecraft mc) {
        if (prevSlot >= 0 && mc != null && mc.player != null) mc.player.getInventory().setSelectedSlot(prevSlot);
        prevSlot = -1;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) return;
        boolean blocking = mc.hitResult instanceof EntityHitResult eh && eh.getEntity() instanceof LivingEntity le && le != p && le.isBlocking();
        if (blocking) {
            if (p.getMainHandItem().is(ItemTags.AXES)) return;
            for (int i = 0; i < 9; i++) {
                if (p.getInventory().getItem(i).is(ItemTags.AXES)) {
                    if (prevSlot < 0) prevSlot = p.getInventory().getSelectedSlot();
                    p.getInventory().setSelectedSlot(i);
                    return;
                }
            }
        } else if (restore.getValue() && prevSlot >= 0) back(mc);
    }
}
