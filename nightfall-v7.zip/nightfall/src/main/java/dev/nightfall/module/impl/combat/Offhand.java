package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.OffhandLogic;
import dev.nightfall.util.OffhandLogic.Item;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.inventory.ClickType;

/** Off hand manager: the totem when you are low, otherwise your preferred item (Mode 0 totem, 1 golden apple, 2 crystal, 3 shield). One swap per delay. */
public class Offhand extends Module implements Tickable {
    private final Setting.IntSetting mode = new Setting.IntSetting("Mode", 1, 0, 3);
    private final Setting.DoubleSetting totemBelow = new Setting.DoubleSetting("TotemBelow", 10.0, 2.0, 20.0);
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 4, 1, 20);
    private int tick;

    public Offhand() {
        super("Offhand", "Totem when low, else your preferred off-hand item.", Category.COMBAT);
        settings.add(mode); settings.add(totemBelow); settings.add(delay);
    }

    @Override public void onEnable() { tick = 0; }
    @Override public void onDisable() { }

    private static net.minecraft.world.item.Item toItem(Item i) {
        return switch (i) {
            case TOTEM -> net.minecraft.world.item.Items.TOTEM_OF_UNDYING;
            case GAPPLE -> net.minecraft.world.item.Items.GOLDEN_APPLE;
            case CRYSTAL -> net.minecraft.world.item.Items.END_CRYSTAL;
            case SHIELD -> net.minecraft.world.item.Items.SHIELD;
        };
    }

    private static int find(LocalPlayer p, net.minecraft.world.item.Item it) {
        for (int i = 9; i < 45; i++) if (p.inventoryMenu.getSlot(i).getItem().is(it)) return i;
        return -1;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
        if (++tick % delay.getValue() != 0 || !p.containerMenu.getCarried().isEmpty()) return;
        Item preferred = Item.values()[Math.max(0, Math.min(3, mode.getValue()))];
        boolean hasTotem = p.getOffhandItem().is(toItem(Item.TOTEM)) || find(p, toItem(Item.TOTEM)) >= 0;
        boolean hasPref = p.getOffhandItem().is(toItem(preferred)) || find(p, toItem(preferred)) >= 0;
        Item want = OffhandLogic.pick(p.getHealth() + p.getAbsorptionAmount(), totemBelow.getValue(), preferred, hasTotem, hasPref);
        if (want == null || p.getOffhandItem().is(toItem(want))) return;
        int from = find(p, toItem(want));
        if (from < 0) return;
        int id = p.inventoryMenu.containerId;
        mc.gameMode.handleInventoryMouseClick(id, from, 0, ClickType.PICKUP, p);
        mc.gameMode.handleInventoryMouseClick(id, 45, 0, ClickType.PICKUP, p);
        if (!p.containerMenu.getCarried().isEmpty()) mc.gameMode.handleInventoryMouseClick(id, from, 0, ClickType.PICKUP, p);
    }
}
