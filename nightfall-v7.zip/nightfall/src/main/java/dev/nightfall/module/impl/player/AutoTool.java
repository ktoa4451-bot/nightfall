package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** While you mine a block, selects the hotbar tool that breaks it fastest; puts your slot back when you let go. */
public class AutoTool extends Module implements Tickable {
    private final Setting.BooleanSetting restore = new Setting.BooleanSetting("RestoreSlot", true);
    private int prevSlot = -1;

    public AutoTool() {
        super("AutoTool", "Best tool for the block you mine.", Category.PLAYER);
        settings.add(restore);
    }

    @Override public void onEnable() { prevSlot = -1; }
    @Override public void onDisable() { back(Minecraft.getInstance()); }

    private void back(Minecraft mc) {
        if (prevSlot >= 0 && mc != null && mc.player != null) mc.player.getInventory().setSelectedSlot(prevSlot);
        prevSlot = -1;
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null) return;
        if (!mc.options.keyAttack.isDown() || !(mc.hitResult instanceof BlockHitResult bh)) { if (restore.getValue()) back(mc); return; }
        BlockState st = mc.level.getBlockState(bh.getBlockPos());
        if (st.isAir()) return;
        int cur = p.getInventory().getSelectedSlot(), best = cur;
        float bs = p.getInventory().getItem(cur).getDestroySpeed(st);
        for (int i = 0; i < 9; i++) {
            float s = p.getInventory().getItem(i).getDestroySpeed(st);
            if (s > bs + 0.01f) { bs = s; best = i; }
        }
        if (best != cur) { if (prevSlot < 0) prevSlot = cur; p.getInventory().setSelectedSlot(best); }
    }
}
