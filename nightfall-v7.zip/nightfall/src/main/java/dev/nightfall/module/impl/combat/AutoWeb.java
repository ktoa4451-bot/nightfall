package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/** Puts a cobweb on the nearest player's feet when it is within reach (cobweb in the hotbar, a solid block under them). */
public class AutoWeb extends Module implements Tickable {
    private final Setting.DoubleSetting range = new Setting.DoubleSetting("Range", 4.5, 2.0, 5.0);
    private final Setting.IntSetting cooldown = new Setting.IntSetting("CooldownTicks", 20, 5, 100);
    private int since = 999;

    public AutoWeb() {
        super("AutoWeb", "Cobweb under the nearest enemy.", Category.COMBAT);
        settings.add(range); settings.add(cooldown);
    }

    @Override public void onEnable() { since = 999; }
    @Override public void onDisable() { }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive()) return;
        if (++since < cooldown.getValue()) return;
        Player target = null; double bd = range.getValue();
        for (Player o : mc.level.players()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            double d = p.distanceTo(o);
            if (d < bd) { bd = d; target = o; }
        }
        if (target == null) return;
        BlockPos cell = target.blockPosition(), below = cell.below();
        if (!mc.level.getBlockState(cell).isAir() || mc.level.getBlockState(below).getCollisionShape(mc.level, below).isEmpty()) return;
        if (p.getEyePosition().distanceTo(Vec3.atCenterOf(below)) > 4.5) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(Items.COBWEB)) { slot = i; break; }
        if (slot < 0) return;
        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(Vec3.atCenterOf(below).add(0, 0.5, 0), Direction.UP, below, false));
        p.swing(InteractionHand.MAIN_HAND);
        p.getInventory().setSelectedSlot(prev);
        since = 0;
    }
}
