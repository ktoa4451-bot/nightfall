package dev.nightfall.module.impl.combat;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import dev.nightfall.util.SurroundLogic;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/** Keeps obsidian on the four sides of your feet (needs obsidian in the hotbar). */
public class Surround extends Module implements Tickable {
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 2, 1, 10);
    private final Setting.IntSetting perStep = new Setting.IntSetting("BlocksPerStep", 2, 1, 4);
    private final Setting.BooleanSetting standStill = new Setting.BooleanSetting("OnlyStandingStill", true);
    private int tick;

    public Surround() {
        super("Surround", "Obsidian on the four sides of your feet.", Category.COMBAT);
        settings.add(delay); settings.add(perStep); settings.add(standStill);
    }

    @Override public void onEnable() { tick = 0; }
    @Override public void onDisable() { }

    private static boolean solid(Minecraft mc, int[] c) {
        BlockPos b = new BlockPos(c[0], c[1], c[2]);
        return !mc.level.getBlockState(b).getCollisionShape(mc.level, b).isEmpty();
    }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive() || !p.onGround()) return;
        if (++tick % delay.getValue() != 0) return;
        if (standStill.getValue() && p.getDeltaMovement().horizontalDistanceSqr() > 0.0004) return;
        BlockPos feet = p.blockPosition();
        var todo = SurroundLogic.plan(feet.getX(), feet.getY(), feet.getZ(), c -> solid(mc, c), perStep.getValue());
        if (todo.isEmpty()) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) if (p.getInventory().getItem(i).is(Items.OBSIDIAN)) { slot = i; break; }
        if (slot < 0) return;
        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        for (int[] c : todo) {
            AABB box = new AABB(c[0], c[1], c[2], c[0] + 1, c[1] + 1, c[2] + 1);
            if (!mc.level.getEntitiesOfClass(Entity.class, box, e -> e != p && e.isAlive()).isEmpty()) continue;
            mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND,
                new BlockHitResult(new Vec3(c[0] + 0.5, c[1], c[2] + 0.5), Direction.UP, new BlockPos(c[0], c[1] - 1, c[2]), false));
            p.swing(InteractionHand.MAIN_HAND);
        }
        p.getInventory().setSelectedSlot(prev);
    }
}
