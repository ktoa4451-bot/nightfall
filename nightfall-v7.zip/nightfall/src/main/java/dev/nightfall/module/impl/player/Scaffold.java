package dev.nightfall.module.impl.player;

import dev.nightfall.module.Category;
import dev.nightfall.module.Module;
import dev.nightfall.module.Setting;
import dev.nightfall.module.Tickable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/** Places a block under your feet when there is air there, against a neighbouring block. Uses the first block stack in the hotbar and restores the slot. */
public class Scaffold extends Module implements Tickable {
    private final Setting.IntSetting delay = new Setting.IntSetting("Delay", 2, 1, 10);
    private int tick;

    public Scaffold() {
        super("Scaffold", "Builds a bridge under your feet.", Category.PLAYER);
        settings.add(delay);
    }

    @Override public void onEnable() { tick = 0; }
    @Override public void onDisable() { }

    private static boolean solid(Minecraft mc, BlockPos b) { return !mc.level.getBlockState(b).getCollisionShape(mc.level, b).isEmpty(); }

    @Override
    public void onTick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null || mc.screen != null || !p.isAlive() || p.isFallFlying()) return;
        if (++tick % delay.getValue() != 0) return;
        BlockPos target = BlockPos.containing(p.getX(), p.getY() - 0.5, p.getZ());   // the block under the feet
        if (!mc.level.getBlockState(target).isAir() && mc.level.getBlockState(target).getFluidState().isEmpty()) return;
        // find a solid neighbour to click: below first, then the four sides
        Direction click = null; BlockPos against = null;
        for (Direction d : new Direction[]{Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            BlockPos nb = target.relative(d);
            if (solid(mc, nb)) { click = d.getOpposite(); against = nb; break; }
        }
        if (against == null) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) { ItemStack s = p.getInventory().getItem(i); if (!s.isEmpty() && s.getItem() instanceof BlockItem) { slot = i; break; } }
        if (slot < 0) return;
        int prev = p.getInventory().getSelectedSlot();
        p.getInventory().setSelectedSlot(slot);
        Vec3 hit = Vec3.atCenterOf(against).add(click.getStepX() * 0.5, click.getStepY() * 0.5, click.getStepZ() * 0.5);
        mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, new BlockHitResult(hit, click, against, false));
        p.swing(InteractionHand.MAIN_HAND);
        p.getInventory().setSelectedSlot(prev);
    }
}
