package dev.nightfall.module.impl.combat;

public final class ElytraOrbit {
    private ElytraOrbit() { }

    public enum State { ORBIT, STRIKE }

    public static final int STRIKE_MAX_TICKS = 25;

    public static double[] desired(double sx, double sy, double sz, double tx, double ty, double tz,
                                   double radius, double heightOffset, boolean clockwise, State st) {
        if (st == State.STRIKE) return norm(tx - sx, (ty + 0.9) - sy, tz - sz);
        double rx = sx - tx, rz = sz - tz, d = Math.hypot(rx, rz);
        double ux, uz;
        if (d < 1e-6) { ux = 1; uz = 0; } else { ux = rx / d; uz = rz / d; }
        double txv = clockwise ? uz : -uz, tzv = clockwise ? -ux : ux;
        double pull = Math.max(-1.0, Math.min(1.0, (radius - d) / Math.max(1.0, radius))) * 1.5;
        double hx = txv + pull * ux, hz = tzv + pull * uz;
        double hl = Math.hypot(hx, hz);
        if (hl < 1e-6) { hx = txv; hz = tzv; hl = 1; }
        double vy = Math.max(-0.5, Math.min(0.5, ((ty + heightOffset) - sy) / 8.0));
        return norm(hx / hl, vy, hz / hl);
    }

    public static double yawDeg(double[] v) { return Math.toDegrees(Math.atan2(v[2], v[0])) - 90.0; }
    public static double pitchDeg(double[] v) { return -Math.toDegrees(Math.asin(Math.max(-1.0, Math.min(1.0, v[1])))); }

    private static double[] norm(double x, double y, double z) {
        double l = Math.sqrt(x * x + y * y + z * z);
        return l < 1e-9 ? new double[]{0, 0, 1} : new double[]{x / l, y / l, z / l};
    }

    public static State next(State s, int ticksInState, double dist, boolean attackReady, boolean justHit, int strikeAfter, double maxStrikeDist) {
        if (s == State.ORBIT) return ticksInState >= strikeAfter && attackReady && dist <= maxStrikeDist ? State.STRIKE : State.ORBIT;
        return justHit || ticksInState >= STRIKE_MAX_TICKS || dist < 0.8 ? State.ORBIT : State.STRIKE;
    }

    public static boolean needRocket(double speedBlocksPerTick, double minSpeed, int ticksSinceLast, int minGap, int used, int maxRockets) {
        return speedBlocksPerTick < minSpeed && ticksSinceLast >= minGap && used < maxRockets;
    }
}