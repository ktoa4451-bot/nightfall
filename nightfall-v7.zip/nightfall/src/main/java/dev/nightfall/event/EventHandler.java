package dev.nightfall.event;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.Module;
import dev.nightfall.module.Tickable;
import dev.nightfall.module.impl.combat.Combat;
import dev.nightfall.module.impl.movement.Sprint;
import dev.nightfall.module.impl.player.AutoArmor;
import dev.nightfall.module.impl.player.AutoGapple;
import dev.nightfall.module.impl.visuals.CpsCounter;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

public class EventHandler {
    private boolean lastAttackDown = false;
    private boolean lastUseDown = false;
    private final Map<Module, Boolean> keyWasDown = new HashMap<>();

    public void onTick(Minecraft client) {
        if (client.player == null) return;

        // CPS Counter
        boolean attackDown = client.options.keyAttack.isDown();
        boolean useDown = client.options.keyUse.isDown();
        if (attackDown && !lastAttackDown) triggerCps(true);
        if (useDown && !lastUseDown) triggerCps(false);
        lastAttackDown = attackDown;
        lastUseDown = useDown;

        // module keybinds: a press toggles the module (not while a screen is open, so typing and the menu keep working)
        long win = GLFW.glfwGetCurrentContext();
        for (Module m : NightfallClient.getInstance().moduleManager.getModules()) {
            int key = m.getKeyBind();
            boolean down = win != 0 && key >= 0 && client.screen == null && GLFW.glfwGetKey(win, key) == GLFW.GLFW_PRESS;
            boolean was = keyWasDown.getOrDefault(m, false);
            if (down && !was) m.toggle();
            keyWasDown.put(m, down);
        }

        // Модули на тике
        for (Module m : NightfallClient.getInstance().moduleManager.getModules()) {
            if (!m.isEnabled()) continue;

            if (m instanceof Sprint sp) sp.onTick(client);
            if (m instanceof AutoGapple ag) ag.onTick(client);
            if (m instanceof AutoArmor aa) aa.onTick(client);
            if (m instanceof Tickable t) {
                try { t.onTick(client); }
                catch (RuntimeException e) { dev.nightfall.NightfallClient.LOGGER.warn("Module {} failed: {}", m.getName(), e.toString()); }
            }
        }

        // Combat (KillAura / AutoCrystal / ElytraTarget)
        Combat.tick(client, client.player);
    }

    private void triggerCps(boolean left) {
        var mod = NightfallClient.getInstance().moduleManager.getByName("CpsCounter").orElse(null);
        if (mod instanceof CpsCounter cps && cps.isEnabled()) cps.onClick(left);
    }
}