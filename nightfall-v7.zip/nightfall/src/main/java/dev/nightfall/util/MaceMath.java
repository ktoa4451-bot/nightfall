package dev.nightfall.util;

/** Mace smash damage by fall distance (vanilla: +4 per block for the first 3, +2 for the next 5, +1 after that, on top of the base hit). */
public final class MaceMath {
    private MaceMath() { }

    public static double bonusDamage(double fall) {
        if (fall <= 1.5) return 0.0;               // the mace needs a fall of more than 1.5 blocks to smash
        double f = fall;
        double a = Math.min(f, 3.0) * 4.0;
        double b = Math.min(Math.max(f - 3.0, 0.0), 5.0) * 2.0;
        double c = Math.max(f - 8.0, 0.0);
        return a + b + c;
    }

    public static boolean worthSmash(double fall, double minBonus) { return bonusDamage(fall) >= minBonus; }
}
