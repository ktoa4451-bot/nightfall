package dev.nightfall.util;

import java.util.ArrayList;
import java.util.List;

/** Short rolling log of combat events for the CombatLog overlay: newest last, old entries expire. */
public final class DamageLog {
    public record Entry(long time, String text) { }

    private final List<Entry> entries = new ArrayList<>();
    private final int max;
    private final long lifeMs;

    public DamageLog(int max, long lifeMs) { this.max = Math.max(1, max); this.lifeMs = Math.max(1, lifeMs); }

    public void add(long now, String text) {
        entries.add(new Entry(now, text));
        while (entries.size() > max) entries.remove(0);
    }

    /** Entries still alive at {@code now}, newest last. */
    public List<Entry> alive(long now) {
        entries.removeIf(e -> now - e.time() > lifeMs);
        return List.copyOf(entries);
    }

    /** Opacity 0..1 of an entry: full for the first 60% of its life, then fading. */
    public float alpha(Entry e, long now) {
        double t = (double) (now - e.time()) / lifeMs;
        return (float) (t <= 0.6 ? 1.0 : Math.max(0.0, 1.0 - (t - 0.6) / 0.4));
    }

    /** Health change helper: returns a text like "-4.5 HP" or "+3.0 HP", or null when the change is too small to log. */
    public static String change(double before, double after, double minDelta) {
        double d = after - before;
        if (Math.abs(d) < minDelta) return null;
        return String.format(java.util.Locale.ROOT, "%+.1f HP", d);
    }
}
