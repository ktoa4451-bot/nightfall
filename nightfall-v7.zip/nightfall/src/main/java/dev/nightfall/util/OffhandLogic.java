package dev.nightfall.util;

/** Pure decision for the Offhand manager: what should be in the off hand right now. */
public final class OffhandLogic {
    private OffhandLogic() { }

    public enum Item { TOTEM, GAPPLE, CRYSTAL, SHIELD }

    /**
     * @param hp         health + absorption
     * @param totemBelow at or below this health the totem always wins (if one exists)
     * @param preferred  what you want in the off hand when you are healthy
     * @return the item to hold, or null when nothing in the inventory fits
     */
    public static Item pick(double hp, double totemBelow, Item preferred, boolean hasTotem, boolean hasPreferred) {
        if (hasTotem && (hp <= totemBelow || preferred == Item.TOTEM)) return Item.TOTEM;
        if (hasPreferred) return preferred;
        return hasTotem ? Item.TOTEM : null;
    }
}
