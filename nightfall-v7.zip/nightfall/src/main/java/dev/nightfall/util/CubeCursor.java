package dev.nightfall.util;

/**
 * Resumable walk over the cube of offsets [-r, r]^3, one cell per call, so a big scan can be spread over many ticks.
 * {@link #next} returns null once when a full cycle has just finished (then it starts again).
 */
public final class CubeCursor {
    private final int r;
    private int x, y, z;
    private boolean done;

    public CubeCursor(int r) { this.r = Math.max(1, r); reset(); }

    public void reset() { x = -r; y = -r; z = -r; done = false; }
    public int radius() { return r; }
    public long cells() { long s = 2L * r + 1; return s * s * s; }

    public int[] next() {
        if (done) { reset(); return null; }
        int[] out = {x, y, z};
        if (++z > r) { z = -r; if (++y > r) { y = -r; if (++x > r) done = true; } }
        return out;
    }
}
