package dev.nightfall.util;

/** Pure movement maths for Speed. Minecraft yaw: 0 = south (+z), 90 = west (-x). */
public final class MoveMath {
    private MoveMath() { }

    /**
     * @param forward  +1 forward, -1 back, 0 none
     * @param left     +1 left, -1 right, 0 none
     * @return {vx, vz} with length {@code speed} (diagonal input is normalised), or {0,0} without input
     */
    public static double[] horizontal(double forward, double left, double yawDeg, double speed) {
        double len = Math.sqrt(forward * forward + left * left);
        if (len < 1e-9) return new double[]{0, 0};
        double f = forward / len, s = left / len;
        double yaw = Math.toRadians(yawDeg), sin = Math.sin(yaw), cos = Math.cos(yaw);
        return new double[]{(-f * sin + s * cos) * speed, (f * cos + s * sin) * speed};
    }
}
