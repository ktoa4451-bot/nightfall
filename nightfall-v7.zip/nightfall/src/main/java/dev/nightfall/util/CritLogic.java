package dev.nightfall.util;

/** Pure rules for HitSelect: is a hit a vanilla critical hit right now, and should we swing? No Minecraft types. */
public final class CritLogic {
    private CritLogic() { }

    /** Vanilla critical hit conditions: falling, not on the ground, not climbing, not in water, not blind, not riding. */
    public static boolean isCrit(double fallDistance, boolean onGround, boolean climbing, boolean inWater, boolean blind, boolean riding, double yVelocity) {
        return fallDistance > 0.0 && !onGround && !climbing && !inWater && !blind && !riding && yVelocity < 0.0;
    }

    /**
     * @param cooldownReady attack strength is full
     * @param crit          the hit would be a critical hit
     * @param waitedMs      how long we have been ready and waiting for a crit
     * @param maxWaitMs     after this we hit anyway so the module never stalls a fight (0 = never force)
     */
    public static boolean shouldHit(boolean cooldownReady, boolean crit, long waitedMs, long maxWaitMs) {
        if (!cooldownReady) return false;
        if (crit) return true;
        return maxWaitMs > 0 && waitedMs >= maxWaitMs;
    }
}
