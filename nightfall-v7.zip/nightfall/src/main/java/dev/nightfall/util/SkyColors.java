package dev.nightfall.util;

/** Pure colour helpers for CustomSky (no Minecraft types). */
public final class SkyColors {
    private SkyColors() { }

    public static int argb(int r, int g, int b) {
        return 0xFF000000 | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b);
    }

    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    /** Smooth rainbow: hue goes round once every {@code periodMs}. Saturation/brightness 0..1. */
    public static int rainbow(long timeMs, long periodMs, float sat, float bri) {
        float h = (float) ((timeMs % Math.max(1L, periodMs)) / (double) Math.max(1L, periodMs));
        return hsb(h, sat, bri);
    }

    public static int hsb(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        float c = v * s, x = c * (1 - Math.abs((h * 6) % 2 - 1)), m = v - c;
        float r, g, b;
        int sector = (int) (h * 6);
        switch (sector) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return argb(Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255));
    }

    /** Fog needs start < end; returns {start, end} fixed up with at least 4 blocks between them. */
    public static float[] fogRange(float start, float end) {
        float s = Math.max(0f, start), e = Math.max(s + 4f, end);
        return new float[]{s, e};
    }
}
