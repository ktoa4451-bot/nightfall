package dev.nightfall.util;

/** Small animation helpers for the menu: frame-rate independent smoothing, easing and colour mixing. No Minecraft types. */
public final class Anim {
    private Anim() { }

    /** Moves {@code cur} toward {@code target}; speed ~ 8..20 feels snappy. Same result for 60 and 144 fps because it uses the time step. */
    public static float approach(float cur, float target, float dtSeconds, float speed) {
        if (dtSeconds <= 0f || speed <= 0f) return cur;
        float k = 1f - (float) Math.exp(-speed * Math.min(dtSeconds, 0.1f));
        float v = cur + (target - cur) * k;
        return Math.abs(target - v) < 0.002f ? target : v;
    }

    public static float easeOutCubic(float t) { float u = 1f - Math.max(0f, Math.min(1f, t)); return 1f - u * u * u; }

    public static float clamp01(float t) { return Math.max(0f, Math.min(1f, t)); }

    /** Linear mix of two ARGB colours, t = 0 gives a, t = 1 gives b. */
    public static int mix(int a, int b, float t) {
        t = clamp01(t);
        int aa = (int) (((a >>> 24) & 255) + ((((b >>> 24) & 255) - ((a >>> 24) & 255)) * t));
        int ar = (int) (((a >> 16) & 255) + ((((b >> 16) & 255) - ((a >> 16) & 255)) * t));
        int ag = (int) (((a >> 8) & 255) + ((((b >> 8) & 255) - ((a >> 8) & 255)) * t));
        int ab = (int) ((a & 255) + (((b & 255) - (a & 255)) * t));
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    /** The colour with its alpha multiplied by f (0..1). */
    public static int fade(int argb, float f) {
        int a = (int) (((argb >>> 24) & 255) * clamp01(f));
        return (a << 24) | (argb & 0xFFFFFF);
    }
}
