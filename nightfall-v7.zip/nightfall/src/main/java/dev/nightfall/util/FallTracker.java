package dev.nightfall.util;

/** Tracks how far the player has fallen since leaving the ground (pure; avoids relying on a game field whose name changes between versions). */
public final class FallTracker {
    private double startY = Double.NaN, fall;

    /** Call once per tick. Climbing, swimming and riding reset the fall like in the game. Returns the current fall distance in blocks. */
    public double update(boolean onGround, boolean resets, double y) {
        if (onGround || resets) { startY = y; fall = 0; return 0; }
        if (Double.isNaN(startY)) startY = y;
        if (y > startY) startY = y;            // going up: the fall starts from the highest point
        fall = Math.max(0, startY - y);
        return fall;
    }

    public double fall() { return fall; }
    public void reset() { startY = Double.NaN; fall = 0; }
}
