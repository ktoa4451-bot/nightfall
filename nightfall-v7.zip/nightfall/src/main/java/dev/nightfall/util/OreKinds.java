package dev.nightfall.util;

import java.util.Locale;

/** Pure ore classification for XRay: block registry path -> ore kind. Deepslate variants count as their normal ore. */
public final class OreKinds {
    private OreKinds() { }

    public static final int COAL = 0, IRON = 1, COPPER = 2, GOLD = 3, REDSTONE = 4, LAPIS = 5, DIAMOND = 6, EMERALD = 7, QUARTZ = 8, DEBRIS = 9;
    public static final int COUNT = 10;
    public static final String[] NAMES = {"Coal", "Iron", "Copper", "Gold", "Redstone", "Lapis", "Diamond", "Emerald", "Quartz", "AncientDebris"};
    public static final int[] COLORS = {0x555555, 0xD8AF93, 0xE07B4F, 0xFFD84A, 0xFF3B3B, 0x3B6BFF, 0x4AEDD9, 0x2EE86A, 0xF2EAD8, 0xA35B3C};

    /** @return the ore kind or -1 when the block is not an ore we show */
    public static int classify(String path) {
        if (path == null) return -1;
        String p = path.toLowerCase(Locale.ROOT);
        if (p.startsWith("deepslate_")) p = p.substring(10);
        else if (p.startsWith("nether_")) p = p.substring(7);
        return switch (p) {
            case "coal_ore" -> COAL;
            case "iron_ore" -> IRON;
            case "copper_ore" -> COPPER;
            case "gold_ore" -> GOLD;
            case "redstone_ore" -> REDSTONE;
            case "lapis_ore" -> LAPIS;
            case "diamond_ore" -> DIAMOND;
            case "emerald_ore" -> EMERALD;
            case "quartz_ore" -> QUARTZ;
            case "ancient_debris" -> DEBRIS;
            default -> -1;
        };
    }
}
