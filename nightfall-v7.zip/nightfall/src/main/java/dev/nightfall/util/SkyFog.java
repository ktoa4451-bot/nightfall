package dev.nightfall.util;

import dev.nightfall.NightfallClient;
import dev.nightfall.module.impl.visuals.CustomSky;
import net.minecraft.world.attribute.EnvironmentAttribute;
import net.minecraft.world.attribute.EnvironmentAttributes;

/**
 * Custom sky, fog and cloud values for Minecraft 1.21.11 (environment attributes). Called by the optional mixins in
 * nightfall.sky.mixins.json; a returned value replaces the game's value, null keeps it. If the mixin targets do not exist in
 * your exact game version they do nothing.
 */
public final class SkyFog {
    private SkyFog() { }

    public static Object override(EnvironmentAttribute<?> a) {
        if (a == null) return null;
        var opt = NightfallClient.getInstance().moduleManager.getByName("CustomSky");
        if (opt.isEmpty() || !opt.get().isEnabled()) return null;
        CustomSky m = (CustomSky) opt.get();
        boolean rb = m.rainbow.getValue();
        int rainbow = SkyColors.rainbow(System.currentTimeMillis(), m.rainbowSeconds.getValue() * 1000L, 0.55f, 1f);
        if (a == EnvironmentAttributes.SKY_COLOR && m.sky.getValue()) return rb ? rainbow : SkyColors.argb(m.skyR.getValue(), m.skyG.getValue(), m.skyB.getValue());
        if (a == EnvironmentAttributes.FOG_COLOR && m.fog.getValue()) return rb ? rainbow : SkyColors.argb(m.fogR.getValue(), m.fogG.getValue(), m.fogB.getValue());
        if (a == EnvironmentAttributes.CLOUD_COLOR && m.clouds.getValue()) return SkyColors.argb(m.cloudR.getValue(), m.cloudG.getValue(), m.cloudB.getValue());
        if (m.fogDist.getValue()) {
            float[] r = SkyColors.fogRange(m.fogStart.getValue(), m.fogEnd.getValue());
            if (a == EnvironmentAttributes.FOG_START_DISTANCE) return r[0];
            if (a == EnvironmentAttributes.FOG_END_DISTANCE) return r[1];
        }
        return null;
    }
}
