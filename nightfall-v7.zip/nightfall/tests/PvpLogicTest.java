import dev.nightfall.util.*;
import dev.nightfall.util.OffhandLogic.Item;

public class PvpLogicTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-9; }

    public static void main(String[] a) {
        // CritLogic
        check("crit: falling in the air", CritLogic.isCrit(0.8, false, false, false, false, false, -0.3));
        check("no crit: on the ground / climbing / water / blind / riding / rising", !CritLogic.isCrit(0.8, true, false, false, false, false, -0.3) && !CritLogic.isCrit(0.8, false, true, false, false, false, -0.3)
            && !CritLogic.isCrit(0.8, false, false, true, false, false, -0.3) && !CritLogic.isCrit(0.8, false, false, false, true, false, -0.3) && !CritLogic.isCrit(0.8, false, false, false, false, true, -0.3) && !CritLogic.isCrit(0.8, false, false, false, false, false, 0.2));
        check("no crit without fall distance", !CritLogic.isCrit(0.0, false, false, false, false, false, -0.3));
        check("hit: cooldown not ready -> never", !CritLogic.shouldHit(false, true, 9999, 400));
        check("hit: ready + crit -> now", CritLogic.shouldHit(true, true, 0, 400));
        check("hit: ready, no crit, still waiting -> wait", !CritLogic.shouldHit(true, false, 100, 400));
        check("hit: waited long enough -> hit anyway (never stalls a fight)", CritLogic.shouldHit(true, false, 400, 400));
        check("hit: maxWait 0 = only crits", !CritLogic.shouldHit(true, false, 99999, 0));

        // MaceMath (vanilla numbers)
        check("mace: no smash under 1.5 blocks", MaceMath.bonusDamage(1.0) == 0 && MaceMath.bonusDamage(1.5) == 0);
        check("mace: 3 blocks = +12", near(MaceMath.bonusDamage(3.0), 12.0));
        check("mace: 8 blocks = +12 +10 = 22", near(MaceMath.bonusDamage(8.0), 22.0));
        check("mace: 20 blocks = 22 + 12", near(MaceMath.bonusDamage(20.0), 34.0));
        check("mace: monotonic", MaceMath.bonusDamage(5) > MaceMath.bonusDamage(4) && MaceMath.bonusDamage(12) > MaceMath.bonusDamage(9));
        check("mace: worthSmash threshold", MaceMath.worthSmash(3.0, 10) && !MaceMath.worthSmash(2.0, 10));

        // OffhandLogic
        check("offhand: low health -> totem even if you prefer crystals", OffhandLogic.pick(6, 10, Item.CRYSTAL, true, true) == Item.TOTEM);
        check("offhand: healthy -> your preferred item", OffhandLogic.pick(20, 10, Item.CRYSTAL, true, true) == Item.CRYSTAL);
        check("offhand: preferred missing -> totem fallback", OffhandLogic.pick(20, 10, Item.GAPPLE, true, false) == Item.TOTEM);
        check("offhand: no totem, low health -> preferred", OffhandLogic.pick(4, 10, Item.GAPPLE, false, true) == Item.GAPPLE);
        check("offhand: nothing at all -> null", OffhandLogic.pick(4, 10, Item.GAPPLE, false, false) == null);
        check("offhand: preferred totem", OffhandLogic.pick(20, 10, Item.TOTEM, true, true) == Item.TOTEM);

        // DamageLog
        DamageLog log = new DamageLog(3, 4000);
        log.add(0, "a"); log.add(1000, "b"); log.add(2000, "c"); log.add(3000, "d");
        check("log: keeps only the newest max entries", log.alive(3000).size() == 3 && log.alive(3000).get(0).text().equals("b"));
        check("log: old entries expire", log.alive(5500).size() == 2 && log.alive(9000).isEmpty());
        DamageLog l2 = new DamageLog(5, 1000); l2.add(0, "x");
        DamageLog.Entry e = l2.alive(0).get(0);
        check("log: alpha is 1 at first, fading near the end", near(l2.alpha(e, 100), 1.0) && l2.alpha(e, 900) < 0.6 && l2.alpha(e, 1000) == 0.0);
        check("log: health change text", "-4.5 HP".equals(DamageLog.change(20, 15.5, 0.1)) && "+3.0 HP".equals(DamageLog.change(10, 13, 0.1)) && DamageLog.change(10, 10.05, 0.1) == null);

        // FallTracker
        FallTracker ft = new FallTracker();
        check("fall: on the ground is 0", ft.update(true, false, 64) == 0);
        check("fall: grows while falling", near(ft.update(false, false, 63), 1) && near(ft.update(false, false, 60), 4));
        check("fall: a jump up moves the start to the peak", near(ft.update(false, false, 66), 0) && near(ft.update(false, false, 64), 2));
        check("fall: water or climbing resets", ft.update(false, true, 50) == 0 && ft.fall() == 0);
        check("fall: landing resets", near(ft.update(false, false, 47), 3) && ft.update(true, false, 47) == 0);
        FallTracker f2 = new FallTracker();
        check("fall: first airborne tick starts at the current height (no fake fall)", f2.update(false, false, 80) == 0);

        // CrystalMath (copied from the Ghostline project)
        check("crystal: distance 0 normal difficulty = 85", CrystalMath.rawDamage(0, 1, 2) == 85);
        check("crystal: out of radius = 0 and peaceful = 0", CrystalMath.rawDamage(12, 1, 2) == 0 && CrystalMath.rawDamage(3, 1, 0) == 0);
        check("crystal: score rejects a deadly spot", CrystalMath.score(30, 20, 20, 1) == -1000.0 && CrystalMath.score(20, 2, 20, 1) > CrystalMath.score(20, 8, 20, 1));
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
