import dev.nightfall.util.SurroundLogic;
import java.util.*;
import java.util.function.Predicate;

public class SurroundLogicTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    static Predicate<int[]> world(Set<String> solid) { return c -> solid.contains(c[0] + "," + c[1] + "," + c[2]); }
    static Set<String> floor(int y) { Set<String> s = new HashSet<>(); for (int x = -5; x <= 5; x++) for (int z = -5; z <= 5; z++) s.add(x + "," + y + "," + z); return s; }

    public static void main(String[] a) {
        Set<String> s = floor(63);                       // flat floor, player stands at (0,64,0)
        check("open floor: all 4 sides missing", SurroundLogic.missing(0, 64, 0, world(s)).size() == 4);
        check("plan respects the per-step limit", SurroundLogic.plan(0, 64, 0, world(s), 2).size() == 2 && SurroundLogic.plan(0, 64, 0, world(s), 9).size() == 4);
        check("limit below 1 still gives one", SurroundLogic.plan(0, 64, 0, world(s), 0).size() == 1);
        s.add("1,64,0"); s.add("0,64,-1");
        check("existing blocks are not planned again", SurroundLogic.missing(0, 64, 0, world(s)).size() == 2);
        s.add("-1,64,0"); s.add("0,64,1");
        check("complete when all four sides are solid", SurroundLogic.complete(0, 64, 0, world(s)) && SurroundLogic.plan(0, 64, 0, world(s), 4).isEmpty());
        Set<String> edge = floor(63); edge.remove("1,63,0");   // no ground under the east cell: cannot place it from above
        List<int[]> p = SurroundLogic.plan(0, 64, 0, world(edge), 4);
        boolean noEast = true; for (int[] c : p) if (c[0] == 1 && c[2] == 0) noEast = false;
        check("a cell without a block under it is not planned (3 of 4 placeable)", p.size() == 3 && noEast);
        check("canPlace looks at the block under the cell", SurroundLogic.canPlace(new int[]{1, 64, 0}, world(floor(63))) && !SurroundLogic.canPlace(new int[]{1, 64, 0}, world(edge)));
        check("order is stable (east first)", SurroundLogic.plan(0, 64, 0, world(floor(63)), 1).get(0)[0] == 1);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
