import dev.nightfall.util.Anim;

public class AnimTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }

    public static void main(String[] a) {
        check("approach moves toward the target without overshooting", Anim.approach(0f, 1f, 0.016f, 12f) > 0f && Anim.approach(0f, 1f, 0.016f, 12f) < 1f);
        float v = 0f; for (int i = 0; i < 120; i++) v = Anim.approach(v, 1f, 1f / 60f, 12f);
        check("approach reaches the target and snaps to it", v == 1f);
        float down = 1f; for (int i = 0; i < 120; i++) down = Anim.approach(down, 0f, 1f / 60f, 12f);
        check("approach works downward too", down == 0f);
        float s60 = 0f; for (int i = 0; i < 30; i++) s60 = Anim.approach(s60, 1f, 1f / 60f, 10f);
        float s144 = 0f; for (int i = 0; i < 72; i++) s144 = Anim.approach(s144, 1f, 1f / 144f, 10f);
        check("same progress after 0.5 s at 60 and 144 fps (frame-rate independent)", Math.abs(s60 - s144) < 0.01f);
        check("zero time step or zero speed changes nothing", Anim.approach(0.3f, 1f, 0f, 10f) == 0.3f && Anim.approach(0.3f, 1f, 0.016f, 0f) == 0.3f);
        check("a huge time step (lag spike) is capped and does not jump past the target", Anim.approach(0f, 1f, 5f, 8f) <= 1f);
        check("easeOutCubic endpoints, monotonic, clamped", Anim.easeOutCubic(0f) == 0f && Anim.easeOutCubic(1f) == 1f && Anim.easeOutCubic(0.3f) < Anim.easeOutCubic(0.6f) && Anim.easeOutCubic(2f) == 1f && Anim.easeOutCubic(-1f) == 0f);
        check("mix: ends and middle", Anim.mix(0xFF000000, 0xFFFFFFFF, 0f) == 0xFF000000 && Anim.mix(0xFF000000, 0xFFFFFFFF, 1f) == 0xFFFFFFFF && (Anim.mix(0xFF000000, 0xFFFFFFFF, 0.5f) & 0xFF) == 127);
        check("mix: per-channel and alpha, t clamped", Anim.mix(0x00FF0000, 0xFF0000FF, 1f) == 0xFF0000FF && Anim.mix(0xFF102030, 0xFF102030, 0.7f) == 0xFF102030 && Anim.mix(0xFF000000, 0xFFFFFFFF, 9f) == 0xFFFFFFFF);
        check("fade: scales alpha only", Anim.fade(0xFF336699, 0.5f) == 0x7F336699 && Anim.fade(0xFF336699, 0f) == 0x00336699 && Anim.fade(0xFF336699, 2f) == 0xFF336699);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
