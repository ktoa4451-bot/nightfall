import dev.nightfall.util.HoleLogic;
import java.util.function.IntFunction;

public class HoleLogicTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }

    /** Builds a world: air at the feet and head cell, the five wall/floor cells set to the given kinds. */
    static IntFunction<Integer> hole(int floor, int e, int w, int s, int n) {
        return i -> {
            if (i == HoleLogic.idx(0, 0, 0) || i == HoleLogic.idx(0, 1, 0)) return HoleLogic.AIR;
            if (i == HoleLogic.idx(0, -1, 0)) return floor;
            if (i == HoleLogic.idx(1, 0, 0)) return e;
            if (i == HoleLogic.idx(-1, 0, 0)) return w;
            if (i == HoleLogic.idx(0, 0, 1)) return s;
            if (i == HoleLogic.idx(0, 0, -1)) return n;
            return HoleLogic.AIR;
        };
    }

    public static void main(String[] a) {
        int B = HoleLogic.BEDROCK, O = HoleLogic.OBSIDIAN, X = HoleLogic.OTHER, A = HoleLogic.AIR;
        check("all bedrock: BEDROCK_HOLE", HoleLogic.classify(hole(B, B, B, B, B)) == HoleLogic.BEDROCK_HOLE);
        check("bedrock + obsidian mix: MIXED_SAFE", HoleLogic.classify(hole(B, O, B, O, B)) == HoleLogic.MIXED_SAFE);
        check("all obsidian: MIXED_SAFE", HoleLogic.classify(hole(O, O, O, O, O)) == HoleLogic.MIXED_SAFE);
        check("one breakable side: UNSAFE", HoleLogic.classify(hole(B, B, X, B, B)) == HoleLogic.UNSAFE);
        check("breakable floor: UNSAFE", HoleLogic.classify(hole(X, O, O, O, O)) == HoleLogic.UNSAFE);
        check("open side: not a hole", HoleLogic.classify(hole(B, B, B, A, B)) == HoleLogic.NONE);
        check("no floor: not a hole", HoleLogic.classify(hole(A, B, B, B, B)) == HoleLogic.NONE);
        IntFunction<Integer> blockedHead = i -> i == HoleLogic.idx(0, 1, 0) ? X : hole(B, B, B, B, B).apply(i);
        check("head space blocked: not a hole", HoleLogic.classify(blockedHead) == HoleLogic.NONE);
        boolean unique = true; java.util.Set<Integer> seen = new java.util.HashSet<>();
        for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 2; dy++) for (int dz = -1; dz <= 1; dz++) { if (!seen.add(HoleLogic.idx(dx, dy, dz))) unique = false; }
        check("idx() is unique and decodes back (the ESP relies on it)", unique && seen.size() == 36 && HoleLogic.idx(1, 2, 1) == 35 && HoleLogic.idx(-1, -1, -1) == 0);
        int i = HoleLogic.idx(1, 0, -1); check("decode formula used by HoleEsp", i % 3 - 1 == -1 && (i / 3) % 4 - 1 == 0 && i / 12 - 1 == 1);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
