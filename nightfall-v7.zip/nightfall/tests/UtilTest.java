import dev.nightfall.util.MoveMath;
import dev.nightfall.util.SkyColors;
import dev.nightfall.util.Waypoints;

public class UtilTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-9; }

    public static void main(String[] a) {
        // MoveMath: yaw 0 = south (+z), 90 = west (-x), -90 = east (+x)
        double[] f0 = MoveMath.horizontal(1, 0, 0, 0.3);
        check("forward at yaw 0 goes +z", near(f0[0], 0) && near(f0[1], 0.3));
        double[] f90 = MoveMath.horizontal(1, 0, 90, 0.3);
        check("forward at yaw 90 goes -x", near(f90[0], -0.3) && Math.abs(f90[1]) < 1e-9);
        double[] l0 = MoveMath.horizontal(0, 1, 0, 0.3);
        check("left at yaw 0 goes +x", near(l0[0], 0.3) && Math.abs(l0[1]) < 1e-9);
        double[] b0 = MoveMath.horizontal(-1, 0, 0, 0.3);
        check("back at yaw 0 goes -z", near(b0[1], -0.3));
        double[] d = MoveMath.horizontal(1, 1, 37, 0.5);
        check("diagonal input is normalised to the set speed", near(Math.hypot(d[0], d[1]), 0.5));
        double[] n = MoveMath.horizontal(0, 0, 123, 0.5);
        check("no input -> no movement", n[0] == 0 && n[1] == 0);

        // SkyColors
        check("argb clamps", SkyColors.argb(1, 2, 3) == 0xFF010203 && SkyColors.argb(-5, 300, 0) == 0xFF00FF00);
        check("rainbow thirds", SkyColors.rainbow(0, 9000, 1f, 1f) == 0xFFFF0000 && SkyColors.rainbow(3000, 9000, 1f, 1f) == 0xFF00FF00 && SkyColors.rainbow(6000, 9000, 1f, 1f) == 0xFF0000FF);
        float[] fr = SkyColors.fogRange(50, 20);
        check("fog range keeps end >= start + 4", fr[1] >= fr[0] + 4 && SkyColors.fogRange(-5, 10)[0] == 0f);

        // Waypoints
        Waypoints w = new Waypoints();
        check("set + get (case-insensitive)", w.set("Home", 10, 64, -5, "minecraft:overworld") == null && w.get("HOME").x() == 10);
        check("bad names rejected", w.set("bad name", 0, 0, 0, "") != null && w.set("", 0, 0, 0, "") != null);
        w.set("mine", 1, 2, 3, "a;b=c,d");
        Waypoints back = Waypoints.parse(w.format());
        check("format/parse round trip, dimension sanitised", back.all().size() == 2 && back.get("mine").z() == 3 && !back.get("mine").dim().contains(";"));
        check("broken data skipped", Waypoints.parse("x=1,2;ok=1,2,3,d;=5,5,5;q=a,b,c;;").all().size() == 1);
        check("remove", w.remove("home") && !w.remove("home"));
        Waypoints full = new Waypoints(); String last = null; for (int i = 0; i < 40; i++) last = full.set("p" + i, i, 0, 0, "");
        check("limit enforced", full.all().size() == Waypoints.MAX && last != null);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
