import dev.nightfall.util.CubeCursor;
import dev.nightfall.util.OreKinds;
import java.util.HashSet;
import java.util.Set;

public class XrayTest {
    static int pass, fail;
    static void check(String n, boolean ok) { if (ok) pass++; else fail++; System.out.println((ok ? "PASS " : "FAIL ") + n); }

    public static void main(String[] a) {
        check("ores", OreKinds.classify("diamond_ore") == OreKinds.DIAMOND && OreKinds.classify("iron_ore") == OreKinds.IRON && OreKinds.classify("emerald_ore") == OreKinds.EMERALD
            && OreKinds.classify("gold_ore") == OreKinds.GOLD && OreKinds.classify("coal_ore") == OreKinds.COAL && OreKinds.classify("lapis_ore") == OreKinds.LAPIS
            && OreKinds.classify("redstone_ore") == OreKinds.REDSTONE && OreKinds.classify("copper_ore") == OreKinds.COPPER && OreKinds.classify("ancient_debris") == OreKinds.DEBRIS);
        check("deepslate and nether variants map to the base ore", OreKinds.classify("deepslate_diamond_ore") == OreKinds.DIAMOND && OreKinds.classify("nether_gold_ore") == OreKinds.GOLD
            && OreKinds.classify("nether_quartz_ore") == OreKinds.QUARTZ && OreKinds.classify("deepslate_redstone_ore") == OreKinds.REDSTONE);
        check("non-ores are -1 (stone, raw blocks, null, look-alikes)", OreKinds.classify("stone") == -1 && OreKinds.classify("diamond_block") == -1 && OreKinds.classify("raw_iron_block") == -1
            && OreKinds.classify(null) == -1 && OreKinds.classify("iron_ore_slab") == -1 && OreKinds.classify("") == -1);
        check("names and colours cover every kind", OreKinds.NAMES.length == OreKinds.COUNT && OreKinds.COLORS.length == OreKinds.COUNT);

        CubeCursor c = new CubeCursor(2);
        check("cells = 5^3", c.cells() == 125);
        Set<String> seen = new HashSet<>(); int n = 0; int[] o;
        while ((o = c.next()) != null) { seen.add(o[0] + "," + o[1] + "," + o[2]); n++; if (n > 1000) break; }
        check("one full pass visits every cell exactly once (125)", n == 125 && seen.size() == 125);
        boolean inRange = true; for (String s : seen) for (String p : s.split(",")) { int v = Integer.parseInt(p); if (v < -2 || v > 2) inRange = false; }
        check("offsets stay within the radius", inRange);
        int[] first = c.next();
        check("after the end marker it starts again from the corner", first != null && first[0] == -2 && first[1] == -2 && first[2] == -2);
        CubeCursor big = new CubeCursor(20); long total = 0; int steps = 0; boolean wrapped = false;
        for (int t = 0; t < 12 && !wrapped; t++) { for (int k = 0; k < 6000; k++) { if (big.next() == null) { wrapped = true; break; } total++; } steps++; }
        check("radius 20 is 68921 cells: a pass takes 12 ticks at 6000 per tick", big.cells() == 68921 && wrapped && steps == 12 && total == 68921);
        check("radius is clamped to at least 1", new CubeCursor(0).radius() == 1 && new CubeCursor(-5).cells() == 27);
        System.out.println(pass + " passed, " + fail + " failed"); if (fail > 0) System.exit(1);
    }
}
